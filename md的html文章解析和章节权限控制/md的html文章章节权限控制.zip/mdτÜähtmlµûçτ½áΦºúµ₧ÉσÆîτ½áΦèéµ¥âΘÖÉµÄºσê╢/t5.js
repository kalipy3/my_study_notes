const fs = require("fs")

fs.readFile("./readme2.html","utf8",function(err,dataStr){

    let reg = /<div id='write'  class=''>(.*?)<\/div>\n<\/body>/igs
    let ret = reg.exec(dataStr)

    let chapters = []
    let reg1 = /<h([0-9]*)>(.*?)<h([0-9]*)>/igs//文章章节
    let reg3 = /<h([0-9]*)>(.*?)<\/div>\n/igs//由于最后一个章节不符合reg1的格式，所以单独处理，因为一片文章的结束就是用的</div>，因为用</div>去匹配最后一个章节
    let ret2;
    let preIdx;
    while ((ret2 = reg1.exec(ret[0]))) {
        preIdx = reg1.lastIndex
        reg1.lastIndex -= 4//如<h3>...<h3>匹配后，lastIndex指向最后一个`>`号，而第二个<h3>是下一个章节的起始要匹配的位置，所以lastIndex-=4就刚好是紧接着的下一个章节的起始位置
        //console.log("title:h" + ret2[1] + "  html片段：" + ret2[0].substring(0, ret2[0].length - 4))
        //console.log("\r\n")
        chapters.push({level: ret2[1], html: ret2[0].substring(0, ret2[0].length - 4)})
    }

    reg3.lastIndex = preIdx - 4;
    let ret3 = reg3.exec(ret[0])
    //console.log("title:h" + ret3[1] + "  html片段：" + ret3[0].substring(0, ret3[0].length - 6))
    chapters.push({level: ret3[1], html: ret3[0].substring(0, ret3[0].length - 7)})



    let reg2 = /class="md-header-anchor"><\/a><span>(.*?)<\/span>/is
    let ret4
    let result = []
    for (let i = 0; i < chapters.length; i++) {
        ret4 = reg2.exec(chapters[i].html)
        result.push({level: chapters[i].level, title: ret4[1], html: chapters[i].html})
    }

    for (let i = 0; i < chapters.length; i++) {
        console.log(result[i])
    }

})
