const fs = require("fs")

fs.readFile("./readme.html","utf8",function(err,dataStr){

    let reg = /<div id="write" class="">(.*?)<\/div>/igs
    let ret = reg.exec(`fdfas<div id="write" class=""><h1><a name="aaa" class="md-header-anchor"></a><span>aaa</span></h1>
<h1><a name="aaa" class="md-header-anchor"></a><span>aadfsada</span></h1><h2><a name="bbb" class="md-header-anchor"></a><span>bbb</span></h2><h3><a name="ccc" class="md-header-anchor"></a><span>ccc</span></h3><h4><a name="ddd" class="md-header-anchor"></a><span>ddd</span></h4><h5><a name="eee" class="md-header-anchor"></a><span>eee</span></h5><hr><h1><a name="aaa-n9" class="md-header-anchor"></a><span>aaa</span></h1><h2><a name="bbb-n10" class="md-header-anchor"></a><span>bbb</span></h2><h3><a name="ccc-n11" class="md-header-anchor"></a><span>ccc</span></h3><h4><a name="ddd-n12" class="md-header-anchor"></a><span>ddd</span></h4><h5><a name="eee-n13" class="md-header-anchor"></a><span>eee</span></h5><hr><h3><a name="111" class="md-header-anchor"></a><span>111</span></h3><h3><a name="222" class="md-header-anchor"></a><span>222</span></h3><hr><h2><a name="a" class="md-header-anchor"></a><span>a</span></h2><h3><a name="a-a" class="md-header-anchor"></a><span>a-a</span></h3><h3><a name="a-b" class="md-header-anchor"></a><span>a-b</span></h3></div>`)[1]

    let reg1 = /<h(.*?)><\/h(.*?)>/igs
    let arr = []
    let ret2;
    let reg2 = /<span>(.*?)<\/span>/igs
    let ret3;
    while ((ret2 = reg1.exec(ret)) && (ret3 = reg2.exec(ret))) {
        console.log("tagName:p" + ret2[2] + "  title:" + ret3[1])
    }
})
