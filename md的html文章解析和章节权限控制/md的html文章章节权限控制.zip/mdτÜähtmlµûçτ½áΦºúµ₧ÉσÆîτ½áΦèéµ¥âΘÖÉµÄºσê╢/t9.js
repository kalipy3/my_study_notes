const fs = require("fs")

fs.readFile("./readme4.html","utf8",function(err,dataStr){

    let reg = /<div id='write'  class=''>(.*?)<\/div>\n<\/body>/igs
    let ret = reg.exec(dataStr)

    let chapters = []
    let reg1 = /<h([0-9]*)>(.*?)<h([0-9]*)>/igs//文章章节
    let reg3 = /<h([0-9]*)>(.*?)<\/div>\n/igs//由于最后一个章节不符合reg1的格式，所以单独处理，因为一片文章的结束就是用的</div>，因为用</div>去匹配最后一个章节
    let ret2;
    let preIdx;
    while ((ret2 = reg1.exec(ret[0]))) {
        preIdx = reg1.lastIndex
        reg1.lastIndex -= 4//如<h3>...<h3>匹配后，lastIndex指向最后一个`>`号，而第二个<h3>是下一个章节的起始要匹配的位置，所以lastIndex-=4就刚好是紧接着的下一个章节的起始位置
        //console.log("title:h" + ret2[1] + "  html片段：" + ret2[0].substring(0, ret2[0].length - 4))
        //console.log("\r\n")
        chapters.push({level: ret2[1], html: ret2[0].substring(0, ret2[0].length - 4)})
    }

    reg3.lastIndex = preIdx - 4;
    let ret3 = reg3.exec(ret[0])
    //console.log("title:h" + ret3[1] + "  html片段：" + ret3[0].substring(0, ret3[0].length - 6))
    chapters.push({level: ret3[1], html: ret3[0].substring(0, ret3[0].length - 7)})



    let reg2 = /class="md-header-anchor"><\/a><span>(.*?)<\/span>/is
    let ret4
    let result = []
    for (let i = 0; i < chapters.length; i++) {
        ret4 = reg2.exec(chapters[i].html)
        result.push({level: chapters[i].level, title: ret4[1], html: chapters[i].html})
    }

    adapter(result)

})

//{
//    label: '一级 1',
//        url: '/a',
//        permission: 'admin',
//        content: '<li>test</li>',//之后改为id
//        children: [{
//            label: '二级 1-1',
//            url: '/b',
//            children: [{
//                url: '/c',
//                label: '三级 1-1-1'
//            }]
//        }]
//}
//
//{
//  level: '1',
//  title: 'aaa',
//  html: '<h1><a name="aaa" class="md-header-anchor"></a><span>aaa</span></h1>'
//},
//{
//  level: '2',
//  title: 'bbb',
//  html: '<h2><a name="bbb" class="md-header-anchor"></a><span>bbb</span></h2>'
//},
function adapter(data) {
    //console.log(data)
    if (data.length <= 0) return

    let arr = []
    for (let i = 0; i < data.length; i++) {
        let obj = {
            id: i + 1,
            level: data[i].level,
            label: data[i].title,
            content: data[i].html
        }
        arr.push(obj)
    }

    let arr2 = []
    let pid = -1
    var stack = []
    //单调栈：找到每个节点左边第一个比其小的节点(即找到每个节点的父节点)
    for (let i = 0; i < arr.length; i++) {
        while (stack.length != 0 && arr[i].level <= arr[stack[stack.length-1]].level) {
            pid = arr[stack[stack.length-1]].id
            stack.pop()
        }
        if (stack.length == 0) {
            pid = -1
        } else {
            pid = arr[stack[stack.length-1]].id
        }
        stack.push(i)

        let obj = {
            id: arr[i].id,
            pid: pid,
            level: arr[i].level,
            label: arr[i].label,
            content: arr[i].content,
            children: []
        }
        arr2.push(obj)
    }

    for (let i = 0; i < arr2.length; i++) {
        //console.log(arr2[i])
    }


    let map = new Map()
    for (let i = 0; i < arr2.length; i++) {
        map.set(arr2[i].id, arr2[i])
    }

    let arr3 = []
    for (let i = 0; i < arr2.length; i++) {
        let obj = arr2[i]
        let obj2 = map.get(obj.pid)
        if (obj2 == null || obj2 == undefined || obj.pid == -1) {
            arr3.push(obj)
        } else {
            map.get(obj.pid).children.push(obj)
        }
    }

    console.dir(arr3, {depth:null})

}
