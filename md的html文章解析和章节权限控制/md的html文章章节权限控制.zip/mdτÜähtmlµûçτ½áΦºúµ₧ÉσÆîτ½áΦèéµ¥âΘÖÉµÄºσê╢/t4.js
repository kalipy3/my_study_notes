const fs = require("fs")

fs.readFile("./readme.html","utf8",function(err,dataStr){

    let reg = /^<div id="write" class="">(.*?)<\/div>$/igs
    let ret = reg.exec(`<div id="write" class=""><h3><a name="111" class="md-header-anchor"></a><span>111</span></h3><p><span>放大放大放大沙发</span></p><pre spellcheck="false" class="md-fences md-end-block ty-contain-cm modeLoaded" lang=""><div class="CodeMirror cm-s-inner CodeMirror-wrap" lang=""><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 8.16406px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; outline: none;"></textarea></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 0px; margin-bottom: 0px; border-right-width: 0px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-code" role="presentation"><div class="CodeMirror-activeline" style="position: relative;"><div class="CodeMirror-activeline-background CodeMirror-linebackground"></div><div class="CodeMirror-gutter-background CodeMirror-activeline-gutter" style="left: 0px; width: 0px;"></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">public static  void main(void) {</span></pre></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"> &nbsp;  System.out.println("gg");</span></pre><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">}</span></pre></div></div></div></div></div><div style="position: absolute; height: 0px; width: 1px; border-bottom: 0px solid transparent; top: 68px;"></div><div class="CodeMirror-gutters" style="display: none; height: 68px;"></div></div></div></pre><ol start=""><li><span>aaaa</span></li><li><span>bbbb</span></li></ol><h3><a name="222" class="md-header-anchor"></a><span>222</span></h3><hr><h2><a name="a" class="md-header-anchor"></a><span>a</span></h2><p><span>1111111111111</span></p><p><span>gg</span></p><h3><a name="a-a" class="md-header-anchor"></a><span>a-a</span></h3><p><span>22222222222222222</span></p><p><span>ggg</span></p><h3><a name="a-b" class="md-header-anchor"></a><span>a-b</span></h3><p><span>333333333333333</span></p><p><span>gggg</span></p></div>`)

    let chapters = []
    let reg1 = /<h([0-9]*)>(.*?)<h([0-9]*)>/igs//文章章节
    let reg3 = /<h([0-9]*)>(.*?)<\/div>$/igs//由于最后一个章节不符合reg1的格式，所以单独处理，因为一片文章的结束就是用的</div>，因为用</div>去匹配最后一个章节
    let ret2;
    let preIdx;
    while ((ret2 = reg1.exec(ret[0]))) {
        preIdx = reg1.lastIndex
        reg1.lastIndex -= 4//如<h3>...<h3>匹配后，lastIndex指向最后一个`>`号，而第二个<h3>是下一个章节的起始要匹配的位置，所以lastIndex-=4就刚好是紧接着的下一个章节的起始位置
        //console.log("title:h" + ret2[1] + "  html片段：" + ret2[0].substring(0, ret2[0].length - 4))
        //console.log("\r\n")
        chapters.push({level: ret2[1], html: ret2[0].substring(0, ret2[0].length - 4)})
    }

    reg3.lastIndex = preIdx - 4;
    let ret3 = reg3.exec(ret[0])
    //console.log("title:h" + ret3[1] + "  html片段：" + ret3[0].substring(0, ret3[0].length - 6))
    chapters.push({level: ret3[1], html: ret3[0].substring(0, ret3[0].length - 6)})



    let reg2 = /class="md-header-anchor"><\/a><span>(.*?)<\/span>/is
    let ret4
    let result = []
    for (let i = 0; i < chapters.length; i++) {
        ret4 = reg2.exec(chapters[i].html)
        result.push({level: chapters[i].level, title: ret4[1], html: chapters[i].html})
    }

    for (let i = 0; i < chapters.length; i++) {
        console.log(result[i])
    }

})
