package com.ruoyi.hsw.dto;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/11 0011
 */
@Data
public class CameraViewDto implements Serializable {
    /** 主键 */
    private Long id;

    /** 序列号 */
    @Excel(name = "序列号")
    private String sn;

    /** 方位 */
    @Excel(name = "方位")
    private String position;

    /** 生产厂商 */
    @Excel(name = "生产厂商")
    private String manufacturer;

    /** 经度 */
    @Excel(name = "经度")
    private String longitude;

    /** 纬度 */
    @Excel(name = "纬度")
    private String latitude;

    /** 型号 */
    @Excel(name = "型号")
    private String model;

    /** 所属诊断器ip */
    @Excel(name = "所属诊断器ip")
    private String ip;

    /** 安装时间 */
    @Excel(name = "安装时间")
    private Long installTime;

    /** 类型 */
    @Excel(name = "类型")
    private String deviceType;

    /** 端口号 */
    @Excel(name = "端口号")
    private Integer port;

    /** 所属分工 */
    @Excel(name = "所属分工")
    private Long divideWorkId;

    /** 详细地址 */
    @Excel(name = "详细地址")
    private String address;

    /** 建设单位id */
    @Excel(name = "建设单位id")
    private Long cuId;

    /** 项目名称 */
    @Excel(name = "项目名称")
    private String projectTitle;

    /** 区域 */
    @Excel(name = "区域")
    private String divideArea;

    /** 所属项目 */
    @Excel(name = "所属项目")
    private Long pid;

    /** 自身IP */
    @Excel(name = "自身IP")
    private String selfIp;

    /** 省 */
    @Excel(name = "省")
    private Integer province;

    /** 市 */
    @Excel(name = "市")
    private Integer city;

    /** 区 */
    @Excel(name = "区")
    private Integer district;

    /** 逻辑地址 */
    @Excel(name = "逻辑地址")
    private String logicalAddr;

    /** 摄像头数量 */
    @Excel(name = "摄像头数量")
    private Integer cameraCount;

    /** 质保期(年) */
    @Excel(name = "质保期(年)")
    private Integer warranty;

    /** 名称 */
    @Excel(name = "名称")
    private String constructingTeamName;

    /** 名称 */
    @Excel(name = "名称")
    private String maintenanceUnitsName;

    /** 距指挥中心距离(KM) */
    @Excel(name = "距指挥中心距离(KM)")
    private Integer distance;


    private String installTimeStr;

    private Integer isFault = 0;
    private Integer faultLevel = 0;

    private String localCity;
    private Long[] pids; //项目id组，查询用

    // 关键字
    private String keyword;
}
