package com.ruoyi.hsw.commonEnum;

/**
 * 一键导出
 */
public enum ExportEnum {

    ZDQ(0, "诊断器"),
    SXT(1, "摄像头"),
    GQSFQ(2, "光纤收发器"),
    QTSB(3, "其他设备"),
    HDGZ(4, "活动故障信息列表"),
    LSHDGZ(5, "历史故障信息列表"),
    HDGD(6, "活动工单列表"),
    LSHDGD(7, "历史工单列表"),
    ZCTJ(8, "资产统计"),
    YXTJ(9, "运行统计"),
    GZTJ(10, "故障统计"),
    XFTJ(11, "修复统计"),
    GDTJ_WXD(12, "工单统计-维修队"),
    GDTJ_WXYG(13, "工单统计-维修队"),
    NULL(9999, "未知状态");

    private Integer value;
    private String label;

    ExportEnum(Integer value, String label) {
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getLabel() {
        return this.label;
    }

    public static ExportEnum valueOf(int value) {
        switch (value) {
            /**
             * 诊断器
             */
            case 0:
                return ZDQ;
            /**
             * 摄像头
             */
            case 1:
                return SXT;
            /**
             * 光纤收发器
             */
            case 2:
                return GQSFQ;
            /**
             * 其他设备
             */
            case 3:
                return QTSB;
            /**
             * 活动故障信息列表
             */
            case 4:
                return HDGZ;
            /**
             * 历史故障信息列表
             */
            case 5:
                return LSHDGZ;
            /**
             * 活动工单列表
             */
            case 6:
                return HDGD;
            /**
             * 历史工单列表
             */
            case 7:
                return LSHDGD;
            /**
             * 资产统计
             */
            case 8:
                return ZCTJ;
            /**
             * 运行统计
             */
            case 9:
                return YXTJ;
            /**
             * 故障统计
             */
            case 10:
                return GZTJ;
            /**
             * 修复统计
             */
            case 11:
                return XFTJ;
            /**
             * 工单统计-维修队
             */
            case 12:
                return GDTJ_WXD;
            /**
             * 工单统计-维修队
             */
            case 13:
                return GDTJ_WXYG;
            default:
                return NULL;
        }
    }
}
