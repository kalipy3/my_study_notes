package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.exception.CustomException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.domain.HswOtherDevice;
import com.ruoyi.hsw.mapper.HswDiagnosisDeviceMapper;
import com.ruoyi.hsw.mapper.HswOtherDeviceMapper;
import com.ruoyi.hsw.service.IHswOtherDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 其他设备Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Service
@Transactional
public class HswOtherDeviceServiceImpl implements IHswOtherDeviceService {

    private static final Logger log = LoggerFactory.getLogger(HswOtherDevice.class);

    @Autowired
    private HswOtherDeviceMapper hswOtherDeviceMapper;

    @Autowired
    private HswDiagnosisDeviceMapper hswDiagnosisDeviceMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询其他设备
     *
     * @param id 其他设备ID
     * @return 其他设备
     */
    @Override
    public HswOtherDevice selectHswOtherDeviceById(Long id) {
        return hswOtherDeviceMapper.selectHswOtherDeviceById(id);
    }

    /**
     * 查询其他设备列表
     *
     * @param hswOtherDevice 其他设备
     * @return 其他设备
     */
    @Override
    public List<HswOtherDevice> selectHswOtherDeviceList(HswOtherDevice hswOtherDevice) {
        return hswOtherDeviceMapper.selectHswOtherDeviceList(hswOtherDevice);
    }

    /**
     * 新增其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    @Override
    public int insertHswOtherDevice(HswOtherDevice hswOtherDevice) {
        hswOtherDevice.setCreateTime(DateUtils.getNowDate());
        return hswOtherDeviceMapper.insertHswOtherDevice(hswOtherDevice);
    }

    /**
     * 修改其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    @Override
    public int updateHswOtherDevice(HswOtherDevice hswOtherDevice) {
        hswOtherDevice.setUpdateTime(DateUtils.getNowDate());
        return hswOtherDeviceMapper.updateHswOtherDevice(hswOtherDevice);
    }

    /**
     * 批量删除其他设备
     *
     * @param ids 需要删除的其他设备ID
     * @return 结果
     */
    @Override
    public int deleteHswOtherDeviceByIds(Long[] ids) {
        return hswOtherDeviceMapper.deleteHswOtherDeviceByIds(ids);
    }

    /**
     * 删除其他设备信息
     *
     * @param id 其他设备ID
     * @return 结果
     */
    @Override
    public int deleteHswOtherDeviceById(Long id) {
        return hswOtherDeviceMapper.deleteHswOtherDeviceById(id);
    }

    /**
     * 根据诊断器ip删除其他设备
     *
     * @param ip
     * @return
     */
    @Override
    public int deleteHswOtherDeviceByIp(String ip) {

        if (StringUtils.isNotEmpty(ip)) {
            return this.hswOtherDeviceMapper.deleteHswOtherDeviceByIp(ip);
        }
        return 0;
    }

    /**
     * 根据所属诊断器ip获取其他设备数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    @Override
    public int selectOtherDeviceCountByIp(String ip) {
        return hswOtherDeviceMapper.selectOtherDeviceCountByIp(ip);
    }

    /**
     * 导入其他设备数据
     *
     * @param list     其他设备列表
     * @param operName 操作用户
     * @return
     */
    @Override
    public String importOtherDevice(List<HswOtherDevice> list, String operName) {
        if (StringUtils.isNull(list) || list.size() == 0) {
            throw new CustomException("导入其他设备数据不能为空！");
        }
        int successNum = 0;
        int failureNum = 0;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        for (HswOtherDevice otherDevice : list) {
            try {
                otherDevice.setCreateBy(operName);
                otherDevice.setInstallTime(DateUtils.getDateMr(otherDevice.getInstallDate()));
                this.insertHswOtherDevice(otherDevice);
                successNum++;
                successMsg.append("<br/>第" + successNum + " 导入成功");
            } catch (Exception e) {
                failureNum++;
                String msg = "<br/>第" + failureNum + " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                log.error(msg, e);
            }
        }
        if (failureNum > 0) {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            throw new CustomException(failureMsg.toString());
        } else {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }

    @Override
    public String checkValid(HswOtherDevice hswOtherDevice, List<HswOtherDevice> list) {
        StringBuilder validMsg = new StringBuilder();

        if (hswOtherDevice == null) {
            return "其他设备不能为空";
        }

        if (StringUtils.isEmpty(hswOtherDevice.getName())) {
            return "设备名称不能为空";
        }

        if (StringUtils.isEmpty(hswOtherDevice.getIp())) {
            return "所属诊断器ip不能为空";
        }

        if (StringUtils.isNull(hswOtherDevice.getInstallDate())) {
            validMsg.append("<br/>" + "请输入正确格式的安装日期");
        }

        if (StringUtils.isNull(hswOtherDevice.getWarranty())) {
            validMsg.append("<br/>" + "请输入正确格式的质保期");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(hswOtherDevice.getIp()))) {
            validMsg.append("<br/>" + "所属诊断器ip'" + hswOtherDevice.getIp() + "'不存在");
        }

        return validMsg.toString();
    }
}
