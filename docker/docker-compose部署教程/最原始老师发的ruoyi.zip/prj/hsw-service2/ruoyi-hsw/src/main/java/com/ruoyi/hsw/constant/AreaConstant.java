package com.ruoyi.hsw.constant;

import com.ruoyi.hsw.domain.vo.AreaVo;

import java.util.ArrayList;
import java.util.List;

/**
 * 区域常量
 *
 * @author zyj
 * @date 2020/11/20 14:33
 */
public interface AreaConstant {

    AreaVo NC_AREA = new AreaVo("3601", "南昌市", "115.85", "28.68");

    AreaVo JDZ_AREA = new AreaVo("3602", "景德镇市", "117.17", "29.27");

    AreaVo PX_AREA = new AreaVo("3603", "萍乡市", "113.85", "27.63");

    AreaVo JJ_AREA = new AreaVo("3604", "九江市", "116.0", "29.7");

    AreaVo XY_AREA = new AreaVo("3605", "新余市", "114.92", "27.82");

    AreaVo YT_AREA = new AreaVo("3606", "鹰潭市", "117.07", "28.27");

    AreaVo GZ_AREA = new AreaVo("3607", "赣州市", "114.93", "25.83");

    AreaVo JA_AREA = new AreaVo("3608", "吉安市", "114.98", "27.12");

    AreaVo YC_AREA = new AreaVo("3609", "宜春市", "114.38", "27.8");

    AreaVo FZ_AREA = new AreaVo("3610", "抚州市", "116.35", "28.0");

    AreaVo SR_AREA = new AreaVo("3611", "上饶市", "117.97", "28.0");

}
