package com.ruoyi.hsw.dto.index;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 描述:
 * 设备故障Dto
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 10:51
 */
@Data
public class EquFaultPageableDto implements Serializable {

    // 级别(0=市，1=县)
    public static Integer LEVEL_CITY = 0;
    public static Integer LEVEL_DISTRICT = 1;

    // 项目集合
    private List<Long> pIds;

    // 省
    private Integer province;

    // 市
    private Integer city;

    // 县
    private Integer district;

    // 开始时间
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 开始时间(日期格式)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startDate;

    // 结束时间(日期格式)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endDate;

    // 级别(0=市，1=县)
    private Integer level = 0;
}
