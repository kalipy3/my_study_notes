package com.ruoyi.hsw.dto;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/13 0013
 */
@Data
public class UserMsgView implements Serializable {
    /** 日志标题 */
    @Excel(name = "日志标题")
    private String title;

    /** 日志内容 */
    @Excel(name = "日志内容")
    private String content;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createName;

    /** 创建时间 */
    @Excel(name = "创建时间")
    private String createTime;

    /** 用户id */
    @Excel(name = "用户id")
    private Long uid;

    /** 消息id */
    @Excel(name = "消息id")
    private Long mid;

    /** 创建时间 */
    @Excel(name = "创建时间")
    private Integer readTime;

    /** 状态(0=未读；1=已读；3=归档) */
    @Excel(name = "状态(0=未读；1=已读；3=归档)")
    private Integer status;

    /** $column.columnComment */
    @Excel(name = "状态(0=未读；1=已读；3=归档)")
    private String uname;

    /** 关联工单编号 */
    @Excel(name = "关联工单编号")
    private String jobNo;
}
