package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 故障信息视图分页
 *
 * @author zyj
 * @date 2020/11/25 13:48
 */
@Data
public class FaultViewPageableDto implements Serializable {

    //项目id组
    private Long[] pids;

    // 归档状态
    private Integer flagStatus;


}
