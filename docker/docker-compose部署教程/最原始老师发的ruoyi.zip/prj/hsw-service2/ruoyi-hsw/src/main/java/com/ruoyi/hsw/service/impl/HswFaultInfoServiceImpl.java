package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.commonEnum.HandleStatusEnum;
import com.ruoyi.hsw.commonEnum.JobStatusEnum;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.*;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.domain.vo.FaultStatusVo;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.index.DeviceDateCountDto;
import com.ruoyi.hsw.mapper.*;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.system.domain.SysUserRole;
import com.ruoyi.system.mapper.SysDictDataMapper;
import com.ruoyi.system.mapper.SysUserRoleMapper;
import com.ruoyi.system.service.ISysUserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 故障信息Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Slf4j
@Service
@Transactional
public class HswFaultInfoServiceImpl implements IHswFaultInfoService {
    @Autowired
    private HswFaultInfoMapper hswFaultInfoMapper;

    @Autowired
    private HswJobInfoMapper hswJobInfoMapper;

    @Autowired
    private HswJobLogMapper hswJobLogMapper;

    @Autowired
    private HswCameraMapper hswCameraMapper;

    @Autowired
    private IHswDiagnosisDeviceService diagnosisDeviceService;

    @Autowired
    private IHswProjectService projectService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private SysUserRoleMapper sysUserRoleMapper;

    @Autowired
    private HswDivideWorkMapper hswDivideWorkMapper;

    @Autowired
    private SysDictDataMapper sysDictDataMapper;


    /**
     * 查询故障信息
     *
     * @param id 故障信息ID
     * @return 故障信息
     */
    @Override
    public HswFaultInfo selectHswFaultInfoById(Long id) {
        return hswFaultInfoMapper.selectHswFaultInfoById(id);
    }

    /**
     * 查询活动故障信息列表
     *
     * @param hswFaultInfo 故障信息
     * @return 故障信息
     */
    @Override
    public List<HswFaultInfo> selectHswFaultInfoList(HswFaultInfo hswFaultInfo) {
        return hswFaultInfoMapper.selectHswFaultInfoList(hswFaultInfo);
    }

    /**
     * 查询历史故障信息列表
     */
    @Override
    public List<HswFaultInfo> selectHistoryList(HswFaultInfo hswFaultInfo) {
        return hswFaultInfoMapper.selectHistoryList(hswFaultInfo);
    }

    /**
     * 新增故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    @Override
    public int insertHswFaultInfo(HswFaultInfo hswFaultInfo) {
        hswFaultInfo.setCreateTime(DateUtils.getNowDate());
        return hswFaultInfoMapper.insertHswFaultInfo(hswFaultInfo);
    }

    /**
     * 修改故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    @Override
    public int updateHswFaultInfo(HswFaultInfo hswFaultInfo) {
        hswFaultInfo.setUpdateTime(DateUtils.getNowDate());
        return hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
    }

    /**
     * 批量删除故障信息
     *
     * @param ids 需要删除的故障信息ID
     * @return 结果
     */
    @Override
    public int deleteHswFaultInfoByIds(Long[] ids) {
        return hswFaultInfoMapper.deleteHswFaultInfoByIds(ids);
    }

    /**
     * 删除故障信息信息
     *
     * @param id 故障信息ID
     * @return 结果
     */
    @Override
    public int deleteHswFaultInfoById(Long id) {
        return hswFaultInfoMapper.deleteHswFaultInfoById(id);
    }

    /**
     * 派单
     */
    @Override
    public Map<String, Object> insertHswJobInfo(HswJobInfo hswJobInfo) {

        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);

        FaultViewDto faultViewDto = this.hswFaultInfoMapper.selectFaultViewById(hswJobInfo.getFaultId());
        if (faultViewDto != null) {
            // 添加工单
            DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
            Date date = new Date();
            hswJobInfo.setJobNo(format1.format(date)); // 工单编号
            hswJobInfo.setSendTime(DateUtils.getDateMr(new Date())); // 派单时间
            hswJobInfo.setSendUid(SecurityUtils.getLoginUser().getUser().getUserId()); // 派单人
            hswJobInfo.setReceiverTime(DateUtils.getDateMr(new Date())); // 接单时间
            hswJobInfo.setStatus(JobStatusEnum.WXZ.getValue()); //工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
            hswJobInfo.setRepairTime(0L); // 修复时间
            hswJobInfo.setRepairRecord(""); // 修复记录
            hswJobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY); // 归档状态（0=活动工单；1=历史工单）
            hswJobInfo.setHangUpTime(0L); // 挂起时间
            hswJobInfo.setHangUpReason(""); // 挂起原因
            hswJobInfo.setResumeTime(0L); // 建立时间
            hswJobInfo.setHandleStatus(HandleStatusEnum.YPD.getValue()); // 操作状态
            hswJobInfo.setCreateBy(SecurityUtils.getUsername()); // 创建人
            hswJobInfo.setCreateTime(DateUtils.getNowDate()); // 创建时间
            int jobInfo = this.hswJobInfoMapper.insertHswJobInfo(hswJobInfo);
            if (jobInfo > 0) {
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setStatus(JobStatusEnum.WXZ.getValue().toString()); //故障状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
                hswFaultInfo.setJobId(hswJobInfo.getId()); // 工单id
                hswFaultInfo.setJobNo(hswJobInfo.getJobNo()); // 工单编号
                hswFaultInfo.setId(hswJobInfo.getFaultId());
                hswFaultInfo.setUpdateBy(SecurityUtils.getUsername());
                hswFaultInfo.setUpdateTime(DateUtils.getNowDate());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId()); // 工单id
                hswJobLog.setJobNo(hswJobInfo.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.WXZ.getValue()); // 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
                hswJobLog.setHandleUid(hswJobInfo.getSendUid()); // 操作人id
                hswJobLog.setHandleUname(SecurityUtils.getLoginUser().getUser().getNickName()); // 操作人
                hswJobLog.setHandleTime(hswJobInfo.getSendTime()); // 操作时间
                hswJobLog.setHandleStatus(HandleStatusEnum.YPD.getValue());
                hswJobLog.setCreateBy(SecurityUtils.getUsername()); // 创建人
                hswJobLog.setCreateTime(DateUtils.getNowDate()); // 创建时间
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("cuId", faultViewDto.getCuId());
                map.put("jobNo", hswJobInfo.getJobNo());
                map.put("code", jobInfo);
            }
            return map;
        }

        return map;
    }

    @Override
    public boolean updateHswFaultInfoByApi(UpdateFaultDto updateFaultDto) {
        return this.hswFaultInfoMapper.updateHswFaultInfoByApi(updateFaultDto);
    }

    @Override
    public Map<String, Object> addfromDevice(String ip, Integer port, String type, String descr, Integer zigzagCount, Integer zigzagType, Integer zigzagStatus, String opState, String taketime) {
        log.info("新增故障->ip={},port={},type={},descr={},zigzag_type={},zigzag_count={},zigzag_status={},op_state={},taketime={}", ip, port, type, descr, zigzagType, zigzagCount, zigzagStatus, opState, taketime);

        Long takeTime = DateUtils.parseDateToSeconds(new Date());
        if (StringUtils.isNotBlank(taketime)) {
            Date d = DateUtils.parseDate(taketime);
            if (d != null) {
                takeTime = DateUtils.parseDateToSeconds(d);
            }
        }

        Map<String, Object> resMsg = new HashMap<>();
        resMsg.put("code", 0);

        HswFaultInfo faultInfo = new HswFaultInfo();
        faultInfo.setFaultNo(DateUtils.parseDateToStr("yyMMddHHmmss", new Date()) + RandomStringUtils.randomNumeric(3, 3));
        faultInfo.setIp(ip);
        faultInfo.setPort(port);
        faultInfo.setType(type);
        faultInfo.setTakeTime(takeTime);
        faultInfo.setStatus(JobStatusEnum.WPD.getValue().toString());
        faultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY.toString());
        faultInfo.setJobId(0L);
        faultInfo.setJobNo("");
        faultInfo.setDescr(descr);
        faultInfo.setSn("");
        faultInfo.setRepairTime(0L);
        faultInfo.setZigzagCount(zigzagCount);
        faultInfo.setZigzagType(zigzagType);
        faultInfo.setZigzagStatus(zigzagStatus);
        faultInfo.setOpState(opState);

        DiagnosisDeviceViewDto diagnosisDeviceViewDto = this.diagnosisDeviceService.selectDiagnosisDeviceViewByIpForApp(ip);
        if (diagnosisDeviceViewDto == null) {
            resMsg.put("msg", "添加失败:ip非法");
            resMsg.put("token", "");
            return resMsg;
        }

        //从诊断器中获得故障设备基础信息
        faultInfo.setPid(diagnosisDeviceViewDto.getPid());
        faultInfo.setMtId(diagnosisDeviceViewDto.getAtId());
        faultInfo.setRegionName(diagnosisDeviceViewDto.getCityLabel() + diagnosisDeviceViewDto.getDistrictLabel() + diagnosisDeviceViewDto.getAddress());
        faultInfo.setMuId(diagnosisDeviceViewDto.getMaintenanceUnitsId());
        faultInfo.setArea(diagnosisDeviceViewDto.getDivideArea());
        faultInfo.setDivideWorkId(diagnosisDeviceViewDto.getDivideWorkId());
        faultInfo.setNetwork(diagnosisDeviceViewDto.getNetwork());

        List<SysDictData> dictDataList = this.sysDictDataMapper.selectDictDataByType(CommonParameter.HSW_FAULT_TYPE);
//        if (!dictDataList.isEmpty()) {
//            for (SysDictData sysDictData:dictDataList) {
//                if (sysDictData.getDictValue().equals(faultInfo.getType())) {
//                    faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
//                }
//            }
//        }
        switch (Integer.valueOf(faultInfo.getType())) {
            case CommonConstant.SDDD:
                faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                break;//市电断电
            case CommonConstant.GQLL:
                faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                break;//光纤链路故障
            case CommonConstant.GQSFQ:
                faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                break;//光纤收发器故障
            case CommonConstant.SXJLL:
                faultInfo.setInfluenceCameraCount(1);
                break;//摄像机链路故障
            case CommonConstant.SXJ:
                faultInfo.setInfluenceCameraCount(1);
                break;//摄像机故障
            case CommonConstant.ZGL:
                faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                break;//主光缆故障
            case CommonConstant.ZDQ:
                faultInfo.setInfluenceCameraCount(0);
                break;//诊断器故障
            case CommonConstant.ZDXHSCBZC:
                faultInfo.setInfluenceCameraCount(0);
                break;//诊断信号输出不正常
            case CommonConstant.GZBWD:
                faultInfo.setInfluenceCameraCount(0);
                break;//工作不稳定-当前正常
            case CommonConstant.GZBWD_DQGZ://工作不稳定-当前故障
                switch (faultInfo.getZigzagType()) {
                    case CommonConstant.SDDD:
                        faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                        break;//市电断电
                    case CommonConstant.GQLL:
                        faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                        break;//光纤链路故障
                    case CommonConstant.GQSFQ:
                        faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                        break;//光纤收发器故障
                    case CommonConstant.SXJLL:
                        faultInfo.setInfluenceCameraCount(1);
                        break;//摄像机链路故障
                    case CommonConstant.SXJ:
                        faultInfo.setInfluenceCameraCount(1);
                        break;//摄像机故障
                    case CommonConstant.ZGL:
                        faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                        break;//主光缆故障
                    case CommonConstant.ZDQ:
                        faultInfo.setInfluenceCameraCount(0);
                        break;//诊断器故障
                    case CommonConstant.ZDXHSCBZC:
                        faultInfo.setInfluenceCameraCount(0);
                        break;//诊断信号输出不正常
                    case CommonConstant.ONULL:
                        faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                        break;//ONU链路故障
                    case CommonConstant.ZDQDYSPQ:
                        faultInfo.setInfluenceCameraCount(0);
                        break;//诊断器电源适配器故障
                    case CommonConstant.SXJLLZDXHBZC:
                        faultInfo.setInfluenceCameraCount(0);
                        break;//摄像机链路诊断信号不正常
                    case CommonConstant.GQLLZDXHSCBZC:
                        faultInfo.setInfluenceCameraCount(0);
                        break;//光纤链路诊断信号输出不正常
                    default:
                        faultInfo.setInfluenceCameraCount(0);
                        break;
                }
                break;
            case CommonConstant.ONULL:
                faultInfo.setInfluenceCameraCount(diagnosisDeviceViewDto.getCameraCount());
                break;//ONU链路故障
            case CommonConstant.ZDQDYSPQ:
                faultInfo.setInfluenceCameraCount(0);
                break;//诊断器电源适配器故障
            case CommonConstant.SXJLLZDXHBZC:
                faultInfo.setInfluenceCameraCount(0);
                break;//摄像机链路诊断信号不正常
            case CommonConstant.GQLLZDXHSCBZC:
                faultInfo.setInfluenceCameraCount(0);
                break;//光纤链路诊断信号输出不正常
            default:
                break;
        }

        if (StringUtils.isNotBlank(ip) && port != null && port > 0) {
            FaultInfoParamAppDto faultInfoParamAppDto = new FaultInfoParamAppDto();
            faultInfoParamAppDto.setIp(ip);
            faultInfoParamAppDto.setPort(port);
            faultInfoParamAppDto.setTakeStartTime(DateUtils.parseDateToSeconds(DateUtils.parseDate(DateUtils.parseDateToStr("yyyy-MM-dd", new Date()) + " 00:00:00")));
            faultInfoParamAppDto.setTakeEndTime(DateUtils.parseDateToSeconds(DateUtils.parseDate(DateUtils.parseDateToStr("yyyy-MM-dd", new Date()) + " 23:59:59")));
            List<HswFaultInfo> hswFaultInfos = this.hswFaultInfoMapper.selectFaultInfoListByFaultInfoParamAppDto(faultInfoParamAppDto);
            faultInfo.setTodayTakeCount(hswFaultInfos.size() + 1L);
        }

        HswProject project = this.projectService.selectHswProjectById(faultInfo.getPid());

        //写入超时相关的中间数据
        faultInfo.setDeviceDistance(diagnosisDeviceViewDto.getDistance());
        if (project != null) {
            faultInfo.setTimeoutLevel(0L);
            faultInfo.setStartDistance(0);
            faultInfo.setEndDistance(0);
            faultInfo.setTimeoutHour(0);

            if (faultInfo.getDeviceDistance() < project.getTimeoutEnd1()) {
                faultInfo.setTimeoutLevel(1L);
                faultInfo.setStartDistance(0);
                faultInfo.setEndDistance(project.getTimeoutEnd1());
                faultInfo.setTimeoutHour(project.getTimeoutHour1());
            } else if (faultInfo.getDeviceDistance() >= project.getTimeoutStart2() && faultInfo.getDeviceDistance() < project.getTimeoutEnd2()) {
                faultInfo.setTimeoutLevel(2L);
                faultInfo.setStartDistance(project.getTimeoutStart2());
                faultInfo.setEndDistance(project.getTimeoutEnd2());
                faultInfo.setTimeoutHour(project.getTimeoutHour2());
            } else {
                faultInfo.setTimeoutLevel(3L);
                faultInfo.setStartDistance(project.getTimeoutStart3());
                faultInfo.setEndDistance(project.getTimeoutEnd3());
                faultInfo.setTimeoutHour(project.getTimeoutHour3());
            }
            faultInfo.setSendWorkOrderLimit(project.getSendWorkOrderLimit());
        }

        int res = this.insertHswFaultInfo(faultInfo);
        if (res > 0) {
            resMsg.put("msg", "添加成功");
            resMsg.put("faultId", faultInfo.getId());
            resMsg.put("faultNo", faultInfo.getFaultNo());
            resMsg.put("regionName", faultInfo.getRegionName());
            resMsg.put("takeTime", faultInfo.getTakeTime());
            resMsg.put("type", faultInfo.getType());
            resMsg.put("area", faultInfo.getArea());
            resMsg.put("ip", faultInfo.getIp());
            resMsg.put("port", faultInfo.getPort());
            resMsg.put("id", faultInfo.getId());
            if (project != null) {
                resMsg.put("cuId", project.getCuId());
            }

            // 维修队长用户
            List<SysUserRole> sysUserRoles = sysUserRoleMapper.selectSysUserRoleList(CommonConstant.ROLE_MTL, null);
            SysUser sysUserParam = new SysUser();
            sysUserParam.setTeamId(faultInfo.getMtId());
            sysUserParam.setType(CommonConstant.USER_TYPE_MU);
            List<SysUser> sysUsers = this.sysUserService.selectUserList(sysUserParam);
            sysUsers = sysUsers.stream().filter(u -> {
                for (SysUserRole sysUserRole : sysUserRoles) {
                    if (sysUserRole.getUserId().equals(u.getUserId())) {
                        return true;
                    }
                }
                return false;
            }).collect(Collectors.toList());
            resMsg.put("user", sysUsers);
            resMsg.put("code", 1);
        } else {
            resMsg.put("msg", "添加失败");
        }

        return resMsg;
    }

    @Override
    public List<FaultViewDto> selectFaultViewListForApp(ActiveFaultPageableDto activeFaultPageableDto) {
        return this.hswFaultInfoMapper.selectFaultViewListForApp(activeFaultPageableDto);
    }

    @Override
    public List<FaultViewDto> selectFaultViewList(FaultViewDto faultViewDto) {
        return this.hswFaultInfoMapper.selectFaultViewList(faultViewDto);
    }

    @Override
    public FaultViewDto selectFaultViewById(Long id) {
        return this.hswFaultInfoMapper.selectFaultViewById(id);
    }

    /**
     * app 派单
     */
    @Override
    public Map<String, Object> assignForApp(Long id, Long assignUserId, Long receiverId, String remark, String assignUserNickName) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        //TODO: 未实现
        FaultViewDto faultViewDto = this.hswFaultInfoMapper.selectFaultViewById(id);
        if (faultViewDto != null) {
            JobViewDto jobViewDto = new JobViewDto();
            jobViewDto.setFaultId(faultViewDto.getId());
            List<JobViewDto> jobViewDtos = this.hswJobInfoMapper.selectJobViewList(jobViewDto);
            if (jobViewDtos.size() > 0) {
                msg.put("msg", "派单失败：重复派单");
                return msg;
            }
            HswJobInfo jobInfo = new HswJobInfo();
            // 添加工单
            DateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
            Date date = new Date();
            jobInfo.setJobNo(format1.format(date)); // 工单编号
            jobInfo.setFaultId(faultViewDto.getId()); // 故障id
            jobInfo.setFaultNo(faultViewDto.getFaultNo()); // 故障编号
            jobInfo.setSendTime(DateUtils.getDateMr(new Date())); // 派单时间
            jobInfo.setSendUid(SecurityUtils.getLoginUser().getUser().getUserId()); // 派单人
            jobInfo.setReceiverId(receiverId); // 接单人
            jobInfo.setReceiverTime(DateUtils.getDateMr(new Date())); // 接单时间
            jobInfo.setStatus(JobStatusEnum.WXZ.getValue()); //工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
            jobInfo.setRepairTime(0L); // 修复时间
            jobInfo.setRepairRecord(""); // 修复记录
            jobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY); // 归档状态（0=活动工单；1=历史工单）
            jobInfo.setHangUpTime(0L); // 挂起时间
            jobInfo.setHangUpReason(""); // 挂起原因
            jobInfo.setResumeTime(0L); // 建立时间
            jobInfo.setHandleStatus(HandleStatusEnum.YPD.getValue()); // 操作状态
            jobInfo.setCreateBy(SecurityUtils.getUsername()); // 创建人
            jobInfo.setCreateTime(DateUtils.getNowDate()); // 创建时间
            int res = this.hswJobInfoMapper.insertHswJobInfo(jobInfo);
            if (res > 0) {
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setStatus(JobStatusEnum.WXZ.getValue().toString()); //故障状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
                hswFaultInfo.setJobId(jobInfo.getId()); // 工单id
                hswFaultInfo.setJobNo(jobInfo.getJobNo()); // 工单编号
                hswFaultInfo.setId(id); // 故障id
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                msg.put("job_no", jobInfo.getJobNo());
                msg.put("cu_id", faultViewDto.getCuId());
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobInfo.getId()); // 工单id
                hswJobLog.setJobNo(jobInfo.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.WXZ.getValue()); // 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
                hswJobLog.setHandleUid(jobInfo.getSendUid()); // 操作人id
                hswJobLog.setHandleUname(SecurityUtils.getLoginUser().getUser().getNickName()); // 操作人
                hswJobLog.setHandleTime(jobInfo.getSendTime()); // 操作时间
                hswJobLog.setHandleStatus(HandleStatusEnum.YPD.getValue()); // 操作状态
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                msg.put("code", 1);
                msg.put("msg", "派单成功");
                return msg;
            } else {
                msg.put("msg", "派单失败：生成工单失败");
                return msg;
            }
        } else {
            msg.put("msg", "派单失败:找不到要派的故障单");
            return msg;
        }
    }

    /**
     * 根据项目id和时间范围获取故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<FaultViewDto> selectFaultCountByPidsAndDate(Long[] pids, Long startDate, Long endDate) {
        if (StringUtils.isNull(pids) || pids.length <= 0) {
            return null;
        }

        if (startDate == null || endDate == null) {
            return null;
        }

        List<FaultViewDto> faultView = hswFaultInfoMapper.selectFaultCountByPidsAndDate(pids, startDate, endDate);

        if (CollectionUtils.isEmpty(faultView)) {
            return null;
        }

        long nd = 1000 * 24 * 60 * 60;
        Long diff = (endDate - startDate) * 1000;
        // 计算差多少天
        Long day = diff / nd;

        DecimalFormat df = new DecimalFormat("#.00");

        List<HswCamera> hswCameras = hswCameraMapper.selectCountGroupByDwidAndPid(pids);
        faultView.forEach(f -> {
            f.setOfflineAvgCount(Double.valueOf(df.format(f.getInfluenceCameraCount() / day.intValue())));
            f.setHungAvgCount(Double.valueOf(df.format(f.getHungCount() / day)));

            if (!CollectionUtils.isEmpty(hswCameras)) {
                Long cameraCount = hswCameras.stream()
                        .filter(c -> f.getDivideWorkId().equals(c.getHswDiagnosisDevice().getDivideWorkId()))
                        .map(c -> c.getCameraCountAll())
                        .count();

                f.setCameraCountAll(Double.valueOf(df.format(cameraCount.doubleValue())));
                f.setOnlineAvgCount(Double.valueOf(df.format(cameraCount.doubleValue() - f.getOfflineAvgCount())));
                f.setOnlineAvgRate(Double.valueOf(df.format(f.getOnlineAvgCount() * 100 / cameraCount.doubleValue())));
            }

        });

        return faultView;
    }

    /**
     * 根据时间范围获取故障设备数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<FaultViewDto> selectFaultCountByDate(Long pid, Long startDate, Long endDate) {

        List<FaultViewDto> faultView = hswFaultInfoMapper.selectFaultCountDate(pid, startDate, endDate);

        if (CollectionUtils.isEmpty(faultView)) {
            return new ArrayList<FaultViewDto>();
        }

        if (StringUtils.isNull(startDate) && StringUtils.isNull(endDate)) {
            startDate = 0L;
            endDate = 0L;
        }
        long nd = 1000 * 24 * 60 * 60;
        Long diff = (endDate - startDate) * 1000;
        // 计算差多少天
        Long day = diff / nd;

        DecimalFormat df = new DecimalFormat("#.00");

        List<HswCamera> hswCameras = hswCameraMapper.selectCountGroupByDwid(pid);
        faultView.forEach(f -> {
            if (day > 0L) {
                f.setOfflineAvgCount(Double.valueOf(df.format(f.getInfluenceCameraCount() / day.intValue())));
                f.setHungAvgCount(Double.valueOf(df.format(f.getHungCount() / day)));
            } else {
                f.setOfflineAvgCount(0.00D);
                f.setHungAvgCount(0.00D);
            }
            if (!CollectionUtils.isEmpty(hswCameras)) {
                Long cameraCount = hswCameras.stream()
                        .filter(c -> f.getDivideWorkId().equals(c.getHswDiagnosisDevice().getDivideWorkId()))
                        .map(c -> c.getCameraCountAll())
                        .count();
                f.setCameraCountAll(Double.valueOf(df.format(cameraCount.doubleValue())));
                if (f.getOfflineAvgCount() > 0L) {
                    f.setOnlineAvgCount(Double.valueOf(df.format(cameraCount.doubleValue() - f.getOfflineAvgCount())));
                } else {
                    f.setOnlineAvgCount(0.00D);
                }
                if (cameraCount > 0) {
                    f.setOnlineAvgRate(Double.valueOf(df.format(f.getOnlineAvgCount() * 100 / cameraCount.doubleValue())));
                } else {
                    f.setOnlineAvgRate(0.00D);
                }
            }

        });

        return faultView;
    }


    /**
     * 根据项目id和时间范围获取不同故障类型数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public Map<String, Object> selectFaultTypeCountByPidsAndDate(Long[] pids, Long startDate, Long endDate) {
        if (startDate == null || endDate == null) {
            return null;
        }

        Map<String, Object> map = new HashMap<>();

        DecimalFormat df = new DecimalFormat("#.00");

        // 不同故障类型的数量列表
        List<FaultStatisticsVo> faultStatisticsList = hswFaultInfoMapper.selectFaultTypeCountByPidsAndDate(pids, startDate, endDate);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = sdf.format(new Date(startDate * 1000)); // 时间戳转换日期
        String endDateString = sdf.format(new Date(endDate * 1000)); // 时间戳转换日期

        // 时间范围列表
        List<String> dateStr = hswFaultInfoMapper.selectDateRange(startDateString, endDateString);

        List<FaultStatisticsVo> faultList = new ArrayList<>();
        dateStr.forEach(d -> {
            Optional<FaultStatisticsVo> any = faultStatisticsList.stream().filter(f -> d.equals(f.getDatestr())).findAny();
            if (any.isPresent()) {
                faultList.add(any.get());
            } else {
                FaultStatisticsVo faultStatistics = new FaultStatisticsVo();
                faultStatistics.setDatestr(d);
                faultList.add(faultStatistics);
            }
        });

        // 总数统计
        FaultStatisticsVo allFault = new FaultStatisticsVo();
        // 市电断电数量
        Integer type1Count = 0;
        // 光纤链路故障数量
        Integer type2Count = 0;
        // 光纤收发器故障数量
        Integer type3Count = 0;
        // 摄像机链路故障数量
        Integer type4Count = 0;
        // 摄像机故障数量
        Integer type5Count = 0;
        // 主光缆故障数量
        Integer type6Count = 0;
        // 诊断器故障数量
        Integer type7Count = 0;
        // 诊断信号输出不正常数量
        Integer type8Count = 0;
        // 工作不稳定数量
        Integer type9Count = 0;
        // 工作不稳定-当前故障数量
        Integer type10Count = 0;
        // ONU链路故障数量
        Integer type11Count = 0;
        // 所有类型的数量
        Integer typeAllCount;
        // 总在线率
        Double allOnlineRate = 0D;

        // 摄像机总数
        Double cameraAll = (double) hswCameraMapper.selectCountByPid(pids);

        for (FaultStatisticsVo f : faultList) {
            type1Count = type1Count + f.getType1Count();
            type2Count = type2Count + f.getType2Count();
            type3Count = type3Count + f.getType3Count();
            type4Count = type4Count + f.getType4Count();
            type5Count = type5Count + f.getType5Count();
            type6Count = type6Count + f.getType6Count();
            type7Count = type7Count + f.getType7Count();
            type8Count = type8Count + f.getType8Count();
            type9Count = type9Count + f.getType9Count();
            type10Count = type10Count + f.getType10Count();
            type11Count = type11Count + f.getType11Count();

            // 统计在线率
            if (cameraAll > 0) {
                Double aDouble = Double.valueOf(df.format((cameraAll - f.getCameraFaultCount()) * 100D / cameraAll));
                if (aDouble > 0) {
                    f.setOnlineRate(aDouble);
                } else {
                    f.setOnlineRate(0D);
                }
                allOnlineRate = allOnlineRate + f.getOnlineRate();
            } else {
                f.setOnlineRate(0D);
            }
        }
        allFault.setType1Count(type1Count);
        allFault.setType2Count(type2Count);
        allFault.setType3Count(type3Count);
        allFault.setType4Count(type4Count);
        allFault.setType5Count(type5Count);
        allFault.setType6Count(type6Count);
        allFault.setType7Count(type7Count);
        allFault.setType8Count(type8Count);
        allFault.setType9Count(type9Count);
        allFault.setType10Count(type10Count);
        allFault.setType11Count(type11Count);

        typeAllCount = type1Count + type2Count + type3Count + type4Count + type5Count + type6Count + type7Count + type8Count + type9Count + type10Count + type11Count;

        if (typeAllCount > 0) {
            allFault.setType1CountRate(Double.valueOf(df.format((type1Count * 100D / typeAllCount))));
            allFault.setType3CountRate(Double.valueOf(df.format((type3Count * 100D / typeAllCount))));
            allFault.setType4CountRate(Double.valueOf(df.format((type4Count * 100D / typeAllCount))));
            allFault.setType5CountRate(Double.valueOf(df.format((type5Count * 100D / typeAllCount))));
            allFault.setType6CountRate(Double.valueOf(df.format((type6Count * 100D / typeAllCount))));
            allFault.setType7CountRate(Double.valueOf(df.format((type7Count * 100D / typeAllCount))));
            allFault.setType8CountRate(Double.valueOf(df.format((type8Count * 100D / typeAllCount))));
            allFault.setType9CountRate(Double.valueOf(df.format((type9Count * 100D / typeAllCount))));
            allFault.setType10CountRate(Double.valueOf(df.format((type10Count * 100D / typeAllCount))));
            allFault.setType11CountRate(Double.valueOf(df.format((type11Count * 100D / typeAllCount))));
        }

        if (faultList.size() > 0) {
            allFault.setAllOnlineRate(Double.valueOf(df.format(allOnlineRate / faultList.size())));
        } else {
            allFault.setAllOnlineRate(allOnlineRate);
        }

        map.put("faultList", faultList);
        map.put("fault", allFault);
        return map;
    }

    /**
     * 根据时间范围获取不同故障类型数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public Map<String, Object> selectFaultTypeCountByDate(Long pid, Long startDate, Long endDate) {

        Map<String, Object> map = new HashMap<>();

        List<FaultStatisticsVo> faultList = new ArrayList<>();

        if (startDate == null || endDate == null) {
            map.put("faultList", faultList);
            return map;
        }


        DecimalFormat df = new DecimalFormat("#.00");

        // 不同故障类型的数量列表
        List<FaultStatisticsVo> faultStatisticsList = hswFaultInfoMapper.selectFaultTypeCountByDate(pid, startDate, endDate);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startDateString = sdf.format(new Date(startDate * 1000)); // 时间戳转换日期
        String endDateString = sdf.format(new Date(endDate * 1000)); // 时间戳转换日期

        // 时间范围列表
        List<String> dateStr = hswFaultInfoMapper.selectDateRange(startDateString, endDateString);

        dateStr.forEach(d -> {
            Optional<FaultStatisticsVo> any = faultStatisticsList.stream().filter(f -> d.equals(f.getDatestr())).findAny();
            if (any.isPresent()) {
                faultList.add(any.get());
            } else {
                FaultStatisticsVo faultStatistics = new FaultStatisticsVo();
                faultStatistics.setDatestr(d);
                faultList.add(faultStatistics);
            }
        });

        // 总数统计
        FaultStatisticsVo allFault = new FaultStatisticsVo();
        // 市电断电数量
        Integer type1Count = 0;
        // 光纤链路故障数量
        Integer type2Count = 0;
        // 光纤收发器故障数量
        Integer type3Count = 0;
        // 摄像机链路故障数量
        Integer type4Count = 0;
        // 摄像机故障数量
        Integer type5Count = 0;
        // 主光缆故障数量
        Integer type6Count = 0;
        // 诊断器故障数量
        Integer type7Count = 0;
        // 诊断信号输出不正常数量
        Integer type8Count = 0;
        // 工作不稳定数量
        Integer type9Count = 0;
        // 工作不稳定-当前故障数量
        Integer type10Count = 0;
        // ONU链路故障数量
        Integer type11Count = 0;
        // 所有类型的数量
        Integer typeAllCount;
        // 总在线率
        Double allOnlineRate = 0D;

        // 摄像机总数
        Double cameraAll = (double) hswCameraMapper.selectCount(pid);

        for (FaultStatisticsVo f : faultList) {
            type1Count = type1Count + f.getType1Count();
            type2Count = type2Count + f.getType2Count();
            type3Count = type3Count + f.getType3Count();
            type4Count = type4Count + f.getType4Count();
            type5Count = type5Count + f.getType5Count();
            type6Count = type6Count + f.getType6Count();
            type7Count = type7Count + f.getType7Count();
            type8Count = type8Count + f.getType8Count();
            type9Count = type9Count + f.getType9Count();
            type10Count = type10Count + f.getType10Count();
            type11Count = type11Count + f.getType11Count();

            // 统计在线率
            if (cameraAll > 0) {
                Double aDouble = Double.valueOf(df.format((cameraAll - f.getCameraFaultCount()) * 100D / cameraAll));
                if (aDouble > 0) {
                    f.setOnlineRate(aDouble);
                } else {
                    f.setOnlineRate(0D);
                }
                allOnlineRate = allOnlineRate + f.getOnlineRate();
            } else {
                f.setOnlineRate(0D);
            }
        }
        allFault.setType1Count(type1Count);
        allFault.setType2Count(type2Count);
        allFault.setType3Count(type3Count);
        allFault.setType4Count(type4Count);
        allFault.setType5Count(type5Count);
        allFault.setType6Count(type6Count);
        allFault.setType7Count(type7Count);
        allFault.setType8Count(type8Count);
        allFault.setType9Count(type9Count);
        allFault.setType10Count(type10Count);
        allFault.setType11Count(type11Count);

        typeAllCount = type1Count + type2Count + type3Count + type4Count + type5Count + type6Count + type7Count + type8Count + type9Count + type10Count + type11Count;

        if (typeAllCount > 0) {
            allFault.setType1CountRate(Double.valueOf(df.format((type1Count * 100D / typeAllCount))));
            allFault.setType3CountRate(Double.valueOf(df.format((type3Count * 100D / typeAllCount))));
            allFault.setType4CountRate(Double.valueOf(df.format((type4Count * 100D / typeAllCount))));
            allFault.setType5CountRate(Double.valueOf(df.format((type5Count * 100D / typeAllCount))));
            allFault.setType6CountRate(Double.valueOf(df.format((type6Count * 100D / typeAllCount))));
            allFault.setType7CountRate(Double.valueOf(df.format((type7Count * 100D / typeAllCount))));
            allFault.setType8CountRate(Double.valueOf(df.format((type8Count * 100D / typeAllCount))));
            allFault.setType9CountRate(Double.valueOf(df.format((type9Count * 100D / typeAllCount))));
            allFault.setType10CountRate(Double.valueOf(df.format((type10Count * 100D / typeAllCount))));
            allFault.setType11CountRate(Double.valueOf(df.format((type11Count * 100D / typeAllCount))));
        }

        if (faultList.size() > 0) {
            allFault.setAllOnlineRate(Double.valueOf(df.format(allOnlineRate / faultList.size())));
        } else {
            allFault.setAllOnlineRate(allOnlineRate);
        }

        map.put("faultList", faultList);
        map.put("fault", allFault);
        return map;
    }

    /**
     * 根据项目获取故障统计获取不同故障类型数量
     */
    @Override
    public FaultStatisticsVo selectFaultTypeCountByIp(String ip) {

        // 不同故障类型的数量列表
        List<FaultStatisticsVo> faultStatisticsList = hswFaultInfoMapper.selectFaultTypeCountByIp(ip);

        // 总数统计
        FaultStatisticsVo allFault = new FaultStatisticsVo();
        // 市电断电数量
        Integer type1Count = 0;
        // 光纤链路故障数量
        Integer type2Count = 0;
        // 光纤收发器故障数量
        Integer type3Count = 0;
        // 摄像机链路故障数量
        Integer type4Count = 0;
        // 摄像机故障数量
        Integer type5Count = 0;
        // 主光缆故障数量
        Integer type6Count = 0;
        // 诊断器故障数量
        Integer type7Count = 0;
        // 诊断信号输出不正常数量
        Integer type8Count = 0;
        // 工作不稳定数量
        Integer type9Count = 0;
        // 工作不稳定-当前故障数量
        Integer type10Count = 0;
        // ONU链路故障数量
        Integer type11Count = 0;

        for (FaultStatisticsVo f : faultStatisticsList) {
            type1Count = type1Count + f.getType1Count();
            type2Count = type2Count + f.getType2Count();
            type3Count = type3Count + f.getType3Count();
            type4Count = type4Count + f.getType4Count();
            type5Count = type5Count + f.getType5Count();
            type6Count = type6Count + f.getType6Count();
            type7Count = type7Count + f.getType7Count();
            type8Count = type8Count + f.getType8Count();
            type9Count = type9Count + f.getType9Count();
            type10Count = type10Count + f.getType10Count();
            type11Count = type11Count + f.getType11Count();
        }
        allFault.setType1Count(type1Count);
        allFault.setType2Count(type2Count);
        allFault.setType3Count(type3Count);
        allFault.setType4Count(type4Count);
        allFault.setType5Count(type5Count);
        allFault.setType6Count(type6Count);
        allFault.setType7Count(type7Count);
        allFault.setType8Count(type8Count);
        allFault.setType9Count(type9Count);
        allFault.setType10Count(type10Count);
        allFault.setType11Count(type11Count);

        return allFault;
    }

    @Override
    public FaultViewDto selectFaultViewForRecoveryForApi(String ip, Integer port, String type, Integer zigzagType) {
        return this.hswFaultInfoMapper.selectFaultViewForRecoveryForApi(ip, port, type, zigzagType);
    }

    /**
     * 根据项目id和时间范围获取不同故障状态数量
     *
     * @param pid
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<FaultStatusVo> selectFaultStatusByPidAndDate(Long pid, Long startDate, Long endDate) {

        if (pid == null) {
            return null;
        }

        if (startDate == null) {
            return null;
        }

        if (endDate == null) {
            return null;
        }

        // 不同故障状态的数量列表
        List<FaultStatusVo> faultStatusList = hswFaultInfoMapper.selectFaultStatusByPidAndDate(pid, startDate, endDate);

        // 该项目下所有分工
        List<HswDivideWork> hswDivideWorkList = hswDivideWorkMapper.selectHswDivideWorkByPid(pid);

        if (CollectionUtils.isEmpty(hswDivideWorkList)) {
            return null;
        }

        DecimalFormat df = new DecimalFormat("#.00");

        List<FaultStatusVo> statusList = new ArrayList<>();
        for (HswDivideWork divideWork : hswDivideWorkList) {
            Optional<FaultStatusVo> any = faultStatusList.stream().filter(f -> divideWork.getId().equals(f.getDivideWorkId())).findAny();

            if (any.isPresent()) {
                FaultStatusVo faultStatusVo = any.get();

                // 工单数为0时，完成率也为0
                if (faultStatusVo.getAssignCount().equals(0)) {
                    faultStatusVo.setFinishRate(0D);
                } else {
                    faultStatusVo.setFinishRate(Double.valueOf(df.format(faultStatusVo.getFinishCount() * 100D / faultStatusVo.getAssignCount())));
                }

                // 完成数为0时，平均时长为空
                if (!faultStatusVo.getFinishCount().equals(0)) {
                    faultStatusVo.setAvg(Double.valueOf(df.format(faultStatusVo.getTotalRepairTime() / (faultStatusVo.getFinishCount() * 3600D))));
                }

                faultStatusVo.setArea(divideWork.getArea());
                statusList.add(faultStatusVo);
            } else {
                FaultStatusVo faultStatus = new FaultStatusVo();
                faultStatus.setArea(divideWork.getArea());
                statusList.add(faultStatus);
            }
        }

        return statusList;
    }

    /**
     * 根据时间范围获取不同故障状态数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<FaultStatusVo> selectFaultStatusByDate(Long pid, Long startDate, Long endDate) {

        // 不同故障状态的数量列表
        List<FaultStatusVo> faultStatusList = hswFaultInfoMapper.selectFaultStatusByDate(pid, startDate, endDate);

        // 该项目下所有分工
        List<HswDivideWork> hswDivideWorkList = hswDivideWorkMapper.selectHswDivideWorkByPid(pid);

        if (CollectionUtils.isEmpty(hswDivideWorkList)) {
            return new ArrayList<FaultStatusVo>();
        }

        DecimalFormat df = new DecimalFormat("#.00");

        List<FaultStatusVo> statusList = new ArrayList<>();
        for (HswDivideWork divideWork : hswDivideWorkList) {
            Optional<FaultStatusVo> any = faultStatusList.stream().filter(f -> divideWork.getId().equals(f.getDivideWorkId())).findAny();

            if (any.isPresent()) {
                FaultStatusVo faultStatusVo = any.get();

                // 工单数为0时，完成率也为0
                if (faultStatusVo.getAssignCount().equals(0)) {
                    faultStatusVo.setFinishRate(0D);
                } else {
                    faultStatusVo.setFinishRate(Double.valueOf(df.format(faultStatusVo.getFinishCount() * 100D / faultStatusVo.getAssignCount())));
                }

                // 完成数为0时，平均时长为空
                if (!faultStatusVo.getFinishCount().equals(0)) {
                    faultStatusVo.setAvg(Double.valueOf(df.format(faultStatusVo.getTotalRepairTime() / (faultStatusVo.getFinishCount() * 3600D))));
                }

                faultStatusVo.setArea(divideWork.getArea());
                statusList.add(faultStatusVo);
            } else {
                FaultStatusVo faultStatus = new FaultStatusVo();
                faultStatus.setArea(divideWork.getArea());
                statusList.add(faultStatus);
            }
        }

        return statusList;
    }

    @Override
    public List<SysUser> mtMan(Long id) {
        HswFaultInfo hswFaultInfo = this.hswFaultInfoMapper.selectHswFaultInfoById(id);
        return this.sysUserService.selectByMtId(hswFaultInfo.getMtId());
    }

    /**
     * 获取用户数据权限
     */
    public HswFaultInfo dataPermission(HswFaultInfo hswFaultInfo) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        //1=系统管理员用户；2=建设单位用户；3=运维单位用户
        switch (user.getType()) {
            case 2:
                // 建设单位id
                hswFaultInfo.setCuId(user.getConstructingUnitsId());
                break;
            case 3:
                // 运维单位id
                hswFaultInfo.setMuId(user.getMaintenanceUnitsId());
                if (user.getTeamId() != null && user.getTeamId() != 0) {
                    // 运维队id
                    hswFaultInfo.setMtId(user.getTeamId());
                }
                // 维修员id
                if (!user.getRoles().isEmpty()) {
                    user.getRoles().forEach(sysRole -> {
                        if (sysRole.getRoleId() == 7) {
                            hswFaultInfo.setReceiverId(user.getUserId());
                        }
                    });
                }
                break;
            default:
                break;
        }

        return hswFaultInfo;
    }

    /**
     * 查询活动故障信息列表
     *
     * @return 故障信息集合
     */
    @Override
    public List<HswFaultInfo> selectHswFaultInfoListByIp(String ip) {
        return this.hswFaultInfoMapper.selectHswFaultInfoListByIp(ip);
    }

    @Override
    public boolean isFaultExistsForIot(HswFaultInfo faultInfo) {
        return this.hswFaultInfoMapper.selectFaultExistsForIot(faultInfo) > 0;
    }

    /**
     * 获取故障视图列表
     *
     * @param faultViewPageableDto
     * @return
     */
    @Override
    public List<FaultViewDto> selectFaultViewList2(FaultViewPageableDto faultViewPageableDto) {
        return this.hswFaultInfoMapper.selectFaultViewList2(faultViewPageableDto);
    }

    @Override
    public boolean isFaultExistsForApi(HswFaultInfo faultInfo) {
        return this.hswFaultInfoMapper.selectFaultExistsForApi(faultInfo) > 0;
    }

    /**
     * 按小时分组统计故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<DeviceDateCountDto> selectFaultGroupHour(Long[] pids, Long startDate, Long endDate) {
        if (startDate == null || endDate == null) {
            return null;
        }

        return this.hswFaultInfoMapper.selectFaultGroupHour(pids, startDate, endDate);
    }

    @Override
    public List<FaultReportDto> selectFaultReportList(Long[] pids, Long startDate, Long endDate) {
        return this.hswFaultInfoMapper.selectFaultReportList(pids, startDate, endDate);
    }

    /**
     * 统计故障数量
     *
     * @param faultViewDto
     * @return
     */
    @Override
    public Integer selectFaultViewCount(FaultViewDto faultViewDto) {
        return this.hswFaultInfoMapper.selectFaultViewCount(faultViewDto);
    }
}
