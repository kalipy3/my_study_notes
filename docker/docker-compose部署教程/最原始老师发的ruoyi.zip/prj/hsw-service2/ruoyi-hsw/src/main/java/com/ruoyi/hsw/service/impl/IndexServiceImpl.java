package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.JobViewDto;
import com.ruoyi.hsw.dto.index.*;
import com.ruoyi.hsw.mapper.IndexMapper;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.hsw.service.IIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 描述:
 * 首页大屏
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 10:38
 */
@Service
@Transactional
public class IndexServiceImpl implements IIndexService {

    @Autowired
    private IndexMapper indexMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 近一周故障类型分布
     */
    @Override
    public FaultTypeDto faultTypeDistribution(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (7 * 24 * 60 * 60);
        equFaultPageableDto.setStartTime(startTime);
        equFaultPageableDto.setEndTime(endTime);
        return this.indexMapper.faultTypeDistribution(equFaultPageableDto);
    }

    /**
     * 近一周故障设备分布
     */
    @Override
    public FaultEquDto faultEquDistribution(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (7 * 24 * 60 * 60);
        equFaultPageableDto.setStartTime(startTime);
        equFaultPageableDto.setEndTime(endTime);
        return this.indexMapper.faultEquDistribution(equFaultPageableDto);
    }

    /**
     * 活动工单
     */
    @Override
    public List<JobViewDto> activeJobList(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        return this.indexMapper.activeJobList(equFaultPageableDto);
    }

    /**
     * 活动故障
     */
    @Override
    public List<FaultViewDto> activeFaultList(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        return this.indexMapper.activeFaultList(equFaultPageableDto);
    }

    /**
     * 频繁故障视点
     */
    @Override
    public List<FaultViewDto> frequentFaultSiteList(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        return this.indexMapper.frequentFaultSiteList(equFaultPageableDto);
    }

    /**
     * 实施项目数
     */
    @Override
    public Integer projectCount() {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            return pIds.size();
        }
        return 0;
    }

    @Override
    public Integer constructingUnitsCount() {
        List<Long> cuIds = this.hswProjectService.selectCuCount();
        if (!cuIds.isEmpty()) {
            return cuIds.size();
        }
        return 0;
    }

    /**
     * 近6个月工单统计
     */
    @Override
    public List<ChartDto> monthJobData() {

        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (6 * 30 * 24 * 60 * 60);
        return this.indexMapper.monthJobData(startTime, endTime);
    }

    /**
     * 近一个月维修队工单统计
     */
    @Override
    public List<JobMtDataDto> monthJobMtData(EquFaultPageableDto equFaultPageableDto) {

        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (30 * 24 * 60 * 60);
        equFaultPageableDto.setStartTime(startTime);
        equFaultPageableDto.setEndTime(endTime);
        return this.indexMapper.monthJobMtData(equFaultPageableDto);
    }

    /**
     * 近一周在线率（当天在线率获取最后一条数据）
     */
    @Override
    public List<FaultTypeDto> onlineRate(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }
        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (7 * 24 * 60 * 60);
        // long类型-开始时间
        equFaultPageableDto.setStartTime(startTime);
        // long类型-结束时间
        equFaultPageableDto.setEndTime(endTime);
        // Date类型-开始时间
        equFaultPageableDto.setStartDate(DateUtils.getSevenDays());
        // Date类型-结束时间
        equFaultPageableDto.setEndDate(new Date());
        List<FaultTypeDto> faultTypeDtos = this.indexMapper.onlineRate(equFaultPageableDto);
        if (!faultTypeDtos.isEmpty()) {
            Integer camers = this.indexMapper.cameraCount(equFaultPageableDto);
            faultTypeDtos.forEach(faultTypeDto -> {
                if (camers == 0) {
                    faultTypeDto.setOnlineRate(0D);
                } else {
                    faultTypeDto.setOnlineRate(100D * (camers - faultTypeDto.getCamera_fault_count()) / camers);
                }

                if (faultTypeDto.getOnlineRate() < 0) {
                    faultTypeDto.setOnlineRate(0D);
                }
            });
        }
        return faultTypeDtos;
    }

    /**
     * 设备数量
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public DeviceAreaDto deviceCount(EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        } else {
            List<Long> defaultPids = new ArrayList<>();
            defaultPids.add(-1L);

            equFaultPageableDto.setPIds(defaultPids);
        }

        // 默认省在江西
        equFaultPageableDto.setProvince(36);

        // 诊断器数量
        int diagnosisDeviceCount = this.indexMapper.diagnosisDeviceCount(equFaultPageableDto);

        // 光纤收发器数量
        int opticalTransceiverCount = this.indexMapper.opticalTransceiverCount(equFaultPageableDto);

        // 摄像机数量
        int cameraCount = this.indexMapper.cameraCount(equFaultPageableDto);

        // 其他设备数量
        int otherCount = this.indexMapper.otherDeviceCount(equFaultPageableDto);

        // 故障监视点数
        int cameraFaultCount = this.indexMapper.cameraFaultCount(equFaultPageableDto);

        // 正常监测点数
        int cameraOkCount;

        // 如果故障监视点数大于摄像机总数
        if (cameraFaultCount > cameraCount) {
            cameraFaultCount = cameraCount;
            cameraOkCount = 0;
        } else {
            cameraOkCount = cameraCount - cameraFaultCount;
        }

        DeviceAreaDto deviceAreaDto = new DeviceAreaDto();

        deviceAreaDto.setDiagnosisDeviceCount(diagnosisDeviceCount);
        deviceAreaDto.setOpticalTransceiverCount(opticalTransceiverCount);
        deviceAreaDto.setCameraCount(cameraCount);
        deviceAreaDto.setOtherCount(otherCount);
        deviceAreaDto.setCameraOkCount(cameraOkCount);
        deviceAreaDto.setCameraFaultCount(cameraFaultCount);
        DecimalFormat df = new DecimalFormat("#.0");
        deviceAreaDto.setOnlineRateEle(cameraCount == 0 ? 0D : Double.valueOf(df.format(cameraOkCount * 100D / cameraCount)));

        return deviceAreaDto;
    }

    /**
     * 根据市分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public List<CameraAreaDto> cameraCountGroupByCity(EquFaultPageableDto equFaultPageableDto) {
        // 默认省在江西
        equFaultPageableDto.setProvince(36);

        return this.indexMapper.cameraCountGroupByCity(equFaultPageableDto);
    }

    /**
     * 根据县/区分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public List<CameraAreaDto> cameraCountGroupByDistrict(EquFaultPageableDto equFaultPageableDto) {
        // 默认省在江西
//        equFaultPageableDto.setProvince(36);

        return this.indexMapper.cameraCountGroupByDistrict(equFaultPageableDto);
    }

    /**
     * 设备数量-App
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public DeviceAreaDto deviceCountForApi(EquFaultPageableDto equFaultPageableDto) {
        // 诊断器数量
        int diagnosisDeviceCount = this.indexMapper.diagnosisDeviceCount(equFaultPageableDto);

        // 光纤收发器数量
        int opticalTransceiverCount = this.indexMapper.opticalTransceiverCount(equFaultPageableDto);

        // 摄像机数量
        int cameraCount = this.indexMapper.cameraCount(equFaultPageableDto);

        // 其他设备数量
        int otherCount = this.indexMapper.otherDeviceCount(equFaultPageableDto);

        // 故障监视点数
        int cameraFaultCount = this.indexMapper.cameraFaultCount(equFaultPageableDto);

        // 正常监测点数
        int cameraOkCount;

        // 如果故障监视点数大于摄像机总数
        if (cameraFaultCount > cameraCount) {
            cameraFaultCount = cameraCount;
            cameraOkCount = 0;
        } else {
            cameraOkCount = cameraCount - cameraFaultCount;
        }

        DeviceAreaDto deviceAreaDto = new DeviceAreaDto();

        deviceAreaDto.setDiagnosisDeviceCount(diagnosisDeviceCount);
        deviceAreaDto.setOpticalTransceiverCount(opticalTransceiverCount);
        deviceAreaDto.setCameraCount(cameraCount);
        deviceAreaDto.setOtherCount(otherCount);
        deviceAreaDto.setCameraOkCount(cameraOkCount);
        deviceAreaDto.setCameraFaultCount(cameraFaultCount);

        DecimalFormat df = new DecimalFormat("#.0");
        deviceAreaDto.setOnlineRateEle(cameraCount == 0 ? 0D : Double.valueOf(df.format(cameraOkCount * 100D / cameraCount)));

        return deviceAreaDto;
    }

    /**
     * 故障趋势
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public List<FaultTypeDto> faultTrend(EquFaultPageableDto equFaultPageableDto) {
        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (7 * 24 * 60 * 60);
        // long类型-开始时间
        equFaultPageableDto.setStartTime(startTime);
        // long类型-结束时间
        equFaultPageableDto.setEndTime(endTime);
        // Date类型-开始时间
        equFaultPageableDto.setStartDate(DateUtils.getSevenDays());
        // Date类型-结束时间
        equFaultPageableDto.setEndDate(new Date());
        List<FaultTypeDto> faultTypeDtos = this.indexMapper.faultTrend(equFaultPageableDto);
        return faultTypeDtos;
    }

    /**
     * 绩效综合对比
     *
     * @param equFaultPageableDto
     * @return
     */
    @Override
    public List<PerformanceDto> performanceComparison(EquFaultPageableDto equFaultPageableDto) {

        Long endTime = DateUtils.getDateMr(new Date());
        Long startTime = endTime - (7 * 24 * 60 * 60);
        // long类型-开始时间
        equFaultPageableDto.setStartTime(startTime);
        // long类型-结束时间
        equFaultPageableDto.setEndTime(endTime);
        // Date类型-开始时间
        equFaultPageableDto.setStartDate(DateUtils.getSevenDays());
        // Date类型-结束时间
        equFaultPageableDto.setEndDate(new Date());

        List<PerformanceDto> performanceDtos = this.indexMapper.performanceComparison(equFaultPageableDto);
        if (!CollectionUtils.isEmpty(performanceDtos)) {
            performanceDtos.forEach(performanceDto -> {
                // 有效完成数
                performanceDto.setEffectiveOrder(performanceDto.getTotalOrder() - performanceDto.getRepairTimeoutCount());
                // 有效派单数
                performanceDto.setSendCount(performanceDto.getTotalOrder() - performanceDto.getSendTimeoutCount());

                // 维修效率
                if (performanceDto.getEffectiveOrder() == 0 || performanceDto.getTotalOrder() == 0) {
                    performanceDto.setRepairRate(0D);
                } else {
                    performanceDto.setRepairRate(Double.valueOf(String.format("%.2f", performanceDto.getEffectiveOrder() * 100d / performanceDto.getTotalOrder())));
                }
                // 派单效率
                if (performanceDto.getSendCount() == 0 || performanceDto.getTotalOrder() == 0) {
                    performanceDto.setSendRate(0D);
                } else {
                    performanceDto.setSendRate(Double.valueOf(String.format("%.2f", performanceDto.getSendCount() * 100d / performanceDto.getTotalOrder())));
                }
            });
        }

        return performanceDtos;
    }
}
