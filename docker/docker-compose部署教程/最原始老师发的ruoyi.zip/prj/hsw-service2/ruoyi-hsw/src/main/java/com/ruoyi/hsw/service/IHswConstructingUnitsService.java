package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswConstructingUnits;

import java.util.List;

/**
 * 建设单位Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswConstructingUnitsService {
    /**
     * 查询建设单位
     *
     * @param id 建设单位ID
     * @return 建设单位
     */
    public HswConstructingUnits selectHswConstructingUnitsById(Long id);

    /**
     * 查询建设单位列表
     *
     * @param hswConstructingUnits 建设单位
     * @return 建设单位集合
     */
    public List<HswConstructingUnits> selectHswConstructingUnitsList(HswConstructingUnits hswConstructingUnits);

    /**
     * 新增建设单位
     *
     * @param hswConstructingUnits 建设单位
     * @return 结果
     */
    public int insertHswConstructingUnits(HswConstructingUnits hswConstructingUnits);

    /**
     * 修改建设单位
     *
     * @param hswConstructingUnits 建设单位
     * @return 结果
     */
    public int updateHswConstructingUnits(HswConstructingUnits hswConstructingUnits);

    /**
     * 批量删除建设单位
     *
     * @param ids 需要删除的建设单位ID
     * @return 结果
     */
    public int deleteHswConstructingUnitsByIds(Long[] ids);

    /**
     * 删除建设单位信息
     *
     * @param id 建设单位ID
     * @return 结果
     */
    public int deleteHswConstructingUnitsById(Long id);

    /**
     * 通过当前登录用户获取id列表
     *
     * @return
     */
    public List<Long> findIdByUser();

    /**
     * 判断建设单位是否存在
     */
    public boolean existCount();
}
