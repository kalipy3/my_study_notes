package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 描述:
 * 光纤收发器故障
 *
 * @author xiongxiangpeng
 * @create 2020-11-18 15:47
 */
@Data
public class FaultOpticalTransceiverDto implements Serializable {

    // 主键
    private Long id;

    // 故障编号
    private String faultNo;

    // 视点位置
    private String regionName;

    // 视点IP
    private String ip;

    // 逻辑地址32位
    private String sn;

    // 端口号，非摄像机故障为0
    private Integer port;

    // 故障类型
    private String type;

    // 发生时间
    private Long takeTime;

    // 所属项目
    private Long pid;

    // 故障描述
    private String descr;

    // 故障状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
    private String status;

    // 归档状态（0=活动故障；1=历史故障；）
    private String flagStatus;

    // 修复时间
    private Long repairTime;

    // 对应工单id
    private Long jobId;

    // 对应工单编号
    private String jobNo;

    // 维修队id
    private Long mtId;

    // 来源于设备对应分工区域名称（乡镇/街道/小区），便于查询
    private String area;

    // 运维单位
    private Long muId;

    // 仅对摄像机故障有效，一天该摄像机发生的第几次故障
    private Long todayTakeCount;

    // 故障所属分工区域id
    private Long divideWorkId;

    // $column.columnComment
    private String opState;

    // 颠簸次数
    private Integer zigzagCount;

    // 影响摄像机数量
    private Integer influenceCameraCount;

    // 颠簸故障类型（同故障状态，除工作不稳定2种）
    private Integer zigzagType;

    // 颠簸状态（0=未处理；1=已处理）
    private Integer zigzagStatus;

    // 距离范围
    private Long timeoutLevel;

    // $column.columnComment
    private Integer startDistance;

    // $column.columnComment
    private Integer endDistance;

    // $column.columnComment
    private Integer timeoutHour;

    // $column.columnComment
    private Integer deviceDistance;

    // $column.columnComment
    private BigDecimal sendWorkOrderLimit;

    // 生产厂商
    private String manufacturer;

    // 维修时间
    private Long repairTimeCount;
}
