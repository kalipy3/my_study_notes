package com.ruoyi.hsw.domain.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 树形结构Vo
 *
 * @author zyj
 * @date 2020/11/20 11:59
 */
@Data
public class TreeVo implements Serializable {

    // id
    private Long id;

    // 标签名称
    private String label;

    // 类型
    private Integer type;

    // 标识
    private String code;

    // 经度
    private String longitude;

    // 纬度
    private String latitude;

    // 诊断器ip
    private String ip;

    // 子集
    private List<TreeVo> children;

}
