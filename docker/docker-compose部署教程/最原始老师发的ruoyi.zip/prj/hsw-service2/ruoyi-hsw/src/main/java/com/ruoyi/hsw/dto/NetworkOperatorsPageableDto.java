package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 网络运营商查询参数
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 16:58
 */
@Data
public class NetworkOperatorsPageableDto implements Serializable {

    // 分析类型(3=已修复，2=未修复)
    private Integer analysisType;

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 项目id
    private Long pid;

    // 修复时间
    private Double repaireHour;

    // 网络运营商
    private String communicationsOperations;

    // 项目id集合
    private List<Long> pIds;
}
