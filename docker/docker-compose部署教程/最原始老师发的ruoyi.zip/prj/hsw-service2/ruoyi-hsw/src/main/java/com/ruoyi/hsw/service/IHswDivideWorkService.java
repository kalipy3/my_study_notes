package com.ruoyi.hsw.service;

import java.util.List;

import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.vo.DivideWorkTreeVo;
import com.ruoyi.hsw.domain.vo.TreeVo;

/**
 * 分工职责Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswDivideWorkService {
    /**
     * 查询分工职责
     *
     * @param id 分工职责ID
     * @return 分工职责
     */
    public HswDivideWork selectHswDivideWorkById(Long id);

    /**
     * 查询分工职责列表
     *
     * @param hswDivideWork 分工职责
     * @return 分工职责集合
     */
    public List<HswDivideWork> selectHswDivideWorkList(HswDivideWork hswDivideWork);

    /**
     * 新增分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    public int insertHswDivideWork(HswDivideWork hswDivideWork);

    /**
     * 修改分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    public int updateHswDivideWork(HswDivideWork hswDivideWork);

    /**
     * 批量删除分工职责
     *
     * @param ids 需要删除的分工职责ID
     * @return 结果
     */
    public int deleteHswDivideWorkByIds(Long[] ids);

    /**
     * 删除分工职责信息
     *
     * @param id 分工职责ID
     * @return 结果
     */
    public int deleteHswDivideWorkById(Long id);

    /**
     * 判断区域是否存在(新增)
     */
    public boolean existArea(String area, Long pid);

    /**
     * 判断区域是否存在(编辑)
     */
    public boolean existAreaWithNeId(String area, Long pid, Long id);

    /**
     * 根据项目id查询分工
     *
     * @param pid
     * @return
     */
    public List<HswDivideWork> selectHswDivideWorkByPid(Long pid);

    /**
     * 根据项目id获取分工树形结构
     *
     * @return
     */
    public List<DivideWorkTreeVo> selectTreeByPid();

    /**
     * 通过项目列表获取分工
     *
     * @param pids
     * @return
     */
    public List<HswDivideWork> selectHswDivideWorkByPids(Long[] pids);

    /**
     * 根据项目获取分工树
     *
     * @return
     */
    public List<TreeVo> getTreeByPid();
}
