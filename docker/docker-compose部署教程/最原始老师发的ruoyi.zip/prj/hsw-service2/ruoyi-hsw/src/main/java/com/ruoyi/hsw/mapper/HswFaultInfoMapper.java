package com.ruoyi.hsw.mapper;

import java.util.List;
import java.util.Map;

import com.ruoyi.hsw.domain.HswFaultInfo;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.domain.vo.FaultStatusVo;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.index.DeviceDateCountDto;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 故障信息Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswFaultInfoMapper {
    /**
     * 查询故障信息
     *
     * @param id 故障信息ID
     * @return 故障信息
     */
    public HswFaultInfo selectHswFaultInfoById(Long id);

    /**
     * 查询活动故障信息列表
     *
     * @param hswFaultInfo 故障信息
     * @return 故障信息集合
     */
    public List<HswFaultInfo> selectHswFaultInfoList(HswFaultInfo hswFaultInfo);

    /**
     * 查询历史故障信息列表
     *
     * @param hswFaultInfo 故障信息
     * @return 故障信息集合
     */
    public List<HswFaultInfo> selectHistoryList(HswFaultInfo hswFaultInfo);


    /**
     * 新增故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    public int insertHswFaultInfo(HswFaultInfo hswFaultInfo);

    /**
     * 修改故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    public int updateHswFaultInfo(HswFaultInfo hswFaultInfo);

    /**
     * 删除故障信息
     *
     * @param id 故障信息ID
     * @return 结果
     */
    public int deleteHswFaultInfoById(Long id);

    /**
     * 批量删除故障信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswFaultInfoByIds(Long[] ids);

    /**
     * 根据项目id删除
     */
    public int deleteByPid(Long pid);

    /**
     * 更新故障信息
     *
     * @param updateFaultDto
     * @return
     */
    boolean updateHswFaultInfoByApi(UpdateFaultDto updateFaultDto);

    /**
     * 更新故障状态状态
     */
    int updateStatusById(@Param("id") Long id, @Param("status") Integer status, @Param("updateBy") String updateBy);

    /**
     * 活动故障 动态搜索条件：所属项目、时间范围、故障类型、故障状态(api调用)
     *
     * @param activeFaultPageableDto
     * @return
     */
    List<FaultViewDto> selectFaultViewListForApp(ActiveFaultPageableDto activeFaultPageableDto);


    /**
     * 根据项目id和时间范围获取故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultViewDto> selectFaultCountByPidsAndDate(@Param("pids") Long[] pids, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 根据时间范围获取故障设备数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultViewDto> selectFaultCountDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    List<HswFaultInfo> selectFaultInfoListByFaultInfoParamAppDto(FaultInfoParamAppDto faultInfoParamAppDto);


    /**
     * 根据项目id和时间范围获取不同故障类型数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatisticsVo> selectFaultTypeCountByPidsAndDate(@Param("pids") Long[] pids, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 根据时间范围获取不同故障类型数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatisticsVo> selectFaultTypeCountByDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 根据项目id获取不同故障类型数量
     */
    List<FaultStatisticsVo> selectFaultTypeCountByIp(@Param("ip") String ip);


    /**
     * 根据时间范围获取所有时间日期
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<String> selectDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);

    FaultViewDto selectFaultViewForRecoveryForApi(@Param("ip") String ip, @Param("port") Integer port, @Param("type") String type, @Param("zigzagType") Integer zigzagType);

    List<FaultViewDto> selectFaultViewList(FaultViewDto faultViewDto);

    FaultViewDto selectFaultViewById(Long id);

    /**
     * 根据项目id和时间范围获取不同故障状态数量
     *
     * @param pid
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatusVo> selectFaultStatusByPidAndDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 根据时间范围获取不同故障状态数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatusVo> selectFaultStatusByDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 获取故障视图列表
     *
     * @param faultViewPageableDto
     * @return
     */
    List<FaultViewDto> selectFaultViewList2(@Param("vo") FaultViewPageableDto faultViewPageableDto);

    /**
     * 指定IP，指定故障是否存在
     *
     * @param faultInfo
     * @return
     */
    Integer selectFaultExistsForApi(HswFaultInfo faultInfo);

    /**
     * 按小时分组统计故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<DeviceDateCountDto> selectFaultGroupHour(@Param("pids") Long[] pids, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 故障报告
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultReportDto> selectFaultReportList(@Param("pids") Long[] pids, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 统计故障数量
     *
     * @param faultViewDto
     * @return
     */
    Integer selectFaultViewCount(FaultViewDto faultViewDto);

    /**
     * 根据ip查询活动故障信息列表
     *
     * @return 故障信息集合
     */
    List<HswFaultInfo> selectHswFaultInfoListByIp(@Param("ip") String ip);

    /**
     * 根据ip查询发生故障数
     */
    int selectCountByIp(@Param("ip") String ip);

    /**
     * 指定IP，指定故障是否存在
     *
     * @param faultInfo
     * @return
     */
    Integer selectFaultExistsForIot(HswFaultInfo faultInfo);
}
