package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.domain.HswMaintenanceTeam;
import com.ruoyi.hsw.mapper.HswMaintenanceTeamMapper;
import com.ruoyi.hsw.service.IHswMaintenanceTeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 维修队Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswMaintenanceTeamServiceImpl implements IHswMaintenanceTeamService {
    @Autowired
    private HswMaintenanceTeamMapper hswMaintenanceTeamMapper;

    /**
     * 查询维修队
     *
     * @param id 维修队ID
     * @return 维修队
     */
    @Override
    public HswMaintenanceTeam selectHswMaintenanceTeamById(Long id) {
        return hswMaintenanceTeamMapper.selectHswMaintenanceTeamById(id);
    }

    /**
     * 查询维修队列表
     *
     * @param hswMaintenanceTeam 维修队
     * @return 维修队
     */
    @Override
    public List<HswMaintenanceTeam> selectHswMaintenanceTeamList(HswMaintenanceTeam hswMaintenanceTeam) {
        return hswMaintenanceTeamMapper.selectHswMaintenanceTeamList(hswMaintenanceTeam);
    }

    @Override
    public boolean selectHswMaintenanceTeamCountByMuId(Long muId) {
        return hswMaintenanceTeamMapper.selectHswMaintenanceTeamCountByMuId(muId) > 0;
    }

    /**
     * 新增维修队
     *
     * @param hswMaintenanceTeam 维修队
     * @return 结果
     */
    @Override
    public int insertHswMaintenanceTeam(HswMaintenanceTeam hswMaintenanceTeam) {
        hswMaintenanceTeam.setCreateTime(DateUtils.getNowDate());
        return hswMaintenanceTeamMapper.insertHswMaintenanceTeam(hswMaintenanceTeam);
    }

    /**
     * 修改维修队
     *
     * @param hswMaintenanceTeam 维修队
     * @return 结果
     */
    @Override
    public int updateHswMaintenanceTeam(HswMaintenanceTeam hswMaintenanceTeam) {
        hswMaintenanceTeam.setUpdateTime(DateUtils.getNowDate());
        return hswMaintenanceTeamMapper.updateHswMaintenanceTeam(hswMaintenanceTeam);
    }

    /**
     * 批量删除维修队
     *
     * @param ids 需要删除的维修队ID
     * @return 结果
     */
    @Override
    public int deleteHswMaintenanceTeamByIds(Long[] ids) {
        return hswMaintenanceTeamMapper.deleteHswMaintenanceTeamByIds(ids);
    }

    /**
     * 删除维修队信息
     *
     * @param id 维修队ID
     * @return 结果
     */
    @Override
    public int deleteHswMaintenanceTeamById(Long id) {
        return hswMaintenanceTeamMapper.deleteHswMaintenanceTeamById(id);
    }

    /**
     * 判断维修队名称是否存在
     */
    @Override
    public boolean existName(String name) {
        return this.hswMaintenanceTeamMapper.selectCountByName(name) > 0;
    }

    /**
     * 判断维修队是否存在
     */
    @Override
    public boolean existCount() {
        return this.hswMaintenanceTeamMapper.selectCount() > 0;
    }
}
