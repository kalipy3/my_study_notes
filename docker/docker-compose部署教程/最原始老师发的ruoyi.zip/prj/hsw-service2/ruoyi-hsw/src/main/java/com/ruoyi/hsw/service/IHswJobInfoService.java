package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswJobInfo;
import com.ruoyi.hsw.domain.vo.JobStaffStatisticsVo;
import com.ruoyi.hsw.domain.vo.JobTeamStatisticsVo;
import com.ruoyi.hsw.dto.JobViewDto;

import java.util.List;
import java.util.Map;

/**
 * 工单Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswJobInfoService {
    /**
     * 查询工单
     *
     * @param id 工单ID
     * @return 工单
     */
    public HswJobInfo selectHswJobInfoById(Long id);

    /**
     * 查询活动工单列表
     *
     * @param hswJobInfo 工单
     * @return 工单集合
     */
    public List<HswJobInfo> selectHswJobInfoList(HswJobInfo hswJobInfo);

    /**
     * 查询历史工单列表
     */
    public List<HswJobInfo> selectHistoryList(HswJobInfo hswJobInfo);

    /**
     * 新增工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    public int insertHswJobInfo(HswJobInfo hswJobInfo);

    /**
     * 修改工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    public int updateHswJobInfo(HswJobInfo hswJobInfo);

    /**
     * 批量删除工单
     *
     * @param ids 需要删除的工单ID
     * @return 结果
     */
    public int deleteHswJobInfoByIds(Long[] ids);

    /**
     * 删除工单信息
     *
     * @param id 工单ID
     * @return 结果
     */
    public int deleteHswJobInfoById(Long id);

    /**
     * 根据故障id判断是否存在
     */
    public boolean existFaultId(Long faultId);

    /**
     * 接单
     */
    public int accept(HswJobInfo hswJobInfo);

    /**
     * 拒绝派单
     */
    public int refuse(HswJobInfo hswJobInfo);

    /**
     * 申请改派
     */
    public Map<String, Object> applyChangeAssign(HswJobInfo hswJobInfo);

    /**
     * 改派工单
     */
    public Map<String, Object> reAssign(HswJobInfo hswJobInfo, Long receiverId);

    /**
     * 拒绝改派
     */
    public Map<String, Object> refuseAssign(HswJobInfo hswJobInfo);

    /**
     * 维修员维修后反馈
     */
    public Map<String, Object> repair(HswJobInfo hswJobInfo);

    /**
     * 申请挂起
     */
    public Map<String, Object> applyHangUp(HswJobInfo hswJobInfo);

    /**
     * 0=未派单；1=待接单；2=在修； 3=已修复；4=挂起
     * 挂起工单
     */
    public Map<String, Object> hangUp(HswJobInfo hswJobInfo);

    /**
     * 0=未派单；1=待接单；2=在修； 3=已修复；4=挂起
     * 拒绝挂起工单
     */
    public Map<String, Object> refuseHangUp(HswJobInfo hswJobInfo);

    /**
     * 撤回挂起
     */
    public Map<String, Object> resume(HswJobInfo hswJobInfo);

    /**
     * 撤销工单
     */
    public Map<String, Object> revoke(HswJobInfo hswJobInfo);

    /**
     * 从视图取列表
     *
     * @return
     */
    List<JobViewDto> selectJobViewList(JobViewDto jobViewDto);

    /**
     * 从视图取
     *
     * @return
     */
    JobViewDto selectJobViewById(Long id);

    /**
     * app改派工单 同意
     */
    Map<String, Object> changeAssignForApp(Long id, Long userId, Long receiverId, String reason, String nickName);

    /**
     * app改派工单 拒绝
     */
    Map<String, Object> refuseChangeAssignForApp(Long id, String reason, Long userId, String nickName);

    /**
     * app申请改派
     */
    Map<String, Object> applyChangeAssignForApp(Long id, Long userId, String nickName, String handleReason);

    /**
     * app申请挂起
     */
    Map<String, Object> applyHangUpForApp(Long id, Long userId, String nickName, String handleReason);

    /**
     * app挂起 同意
     */
    Map<String, Object> hangUpForApp(Long id, Long userId, String nickName, String reason);

    /**
     * app挂起 拒绝
     */
    Map<String, Object> refuseHangUpForApp(Long id, Long userId, String nickName, String reason);

    /**
     * app撤回挂起
     */
    Map<String, Object> resumeForApp(Long id, Long userId, String nickName, String reason, Long receiverId);

    /**
     * 撤销工单
     */
    Map<String, Object> revokeForApp(Long id, Long userId, String nickName, String handleReason);

    /**
     * 结单
     */
    Map<String, Object> repairForApp(Long id, Long userId, String nickName, String repairRecord);

    /**
     * 根据维修队和运维单位分组，通过分工id和时间范围查询维修队工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobTeamStatisticsVo> selectJobTeamByDivideWorkIdsAndDate(Long[] divideWorkIds,
                                                                         Long startDate,
                                                                         Long endDate);

    /**
     * 根据维修队和运维单位分组，通过分工id和时间范围查询维修队工单统计信息
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobTeamStatisticsVo> selectJobTeamByDate(Long pid, Long startDate, Long endDate);

    /**
     * 根据维修队和运维单位和维修员工分组，通过分工id和时间范围查询维修队员工工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobStaffStatisticsVo> selectJobStaffByDivideWorkIdsAndDate(Long[] divideWorkIds,
                                                                           Long startDate,
                                                                           Long endDate);

    /**
     * 根据维修队和运维单位和维修员工分组，通过时间范围查询维修队员工工单统计信息
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobStaffStatisticsVo> selectJobStaffByDate(Long pid, Long startDate, Long endDate);

    /**
     * 统计工单数量
     *
     * @param jobViewDto
     * @return
     */
    Integer selectJobViewCount(JobViewDto jobViewDto);

    /**
     * 推送消息通知
     *
     * @param tplKey 消息模版key 见系统配置
     * @param args   需要替换的参数  必须带有工单号
     */
    public void sendMsg(String tplKey, Map<String, Object> args);

    /**
     * 查询活动工单列表
     *
     * @return 工单集合
     */
    public List<HswJobInfo> selectHswJobInfoListByIp(String ip);
}
