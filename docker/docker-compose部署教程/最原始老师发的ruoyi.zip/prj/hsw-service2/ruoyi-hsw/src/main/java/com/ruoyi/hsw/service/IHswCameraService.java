package com.ruoyi.hsw.service;

import java.util.List;

import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.dto.CameraViewDto;

/**
 * 摄像机Service接口
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public interface IHswCameraService {
    /**
     * 查询摄像机
     *
     * @param id 摄像机ID
     * @return 摄像机
     */
    public HswCamera selectHswCameraById(Long id);

    /**
     * 查询摄像机列表
     *
     * @param hswCamera 摄像机
     * @return 摄像机集合
     */
    public List<HswCamera> selectHswCameraList(HswCamera hswCamera);

    /**
     * 新增摄像机
     *
     * @param hswCamera 摄像机
     * @return 结果
     */
    public int insertHswCamera(HswCamera hswCamera);

    /**
     * 修改摄像机
     *
     * @param hswCamera 摄像机
     * @return 结果
     */
    public int updateHswCamera(HswCamera hswCamera);

    /**
     * 批量删除摄像机
     *
     * @param ids 需要删除的摄像机ID
     * @return 结果
     */
    public int deleteHswCameraByIds(Long[] ids);

    /**
     * 删除摄像机信息
     *
     * @param id 摄像机ID
     * @return 结果
     */
    public int deleteHswCameraById(Long id);

    /**
     * 通过所属诊断器ip删除摄像机
     *
     * @param ip
     * @return
     */
    public int deleteHswCameraByIp(String ip);

    /**
     * 根据所属诊断器ip获取摄像机数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    public int selectCameraCountByIp(String ip);

    /**
     * 校验自身IP是否唯一
     *
     * @param hswCamera
     * @return
     */
    public String checkSelfIpUnique(HswCamera hswCamera);

    /**
     * 根据诊断器ip校验端口号是否唯一
     *
     * @param hswCamera
     * @return
     */
    public String checkPortUniqueByIp(HswCamera hswCamera);

    /**
     * 导入摄像机数据
     *
     * @param list     摄像机列表
     * @param operName 操作用户
     * @return 结果
     */
    public String importCamera(List<HswCamera> list, String operName);

    /**
     * 校验
     *
     * @param hswCamera
     * @param list
     * @return
     */
    public String checkValid(HswCamera hswCamera, List<HswCamera> list);

    /**
     * 根据所属诊断器ip和端口号查询摄像机
     *
     * @param ip
     * @param port
     * @return
     */
    public HswCamera selectHswCameraByIpAndPort(String ip, String port);

    /**
     * 查询VIEW
     *
     * @param id VIEWID
     * @return VIEW
     **/
    CameraViewDto selectCameraViewById(Long id);

    /**
     * 查询VIEW列表
     *
     * @param cameraView VIEW
     * @return VIEW集合
     */
    public List<CameraViewDto> selectCameraViewList(CameraViewDto cameraView);

    CameraViewDto selectCameraViewByIpAndPortForApp(String ip, Integer port);

    List<CameraViewDto> selectCameraViewListByIpAndPortForApp(String ip, Integer port);

    /**
     * 根据摄像机ip更新经纬度
     *
     * @param selfIp
     * @param longitude
     * @param latitude
     * @return
     */
    int updateHswCameraBySelfIp(String selfIp, String longitude, String latitude);

    /**
     * 根据诊断器ip更新经纬度
     *
     * @param ip
     * @param longitude
     * @param latitude
     * @return
     */
    int updateHswCameraByIp(String ip, String longitude, String latitude);

    /**
     * 根据所属诊断器ip查询摄像机列表
     *
     * @param ip
     * @return
     */
    public List<HswCamera> selectCameraListByIp(String ip);
}
