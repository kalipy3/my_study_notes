package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswMaintenanceTeam;

import java.util.List;

/**
 * 维修队Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswMaintenanceTeamService {
    /**
     * 查询维修队
     *
     * @param id 维修队ID
     * @return 维修队
     */
    public HswMaintenanceTeam selectHswMaintenanceTeamById(Long id);

    /**
     * 查询维修队列表
     *
     * @param hswMaintenanceTeam 维修队
     * @return 维修队集合
     */
    public List<HswMaintenanceTeam> selectHswMaintenanceTeamList(HswMaintenanceTeam hswMaintenanceTeam);

    /**
     * 根据运维单位取维修队数量
     *
     * @param muId
     * @return
     */
    public boolean selectHswMaintenanceTeamCountByMuId(Long muId);

    /**
     * 新增维修队
     *
     * @param hswMaintenanceTeam 维修队
     * @return 结果
     */
    public int insertHswMaintenanceTeam(HswMaintenanceTeam hswMaintenanceTeam);

    /**
     * 修改维修队
     *
     * @param hswMaintenanceTeam 维修队
     * @return 结果
     */
    public int updateHswMaintenanceTeam(HswMaintenanceTeam hswMaintenanceTeam);

    /**
     * 批量删除维修队
     *
     * @param ids 需要删除的维修队ID
     * @return 结果
     */
    public int deleteHswMaintenanceTeamByIds(Long[] ids);

    /**
     * 删除维修队信息
     *
     * @param id 维修队ID
     * @return 结果
     */
    public int deleteHswMaintenanceTeamById(Long id);

    /**
     * 判断维修队名称是否存在
     */
    public boolean existName(String name);

    /**
     * 判断维修队是否存在
     */
    public boolean existCount();
}
