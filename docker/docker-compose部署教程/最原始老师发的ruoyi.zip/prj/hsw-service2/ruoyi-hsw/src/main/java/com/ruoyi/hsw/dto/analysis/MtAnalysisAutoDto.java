package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 运维队分析-自动恢复
 *
 * @author xiongxiangpeng
 */
@Data
public class MtAnalysisAutoDto implements Serializable {

    // 分工区域
    private String area;

    // 项目id
    private Long pid;

    // 项目名称
    @Excel(name = "项目分工", sort = 2)
    private String projectTitle;

    // 运维单位id
    private Long muId;

    // 运维单位名称
    private String maintenanceUnitsName;

    // 维修队id
    private Long mtId;

    // 运维队名称
    @Excel(name = "运维队", sort = 1)
    private String maintenanceTeamName;

    // 故障总数
    @Excel(name = "故障总数", sort = 3)
    private Integer totalFault=0;

    // 自动修复数
    @Excel(name = "自动修复数", sort = 4)
    private Integer autoRepairCount=0;

    // 总自动修复时长
    private Long totalAutoRepairTime=0L;

    // 平均修复时长(小时)
    @Excel(name = "平均修复时长(小时)", sort = 5)
    private Double repairAvg=0D;

    // 维修效率
    private Double repairRate=0D;

    // 维修效率 + %
    @Excel(name = "占比", sort = 6)
    private String repairRateString;
}
