package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 工单饼状图
 *
 * @author xiongxiangpeng
 * @create 2020-11-18 10:29
 */
@Data
public class PicChartDto implements Serializable {

    // 市电断电故障
    private Integer type1Count;

    // 光纤链路故障
    private Integer type2Count;

    // 光纤收发器故障
    private Integer type3Count;

    // 摄像机故障
    private Integer type5Count;

    // 主光缆故障
    private Integer type6Count;

    // 诊断器故障
    private Integer type7Count;

    // 工作不稳定
    private Integer type9Count;

    // ONU链路故障
    private Integer type11Count;
}
