package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.domain.HswSysMsg;
import com.ruoyi.hsw.mapper.HswSysMsgMapper;
import com.ruoyi.hsw.mapper.HswUserMsgMapper;
import com.ruoyi.hsw.service.IHswSysMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 系统消息Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswSysMsgServiceImpl implements IHswSysMsgService {
    @Autowired
    private HswSysMsgMapper hswSysMsgMapper;

    @Autowired
    private HswUserMsgMapper hswUserMsgMapper;

    /**
     * 查询系统消息
     *
     * @param id 系统消息ID
     * @return 系统消息
     */
    @Override
    public HswSysMsg selectHswSysMsgById(Long id) {
        return hswSysMsgMapper.selectHswSysMsgById(id);
    }

    /**
     * 查询系统消息列表
     *
     * @param hswSysMsg 系统消息
     * @return 系统消息
     */
    @Override
    public List<HswSysMsg> selectHswSysMsgList(HswSysMsg hswSysMsg) {
        return hswSysMsgMapper.selectHswSysMsgList(hswSysMsg);
    }

    /**
     * 新增系统消息
     *
     * @param hswSysMsg 系统消息
     * @return 结果
     */
    @Override
    public int insertHswSysMsg(HswSysMsg hswSysMsg) {
        hswSysMsg.setCreateTime(DateUtils.getNowDate());
        return hswSysMsgMapper.insertHswSysMsg(hswSysMsg);
    }

    /**
     * 修改系统消息
     *
     * @param hswSysMsg 系统消息
     * @return 结果
     */
    @Override
    public int updateHswSysMsg(HswSysMsg hswSysMsg) {
        hswSysMsg.setUpdateTime(DateUtils.getNowDate());
        return hswSysMsgMapper.updateHswSysMsg(hswSysMsg);
    }

    /**
     * 批量删除系统消息
     *
     * @param ids 需要删除的系统消息ID
     * @return 结果
     */
    @Override
    public int deleteHswSysMsgByIds(Long[] ids) {
        return hswSysMsgMapper.deleteHswSysMsgByIds(ids);
    }

    /**
     * 删除系统消息信息
     *
     * @param id 系统消息ID
     * @return 结果
     */
    @Override
    public int deleteHswSysMsgById(Long id) {
        int result = hswSysMsgMapper.deleteHswSysMsgById(id);
        if (result > 0) {
            this.hswUserMsgMapper.deleteHswUserMsgById(id);
        }
        return result;
    }
}
