package com.ruoyi.hsw.commonEnum;

/**
 * 描述:
 * 故障类型
 *
 * @author xiongxiangpeng
 * @create 2020-12-17 11:49
 */
public enum FaultTypeEnum {

    SDDD(1, "市电断电"),
    GQLL(2, "光纤链路故障"),
    GQSFQ(3, "光纤收发器故障"),
    SXJLL(4, "摄像机链路故障"),
    SXJ(5, "摄像机故障"),
    ZGL(6, "主光缆故障"),
    ZDQ(7, "诊断器故障"),
    ZDXHSCBZC(8, "诊断信号输出不正常"),
    GZBWD(9, "工作不稳定"),
    GZBWD_DQGZ(10, "工作不稳定-当前故障"),
    ONULL(11, "ONU链路故障"),
    ZDQDYSPQ(12, "诊断器电源适配器故障"),
    SXJLLZDXHBZC(13, "摄像机链路诊断信号不正常"),
    GQLLZDXHSCBZC(14, "光纤链路诊断信号输出不正常");

    private Integer value;
    private String label;

    FaultTypeEnum(Integer value, String label) {
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getLabel() {
        return this.label;
    }
}
