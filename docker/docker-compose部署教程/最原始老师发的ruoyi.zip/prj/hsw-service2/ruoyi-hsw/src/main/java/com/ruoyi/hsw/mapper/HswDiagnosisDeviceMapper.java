package com.ruoyi.hsw.mapper;

import java.util.List;

import com.ruoyi.hsw.domain.vo.TreeVo;
import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.DiagnosisDeviceViewDto;
import org.apache.ibatis.annotations.Param;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;

/**
 * 诊断器Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-05
 */
public interface HswDiagnosisDeviceMapper {
    /**
     * 查询诊断器
     *
     * @param id 诊断器ID
     * @return 诊断器
     */
    public HswDiagnosisDevice selectHswDiagnosisDeviceById(Long id);

    /**
     * 查询诊断器列表
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 诊断器集合
     */
    public List<HswDiagnosisDevice> selectHswDiagnosisDeviceList(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 新增诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    public int insertHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 修改诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    public int updateHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 删除诊断器
     *
     * @param id 诊断器ID
     * @return 结果
     */
    public int deleteHswDiagnosisDeviceById(Long id);

    /**
     * 批量删除诊断器
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswDiagnosisDeviceByIds(Long[] ids);

    /**
     * 校验ip地址是否唯一
     *
     * @param ip
     * @return
     */
    public HswDiagnosisDevice checkIpUnique(String ip);

    /**
     * 根据ip修改诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    public int updateHswDiagnosisDeviceByIp(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 根据ip查询诊断器
     *
     * @param ip
     * @return
     */
    public HswDiagnosisDevice selectHswDiagnosisDeviceByIp(String ip);

    /**
     * 项目竣工添加安装时间
     */
    public int finish(@Param("pid") Long pid, @Param("time") Long time);

    /**
     * 根据项目id删除
     */
    public int deleteByPid(Long pid);

    /**
     * 根据项目id分组统计诊断器和相关设备数量
     *
     * @param pids
     * @return
     */
    public List<DeviceCountDto> selectGroupByPidCount(Long[] pids);

    /**
     * 统计设备信息
     *
     * @return
     */
    public List<DeviceCountDto> selectGroupCount(Long pid);

    /**
     * 根据项目id统计诊断器总数
     *
     * @param pids
     * @return
     */
    public int selectCountByPid(Long[] pids);

    List<DiagnosisDeviceViewDto> selectDiagnosisDeviceViewList(DiagnosisDeviceViewDto diagnosisDeviceViewDto);

    DiagnosisDeviceViewDto selectDiagnosisDeviceViewById(Long id);

    List<DeviceCountDto> selectDeviceCountList(@Param("pids") Long[] pids);

    /**
     * 校验逻辑地址是否唯一
     *
     * @param logicalAddr
     * @return
     */
    public HswDiagnosisDevice checkLogicalAddrUnique(String logicalAddr);

    /**
     * 根据项目id查询分工树
     *
     * @param pid
     * @return
     */
    public List<TreeVo> selectTreeByPid(Long pid);

}
