package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.exception.CustomException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.domain.vo.TreeVo;
import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.DiagnosisDeviceViewDto;
import com.ruoyi.hsw.mapper.*;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 诊断器Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-05
 */
@Service
@Transactional
public class HswDiagnosisDeviceServiceImpl implements IHswDiagnosisDeviceService {

    private static final Logger log = LoggerFactory.getLogger(HswDiagnosisDevice.class);

    @Autowired
    private HswDiagnosisDeviceMapper hswDiagnosisDeviceMapper;

    @Autowired
    private HswCameraMapper hswCameraMapper;

    @Autowired
    private HswOpticalTransceiverMapper hswOpticalTransceiverMapper;

    @Autowired
    private HswOtherDeviceMapper hswOtherDeviceMapper;

    @Autowired
    private HswDivideWorkMapper hswDivideWorkMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private HswProjectMapper hswProjectMapper;

    @Autowired
    private HswFaultInfoMapper hswFaultInfoMapper;

    /**
     * 查询诊断器
     *
     * @param id 诊断器ID
     * @return 诊断器
     */
    @Override
    public HswDiagnosisDevice selectHswDiagnosisDeviceById(Long id) {
        HswDiagnosisDevice hswDiagnosisDevice = hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceById(id);

        if (StringUtils.isNotNull(hswDiagnosisDevice)) {
            HswDivideWork hswDivideWork = this.hswDivideWorkMapper.selectHswDivideWorkById(hswDiagnosisDevice.getDivideWorkId());
            if (StringUtils.isNotNull(hswDivideWork)) {
                if (StringUtils.isNotNull(hswDivideWork.getMaintenanceUnits())) {
                    hswDiagnosisDevice.setMuName(hswDivideWork.getMaintenanceUnits().getName());
                }
                if (StringUtils.isNotNull(hswDivideWork.getMaintenanceTeam())) {
                    hswDiagnosisDevice.setMtName(hswDivideWork.getMaintenanceTeam().getName());
                }
            }
            HswProject hswProject = this.hswProjectMapper.selectHswProjectById(hswDiagnosisDevice.getPid());
            if (StringUtils.isNotNull(hswProject)) {
                if (StringUtils.isNotNull(hswProject.getConstructingUnits())) {
                    hswDiagnosisDevice.setCuName(hswProject.getConstructingUnits().getName());
                }
            }

            // 发生故障数
            int faultCount = this.hswFaultInfoMapper.selectCountByIp(hswDiagnosisDevice.getIp());
            hswDiagnosisDevice.setFaultCount(faultCount);
        }

        return hswDiagnosisDevice;
    }

    /**
     * 查询诊断器列表
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 诊断器
     */
    @Override
    public List<HswDiagnosisDevice> selectHswDiagnosisDeviceList(HswDiagnosisDevice hswDiagnosisDevice) {
        return hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
    }

    /**
     * 新增诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    @Override
    public int insertHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice) {
        hswDiagnosisDevice.setCameraCount(0);
        hswDiagnosisDevice.setCreateTime(DateUtils.getNowDate());
        return hswDiagnosisDeviceMapper.insertHswDiagnosisDevice(hswDiagnosisDevice);
    }

    /**
     * 修改诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    @Override
    public int updateHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice) {

        // 原诊断器数据
        HswDiagnosisDevice srcDiagnosisDevice = this.selectHswDiagnosisDeviceById(hswDiagnosisDevice.getId());

        if (srcDiagnosisDevice != null) {
            // 修改了ip时
            if (!srcDiagnosisDevice.getIp().equals(hswDiagnosisDevice.getIp())) {
                // 修改该诊断器下摄像头的所属诊断器ip
                this.hswCameraMapper.updateIpByIp(hswDiagnosisDevice.getIp(), srcDiagnosisDevice.getIp());
                // 修改该诊断器下光纤收发器的所属诊断器ip
                this.hswOpticalTransceiverMapper.updateIpByIp(hswDiagnosisDevice.getIp(), srcDiagnosisDevice.getIp());
                // 修改该诊断器下其他设备的所属诊断器ip
                this.hswOtherDeviceMapper.updateIpByIp(hswDiagnosisDevice.getIp(), srcDiagnosisDevice.getIp());
            }

            hswDiagnosisDevice.setUpdateTime(DateUtils.getNowDate());
            return hswDiagnosisDeviceMapper.updateHswDiagnosisDevice(hswDiagnosisDevice);
        }

        return 0;
    }

    /**
     * 批量删除诊断器
     *
     * @param ids 需要删除的诊断器ID
     * @return 结果
     */
    @Override
    public int deleteHswDiagnosisDeviceByIds(Long[] ids) {
        return hswDiagnosisDeviceMapper.deleteHswDiagnosisDeviceByIds(ids);
    }

    /**
     * 删除诊断器信息
     *
     * @param id 诊断器ID
     * @return 结果
     */
    @Override
    public int deleteHswDiagnosisDeviceById(Long id) {
        return hswDiagnosisDeviceMapper.deleteHswDiagnosisDeviceById(id);
    }

    /**
     * 校验ip是否唯一
     *
     * @param hswDiagnosisDevice
     * @return
     */
    @Override
    public String checkIpUnique(HswDiagnosisDevice hswDiagnosisDevice) {

        Long id = StringUtils.isNull(hswDiagnosisDevice.getId()) ? -1L : hswDiagnosisDevice.getId();
        HswDiagnosisDevice info = hswDiagnosisDeviceMapper.checkIpUnique(hswDiagnosisDevice.getIp());
        if (StringUtils.isNotNull(info) && info.getId().longValue() != id.longValue()) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }

    /**
     * 根据ip查询诊断器
     *
     * @param ip
     * @return
     */
    @Override
    public HswDiagnosisDevice selectHswDiagnosisDeviceByIp(String ip) {
        if (StringUtils.isNotEmpty(ip)) {
            return hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(ip);
        }
        return null;
    }

    /**
     * 根据项目id删除
     *
     * @param pid
     * @return
     */
    @Override
    public int deleteByPid(Long pid) {

        // 删除摄像机
        hswCameraMapper.deleteHswCameraByPid(pid);
        // 删除光纤机
        hswOpticalTransceiverMapper.deleteHswOpticalTransceiverByPid(pid);
        // 删除其他设备
        hswOtherDeviceMapper.deleteHswOtherDeviceByPid(pid);

        return hswDiagnosisDeviceMapper.deleteByPid(pid);
    }

    @Override
    public int finish(Long pid, Long time) {
        return hswDiagnosisDeviceMapper.finish(pid, time);
    }

    /**
     * 导入诊断器数据
     *
     * @param list            诊断器列表
     * @param isUpdateSupport 是否更新支持，如果已存在，则进行更新数据
     * @param operName        操作用户
     * @param pid             所属项目id
     * @return
     */
    @Override
    public String importDiagnosisDevice(List<HswDiagnosisDevice> list, Boolean isUpdateSupport, String operName, Long pid) {
        if (StringUtils.isNull(list) || list.size() == 0) {
            throw new CustomException("导入诊断器数据不能为空！");
        }
        int successNum = 0;
        int failureNum = 0;
        int index = 1;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        for (HswDiagnosisDevice diagnosisDevice : list) {
            try {
                index++;
                String validMsg = this.checkValid(diagnosisDevice, pid);
                if (StringUtils.isNotEmpty(validMsg)) {
                    failureNum++;
                    failureMsg.append("<br/>第" + index + "项" + validMsg);
                } else {
                    // 验证是否存在这个诊断器ip
                    HswDiagnosisDevice d = hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(diagnosisDevice.getIp());
                    if (StringUtils.isNull(d)) {
                        diagnosisDevice.setPid(pid);
                        diagnosisDevice.setCreateBy(operName);
                        diagnosisDevice.setInstallTime(DateUtils.getDateMr(diagnosisDevice.getInstallDate()));
                        this.insertHswDiagnosisDevice(diagnosisDevice);
                        successNum++;
                        successMsg.append("<br/>" + index + "、ip " + diagnosisDevice.getIp() + " 导入成功");
                    } else if (isUpdateSupport) {
                        diagnosisDevice.setPid(pid);
                        diagnosisDevice.setId(d.getId());
                        diagnosisDevice.setUpdateBy(operName);
                        diagnosisDevice.setInstallTime(DateUtils.getDateMr(diagnosisDevice.getInstallDate()));
                        this.updateHswDiagnosisDevice(diagnosisDevice);
                        successNum++;
                        successMsg.append("<br/>" + index + "、ip " + diagnosisDevice.getIp() + " 更新成功");
                    } else {
                        failureNum++;
                        failureMsg.append("<br/>" + index + "、ip " + diagnosisDevice.getIp() + " 已存在");
                    }
                }
            } catch (Exception e) {
                failureNum++;
                String msg = "<br/>" + index + "、ip " + diagnosisDevice.getIp() + " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                log.error(msg, e);
            }
        }
        if (failureNum > 0) {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            throw new CustomException(failureMsg.toString());
        } else {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }

    /**
     * 校验
     *
     * @param hswDiagnosisDevice
     * @return
     */
    @Override
    public String checkValid(HswDiagnosisDevice hswDiagnosisDevice, Long pid) {

        StringBuilder validMsg = new StringBuilder();

        if (hswDiagnosisDevice == null) {
            validMsg.append("<br/>" + "诊断器不能为空");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getWorkAddress())) {
            return "所属分工不能为空";
        }

        // 判断所属分工是否存在
        HswDivideWork hswDivideWork = hswDivideWorkMapper.selectHswDivideWorkByArea(hswDiagnosisDevice.getWorkAddress(), pid);

        if (hswDivideWork == null) {
            return "所属分工不存在";
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getAddress())) {
            validMsg.append("<br/>" + "详细地址不能为空");
        }

        if (StringUtils.isNull(hswDiagnosisDevice.getUplinkPort())) {
            validMsg.append("<br/>" + "上行端口的值必须为[光口,电口0,电口1]中的其中一个");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getLogicalAddr())) {
            validMsg.append("<br/>" + "逻辑地址不能为空");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getSn())) {
            validMsg.append("<br/>" + "序列号不能为空");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getModel())) {
            validMsg.append("<br/>" + "型号不能为空");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getVer())) {
            validMsg.append("<br/>" + "版本不能为空");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getIp())) {
            validMsg.append("<br/>" + "ip不能为空");
        }

        if (StringUtils.isNull(hswDiagnosisDevice.getInstallDate())) {
            validMsg.append("<br/>" + "请输入正确格式的安装日期");
        }

        if (StringUtils.isNull(hswDiagnosisDevice.getWarranty())) {
            validMsg.append("<br/>" + "请输入正确格式的质保期");
        }

        if (StringUtils.isEmpty(hswDiagnosisDevice.getNetwork())) {
            validMsg.append("<br/>" + "网络运营商的值必须为[电信,移动,联通]中的其中一个");
        }

        hswDiagnosisDevice.setDivideWorkId(hswDivideWork.getId());

        return validMsg.toString();
    }

    /**
     * 根据项目id分组统计设备信息
     *
     * @param pids
     * @return
     */
    @Override
    public List<DeviceCountDto> selectGroupByPidCount(Long[] pids) {
        if (StringUtils.isNull(pids) || pids.length <= 0) {
            return null;
        }

        List<DeviceCountDto> diagnosisCountList = hswDiagnosisDeviceMapper.selectGroupByPidCount(pids);

        return diagnosisCountList;
    }

    /**
     * 统计设备信息
     *
     * @return
     */
    @Override
    public List<DeviceCountDto> selectGroupCount(Long pid) {
        return hswDiagnosisDeviceMapper.selectGroupCount(pid);
    }

    /**
     * 根据项目id统计设备总数
     *
     * @param pids
     * @return
     */
    @Override
    public DeviceCountDto selectByPidCountAll(Long[] pids) {
        if (StringUtils.isNull(pids) || pids.length <= 0) {
            return null;
        }

        // 诊断器总数
        int diagnosisAll = hswDiagnosisDeviceMapper.selectCountByPid(pids);

        // 摄像机总数
        int cameraAll = hswCameraMapper.selectCountByPid(pids);

        // 光纤收发器总数
        int opticalAll = hswOpticalTransceiverMapper.selectCountByPid(pids);

        // 其他设备总数
        int otherAll = hswOtherDeviceMapper.selectCountByPid(pids);

        DeviceCountDto deviceCount = new DeviceCountDto();
        deviceCount.setDiagnosisAllCount(diagnosisAll);
        deviceCount.setCameraAllCount(cameraAll);
        deviceCount.setOpticalAllCount(opticalAll);
        deviceCount.setOtherAllCount(otherAll);

        return deviceCount;
    }

    @Override
    public HswDiagnosisDevice selectDiagnosisDeviceForApi(HswDiagnosisDevice diagnosisDevice) {
        List<HswDiagnosisDevice> diagnosisDevices = this.hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceList(diagnosisDevice);
        return diagnosisDevices.size() > 0 ? diagnosisDevices.get(0) : null;
    }

    @Override
    public DiagnosisDeviceViewDto selectDiagnosisDeviceViewById(Long id) {
        return this.hswDiagnosisDeviceMapper.selectDiagnosisDeviceViewById(id);
    }

    /**
     * 查询诊断器视图列表
     *
     * @param diagnosisDeviceViewDto
     * @return
     */
    @Override
    public List<DiagnosisDeviceViewDto> selectDiagnosisDeviceViewList(DiagnosisDeviceViewDto diagnosisDeviceViewDto) {
        return hswDiagnosisDeviceMapper.selectDiagnosisDeviceViewList(diagnosisDeviceViewDto);
    }

    @Override
    public DiagnosisDeviceViewDto selectDiagnosisDeviceViewByIpForApp(String ip) {
        if (StringUtils.isBlank(ip)) {
            return null;
        }

        DiagnosisDeviceViewDto diagnosisDeviceViewDto = new DiagnosisDeviceViewDto();
        diagnosisDeviceViewDto.setIp(ip);
        List<DiagnosisDeviceViewDto> diagnosisDeviceViewDtos = this.hswDiagnosisDeviceMapper.selectDiagnosisDeviceViewList(diagnosisDeviceViewDto);
        return diagnosisDeviceViewDtos.size() > 0 ? diagnosisDeviceViewDtos.get(0) : null;
    }

    @Override
    public List<DeviceCountDto> selectDeviceCountList(Long[] pids) {
        return this.hswDiagnosisDeviceMapper.selectDeviceCountList(pids);
    }

    /**
     * 校验逻辑地址是否唯一
     *
     * @param hswDiagnosisDevice
     * @return
     */
    @Override
    public String checkLogicalAddrUnique(HswDiagnosisDevice hswDiagnosisDevice) {
        Long id = StringUtils.isNull(hswDiagnosisDevice.getId()) ? -1L : hswDiagnosisDevice.getId();
        HswDiagnosisDevice info = hswDiagnosisDeviceMapper.checkLogicalAddrUnique(hswDiagnosisDevice.getLogicalAddr());
        if (StringUtils.isNotNull(info) && info.getId().longValue() != id.longValue()) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }

    /**
     * 根据项目获取诊断器树
     */
    @Override
    public List<TreeVo> getTreeByPid() {

        // 获取用户可查看的项目
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            return null;
        }

        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        List<HswProject> projectList = hswProjectMapper.selectHswProjectIds(pids);

        if (CollectionUtils.isEmpty(projectList)) {
            return null;
        }

        List<TreeVo> treeList = new ArrayList<>();
        projectList.forEach(p -> {
            List<TreeVo> wTreeList = hswDiagnosisDeviceMapper.selectTreeByPid(p.getId());
            wTreeList.forEach(w -> w.setType(3));
            TreeVo pTree = new TreeVo();
            pTree.setId(p.getId());
            pTree.setLabel(p.getTitle());
            pTree.setType(2);
            pTree.setChildren(wTreeList);

            treeList.add(pTree);
        });

        return treeList;
    }
}
