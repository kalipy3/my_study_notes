package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 我的信息查询参数dto
 *
 * @author xiongxiangpeng
 * @create 2020-12-03 15:47
 */
@Data
public class MyMsgPageableDto implements Serializable {

    // 用户id
    private Long userId;

    // 状态(0=未读；1=已读；3=归档)
    private Integer status;

    // 关键字
    private String keyword;

    // ？(未知)
    private Integer draw;
}
