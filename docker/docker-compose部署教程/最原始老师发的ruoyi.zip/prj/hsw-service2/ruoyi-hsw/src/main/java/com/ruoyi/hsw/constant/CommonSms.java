package com.ruoyi.hsw.constant;

/**
 * 描述:
 * 短信模板
 *
 * @author xiongxiangpeng
 * @create 2020-12-17 14:13
 */
public interface CommonSms {

    // 派单
    String DISTRIBUTE_LEAFLETS = "SMS_187746645";

    // 申请改派
    String APPLY_REASSIGNMENT = "SMS_187746646";

    // 同意改派
    String REASSIGNMENT_YES = "SMS_187746654";

    // 拒绝改派
    String REASSIGNMENT_NO = "SMS_187756717";

    // 结单
    String STATEMENT = "SMS_187746634";

    // 申请挂起
    String APPLY_HANG_UP = "SMS_187746638";

    // 同意挂起
    String HANG_UP_YES = "SMS_187756716";

    // 拒绝挂起
    String HANG_UP_NO = "SMS_187751649";

    // 撤销
    String REVOKE = "SMS_187756719";

    // 故障通知
    String FAULT_NOTICE = "SMS_187751645";

    // 自动恢复
    String AUTOMATIC_RECOVERY = "SMS_187751647";
}
