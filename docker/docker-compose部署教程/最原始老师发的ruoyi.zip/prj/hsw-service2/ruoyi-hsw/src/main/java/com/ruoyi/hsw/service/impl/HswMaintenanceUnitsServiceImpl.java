package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.domain.HswMaintenanceUnits;
import com.ruoyi.hsw.mapper.HswMaintenanceUnitsMapper;
import com.ruoyi.hsw.mapper.HswProjectMaintenanceUnitsMapper;
import com.ruoyi.hsw.service.IHswMaintenanceUnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 运维单位Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswMaintenanceUnitsServiceImpl implements IHswMaintenanceUnitsService {
    @Autowired
    private HswMaintenanceUnitsMapper hswMaintenanceUnitsMapper;

    @Autowired
    private HswProjectMaintenanceUnitsMapper hswProjectMaintenanceUnitsMapper;

    /**
     * 查询运维单位
     *
     * @param id 运维单位ID
     * @return 运维单位
     */
    @Override
    public HswMaintenanceUnits selectHswMaintenanceUnitsById(Long id) {
        return hswMaintenanceUnitsMapper.selectHswMaintenanceUnitsById(id);
    }

    /**
     * 查询运维单位列表
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 运维单位
     */
    @Override
    public List<HswMaintenanceUnits> selectHswMaintenanceUnitsList(HswMaintenanceUnits hswMaintenanceUnits) {
        return hswMaintenanceUnitsMapper.selectHswMaintenanceUnitsList(hswMaintenanceUnits);
    }

    /**
     * 新增运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    @Override
    public int insertHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits) {
        hswMaintenanceUnits.setCreateBy(SecurityUtils.getUsername());
        hswMaintenanceUnits.setCreateTime(DateUtils.getNowDate());
        return hswMaintenanceUnitsMapper.insertHswMaintenanceUnits(hswMaintenanceUnits);
    }

    /**
     * 修改运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    @Override
    public int updateHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits) {
        hswMaintenanceUnits.setUpdateBy(SecurityUtils.getUsername());
        hswMaintenanceUnits.setUpdateTime(DateUtils.getNowDate());
        return hswMaintenanceUnitsMapper.updateHswMaintenanceUnits(hswMaintenanceUnits);
    }

    /**
     * 批量删除运维单位
     *
     * @param ids 需要删除的运维单位ID
     * @return 结果
     */
    @Override
    public int deleteHswMaintenanceUnitsByIds(Long[] ids) {
        return hswMaintenanceUnitsMapper.deleteHswMaintenanceUnitsByIds(ids);
    }

    /**
     * 删除运维单位信息
     *
     * @param id 运维单位ID
     * @return 结果
     */
    @Override
    public int deleteHswMaintenanceUnitsById(Long id) {
        return hswMaintenanceUnitsMapper.deleteHswMaintenanceUnitsById(id);
    }

    @Override
    public List<HswMaintenanceUnits> treeList(Long[] ids) {
        return this.hswMaintenanceUnitsMapper.selectTree(ids);
    }

    /**
     * 判断运维单位是否存在
     */
    @Override
    public boolean existCount() {
        return this.hswMaintenanceUnitsMapper.selectCount() > 0;
    }
}
