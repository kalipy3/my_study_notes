package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.sms.AliyunSmsUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.HswConstructingUnits;
import com.ruoyi.hsw.domain.HswSysMsg;
import com.ruoyi.hsw.domain.HswUserMsg;
import com.ruoyi.hsw.service.IHswConstructingUnitsService;
import com.ruoyi.hsw.service.IHswSysMsgService;
import com.ruoyi.hsw.service.IHswUserMsgService;
import com.ruoyi.hsw.service.ISmsService;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.service.ISysConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Set;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/19 0019
 */
@Service
@Transactional
public class SmsServiceImpl implements ISmsService {

    @Autowired
    private IHswConstructingUnitsService constructingUnitsService;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private IHswSysMsgService sysMsgService;

    @Autowired
    private IHswUserMsgService userMsgService;

    @Override
    public AjaxResult sendSMS(Long cuId, String tel, String templateCode, Map<String, Object> templateParam, Map<String, Object> args) {
        HswConstructingUnits constructingUnits = this.constructingUnitsService.selectHswConstructingUnitsById(cuId);
        if (constructingUnits == null) {
            return AjaxResult.error();
        }

        String accessKeyId = constructingUnits.getAccessKeyId();
        String accessKeySecret = constructingUnits.getAccessKeySecret();
        String signName = constructingUnits.getSignName();
        System.out.println("===================发送短信：" + templateParam);
        System.out.println("===================发送短信：" + templateCode);
        System.out.println("===================发送短信：" + tel);
        boolean smsRes = AliyunSmsUtils.isSuccessSendAliyunSms(accessKeyId, accessKeySecret, signName, tel, templateCode, templateParam);
        System.out.println("====================成功还是失败：" + smsRes);
        SysConfig tpl = this.sysConfigService.selectConfigByConfigKey(args.get("tpl_key").toString());
        String title = "消息提醒";
        String content = "您有一条消息需要处理，请点击查看详情";
        if (tpl != null) {
            title = tpl.getConfigName();
            content = tpl.getConfigValue();
            Set<String> keySet = templateParam.keySet();
            for (String key : keySet) {
                if (templateParam.get(key) != null) {
                    content = content.replace("${" + key + "}", templateParam.get(key).toString());
                }
            }
        }

        HswSysMsg sysMsg = new HswSysMsg();
        sysMsg.setTitle(title);
        sysMsg.setContent(content);
        sysMsg.setCreateBy(args.get("send_name").toString());
        sysMsg.setToUids(args.get("receiver_id").toString());
        sysMsg.setJobNo(args.get("job_no").toString());
        int result = this.sysMsgService.insertHswSysMsg(sysMsg);

        if (result > 0) {
            HswUserMsg userMsg = new HswUserMsg();
            userMsg.setMid(sysMsg.getId());
            userMsg.setUid(Long.valueOf(args.get("receiver_id").toString()));
            userMsg.setStatus(CommonConstant.STATUS_UNREAD);
            userMsg.setReadTime(0);
            userMsg.setUname(args.get("receiver_name").toString());
            userMsgService.insertHswUserMsg(userMsg);
        }

        return smsRes ? AjaxResult.success() : AjaxResult.error();
    }
}
