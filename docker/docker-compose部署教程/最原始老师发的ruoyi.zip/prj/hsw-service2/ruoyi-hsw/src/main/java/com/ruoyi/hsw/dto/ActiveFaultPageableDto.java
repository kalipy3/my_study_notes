package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 活动故障 动态搜索条件：所属项目、时间范围、故障类型、故障状态
 *
 * @author youyong
 * @date 2020/11/11 0011
 */
@Data
public class ActiveFaultPageableDto implements Serializable {

    private Long pid;

    private Integer status;

    private Integer type;

    private Long starttime;

    private Long endtime;

    private Integer flagStatus;

    private Long mtId;

    private Long muId;

    private Long cuId;

    private String fuzzy = "";

    private Long receiverId;
}
