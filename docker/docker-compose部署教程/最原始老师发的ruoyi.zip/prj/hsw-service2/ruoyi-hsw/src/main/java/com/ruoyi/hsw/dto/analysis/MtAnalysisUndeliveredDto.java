package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 运维队分析-未派单
 *
 * @author xiongxiangpeng
 */
@Data
public class MtAnalysisUndeliveredDto implements Serializable {

    // 分工区域
    private String area;

    // 项目id
    private Long pid;

    // 项目名称
    private String projectTitle;

    // 运维单位id
    private Long muId;

    // 运维单位名称
    @Excel(name = "所属运维单位", sort = 2)
    private String maintenanceUnitsName;

    // 维修队id
    private Long mtId;

    // 运维队名称
    @Excel(name = "运维队", sort = 1)
    private String maintenanceTeamName;

    // 未派单数
    @Excel(name = "未派单数", sort = 3)
    private Integer nosend=0;

    // 派单超时数量
    @Excel(name = "超时数(派单超时)", sort = 4)
    private Integer sendTimeoutCount=0;

    // 超时率
    private Double sendRate=0D;

    // 超时率 + %
    @Excel(name = "超时率", sort = 5)
    private String sendRateString;
}
