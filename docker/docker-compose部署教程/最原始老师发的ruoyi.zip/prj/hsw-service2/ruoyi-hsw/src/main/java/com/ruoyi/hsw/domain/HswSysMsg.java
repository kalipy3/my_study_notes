package com.ruoyi.hsw.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.util.List;

/**
 * 系统消息对象 hsw_sys_msg
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswSysMsg extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 日志标题 */
    @Excel(name = "日志标题")
    private String title;

    /** 日志内容 */
    @Excel(name = "日志内容")
    private String content;

    /** 接收者uid */
    @Excel(name = "接收者uid")
    private String toUids;

    /** 关联工单编号 */
    @Excel(name = "关联工单编号")
    private String jobNo;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    /** 用户消息信息 */
    private List<HswUserMsg> hswUserMsgs;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }
    public void setContent(String content)
    {
        this.content = content;
    }

    public String getContent()
    {
        return content;
    }
    public void setToUids(String toUids)
    {
        this.toUids = toUids;
    }

    public String getToUids()
    {
        return toUids;
    }
    public void setJobNo(String jobNo)
    {
        this.jobNo = jobNo;
    }

    public String getJobNo()
    {
        return jobNo;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("title", getTitle())
            .append("content", getContent())
            .append("toUids", getToUids())
            .append("jobNo", getJobNo())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public List<HswUserMsg> getHswUserMsgs() {
        return hswUserMsgs;
    }

    public void setHswUserMsgs(List<HswUserMsg> hswUserMsgs) {
        this.hswUserMsgs = hswUserMsgs;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }
}
