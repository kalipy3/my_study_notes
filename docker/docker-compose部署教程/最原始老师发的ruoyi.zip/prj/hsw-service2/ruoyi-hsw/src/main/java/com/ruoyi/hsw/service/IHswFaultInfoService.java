package com.ruoyi.hsw.service;

import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.hsw.domain.HswFaultInfo;
import com.ruoyi.hsw.domain.HswJobInfo;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.domain.vo.FaultStatusVo;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.index.DeviceDateCountDto;

import java.util.List;
import java.util.Map;

/**
 * 故障信息Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswFaultInfoService {
    /**
     * 查询故障信息
     *
     * @param id 故障信息ID
     * @return 故障信息
     */
    public HswFaultInfo selectHswFaultInfoById(Long id);

    /**
     * 查询活动故障信息列表
     *
     * @param hswFaultInfo 故障信息
     * @return 故障信息集合
     */
    public List<HswFaultInfo> selectHswFaultInfoList(HswFaultInfo hswFaultInfo);

    /**
     * 查询历史故障信息列表
     */
    public List<HswFaultInfo> selectHistoryList(HswFaultInfo hswFaultInfo);

    /**
     * 新增故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    public int insertHswFaultInfo(HswFaultInfo hswFaultInfo);

    /**
     * 修改故障信息
     *
     * @param hswFaultInfo 故障信息
     * @return 结果
     */
    public int updateHswFaultInfo(HswFaultInfo hswFaultInfo);

    /**
     * 批量删除故障信息
     *
     * @param ids 需要删除的故障信息ID
     * @return 结果
     */
    public int deleteHswFaultInfoByIds(Long[] ids);

    /**
     * 删除故障信息信息
     *
     * @param id 故障信息ID
     * @return 结果
     */
    public int deleteHswFaultInfoById(Long id);

    /**
     * 派单
     */
    public Map<String, Object> insertHswJobInfo(HswJobInfo hswJobInfo);

    /**
     * 更新故障信息
     *
     * @param updateFaultDto
     * @return
     */
    boolean updateHswFaultInfoByApi(UpdateFaultDto updateFaultDto);


    /**
     * 设备故障调用添加故障信息,$port(非摄像机填写0)
     *
     * @param ip
     * @param port
     * @param type
     * @param descr
     * @param zigzagCount
     * @param zigzagType
     * @param zigzagStatus
     * @param opState
     * @param taketime
     * @return
     */
    Map<String, Object> addfromDevice(String ip, Integer port, String type, String descr, Integer zigzagCount, Integer zigzagType, Integer zigzagStatus, String opState, String taketime);

    /**
     * 活动故障 动态搜索条件：所属项目、时间范围、故障类型、故障状态(api调用)
     *
     * @param activeFaultPageableDto
     * @return
     */
    List<FaultViewDto> selectFaultViewListForApp(ActiveFaultPageableDto activeFaultPageableDto);

    List<FaultViewDto> selectFaultViewList(FaultViewDto faultViewDto);

    FaultViewDto selectFaultViewById(Long id);

    /**
     * 派单
     *
     * @param id
     * @param assignUserId
     * @param receiverId
     * @param remark
     * @param assignUserNickName
     * @return
     */
    Map<String, Object> assignForApp(Long id, Long assignUserId, Long receiverId, String remark, String assignUserNickName);

    /**
     * 根据项目id和时间范围获取故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultViewDto> selectFaultCountByPidsAndDate(Long[] pids, Long startDate, Long endDate);

    /**
     * 根据项目id和时间范围获取故障设备数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultViewDto> selectFaultCountByDate(Long pid, Long startDate, Long endDate);

    /**
     * 根据项目id和时间范围获取不同故障类型数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    Map<String, Object> selectFaultTypeCountByPidsAndDate(Long[] pids, Long startDate, Long endDate);

    /**
     * 根据时间范围获取不同故障类型数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    Map<String, Object> selectFaultTypeCountByDate(Long pid, Long startDate, Long endDate);

    /**
     * 根据项目获取故障统计获取不同故障类型数量
     */
    FaultStatisticsVo selectFaultTypeCountByIp(String ip);

    /**
     * 触发自定恢复
     *
     * @param ip
     * @param port
     * @param type
     * @param zigzagType
     * @return
     */
    FaultViewDto selectFaultViewForRecoveryForApi(String ip, Integer port, String type, Integer zigzagType);

    /**
     * 根据项目id和时间范围获取不同故障状态数量
     *
     * @param pid
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatusVo> selectFaultStatusByPidAndDate(Long pid, Long startDate, Long endDate);

    /**
     * 根据时间范围获取不同故障状态数量
     *
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultStatusVo> selectFaultStatusByDate(Long pid, Long startDate, Long endDate);

    /**
     * 根据故障id获取维修员
     */
    public List<SysUser> mtMan(Long id);

    /**
     * 获取故障视图列表
     *
     * @param faultViewPageableDto
     * @return
     */
    List<FaultViewDto> selectFaultViewList2(FaultViewPageableDto faultViewPageableDto);

    /**
     * 指定IP，指定故障是否存在
     *
     * @param faultInfo
     * @return
     */
    boolean isFaultExistsForApi(HswFaultInfo faultInfo);

    /**
     * 按小时分组统计故障设备数量
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<DeviceDateCountDto> selectFaultGroupHour(Long[] pids, Long startDate, Long endDate);

    /**
     * 故障报告
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    List<FaultReportDto> selectFaultReportList(Long[] pids, Long startDate, Long endDate);

    /**
     * 统计故障数量
     *
     * @param faultViewDto
     * @return
     */
    Integer selectFaultViewCount(FaultViewDto faultViewDto);

    /**
     * 数据权限
     */
    public HswFaultInfo dataPermission(HswFaultInfo hswFaultInfo);

    /**
     * 查询活动故障信息列表
     *
     * @return 故障信息集合
     */
    public List<HswFaultInfo> selectHswFaultInfoListByIp(String ip);

    /**
     * 指定IP，指定故障是否存在
     *
     * @param faultInfo
     * @return
     */
    boolean isFaultExistsForIot(HswFaultInfo faultInfo);
}
