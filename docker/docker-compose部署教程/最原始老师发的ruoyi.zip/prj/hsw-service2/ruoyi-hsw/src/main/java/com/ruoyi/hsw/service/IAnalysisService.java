package com.ruoyi.hsw.service;

import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.analysis.*;

import java.util.List;

/**
 * 描述:
 * 绩效考核
 *
 * @author xiongxiangpeng
 * @create 2020-11-14 15:16
 */
public interface IAnalysisService {

    /**
     * 运维单位分析-人工修复
     */
    public List<MuAnalysisArtificialDto> muAnalysis1(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-自动修复
     */
    public List<MuAnalysisAutoDto> muAnalysis2(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-未派单
     */
    public List<MuAnalysisUndeliveredDto> muAnalysis3(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-维修中
     */
    public List<MuAnalysisUnderRepairDto> muAnalysis4(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-人工修复总数
     */
    public MuAnalysisArtificialDto muAnalysisSum1(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-自动修复总数
     */
    public MuAnalysisAutoDto muAnalysisSum2(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-未派单总数
     */
    public MuAnalysisUndeliveredDto muAnalysisSum3(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-维修中总数
     */
    public MuAnalysisUnderRepairDto muAnalysisSum4(MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 维修队分析-人工修复
     */
    public List<MtAnalysisArtificialDto> mtAnalysis1(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-自动修复
     */
    public List<MtAnalysisAutoDto> mtAnalysis2(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-未派单
     */
    public List<MtAnalysisUndeliveredDto> mtAnalysis3(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-维修中
     */
    public List<MtAnalysisUnderRepairDto> mtAnalysis4(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-人工修复总数
     */
    public MtAnalysisArtificialDto mtAnalysisSum1(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-自动修复总数
     */
    public MtAnalysisAutoDto mtAnalysisSum2(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-未派单总数
     */
    public MtAnalysisUndeliveredDto mtAnalysisSum3(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队分析-维修中总数
     */
    public MtAnalysisUnderRepairDto mtAnalysisSum4(MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 维修队长分析-人工修复
     */
    public List<MtlAnalysisArtificialDto> mtlAnalysis1(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修队长分析-未派单
     */
    public List<MtlAnalysisUndeliveredDto> mtlAnalysis3(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修队长分析-维修中
     */
    public List<MtlAnalysisUnderRepairDto> mtlAnalysis4(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修队长分析-人工修复-总数
     */
    public MtlAnalysisArtificialDto mtlAnalysisSum1(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修队长分析-未派单-总数
     */
    public MtlAnalysisUndeliveredDto mtlAnalysisSum3(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修队长分析-维修中-总数
     */
    public MtlAnalysisUnderRepairDto mtlAnalysisSum4(MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 维修员分析-人工修复
     */
    public List<MtManAnalysisArtificialDto> mtManAnalysis1(MtManAnalysisPageableDto mtManAnalysisPageableDto);

    /**
     * 维修员分析-维修中
     */
    public List<MtManAnalysisUnderRepairDto> mtManAnalysis4(MtManAnalysisPageableDto mtManAnalysisPageableDto);


    /**
     * 维修员分析-人工修复-总数
     */
    public MtManAnalysisArtificialDto mtManAnalysisSum1(MtManAnalysisPageableDto mtManAnalysisPageableDto);

    /**
     * 维修员分析-维修中-总数
     */
    public MtManAnalysisUnderRepairDto mtManAnalysisSum4(MtManAnalysisPageableDto mtManAnalysisPageableDto);

    /**
     * 设备厂商分析
     */
    public List<EquAnalysis1Dto> equAnalysis(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备厂商分析-总数
     */
    public EquAnalysis1Dto equAnalysisSum(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 网络运营商分析
     */
    public List<NetworkOperators1Dto> networkOperators(NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     * 网络运营商分析-总数
     */
    public NetworkOperators1Dto networkOperatorsSum(NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     * 电力运营商分析
     */
    public List<PowerOperators1Dto> powerOperators(PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     * 电力运营商分析-总数
     */
    public PowerOperators1Dto powerOperatorsSum(PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     * 派单员分析
     */
    public List<Dispatcher1Dto> dispatcher(DispatcherPageableDto dispatcherPageableDto);

    /**
     * 派单员分析-总数
     */
    public Dispatcher1Dto dispatcherSum(DispatcherPageableDto dispatcherPageableDto);

    /**
     * 工单记录-列表
     */
    public List<JobViewDto> ordersList(OrdersPageableDto ordersPageableDto);

    /**
     * 工单记录-饼状图
     */
    public PicChartDto ordersPieChart(OrdersPageableDto ordersPageableDto);

    /**
     * 派单记录-列表
     */
    public List<JobViewDto> sendOrdersList(OrdersPageableDto ordersPageableDto);

    /**
     * 派单记录-饼状图
     */
    public PicChartDto sendOrdersPieChart(OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-列表
     */
    public List<FaultViewDto> autoRepairFaultList(OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-饼状图
     */
    public PicChartDto autoRepairFaultPieChart(OrdersPageableDto ordersPageableDto);

    /**
     * 未派单记录-列表
     */
    public List<FaultViewDto> noSendFaultList(OrdersPageableDto ordersPageableDto);

    /**
     * 未派单记录-饼状图
     */
    public PicChartDto noSendFaultPieChart(OrdersPageableDto ordersPageableDto);

    /**
     * 维修中记录-列表
     */
    public List<JobViewDto> underRepairList(OrdersPageableDto ordersPageableDto);

    /**
     * 维修中记录-饼状图
     */
    public PicChartDto underRepairPieChart(OrdersPageableDto ordersPageableDto);

    /**
     * 设备-故障设备记录-光纤收发器-列表
     */
    public List<FaultOpticalTransceiverDto> faultDevicesList(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-摄像机-列表
     */
    public List<FaultCameraDto> faultDevicesCameraList(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-设备类型-饼状图
     */
    public PicChartDto faultDevicesTypePieChart(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-维修效率-饼状图
     */
    public PicCharEquDto faultDevicesPieChart(EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     *  网络运营商故障记录-列表
     */
    public List<FaultProjectDto> netWorkFaultList(NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     * 网络运营商故障记录-饼状图
     */
    public PicCharEquDto netWorkFaultPieChart(NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     *  电力运营商故障记录-列表
     */
    public List<FaultProjectDto> powerCompanyFaultList(PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     * 电力运营商故障记录-饼状图
     */
    public PicCharEquDto powerCompanyFaultPieChart(PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     *  派单员派单记录-列表
     */
    public List<JobViewDto> senderOrderList(DispatcherPageableDto dispatcherPageableDto);

    /**
     * 派单员派单记录-饼状图
     */
    public PicChartDto senderOrderPieChart(DispatcherPageableDto dispatcherPageableDto);

    /**
     * app 运维单位人工修复
     */
    public List<MuAnalysisArtificialDto> MUByArtificialRepair1(String sql);
}
