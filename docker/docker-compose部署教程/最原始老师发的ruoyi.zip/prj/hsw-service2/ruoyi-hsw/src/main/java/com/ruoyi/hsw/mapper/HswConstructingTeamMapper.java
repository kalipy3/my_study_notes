package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.domain.HswConstructingTeam;

import java.util.List;

/**
 * 施工队Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-05
 */
public interface HswConstructingTeamMapper {
    /**
     * 查询施工队
     *
     * @param id 施工队ID
     * @return 施工队
     */
    public HswConstructingTeam selectHswConstructingTeamById(Long id);

    /**
     * 查询施工队列表
     *
     * @param hswConstructingTeam 施工队
     * @return 施工队集合
     */
    public List<HswConstructingTeam> selectHswConstructingTeamList(HswConstructingTeam hswConstructingTeam);

    /**
     * 新增施工队
     *
     * @param hswConstructingTeam 施工队
     * @return 结果
     */
    public int insertHswConstructingTeam(HswConstructingTeam hswConstructingTeam);

    /**
     * 修改施工队
     *
     * @param hswConstructingTeam 施工队
     * @return 结果
     */
    public int updateHswConstructingTeam(HswConstructingTeam hswConstructingTeam);

    /**
     * 删除施工队
     *
     * @param id 施工队ID
     * @return 结果
     */
    public int deleteHswConstructingTeamById(Long id);

    /**
     * 批量删除施工队
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswConstructingTeamByIds(Long[] ids);

    /**
     * 查询施工单位数量
     */
    public int selectCount();
}
