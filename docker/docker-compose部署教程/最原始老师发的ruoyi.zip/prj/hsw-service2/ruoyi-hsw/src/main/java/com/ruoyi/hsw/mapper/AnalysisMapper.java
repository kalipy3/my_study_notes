package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.analysis.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 描述:
 * 绩效考核
 *
 * @author xiongxiangpeng
 * @create 2020-11-14 15:21
 */
@Repository
public interface AnalysisMapper {

    /**
     * 运维单位分析-人工修复
     */
    public List<MuAnalysisArtificialDto> muAnalysis1(@Param("vo") MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-自动修复
     */
    public List<MuAnalysisAutoDto> muAnalysis2(@Param("vo") MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-未派单
     */
    public List<MuAnalysisUndeliveredDto> muAnalysis3(@Param("vo") MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维单位分析-维修中
     */
    public List<MuAnalysisUnderRepairDto> muAnalysis4(@Param("vo") MuAnalysisPageableDto muAnalysisPageableDto);

    /**
     * 运维队分析-人工修复
     */
    public List<MtAnalysisArtificialDto> mtAnalysis1(@Param("vo") MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 运维队分析-自动修复
     */
    public List<MtAnalysisAutoDto> mtAnalysis2(@Param("vo") MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 运维队分析-未派单
     */
    public List<MtAnalysisUndeliveredDto> mtAnalysis3(@Param("vo") MtAnalysisPageableDto mtAnalysisPageableDto);

    /**
     * 运维队分析-维修中
     */
    public List<MtAnalysisUnderRepairDto> mtAnalysis4(@Param("vo") MtAnalysisPageableDto mtAnalysisPageableDto);


    /**
     * 运维队长分析-人工修复
     */
    public List<MtlAnalysisArtificialDto> mtlAnalysis1(@Param("vo") MtlAnalysisPageableDto mtlAnalysisPageableDto);


    /**
     * 运维队长分析-未派单
     */
    public List<MtlAnalysisUndeliveredDto> mtlAnalysis3(@Param("vo") MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 运维队长分析-维修中
     */
    public List<MtlAnalysisUnderRepairDto> mtlAnalysis4(@Param("vo") MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * 运维员分析-人工修复
     */
    public List<MtManAnalysisArtificialDto> mtManAnalysis1(@Param("vo") MtManAnalysisPageableDto mtManAnalysisPageableDto);

    /**
     * 运维员分析-维修中
     */
    public List<MtManAnalysisUnderRepairDto> mtManAnalysis4(@Param("vo") MtManAnalysisPageableDto mtManAnalysisPageableDto);

    /**
     * 设备厂商分析-获取设备数（光纤收发器）
     */
    public int selectDeviceCount(@Param("manufacturer") String manufacturer, @Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备厂商分析-获取故障设备数(光纤收发器)
     */
    public int selectFaultCount(@Param("manufacturer") String manufacturer, @Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备厂商分析-获取设备数(摄像机)
     */
    public int selectDeviceCountByDeviceType(@Param("manufacturer") String manufacturer, @Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备厂商分析-获取故障设备数(摄像机)
     */
    public int selectFaultCountByDeviceType(@Param("manufacturer") String manufacturer, @Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     *  网络运营商分析
     */
    public List<NetworkOperators1Dto> networkOperators(@Param("vo") NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     *  电力运营商分析
     */
    public List<PowerOperators1Dto> powerOperators(@Param("vo") PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     * 派单员分析
     */
    public List<Dispatcher1Dto> dispatcher(@Param("vo") DispatcherPageableDto dispatcherPageableDto);

    /**
     * 工单记录-列表
     */
    public List<JobViewDto> ordersList(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 工单记录-饼状图
     */
    public PicChartDto ordersPieChart(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 派单记录-列表
     */
    public List<JobViewDto> sendOrdersList(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 派单记录-饼状图
     */
    public PicChartDto sendOrdersPieChart(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-列表
     */
    public List<FaultViewDto> autoRepairFaultList(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-饼状图
     */
    public PicChartDto autoRepairFaultPieChart(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-列表
     */
    public List<FaultViewDto> noSendFaultList(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-饼状图
     */
    public PicChartDto noSendFaultPieChart(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-列表
     */
    public List<JobViewDto> underRepairList(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 自动恢复记录-饼状图
     */
    public PicChartDto underRepairPieChart(@Param("vo") OrdersPageableDto ordersPageableDto);

    /**
     * 设备-故障设备记录-光纤收发器-列表
     */
    public List<FaultOpticalTransceiverDto> faultDevicesList(@Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-摄像机-列表
     */
    public List<FaultCameraDto> faultDevicesCameraList(@Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-设备类型-饼状图
     */
    public PicChartDto faultDevicesTypePieChart(@Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     * 设备-故障设备记录-维修效率-饼状图
     */
    public PicCharEquDto faultDevicesPieChart(@Param("vo") EquAnalysisPageableDto equAnalysisPageableDto);

    /**
     *  网络运营商故障记录-列表
     */
    public List<FaultProjectDto> netWorkFaultList(@Param("vo") NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     * 网络运营商故障记录-饼状图
     */
    public PicCharEquDto netWorkFaultPieChart(@Param("vo") NetworkOperatorsPageableDto networkOperatorsPageableDto);

    /**
     *  电力运营商故障记录-列表
     */
    public List<FaultProjectDto> powerCompanyFaultList(@Param("vo") PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     * 电力运营商故障记录-饼状图
     */
    public PicCharEquDto powerCompanyFaultPieChart(@Param("vo") PowerOperatorsPageableDto powerOperatorsPageableDto);

    /**
     *  派单员派单记录-列表
     */
    public List<JobViewDto> senderOrderList(@Param("vo") DispatcherPageableDto dispatcherPageableDto);

    /**
     * 派单员派单记录-饼状图
     */
    public PicChartDto senderOrderPieChart(@Param("vo") DispatcherPageableDto dispatcherPageableDto);

    /**
     * 查询维修队长集合
     */
    public List<Long> selectUserId(@Param("vo") MtlAnalysisPageableDto mtlAnalysisPageableDto);

    /**
     * app 运维单位人工修复
     */
    public List<MuAnalysisArtificialDto> MUByArtificialRepair1(@Param("sql") String sql);

    /**
     * 取所有维修员及队长
     * @return
     */
    List<MtManAnalysisArtificialDto> mtManAnalysis1ForAll();
}