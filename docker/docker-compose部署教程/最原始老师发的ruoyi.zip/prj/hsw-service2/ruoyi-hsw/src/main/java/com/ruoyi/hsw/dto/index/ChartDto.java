package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 统计
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 15:00
 */
@Data
public class ChartDto implements Serializable {

    // 名称
    private String name;

    // 数量
    private Integer count;
}
