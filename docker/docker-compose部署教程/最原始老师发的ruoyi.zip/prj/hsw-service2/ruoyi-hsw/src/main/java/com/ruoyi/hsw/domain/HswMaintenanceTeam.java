package com.ruoyi.hsw.domain;

import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.util.List;

/**
 * 维修队对象 hsw_maintenance_team
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswMaintenanceTeam extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String name;

    /** 负责人 */
    @Excel(name = "负责人")
    private String leader;

    /** 电话 */
    @Excel(name = "电话")
    private String tel;

    /** 运维单位id */
    @Excel(name = "运维单位id")
    private Long muId;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    /**
     * 维修单位
     */
    @Excels({
            @Excel(name = "运维单位", targetAttr = "name", type = Excel.Type.EXPORT),
            @Excel(name = "运维单位负责人", targetAttr = "leader", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceUnits hswMaintenanceUnits;

    // id列表（查询使用）
    private List<Long> ids;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
    public void setLeader(String leader)
    {
        this.leader = leader;
    }

    public String getLeader()
    {
        return leader;
    }
    public void setTel(String tel)
    {
        this.tel = tel;
    }

    public String getTel()
    {
        return tel;
    }
    public void setMuId(Long muId)
    {
        this.muId = muId;
    }

    public Long getMuId()
    {
        return muId;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("leader", getLeader())
            .append("tel", getTel())
            .append("muId", getMuId())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("ids", getIds())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public HswMaintenanceUnits getHswMaintenanceUnits() {
        return hswMaintenanceUnits;
    }

    public void setHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits) {
        this.hswMaintenanceUnits = hswMaintenanceUnits;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }
}
