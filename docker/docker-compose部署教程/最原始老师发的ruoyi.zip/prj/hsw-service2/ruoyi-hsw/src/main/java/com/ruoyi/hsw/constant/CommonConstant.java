package com.ruoyi.hsw.constant;

/**
 * 描述:
 * 公共常量
 *
 * @author xiongxiangpeng
 * @create 2020-12-16 16:39
 */
public interface CommonConstant {

    // 分析类型 人工修复
    int ARTIFICIAL = 1;

    // 分析类型 自动恢复
    int AUTO = 2;

    // 分析类型 未派单
    int UNDELIVERED = 3;

    // 分析类型 维修中
    int UNDERREPAIR = 4;

    // 角色-维修队长id
    Long ROLE_MTL = 6L;

    // 角色-维修员id
    Long ROLE_MAINTENANCE_MAN = 7L;

    // 角色-派单员id
    Long ROLE_DISPATCHER = 11L;

    // 用户类型-建设单位
    Integer TYPE_CONSTRUCTION_UNIT = 2;

    // 归档状态-活动
    Integer FLAG_STATUS_ACTIVITY = 0;

    // 归档状态-历史
    Integer FLAG_STATUS_HISTORY = 1;

    // 用户类型-系统用户
    int USER_TYPE_SYSTEM = 1;

    // 用户类型-建设单位用户
    int USER_TYPE_CU = 2;

    // 用户类型-运维单位用户
    int USER_TYPE_MU = 3;

    // 用户类型-admin用户
    int USER_TYPE_ADMIN = 99;

    // 故障状态-人工修复
    int FAULT_ARTIFICIAL = 3;

    // 故障状态-自动修复
    int FAULT_AUTO = 5;

    // 故障状态-已撤单
    int FAULT_CANCELLED = 6;

    // 诊断器上行端口-光口
    int UPLINK_PORT_LIGHT = 1;

    // 诊断器上行端口-电口0
    int UPLINK_PORT_ELECTRIC_ZERO = 2;

    // 诊断器上行端口-电口1
    int UPLINK_PORT_ELECTRIC_ONE = 3;

    // 诊断器上行端口名称-未知
    String UPLINK_PORT_TEXT = "未知";

    // 诊断器上行端口名称-未知
    String FAULT_TYPE_TEXT = "未知故障";

    // 故障级别 = 0
    Integer FAULT_LEVEL_ZERO = 0;

    // 是否是故障 是
    Integer IS_FAULT_YES = 1;

    // 是否是故障 否
    Integer IS_FAULT_NO = 0;

    // 故障端口号=0
    Integer FAULT_POST = 0;

    // 用户信息状态-未读
    Integer STATUS_UNREAD = 0;

    // 用户信息状态-已读
    Integer STATUS_READ = 1;

    // 用户信息状态-归档
    Integer STATUS_FILE = 3;

    // 市电断电
    int SDDD = 1;

    // 光纤链路故障
    int GQLL = 2;

    // 光纤收发器故障
    int GQSFQ = 3;

    // 摄像机链路故障
    int SXJLL = 4;

    // 摄像机故障
    int SXJ = 5;

    // 主光缆故障
    int ZGL = 6;

    // 诊断器故障
    int ZDQ = 7;

    // 诊断信号输出不正常
    int ZDXHSCBZC = 8;

    // 工作不稳定
    int GZBWD = 9;

    // 工作不稳定-当前故障
    int GZBWD_DQGZ = 10;
    // ONU链路故障
    int ONULL = 11;
    // 诊断器电源适配器故障
    int ZDQDYSPQ = 12;
    // 摄像机链路诊断信号不正常
    int SXJLLZDXHBZC = 13;
    // 光纤链路诊断信号输出不正常
    int GQLLZDXHSCBZC = 14;

    // 颠簸状态-已处理
    int ZIGZAG_STATUS_PROCESSED = 1;

    // 颠簸状态-未处理
    int ZIGZAG_STATUS_UNTREATED = 0;

    // 短信开关-开启
    String SMS_OPEN_YES = "1";

    // 短信开关-关闭
    String SMS_OPEN_NO = "0";

    // 摄像机类型-枪机
    Integer CAMERA_TYPE_QIANGJI = 1;

    // 摄像机类型-球机
    Integer CAMERA_TYPE_QIUJI = 2;

    // 摄像机类型-半球机
    Integer CAMERA_TYPE_BANQIUJI = 3;
}