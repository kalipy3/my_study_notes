package com.ruoyi.hsw.domain.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * 区域Vo
 *
 * @author zyj
 * @date 2020/11/20 14:10
 */
@Data
public class AreaVo implements Serializable {

    // 标识
    private String code;

    // 名称
    private String name;

    // 经度
    private String longitude;

    // 纬度
    private String latitude;

    public AreaVo() {
    }

    public AreaVo(String code, String name, String longitude, String latitude) {
        this.code = code;
        this.name = name;
        this.longitude = longitude;
        this.latitude = latitude;
    }
}
