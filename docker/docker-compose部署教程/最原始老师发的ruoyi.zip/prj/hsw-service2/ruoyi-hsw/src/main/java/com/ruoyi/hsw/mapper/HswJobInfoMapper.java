package com.ruoyi.hsw.mapper;

import java.util.List;

import com.ruoyi.hsw.domain.HswJobInfo;
import com.ruoyi.hsw.domain.vo.JobStaffStatisticsVo;
import com.ruoyi.hsw.domain.vo.JobTeamStatisticsVo;
import com.ruoyi.hsw.dto.JobViewDto;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 工单Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswJobInfoMapper {
    /**
     * 查询工单
     *
     * @param id 工单ID
     * @return 工单
     */
    public HswJobInfo selectHswJobInfoById(Long id);

    /**
     * 查询工单列表
     *
     * @param hswJobInfo 工单
     * @return 工单集合
     */
    public List<HswJobInfo> selectHswJobInfoList(HswJobInfo hswJobInfo);

    /**
     * 查询历史工单列表
     */
    public List<HswJobInfo> selectHistoryList(HswJobInfo hswJobInfo);

    /**
     * 新增工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    public int insertHswJobInfo(HswJobInfo hswJobInfo);

    /**
     * 修改工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    public int updateHswJobInfo(HswJobInfo hswJobInfo);

    /**
     * 删除工单
     *
     * @param id 工单ID
     * @return 结果
     */
    public int deleteHswJobInfoById(Long id);

    /**
     * 批量删除工单
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswJobInfoByIds(Long[] ids);

    /**
     * 根据故障id查询数量
     */
    public int selectCountByFaultId(Long faultId);

    /**
     * 根据维修队和运维单位分组，通过分工id和时间范围查询维修队工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobTeamStatisticsVo> selectJobTeamByDivideWorkIdsAndDate(@Param("divideWorkIds") Long[] divideWorkIds,
                                                                         @Param("startDate") Long startDate,
                                                                         @Param("endDate") Long endDate);

    /**
     * 根据维修队和运维单位分组，通过时间范围查询维修队工单统计信息
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobTeamStatisticsVo> selectJobTeamByDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 根据维修队和运维单位和维修员工分组，通过分工id和时间范围查询维修队员工工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobStaffStatisticsVo> selectJobStaffByDivideWorkIdsAndDate(@Param("divideWorkIds") Long[] divideWorkIds,
                                                                           @Param("startDate") Long startDate,
                                                                           @Param("endDate") Long endDate);

    /**
     * 根据维修队和运维单位和维修员工分组，通过时间范围查询维修队员工工单统计信息
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public List<JobStaffStatisticsVo> selectJobStaffByDate(@Param("pid") Long pid, @Param("startDate") Long startDate, @Param("endDate") Long endDate);

    /**
     * 从视图取列表
     * @return
     */
    List<JobViewDto> selectJobViewList(JobViewDto jobViewDto);

    /**
     * 从视图取
     * @return
     */
    JobViewDto selectJobViewById(Long id);

    /**
     * 统计工单数量
     *
     * @param jobViewDto
     * @return
     */
    Integer selectJobViewCount(JobViewDto jobViewDto);

    /**
     * 查询活动工单列表
     *
     * @return 工单集合
     */
    List<HswJobInfo> selectHswJobInfoListByIp(@Param("ip") String ip);
}
