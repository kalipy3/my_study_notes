package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 派单员分析
 *
 * @author xiongxiangpeng
 */
@Data
public class Dispatcher1Dto implements Serializable {

    // 姓名
    @Excel(name = "派单员", sort = 1)
    private String realName;

    // 用户id
    private Long userId;

    // 总派单时间
    private Long sendTimeCount=0L;

    // 延期数
    private Integer sendTimeout=0;

    // 派单数
    @Excel(name = "派单数", sort = 2)
    private Integer totalSendOrder=0;

    // 有效派单数
    @Excel(name = "有效派单数", sort = 3)
    private Integer sendOk=0;

    // 平均派单时长(小时)
    @Excel(name = "平均派单时长(小时)", sort = 4)
    private Double sendAvg=0D;

    // 派单效率
    private Double sendRate=0D;

    // 派单效率 + %
    @Excel(name = "派单效率", sort = 5)
    private String sendRateString;
}
