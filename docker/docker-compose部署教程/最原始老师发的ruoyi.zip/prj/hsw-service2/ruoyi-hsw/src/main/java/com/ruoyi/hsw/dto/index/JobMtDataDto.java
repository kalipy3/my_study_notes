package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 维修队工单统计Dto
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 15:14
 */
@Data
public class JobMtDataDto implements Serializable {

    // 维修队id
    private Long mtId;

    // 维修队名称
    private String mtName;

    // 工单数量
    private Integer jobNum;

    // 完成数
    private Integer finishcount;

    // 超时数
    private Integer timeoutcount;
}
