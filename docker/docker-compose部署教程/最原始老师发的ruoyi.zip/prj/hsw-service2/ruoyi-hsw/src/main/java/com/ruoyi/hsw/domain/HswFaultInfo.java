package com.ruoyi.hsw.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 故障信息对象 hsw_fault_info
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswFaultInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 故障编号，以日期时间格式化的字符串date("YmdHiproject_titles",time()) */
//    @Excel(name = "故障编号，以日期时间格式化的字符串date("YmdHis",time())")
    private String faultNo;

    /** 视点位置 */
    @Excel(name = "视点位置")
    private String regionName;

    /** 视点IP */
    @Excel(name = "视点IP")
    private String ip;

    /** 逻辑地址32位 */
    @Excel(name = "逻辑地址32位")
    private String sn;

    /** 端口号，非摄像机故障为0 */
    @Excel(name = "端口号，非摄像机故障为0")
    private Integer port;

    /** 故障类型 */
    @Excel(name = "故障类型")
    private String type;

    /** 发生时间 */
    private Long takeTime;

    /** 发生时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "发生时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date takeDate;

    /** 所属项目 */
    private Long pid;

    /** 项目档案对象 */
    @Excels({
            @Excel(name = "项目名称", targetAttr = "title", type = Excel.Type.EXPORT)
    })
    private HswProject project;

    /** 故障描述 */
    @Excel(name = "故障描述")
    private String descr;

    /** 故障状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起） */
    @Excel(name = "故障状态")
    private String status;

    /** 归档状态（0=活动故障；1=历史故障；） */
    private String flagStatus;

    /** 修复时间 */
    private Long repairTime;

    /** 修复时间-时间格式 */
    @Excel(name = "修复时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date repairDate;

    /** 对应工单id， */
    private Long jobId;

    /** 对应工单编号 */
    private String jobNo;

    /** 运维单位 */
    private Long muId;

    /** 运维单位对象 */
    @Excels({
            @Excel(name = "运维单位名称", targetAttr = "name", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceUnits maintenanceUnits;

    /** 维修队id */
    private Long mtId;

    /** 运维队对象 */
    @Excels({
            @Excel(name = "运维队名称", targetAttr = "name", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceTeam maintenanceTeam;

    /** 来源于设备对应分工区域名称（乡镇/街道/小区），便于查询 */
    @Excel(name = "分工区域")
    private String area;

    /** 仅对摄像机故障有效，一天该摄像机发生的第几次故障 */
    private Long todayTakeCount;

    /** 故障所属分工区域id */
    private Long divideWorkId;

    /** 十六进制显示op_state，陈老师网联网调试用  */
    private String opState;

    /** 颠簸次数 */
    @Excel(name = "颠簸次数")
    private Integer zigzagCount;

    /** 影响摄像机数量 */
    @Excel(name = "影响摄像机数量")
    private Integer influenceCameraCount;

    /** 颠簸故障类型（同故障状态，除工作不稳定2种） */
    private Integer zigzagType;

    /** 颠簸状态（0=未处理；1=已处理） */
    private Integer zigzagStatus;

    /** 超时档位 */
    private Long timeoutLevel;

    /** 故障距离指挥中心位最小距离(KM) */
    private Integer startDistance;

    /** 故障距离指挥中心位最大距离(KM) */
    private Integer endDistance;

    /** 超时时长(小时) */
    private Integer timeoutHour;

    /** 距指挥中心距离(KM) */
    private Integer deviceDistance;

    /** 派单要求时长 */
    private BigDecimal sendWorkOrderLimit;

    /** 网络运营商 */
    @Excel(name = "网络运营商")
    private String network;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    /**分工对象 */
    private HswDivideWork divideWork;

    /** 省 */
    private Integer province;

    /** 市 */
    private Integer city;

    /** 县区 */
    private Integer district;

    /** 发生时间-开始时间 */
    private Long takeStartTime;

    /** 发生时间-结束时间 */
    private Long takeEndTime;

    /** 建设单位id */
    private Long cuId;

    /** 维修员id */
    private Long receiverId;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setFaultNo(String faultNo)
    {
        this.faultNo = faultNo;
    }

    public String getFaultNo()
    {
        return faultNo;
    }
    public void setRegionName(String regionName)
    {
        this.regionName = regionName;
    }

    public String getRegionName()
    {
        return regionName;
    }
    public void setIp(String ip)
    {
        this.ip = ip;
    }

    public String getIp()
    {
        return ip;
    }
    public void setSn(String sn)
    {
        this.sn = sn;
    }

    public String getSn()
    {
        return sn;
    }
    public void setPort(Integer port)
    {
        this.port = port;
    }

    public Integer getPort()
    {
        return port;
    }
    public void setType(String type)
    {
        this.type = type;
    }

    public String getType()
    {
        return type;
    }
    public void setTakeTime(Long takeTime)
    {
        this.takeTime = takeTime;
    }

    public Long getTakeTime()
    {
        return takeTime;
    }
    public void setPid(Long pid)
    {
        this.pid = pid;
    }

    public Long getPid()
    {
        return pid;
    }
    public void setDescr(String descr)
    {
        this.descr = descr;
    }

    public String getDescr()
    {
        return descr;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }
    public void setFlagStatus(String flagStatus)
    {
        this.flagStatus = flagStatus;
    }

    public String getFlagStatus()
    {
        return flagStatus;
    }
    public void setRepairTime(Long repairTime)
    {
        this.repairTime = repairTime;
    }

    public Long getRepairTime()
    {
        return repairTime;
    }
    public void setJobId(Long jobId)
    {
        this.jobId = jobId;
    }

    public Long getJobId()
    {
        return jobId;
    }
    public void setJobNo(String jobNo)
    {
        this.jobNo = jobNo;
    }

    public String getJobNo()
    {
        return jobNo;
    }
    public void setMtId(Long mtId)
    {
        this.mtId = mtId;
    }

    public Long getMtId()
    {
        return mtId;
    }
    public void setArea(String area)
    {
        this.area = area;
    }

    public String getArea()
    {
        return area;
    }
    public void setMuId(Long muId)
    {
        this.muId = muId;
    }

    public Long getMuId()
    {
        return muId;
    }
    public void setTodayTakeCount(Long todayTakeCount)
    {
        this.todayTakeCount = todayTakeCount;
    }

    public Long getTodayTakeCount()
    {
        return todayTakeCount;
    }
    public void setDivideWorkId(Long divideWorkId)
    {
        this.divideWorkId = divideWorkId;
    }

    public Long getDivideWorkId()
    {
        return divideWorkId;
    }
    public void setOpState(String opState)
    {
        this.opState = opState;
    }

    public String getOpState()
    {
        return opState;
    }
    public void setZigzagCount(Integer zigzagCount)
    {
        this.zigzagCount = zigzagCount;
    }

    public Integer getZigzagCount()
    {
        return zigzagCount;
    }
    public void setInfluenceCameraCount(Integer influenceCameraCount)
    {
        this.influenceCameraCount = influenceCameraCount;
    }

    public Integer getInfluenceCameraCount()
    {
        return influenceCameraCount;
    }
    public void setZigzagType(Integer zigzagType)
    {
        this.zigzagType = zigzagType;
    }

    public Integer getZigzagType()
    {
        return zigzagType;
    }
    public void setZigzagStatus(Integer zigzagStatus)
    {
        this.zigzagStatus = zigzagStatus;
    }

    public Integer getZigzagStatus()
    {
        return zigzagStatus;
    }
    public void setTimeoutLevel(Long timeoutLevel)
    {
        this.timeoutLevel = timeoutLevel;
    }

    public Long getTimeoutLevel()
    {
        return timeoutLevel;
    }
    public void setStartDistance(Integer startDistance)
    {
        this.startDistance = startDistance;
    }

    public Integer getStartDistance()
    {
        return startDistance;
    }
    public void setEndDistance(Integer endDistance)
    {
        this.endDistance = endDistance;
    }

    public Integer getEndDistance()
    {
        return endDistance;
    }
    public void setTimeoutHour(Integer timeoutHour)
    {
        this.timeoutHour = timeoutHour;
    }

    public Integer getTimeoutHour()
    {
        return timeoutHour;
    }
    public void setDeviceDistance(Integer deviceDistance)
    {
        this.deviceDistance = deviceDistance;
    }

    public Integer getDeviceDistance()
    {
        return deviceDistance;
    }
    public void setSendWorkOrderLimit(BigDecimal sendWorkOrderLimit)
    {
        this.sendWorkOrderLimit = sendWorkOrderLimit;
    }

    public BigDecimal getSendWorkOrderLimit()
    {
        return sendWorkOrderLimit;
    }
    public void setNetwork(String network)
    {
        this.network = network;
    }

    public String getNetwork()
    {
        return network;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("faultNo", getFaultNo())
            .append("regionName", getRegionName())
            .append("ip", getIp())
            .append("sn", getSn())
            .append("port", getPort())
            .append("type", getType())
            .append("takeTime", getTakeTime())
            .append("pid", getPid())
            .append("descr", getDescr())
            .append("status", getStatus())
            .append("flagStatus", getFlagStatus())
            .append("repairTime", getRepairTime())
            .append("jobId", getJobId())
            .append("jobNo", getJobNo())
            .append("mtId", getMtId())
            .append("area", getArea())
            .append("muId", getMuId())
            .append("todayTakeCount", getTodayTakeCount())
            .append("divideWorkId", getDivideWorkId())
            .append("opState", getOpState())
            .append("zigzagCount", getZigzagCount())
            .append("influenceCameraCount", getInfluenceCameraCount())
            .append("zigzagType", getZigzagType())
            .append("zigzagStatus", getZigzagStatus())
            .append("timeoutLevel", getTimeoutLevel())
            .append("startDistance", getStartDistance())
            .append("endDistance", getEndDistance())
            .append("timeoutHour", getTimeoutHour())
            .append("deviceDistance", getDeviceDistance())
            .append("sendWorkOrderLimit", getSendWorkOrderLimit())
            .append("network", getNetwork())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    public Integer getDistrict() {
        return district;
    }

    public void setDistrict(Integer district) {
        this.district = district;
    }

    public Long getTakeStartTime() {
        return takeStartTime;
    }

    public void setTakeStartTime(Long takeStartTime) {
        this.takeStartTime = takeStartTime;
    }

    public Long getTakeEndTime() {
        return takeEndTime;
    }

    public void setTakeEndTime(Long takeEndTime) {
        this.takeEndTime = takeEndTime;
    }

    public HswProject getProject() {
        return project;
    }

    public void setProject(HswProject project) {
        this.project = project;
    }

    public HswDivideWork getDivideWork() {
        return divideWork;
    }

    public void setDivideWork(HswDivideWork divideWork) {
        this.divideWork = divideWork;
    }

    public HswMaintenanceUnits getMaintenanceUnits() {
        return maintenanceUnits;
    }

    public void setMaintenanceUnits(HswMaintenanceUnits maintenanceUnits) {
        this.maintenanceUnits = maintenanceUnits;
    }

    public HswMaintenanceTeam getMaintenanceTeam() {
        return maintenanceTeam;
    }

    public void setMaintenanceTeam(HswMaintenanceTeam maintenanceTeam) {
        this.maintenanceTeam = maintenanceTeam;
    }

    public Long getCuId() {
        return cuId;
    }

    public void setCuId(Long cuId) {
        this.cuId = cuId;
    }

    public Long getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Long receiverId) {
        this.receiverId = receiverId;
    }

    public Date getTakeDate() {
        return takeDate;
    }

    public void setTakeDate(Date takeDate) {
        this.takeDate = takeDate;
    }

    public Date getRepairDate() {
        return repairDate;
    }

    public void setRepairDate(Date repairDate) {
        this.repairDate = repairDate;
    }
}
