package com.ruoyi.hsw.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 故障信息视图
 *
 * @author youyong
 * @date 2020/11/11 0011
 */
@Data
public class FaultViewDto implements Serializable {

    private Integer isFault;

    private Integer faultLevel;

    private JobViewDto workOrder;

    // 故障id
    private Long id;

    // 故障编号
    private String faultNo;

    // 试点位置
    private String regionName;

    // 试点ip
    private String ip;

    //
    private String sn;

    // 端口号
    private Integer port;

    // 发生时间
    private Long takeTime;

    private String takeTimeText;

    // 所属项目
    private Long pid;

    // 故障描述
    private String descr;

    // 故障状态
    private Integer status;

    private String statusText;

    // 归档状态
    private Integer flagStatus;

    // 修复时间
    private Long repairTime;

    private String repairTimeStr;

    private String repairTimeHour;

    // 对应工单id
    private Long jobId;

    // 对应工单编号
    private String jobNo;

    // 维修队id
    private Long mtId;

    // 来源于设备对应分工区域名称（乡镇/街道/小区），便于查询
    @Excel(name = "分工区域", sort = 1, type = Excel.Type.EXPORT)
    private String area;

    // 故障类型
    private Integer type;

    private String typeText;

    // 运维单位id
    private Long muId;

    // 仅对摄像机故障有效，一天该摄像机发生的第几次故障
    private Long todayTakeCount;

    // 故障所属分工区域id
    private Long divideWorkId;

    // 发生时间（yyyy-MM-dd）类型
    private String datestr;

    // 发生时间（yyyy-MM）类型
    private String monthstr;

    // 颠簸次数
    private Long zigzagCount;

    // 影响摄像机数量
    private Double influenceCameraCount;

    // 颠簸故障类型（同故障状态，除工作不稳定2种）
    private Integer zigzagType;

    private String zigzagTypeText;

    // 颠簸状态（0=未处理；1=已处理）
    private Integer zigzagStatus;

    // 操作状态
    private String opState;

    // 超时级别
    private Integer timeoutLevel;

    // 开始距离
    private Integer startDistance;

    // 结束距离
    private Integer endDistance;

    // 超时小时
    private Long timeoutHour;

    //
    private Long deviceDistance;

    // 发送工单限制
    private Double sendWorkOrderLimit;

    // 自动修复时间
    private Long autoRepairTimeCount;

    // 网络运营商
    private String network;

    // 省（项目所属）
    private Integer province;

    // 市（项目所属）
    private Integer city;

    // 县（项目所属）
    private Integer district;

    // 项目名称
    private String projectTitle;

    // 运维单位名称
    private String maintenanceUnitsName;

    // 维修队名称
    private String maintenanceTeamName;

    // 建设单位id
    private Long cuId;

    // 挂起数量
    private Double hungCount;

    // 摄像机总数
    @Excel(name = "摄像机总数", sort = 2, type = Excel.Type.EXPORT)
    private Double cameraCountAll;

    // 平均在线数
    @Excel(name = "平均在线数", sort = 3, type = Excel.Type.EXPORT)
    private Double onlineAvgCount;

    // 平均离线数
    @Excel(name = "平均离线数", sort = 4, type = Excel.Type.EXPORT)
    private Double offlineAvgCount;

    // 平均挂起数
    @Excel(name = "平均挂起数", sort = 5, type = Excel.Type.EXPORT)
    private Double hungAvgCount;

    // 平均在线率
    @Excel(name = "平均在线率", sort = 6, type = Excel.Type.EXPORT)
    private Double onlineAvgRate;

    private String takeTimeStr;
    private String takeTimeHour;
    private Integer userType;
    private Long groupId;
    private Long[] pids; //项目id组，查询用
}
