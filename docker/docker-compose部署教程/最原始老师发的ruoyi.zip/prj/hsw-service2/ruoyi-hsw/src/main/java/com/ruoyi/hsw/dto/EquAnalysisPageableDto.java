package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 设备厂商查询参数
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 16:42
 */
@Data
public class EquAnalysisPageableDto implements Serializable {

    // 分析类型(3=已修复，2=未修复)
    private Integer analysisType;

    // 设备类型(光纤收发器、枪机、球机、半球机)
    private String deviceType;

    // 生产厂家
    private String manufacturer;

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 修复时间
    private Double repaireHour;

    // 项目id集合
    private List<Long> pIds;
}
