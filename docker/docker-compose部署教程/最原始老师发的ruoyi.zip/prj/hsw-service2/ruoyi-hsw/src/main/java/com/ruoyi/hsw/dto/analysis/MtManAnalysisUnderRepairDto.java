package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 维修员分析-维修中
 *
 * @author xiongxiangpeng
 */
@Data
public class MtManAnalysisUnderRepairDto implements Serializable {

    // 运维单位id
    private Long muId;

    // 运维队id
    private Long mtId;

    // 维修员id
    private Long userId;

    // 维修员
    @Excel(name = "维修员", sort = 1)
    private String realName;

    // 运维单位名称
    @Excel(name = "所属运维单位/维修队", sort = 2)
    private String maintenanceUnitsName;

    // 运维队名称
    private String maintenanceTeamName;

    // 工单总数
    @Excel(name = "工单总数(维修中)", sort = 3)
    private Integer totalOrder=0;

    // 维修超时数
    @Excel(name = "超时数(维修中超时)", sort = 4)
    private Integer repaireTimeoutCount=0;

    // 维修超时率
    private Double timeoutRate=0D;

    // 维修超时率
    @Excel(name = "超时率", sort = 5)
    private String timeoutRateString;
}
