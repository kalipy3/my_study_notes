package com.ruoyi.hsw.domain.vo;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 故障统计Vo
 *
 * @author zyj
 * @date 2020/11/14 9:34
 */
@Data
public class FaultStatisticsVo implements Serializable {

    // 日期
    @Excel(name = "日期", sort = 1, type = Excel.Type.EXPORT)
    private String datestr;

    // 市电断电数量
    @Excel(name = "市电断电", sort = 2, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type1Count = 0;

    // 光纤链路故障数量
    @Excel(name = "光纤链路故障", sort = 3, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type2Count = 0;

    // 光纤收发器故障数量
    @Excel(name = "光纤收发器故障", sort = 4, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type3Count = 0;

    // 摄像机链路故障数量
//     @Excel(name = "摄像机链路故障", sort = 5, type = Excel.Type.EXPORT)
    private Integer type4Count = 0;

    // 摄像机故障数量
    @Excel(name = "摄像机故障", sort = 6, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type5Count = 0;

    // 主光缆故障数量
    @Excel(name = "主光缆故障", sort = 7, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type6Count = 0;

    // 诊断器故障数量
    @Excel(name = "诊断器故障", sort = 8, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type7Count = 0;

    // 诊断信号输出不正常数量
//     @Excel(name = "诊断信号输出不正常", sort = 9, type = Excel.Type.EXPORT)
    private Integer type8Count = 0;

    // 工作不稳定数量
    @Excel(name = "工作不稳定", sort = 10, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer type9Count = 0;

    // 工作不稳定-当前故障数量
//     @Excel(name = "工作不稳定-当前故障数量", sort = 11, type = Excel.Type.EXPORT)
    private Integer type10Count = 0;

    // ONU链路故障数量
//     @Excel(name = "ONU链路故障", sort = 13, type = Excel.Type.EXPORT)
    private Integer type11Count = 0;

    // 故障摄像机数量
    private Integer cameraFaultCount = 0;

    // 在线率
    @Excel(name = "在线率", sort = 14, type = Excel.Type.EXPORT)
    private Double onlineRate;

    // 总在线率
    private Double allOnlineRate;

    // 市电断电数量占比
    private Double type1CountRate = 0D;

    // 光纤链路故障数量占比
    private Double type2CountRate = 0D;

    // 光纤收发器故障数量占比
    private Double type3CountRate = 0D;

    // 摄像机链路故障数量占比
    private Double type4CountRate = 0D;

    // 摄像机故障数量占比
    private Double type5CountRate = 0D;

    // 主光缆故障数量占比
    private Double type6CountRate = 0D;

    // 诊断器故障数量占比
    private Double type7CountRate = 0D;

    // 诊断信号输出不正常数量占比
    private Double type8CountRate = 0D;

    // 工作不稳定数量占比
    private Double type9CountRate = 0D;

    // 工作不稳定-当前故障数量占比
    private Double type10CountRate = 0D;

    // ONU链路故障数量占比
    private Double type11CountRate = 0D;

}
