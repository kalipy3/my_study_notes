package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 运维单位分析-未派单
 *
 * @author xiongxiangpeng
 */
@Data
public class MuAnalysisUndeliveredDto implements Serializable {

    // 项目id
    private Long pid;

    // 项目名称
    @Excel(name = "所属项目", sort = 2)
    private String projectTitle;

    // 运维单位id
    private Long muId;

    // 运维单位名称
    @Excel(name = "运维单位", sort = 1)
    private String maintenanceUnitsName;

    // 未派单数
    @Excel(name = "未派单数", sort = 3)
    private Integer totalOrder=0;

    // 超时数(派单超时)
    @Excel(name = "超时数(派单超时)", sort = 4)
    private Integer sendTimeoutCount=0;

    // 超时率
    private Double repairRate=0D;

    // 超时率
    @Excel(name = "超时率", sort = 5)
    private String repairRateString;
}
