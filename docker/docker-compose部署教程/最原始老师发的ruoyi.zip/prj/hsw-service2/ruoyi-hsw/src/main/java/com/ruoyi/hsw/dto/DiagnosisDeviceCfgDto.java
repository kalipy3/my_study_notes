package com.ruoyi.hsw.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/28 0028
 */
@Data
public class DiagnosisDeviceCfgDto implements Serializable {

    @JsonProperty("ip")
    private String ip;

    @JsonProperty("camera_count")
    private Integer cameraCount;

    @JsonProperty("uplink_port")
    private Integer uplinkPort;
}
