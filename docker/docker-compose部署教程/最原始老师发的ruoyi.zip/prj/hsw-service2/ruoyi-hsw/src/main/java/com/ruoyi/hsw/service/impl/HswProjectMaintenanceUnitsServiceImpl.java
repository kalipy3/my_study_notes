package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.domain.HswProjectMaintenanceUnits;
import com.ruoyi.hsw.dto.ProjectMaintenanceUnitsViewDto;
import com.ruoyi.hsw.mapper.HswProjectMaintenanceUnitsMapper;
import com.ruoyi.hsw.service.IHswProjectMaintenanceUnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 项目与运维单位关系Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswProjectMaintenanceUnitsServiceImpl implements IHswProjectMaintenanceUnitsService {
    @Autowired
    private HswProjectMaintenanceUnitsMapper hswProjectMaintenanceUnitsMapper;

    /**
     * 查询项目与运维单位关系
     *
     * @param pid 项目与运维单位关系ID
     * @return 项目与运维单位关系
     */
    @Override
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsById(Long pid) {
        return hswProjectMaintenanceUnitsMapper.selectHswProjectMaintenanceUnitsById(pid);
    }

    /**
     * 查询项目与运维单位关系列表
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 项目与运维单位关系
     */
    @Override
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsList(HswProjectMaintenanceUnits hswProjectMaintenanceUnits) {
        return hswProjectMaintenanceUnitsMapper.selectHswProjectMaintenanceUnitsList(hswProjectMaintenanceUnits);
    }

    /**
     * 新增项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    @Override
    public int insertHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits) {
        hswProjectMaintenanceUnits.setCreateTime(DateUtils.getNowDate());
        return hswProjectMaintenanceUnitsMapper.insertHswProjectMaintenanceUnits(hswProjectMaintenanceUnits);
    }

    /**
     * 修改项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    @Override
    public int updateHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits) {
        hswProjectMaintenanceUnits.setUpdateTime(DateUtils.getNowDate());
        return hswProjectMaintenanceUnitsMapper.updateHswProjectMaintenanceUnits(hswProjectMaintenanceUnits);
    }

    /**
     * 批量删除项目与运维单位关系
     *
     * @param pids 需要删除的项目与运维单位关系ID
     * @return 结果
     */
    @Override
    public int deleteHswProjectMaintenanceUnitsByIds(Long[] pids) {
        return hswProjectMaintenanceUnitsMapper.deleteHswProjectMaintenanceUnitsByIds(pids);
    }

    /**
     * 删除项目与运维单位关系信息
     *
     * @param pid 项目与运维单位关系ID
     * @return 结果
     */
    @Override
    public int deleteHswProjectMaintenanceUnitsById(Long pid) {
        return hswProjectMaintenanceUnitsMapper.deleteHswProjectMaintenanceUnitsById(pid);
    }

    @Override
    public List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewList(Long pid) {
        ProjectMaintenanceUnitsViewDto projectMaintenanceUnitsViewDto = new ProjectMaintenanceUnitsViewDto();
        projectMaintenanceUnitsViewDto.setPid(pid);
        return this.hswProjectMaintenanceUnitsMapper.selectProjectMaintenanceUnitsViewList(projectMaintenanceUnitsViewDto);
    }

    @Override
    public List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewListByPids(Long[] pids) {
        return this.hswProjectMaintenanceUnitsMapper.selectProjectMaintenanceUnitsViewListByPids(pids);
    }

    @Override
    public List<ProjectMaintenanceUnitsViewDto> selectListByPids(List<Long> pids) {
        return this.hswProjectMaintenanceUnitsMapper.selectListByPids(pids);
    }

    @Override
    public List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewList(ProjectMaintenanceUnitsViewDto projectMaintenanceUnitsViewDto) {
        return this.hswProjectMaintenanceUnitsMapper.selectProjectMaintenanceUnitsViewList(projectMaintenanceUnitsViewDto);
    }
}
