package com.ruoyi.hsw.mapper;

import java.util.List;

import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.vo.TreeVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 分工职责Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswDivideWorkMapper {
    /**
     * 查询分工职责
     *
     * @param id 分工职责ID
     * @return 分工职责
     */
    public HswDivideWork selectHswDivideWorkById(Long id);

    /**
     * 查询分工职责列表
     *
     * @param hswDivideWork 分工职责
     * @return 分工职责集合
     */
    public List<HswDivideWork> selectHswDivideWorkList(HswDivideWork hswDivideWork);

    /**
     * 新增分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    public int insertHswDivideWork(HswDivideWork hswDivideWork);

    /**
     * 修改分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    public int updateHswDivideWork(HswDivideWork hswDivideWork);

    /**
     * 删除分工职责
     *
     * @param id 分工职责ID
     * @return 结果
     */
    public int deleteHswDivideWorkById(Long id);

    /**
     * 批量删除分工职责
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswDivideWorkByIds(Long[] ids);

    /**
     * 根据项目id删除
     */
    public int deleteByPid(Long pid);

    /**
     * 根据区域和项目id查询数量
     */
    public int selectCountByArea(@Param("area") String area, @Param("pid") Long pid);

    /**
     * 根据区域、项目id、不等于当前id查询数量
     */
    public int selectCountByAreaWithNeId(@Param("area") String area, @Param("pid") Long pid, @Param("id") Long id);

    /**
     * 根据项目id查询分工
     *
     * @param pid
     * @return
     */
    public List<HswDivideWork> selectHswDivideWorkByPid(Long pid);

    /**
     * 根据区域和项目id查询分工
     *
     * @param area
     * @param pid
     * @return
     */
    public HswDivideWork selectHswDivideWorkByArea(@Param("area") String area, @Param("pid") Long pid);

    /**
     * 根据运维队id获取项目id集合
     */
    public List<Long> selectPidsByAtId(@Param("atId") Long atId);

    /**
     * 根据项目id查询分工树
     *
     * @param pid
     * @return
     */
    public List<TreeVo> selectTreeByPid(Long pid);

    /**
     * 通过项目列表获取分工
     *
     * @param pids
     * @return
     */
    public List<HswDivideWork> selectHswDivideWorkByPids(@Param("pids") Long[] pids);

}
