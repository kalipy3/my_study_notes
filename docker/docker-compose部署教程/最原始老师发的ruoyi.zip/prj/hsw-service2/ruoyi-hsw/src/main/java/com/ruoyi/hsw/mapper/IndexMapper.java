package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.JobViewDto;
import com.ruoyi.hsw.dto.index.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 描述:
 * 首页大屏
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 10:40
 */
@Repository
public interface IndexMapper {
    /**
     * 近一周故障类型分布
     */
    FaultTypeDto faultTypeDistribution(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 近一周故障设备分布
     */
    public FaultEquDto faultEquDistribution(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 活动工单
     */
    public List<JobViewDto> activeJobList(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 活动故障
     */
    public List<FaultViewDto> activeFaultList(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 频繁故障视点
     */
    public List<FaultViewDto> frequentFaultSiteList(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 近6个月工单统计
     */
    public List<ChartDto> monthJobData(@Param("startTime") Long startTime, @Param("endTime") Long endTime);

    /**
     * 近一个月维修队工单统计
     */
    public List<JobMtDataDto> monthJobMtData(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 近一周在线率（当天在线率获取最后一条数据）
     */
    public List<FaultTypeDto> onlineRate(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 诊断器数量统计
     *
     * @param equFaultPageableDto
     * @return
     */
    int diagnosisDeviceCount(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 摄像机数量
     */
    int cameraCount(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 光纤收发器数量
     *
     * @param equFaultPageableDto
     * @return
     */
    int opticalTransceiverCount(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 其他设备数量
     *
     * @param equFaultPageableDto
     * @return
     */
    int otherDeviceCount(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 根据市分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    List<CameraAreaDto> cameraCountGroupByCity(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 根据县/区分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    List<CameraAreaDto> cameraCountGroupByDistrict(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 摄像机故障数量
     *
     * @param equFaultPageableDto
     * @return
     */
    int cameraFaultCount(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 故障趋势
     *
     * @param equFaultPageableDto
     * @return
     */
    List<FaultTypeDto> faultTrend(@Param("vo") EquFaultPageableDto equFaultPageableDto);

    /**
     * 绩效综合对比
     *
     * @param equFaultPageableDto
     * @return
     */
    List<PerformanceDto> performanceComparison(@Param("vo") EquFaultPageableDto equFaultPageableDto);
}