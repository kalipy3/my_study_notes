package com.ruoyi.hsw.dto.index;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 绩效综合对比DTO
 *
 * @author zyj
 * @date 2020/12/16 10:04
 */
@Data
public class PerformanceDto implements Serializable {

    // 运维单位id
    private Long muId;

    // 运维单位名称
    private String muName;

    // 工单总数
    private Integer totalOrder = 0;

    // 超时完成修复完成数量
    private Integer repairTimeoutCount = 0;

    // 派单超时数量
    private Integer sendTimeoutCount = 0;

    // 有效完成数
    private Integer effectiveOrder = 0;

    // 有效派单数
    private Integer sendCount = 0;

    // 维修效率
    private Double repairRate = 0D;

    // 派单效率
    private Double sendRate = 0D;
}
