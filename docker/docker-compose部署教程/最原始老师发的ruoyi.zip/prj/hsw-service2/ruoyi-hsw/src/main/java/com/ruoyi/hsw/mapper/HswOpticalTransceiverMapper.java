package com.ruoyi.hsw.mapper;

import java.util.List;

import com.ruoyi.hsw.domain.HswOpticalTransceiver;
import com.ruoyi.hsw.dto.OpticalTransceiverViewDto;
import org.apache.ibatis.annotations.Param;

/**
 * 光纤收发器Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public interface HswOpticalTransceiverMapper {
    /**
     * 查询光纤收发器
     *
     * @param id 光纤收发器ID
     * @return 光纤收发器
     */
    public HswOpticalTransceiver selectHswOpticalTransceiverById(Long id);

    /**
     * 查询光纤收发器列表
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 光纤收发器集合
     */
    public List<HswOpticalTransceiver> selectHswOpticalTransceiverList(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 新增光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    public int insertHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 修改光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    public int updateHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 删除光纤收发器
     *
     * @param id 光纤收发器ID
     * @return 结果
     */
    public int deleteHswOpticalTransceiverById(Long id);

    /**
     * 批量删除光纤收发器
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswOpticalTransceiverByIds(Long[] ids);

    /**
     * 根据所属诊断器ip删除光纤收发器
     *
     * @param ip
     * @return
     */
    public int deleteHswOpticalTransceiverByIp(String ip);

    /**
     * 校验所属诊断器ip是否唯一
     *
     * @param ip
     * @return
     */
    public HswOpticalTransceiver checkIpUnique(String ip);

    /**
     * 根据所属诊断器ip获取光纤收发器数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    public int selectOpticalTransceiverCountByIp(String ip);

    /**
     * 更新安装时间
     */
    public int finish(@Param("ip") String ip, @Param("time") Long time);

    /**
     * 根据项目id删除
     *
     * @param pid 项目id
     * @return
     */
    public int deleteHswOpticalTransceiverByPid(Long pid);

    /**
     * 根据所属诊断器ip获取光纤收发器
     *
     * @param ip
     * @return
     */
    public HswOpticalTransceiver selectOpticalTransceiverByIp(String ip);

    /**
     * 根据项目id统计光纤收发器数量
     *
     * @param pids
     * @return
     */
    public int selectCountByPid(Long[] pids);

    OpticalTransceiverViewDto selectOpticalTransceiverViewById(Long id);

    List<OpticalTransceiverViewDto> selectOpticalTransceiverViewList(OpticalTransceiverViewDto opticalTransceiverViewDto);

    /**
     * 根据所属诊断器ip修改光纤收发器所属诊断器ip
     *
     * @param newIp 修改后的ip
     * @param oldIp 原ip
     * @return
     */
    int updateIpByIp(@Param("newIp") String newIp, @Param("oldIp") String oldIp);
}
