package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.domain.HswSysMsg;

import java.util.List;

/**
 * 系统消息Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface HswSysMsgMapper {
    /**
     * 查询系统消息
     *
     * @param id 系统消息ID
     * @return 系统消息
     */
    public HswSysMsg selectHswSysMsgById(Long id);

    /**
     * 查询系统消息列表
     *
     * @param hswSysMsg 系统消息
     * @return 系统消息集合
     */
    public List<HswSysMsg> selectHswSysMsgList(HswSysMsg hswSysMsg);

    /**
     * 新增系统消息
     *
     * @param hswSysMsg 系统消息
     * @return 结果
     */
    public int insertHswSysMsg(HswSysMsg hswSysMsg);

    /**
     * 修改系统消息
     *
     * @param hswSysMsg 系统消息
     * @return 结果
     */
    public int updateHswSysMsg(HswSysMsg hswSysMsg);

    /**
     * 删除系统消息
     *
     * @param id 系统消息ID
     * @return 结果
     */
    public int deleteHswSysMsgById(Long id);

    /**
     * 批量删除系统消息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswSysMsgByIds(Long[] ids);
}
