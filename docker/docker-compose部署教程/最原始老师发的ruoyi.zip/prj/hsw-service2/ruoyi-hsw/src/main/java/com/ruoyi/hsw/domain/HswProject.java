package com.ruoyi.hsw.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import org.springframework.data.annotation.Transient;

/**
 * 项目对象 hsw_project
 * 
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswProject extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String title;

    /** 建设时间 */
    @Excel(name = "建设时间")
    private Long buildTime;

    /** 建设时间 */
    private Date buildDateTime;

    /** 建设单位id */
    @Excel(name = "建设单位id")
    private Long cuId;

    /** 施工队id */
    @Excel(name = "施工队id")
    private Long ctId;

    /** 运维队id */
    @Excel(name = "运维队id")
    private Long mtId;

    /** 项目经理信息 */
    @Excel(name = "项目经理信息")
    private String pmInfo;

    /** 电力运营联系人 */
    @Excel(name = "电力运营联系人")
    private String electricityOperatingContacts;

    /** 通讯运营联系人 */
    @Excel(name = "通讯运营联系人")
    private String communicationsOperationsContacts;

    /** 省 */
    @Excel(name = "省")
    private Integer province;

    /** 市 */
    @Excel(name = "市")
    private Integer city;

    /** 区 */
    @Excel(name = "区")
    private Integer district;

    /** 地址 */
    @Excel(name = "地址")
    private String address;

    /** 项目附件（供上传图片使用，大致20张） */
    @Excel(name = "项目附件", readConverterExp = "供=上传图片使用，大致20张")
    private String attachments;

    /** 省名称 */
    @Excel(name = "省名称")
    private String provinceLabel;

    /** 市名称 */
    @Excel(name = "市名称")
    private String cityLabel;

    /** 区名称 */
    @Excel(name = "区名称")
    private String districtLabel;

    /** 竣工日期 */
    @Excel(name = "竣工日期")
    private Long finishTime;

    /** 电力运营单位 */
    @Excel(name = "电力运营单位")
    private String electricityOperating;

    /** 通讯运营单位 */
    @Excel(name = "通讯运营单位")
    private String communicationsOperations;

    /** 超时档位1 */
    @Excel(name = "超时档位1")
    private String timeoutLabel1;

    /** 超时档位2 */
    @Excel(name = "超时档位2")
    private String timeoutLabel2;

    /** 超时档位3 */
    @Excel(name = "超时档位3")
    private String timeoutLabel3;

    /** 最小距离(KM)1 */
    @Excel(name = "最小距离(KM)2")
    private Integer timeoutStart1;

    /** 最大距离(KM)1 */
    @Excel(name = "最大距离(KM)1")
    private Integer timeoutEnd1;

    /** 最小距离(KM)2 */
    @Excel(name = "最小距离(KM)2")
    private Integer timeoutStart2;

    /** 最大距离(KM)2 */
    @Excel(name = "最大距离(KM)2")
    private Integer timeoutEnd2;

    /** 最小距离(KM)3 */
    @Excel(name = "最小距离(KM)3")
    private Integer timeoutStart3;

    /** 最大距离(KM)3 */
    @Excel(name = "最大距离(KM)3")
    private Integer timeoutEnd3;

    /** 超时时长(小时)1 */
    @Excel(name = "超时时长(小时)1")
    private Integer timeoutHour1;

    /** 超时时长(小时)2 */
    @Excel(name = "超时时长(小时)2")
    private Integer timeoutHour2;

    /** 超时时长(小时)3 */
    @Excel(name = "超时时长(小时)3")
    private Integer timeoutHour3;

    /** 派单要求时长（小时） */
    @Excel(name = "派单要求时长（小时）")
    private BigDecimal sendWorkOrderLimit;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    /** 建设单位对象 */
    @Excels({
        @Excel(name = "建设单位名称", targetAttr = "constructingUnitsName", type = Excel.Type.EXPORT)
    })
    private HswConstructingUnits constructingUnits;

    /** 运维单位对象集合 */
    private List<HswMaintenanceUnits> maintenanceUnits;

    /** 运维单位id组 */
    private Long[] maintenanceUnitsIds;

    /** 运维单位di */
    @Transient
    private Long muId;

    public HswProject() {
    }

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setCuId(Long cuId) 
    {
        this.cuId = cuId;
    }

    public Long getCuId() 
    {
        return cuId;
    }
    public void setCtId(Long ctId) 
    {
        this.ctId = ctId;
    }

    public Long getCtId() 
    {
        return ctId;
    }
    public void setMtId(Long mtId) 
    {
        this.mtId = mtId;
    }

    public Long getMtId() 
    {
        return mtId;
    }
    public void setPmInfo(String pmInfo) 
    {
        this.pmInfo = pmInfo;
    }

    public String getPmInfo() 
    {
        return pmInfo;
    }
    public void setElectricityOperatingContacts(String electricityOperatingContacts) 
    {
        this.electricityOperatingContacts = electricityOperatingContacts;
    }

    public String getElectricityOperatingContacts() 
    {
        return electricityOperatingContacts;
    }
    public void setCommunicationsOperationsContacts(String communicationsOperationsContacts) 
    {
        this.communicationsOperationsContacts = communicationsOperationsContacts;
    }

    public String getCommunicationsOperationsContacts() 
    {
        return communicationsOperationsContacts;
    }
    public void setProvince(Integer province) 
    {
        this.province = province;
    }

    public Integer getProvince() 
    {
        return province;
    }
    public void setCity(Integer city) 
    {
        this.city = city;
    }

    public Integer getCity() 
    {
        return city;
    }
    public void setDistrict(Integer district) 
    {
        this.district = district;
    }

    public Integer getDistrict() 
    {
        return district;
    }
    public void setAddress(String address) 
    {
        this.address = address;
    }

    public String getAddress() 
    {
        return address;
    }
    public void setAttachments(String attachments) 
    {
        this.attachments = attachments;
    }

    public String getAttachments() 
    {
        return attachments;
    }
    public void setProvinceLabel(String provinceLabel) 
    {
        this.provinceLabel = provinceLabel;
    }

    public String getProvinceLabel() 
    {
        return provinceLabel;
    }
    public void setCityLabel(String cityLabel) 
    {
        this.cityLabel = cityLabel;
    }

    public String getCityLabel() 
    {
        return cityLabel;
    }
    public void setDistrictLabel(String districtLabel) 
    {
        this.districtLabel = districtLabel;
    }

    public String getDistrictLabel() 
    {
        return districtLabel;
    }
    public void setFinishTime(Long finishTime) 
    {
        this.finishTime = finishTime;
    }

    public Long getFinishTime() 
    {
        return finishTime;
    }
    public void setElectricityOperating(String electricityOperating) 
    {
        this.electricityOperating = electricityOperating;
    }

    public String getElectricityOperating() 
    {
        return electricityOperating;
    }
    public void setCommunicationsOperations(String communicationsOperations) 
    {
        this.communicationsOperations = communicationsOperations;
    }

    public String getCommunicationsOperations() 
    {
        return communicationsOperations;
    }
    public void setTimeoutLabel1(String timeoutLabel1) 
    {
        this.timeoutLabel1 = timeoutLabel1;
    }

    public String getTimeoutLabel1() 
    {
        return timeoutLabel1;
    }
    public void setTimeoutLabel2(String timeoutLabel2) 
    {
        this.timeoutLabel2 = timeoutLabel2;
    }

    public String getTimeoutLabel2() 
    {
        return timeoutLabel2;
    }
    public void setTimeoutLabel3(String timeoutLabel3) 
    {
        this.timeoutLabel3 = timeoutLabel3;
    }

    public String getTimeoutLabel3() 
    {
        return timeoutLabel3;
    }
    public void setTimeoutStart1(Integer timeoutStart1) 
    {
        this.timeoutStart1 = timeoutStart1;
    }

    public Integer getTimeoutStart1() 
    {
        return timeoutStart1;
    }
    public void setTimeoutEnd1(Integer timeoutEnd1) 
    {
        this.timeoutEnd1 = timeoutEnd1;
    }

    public Integer getTimeoutEnd1() 
    {
        return timeoutEnd1;
    }
    public void setTimeoutStart2(Integer timeoutStart2) 
    {
        this.timeoutStart2 = timeoutStart2;
    }

    public Integer getTimeoutStart2() 
    {
        return timeoutStart2;
    }
    public void setTimeoutEnd2(Integer timeoutEnd2) 
    {
        this.timeoutEnd2 = timeoutEnd2;
    }

    public Integer getTimeoutEnd2() 
    {
        return timeoutEnd2;
    }
    public void setTimeoutStart3(Integer timeoutStart3) 
    {
        this.timeoutStart3 = timeoutStart3;
    }

    public Integer getTimeoutStart3() 
    {
        return timeoutStart3;
    }
    public void setTimeoutEnd3(Integer timeoutEnd3) 
    {
        this.timeoutEnd3 = timeoutEnd3;
    }

    public Integer getTimeoutEnd3() 
    {
        return timeoutEnd3;
    }
    public void setTimeoutHour1(Integer timeoutHour1) 
    {
        this.timeoutHour1 = timeoutHour1;
    }

    public Integer getTimeoutHour1() 
    {
        return timeoutHour1;
    }
    public void setTimeoutHour2(Integer timeoutHour2) 
    {
        this.timeoutHour2 = timeoutHour2;
    }

    public Integer getTimeoutHour2() 
    {
        return timeoutHour2;
    }
    public void setTimeoutHour3(Integer timeoutHour3) 
    {
        this.timeoutHour3 = timeoutHour3;
    }

    public Integer getTimeoutHour3() 
    {
        return timeoutHour3;
    }
    public void setSendWorkOrderLimit(BigDecimal sendWorkOrderLimit) 
    {
        this.sendWorkOrderLimit = sendWorkOrderLimit;
    }

    public BigDecimal getSendWorkOrderLimit() 
    {
        return sendWorkOrderLimit;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("title", getTitle())
            .append("cuId", getCuId())
            .append("ctId", getCtId())
            .append("mtId", getMtId())
            .append("pmInfo", getPmInfo())
            .append("electricityOperatingContacts", getElectricityOperatingContacts())
            .append("communicationsOperationsContacts", getCommunicationsOperationsContacts())
            .append("province", getProvince())
            .append("city", getCity())
            .append("district", getDistrict())
            .append("address", getAddress())
            .append("attachments", getAttachments())
            .append("provinceLabel", getProvinceLabel())
            .append("cityLabel", getCityLabel())
            .append("districtLabel", getDistrictLabel())
            .append("remark", getRemark())
            .append("finishTime", getFinishTime())
            .append("electricityOperating", getElectricityOperating())
            .append("communicationsOperations", getCommunicationsOperations())
            .append("timeoutLabel1", getTimeoutLabel1())
            .append("timeoutLabel2", getTimeoutLabel2())
            .append("timeoutLabel3", getTimeoutLabel3())
            .append("timeoutStart1", getTimeoutStart1())
            .append("timeoutEnd1", getTimeoutEnd1())
            .append("timeoutStart2", getTimeoutStart2())
            .append("timeoutEnd2", getTimeoutEnd2())
            .append("timeoutStart3", getTimeoutStart3())
            .append("timeoutEnd3", getTimeoutEnd3())
            .append("timeoutHour1", getTimeoutHour1())
            .append("timeoutHour2", getTimeoutHour2())
            .append("timeoutHour3", getTimeoutHour3())
            .append("sendWorkOrderLimit", getSendWorkOrderLimit())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public HswConstructingUnits getConstructingUnits() {
        return constructingUnits;
    }

    public void setConstructingUnits(HswConstructingUnits constructingUnits) {
        this.constructingUnits = constructingUnits;
    }

    public List<HswMaintenanceUnits> getMaintenanceUnits() {
        return maintenanceUnits;
    }

    public void setMaintenanceUnits(List<HswMaintenanceUnits> maintenanceUnits) {
        this.maintenanceUnits = maintenanceUnits;
    }

    public Long[] getMaintenanceUnitsIds() {
        return maintenanceUnitsIds;
    }

    public void setMaintenanceUnitsIds(Long[] maintenanceUnitsIds) {
        this.maintenanceUnitsIds = maintenanceUnitsIds;
    }

    public Long getMuId() {
        return muId;
    }

    public void setMuId(Long muId) {
        this.muId = muId;
    }

    public Long getBuildTime() {
        return buildTime;
    }

    public void setBuildTime(Long buildTime) {
        this.buildTime = buildTime;
    }

    public Date getBuildDateTime() {
        return buildDateTime;
    }

    public void setBuildDateTime(Date buildDateTime) {
        this.buildDateTime = buildDateTime;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }
}
