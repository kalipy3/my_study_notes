package com.ruoyi.hsw.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 取得活动故障
 *
 * @author youyong
 * @date 2020/11/9 0009
 */
@Data
public class GetActiveFaultDto implements Serializable {
    // 视点IP
    private String ip;

    // 端口号，非摄像机故障为0
    private Integer port;

    // 故障类型
    private String type;

    // 发生时间
    @JsonProperty("take_time")
    private Long takeTime;

    // 颠簸次数
    @JsonProperty("zigzag_count")
    private Integer zigzagCount;

    // 颠簸故障类型
    @JsonProperty("zigzag_type")
    private Integer zigzagType;

    // 颠簸状态
    @JsonProperty("zigzag_status")
    private Integer zigzagStatus;
}
