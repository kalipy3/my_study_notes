package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.domain.HswJobLog;
import com.ruoyi.hsw.mapper.HswJobLogMapper;
import com.ruoyi.hsw.service.IHswJobLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 工单日志Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswJobLogServiceImpl implements IHswJobLogService {
    @Autowired
    private HswJobLogMapper hswJobLogMapper;

    /**
     * 查询工单日志
     *
     * @param id 工单日志ID
     * @return 工单日志
     */
    @Override
    public HswJobLog selectHswJobLogById(Long id) {
        return hswJobLogMapper.selectHswJobLogById(id);
    }

    /**
     * 查询工单日志列表
     *
     * @param hswJobLog 工单日志
     * @return 工单日志
     */
    @Override
    public List<HswJobLog> selectHswJobLogList(HswJobLog hswJobLog) {
        return hswJobLogMapper.selectHswJobLogList(hswJobLog);
    }

    /**
     * 新增工单日志
     *
     * @param hswJobLog 工单日志
     * @return 结果
     */
    @Override
    public int insertHswJobLog(HswJobLog hswJobLog) {
        hswJobLog.setCreateBy(SecurityUtils.getUsername());
        hswJobLog.setCreateTime(DateUtils.getNowDate());
        return hswJobLogMapper.insertHswJobLog(hswJobLog);
    }

    /**
     * 修改工单日志
     *
     * @param hswJobLog 工单日志
     * @return 结果
     */
    @Override
    public int updateHswJobLog(HswJobLog hswJobLog) {
        hswJobLog.setUpdateBy(SecurityUtils.getUsername());
        hswJobLog.setUpdateTime(DateUtils.getNowDate());
        return hswJobLogMapper.updateHswJobLog(hswJobLog);
    }

    /**
     * 批量删除工单日志
     *
     * @param ids 需要删除的工单日志ID
     * @return 结果
     */
    @Override
    public int deleteHswJobLogByIds(Long[] ids) {
        return hswJobLogMapper.deleteHswJobLogByIds(ids);
    }

    /**
     * 删除工单日志信息
     *
     * @param id 工单日志ID
     * @return 结果
     */
    @Override
    public int deleteHswJobLogById(Long id) {
        return hswJobLogMapper.deleteHswJobLogById(id);
    }
}
