package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 运维单位分析-自动修复
 *
 * @author xiongxiangpeng
 */
@Data
public class MuAnalysisAutoDto implements Serializable {

    // 项目id
    private Long pid;

    // 项目名称
    @Excel(name = "所属项目", sort = 2)
    private String projectTitle;

    // 运维单位id
    private Long muId;

    // 运维单位名称
    @Excel(name = "运维单位", sort = 1)
    private String maintenanceUnitsName;

    // 故障总数
    @Excel(name = "故障总数", sort = 3)
    private Integer totalOrder=0;

    // 自动修复数
    @Excel(name = "自动修复数", sort = 4)
    private Integer autoRepairCount=0;

    // 总自动修复时长
    private Long totalAutoRepairTime=0L;

    // 平均修复时长(小时)
    @Excel(name = "平均修复时长(小时)", sort = 5)
    private Double repairAvg=0D;

    // 占比
    private Double repairRate=0D;

    // 占比
    @Excel(name = "占比", sort = 6)
    private String repairRateString;
}
