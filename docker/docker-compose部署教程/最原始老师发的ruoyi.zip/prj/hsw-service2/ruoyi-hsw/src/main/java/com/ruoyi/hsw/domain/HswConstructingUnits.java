package com.ruoyi.hsw.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * 建设单位对象 hsw_constructing_units
 * 
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswConstructingUnits extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String name;

    /** 负责人 */
    @Excel(name = "负责人")
    private String leader;

    /** 电话 */
    @Excel(name = "电话")
    private String tel;

    /** 阿里云AccessKeyId */
    @Excel(name = "阿里云AccessKeyId")
    private String accessKeyId;

    /** 阿里云AccessKeySecret */
    @Excel(name = "阿里云AccessKeySecret")
    private String accessKeySecret;

    /** 阿里云短信签名 */
    @Excel(name = "阿里云短信签名")
    private String signName;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    // id列表（查询使用）
    private List<Long> ids;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    @NotBlank(message = "名称不能为空")
    public String getName() 
    {
        return name;
    }
    public void setLeader(String leader) 
    {
        this.leader = leader;
    }

    @NotBlank(message = "负责人不能为空")
    public String getLeader() 
    {
        return leader;
    }
    public void setTel(String tel) 
    {
        this.tel = tel;
    }

    @NotBlank(message = "电话不能为空")
    public String getTel() 
    {
        return tel;
    }
    public void setAccessKeyId(String accessKeyId) 
    {
        this.accessKeyId = accessKeyId;
    }

    public String getAccessKeyId() 
    {
        return accessKeyId;
    }
    public void setAccessKeySecret(String accessKeySecret) 
    {
        this.accessKeySecret = accessKeySecret;
    }

    public String getAccessKeySecret() 
    {
        return accessKeySecret;
    }
    public void setSignName(String signName) 
    {
        this.signName = signName;
    }

    public String getSignName() 
    {
        return signName;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("leader", getLeader())
            .append("tel", getTel())
            .append("accessKeyId", getAccessKeyId())
            .append("accessKeySecret", getAccessKeySecret())
            .append("signName", getSignName())
            .append("delFlag", getDelFlag())
            .append("ids", getIds())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
