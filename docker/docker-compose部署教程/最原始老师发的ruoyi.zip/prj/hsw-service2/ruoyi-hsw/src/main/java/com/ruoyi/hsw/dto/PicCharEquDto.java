package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 设备厂商饼状图
 *
 * @author xiongxiangpeng
 * @create 2020-11-18 16:51
 */
@Data
public class PicCharEquDto implements Serializable {

    // 枪机
    private Integer dt1;

    // 球机
    private Integer dt2;

    // 半球机
    private Integer dt3;

    // 时间区间0-6小时
    private Integer hour1;

    // 时间区间6-12小时
    private Integer hou2;

    // 时间区间12-24小时
    private Integer hour3;

    // 时间区间1-3天
    private Integer hour4;

    // 时间区间3天以上
    private Integer hour5;

}
