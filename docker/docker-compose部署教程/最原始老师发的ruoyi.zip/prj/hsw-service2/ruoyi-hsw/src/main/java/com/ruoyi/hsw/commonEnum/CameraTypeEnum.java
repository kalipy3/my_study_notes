package com.ruoyi.hsw.commonEnum;

public enum CameraTypeEnum {

    QIANGJI("1", "枪机"),
    QIUJI("2", "球机"),
    BANQIUJI("3", "半球机");

    private String value;
    private String label;

    CameraTypeEnum(String value, String label) {
        this.value = value;
        this.label = label;
    }

    public String getValue() {
        return this.value;
    }

    public String getLabel() {
        return this.label;
    }
}
