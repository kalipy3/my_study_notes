package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.commonEnum.FaultTypeEnum;
import com.ruoyi.hsw.commonEnum.HandleStatusEnum;
import com.ruoyi.hsw.commonEnum.JobStatusEnum;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.*;
import com.ruoyi.hsw.domain.vo.JobStaffStatisticsVo;
import com.ruoyi.hsw.domain.vo.JobTeamStatisticsVo;
import com.ruoyi.hsw.dto.JobViewDto;
import com.ruoyi.hsw.mapper.HswFaultInfoMapper;
import com.ruoyi.hsw.mapper.HswJobInfoMapper;
import com.ruoyi.hsw.mapper.HswJobLogMapper;
import com.ruoyi.hsw.service.IHswJobInfoService;
import com.ruoyi.hsw.service.IHswSysMsgService;
import com.ruoyi.hsw.service.IHswUserMsgService;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.mapper.SysUserMapper;
import com.ruoyi.system.service.ISysConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.text.DecimalFormat;
import java.util.*;

/**
 * 工单Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswJobInfoServiceImpl implements IHswJobInfoService {
    @Autowired
    private HswJobInfoMapper hswJobInfoMapper;

    @Autowired
    private HswFaultInfoMapper hswFaultInfoMapper;

    @Autowired
    private HswJobLogMapper hswJobLogMapper;

    @Lazy
    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private IHswSysMsgService sysMsgService;

    @Autowired
    private IHswUserMsgService userMsgService;

    /**
     * 查询工单
     *
     * @param id 工单ID
     * @return 工单
     */
    @Override
    public HswJobInfo selectHswJobInfoById(Long id) {
        HswJobInfo hswJobInfo = hswJobInfoMapper.selectHswJobInfoById(id);
        if (hswJobInfo != null) {
            SysUser user = this.sysUserMapper.selectUserById(hswJobInfo.getSendUid());
            if (user != null) {
                hswJobInfo.setSendName(user.getNickName());
            }
            SysUser sysUser = this.sysUserMapper.selectUserById(hswJobInfo.getReceiverId());
            if (sysUser != null) {
                hswJobInfo.setReceiverName(sysUser.getNickName());
            }
            HswJobLog hswJobLog = new HswJobLog();
            hswJobLog.setJobId(hswJobInfo.getId());
            List<HswJobLog> hswJobLogs = this.hswJobLogMapper.selectHswJobLogList(hswJobLog);
            if (!hswJobLogs.isEmpty()) {
                hswJobInfo.setJobLogs(hswJobLogs);
            }
        }
        return hswJobInfo;
    }

    /**
     * 查询工单列表
     *
     * @param hswJobInfo 工单
     * @return 工单
     */
    @Override
    public List<HswJobInfo> selectHswJobInfoList(HswJobInfo hswJobInfo) {
        List<HswJobInfo> hswJobInfos = hswJobInfoMapper.selectHswJobInfoList(hswJobInfo);
        if (!hswJobInfos.isEmpty()) {
            hswJobInfos.forEach(jobInfo -> {
                if (jobInfo.getSendTime() > 0) {
                    if (jobInfo.getStatus() == JobStatusEnum.WXZ.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (DateUtils.getDateMr(new Date()) - jobInfo.getSendTime()) / (60 * 60D))));
                    } else if (jobInfo.getStatus() == JobStatusEnum.YXF.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (jobInfo.getRepairTime() - jobInfo.getSendTime()) / (60 * 60D))));
                    }
                } else {
                    jobInfo.setRepairedTime(0D);
                }
            });
        }
        return hswJobInfos;
    }

    /**
     * 查询历史工单列表
     */
    @Override
    public List<HswJobInfo> selectHistoryList(HswJobInfo hswJobInfo) {
        List<HswJobInfo> hswJobInfos = hswJobInfoMapper.selectHistoryList(hswJobInfo);
        if (!hswJobInfos.isEmpty()) {
            hswJobInfos.forEach(jobInfo -> {
                if (jobInfo.getSendTime() > 0) {
                    if (jobInfo.getStatus() == JobStatusEnum.WXZ.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (DateUtils.getDateMr(new Date()) - jobInfo.getSendTime()) / (60 * 60D))));
                    } else if (jobInfo.getStatus() == JobStatusEnum.YXF.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (jobInfo.getRepairTime() - jobInfo.getSendTime()) / (60 * 60D))));
                    }
                } else {
                    jobInfo.setRepairedTime(0D);
                }
            });
        }
        return hswJobInfos;
    }

    /**
     * 新增工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    @Override
    public int insertHswJobInfo(HswJobInfo hswJobInfo) {
        hswJobInfo.setCreateBy(SecurityUtils.getUsername());
        hswJobInfo.setCreateTime(DateUtils.getNowDate());
        return hswJobInfoMapper.insertHswJobInfo(hswJobInfo);
    }

    /**
     * 修改工单
     *
     * @param hswJobInfo 工单
     * @return 结果
     */
    @Override
    public int updateHswJobInfo(HswJobInfo hswJobInfo) {
        hswJobInfo.setUpdateBy(SecurityUtils.getUsername());
        hswJobInfo.setUpdateTime(DateUtils.getNowDate());
        return hswJobInfoMapper.updateHswJobInfo(hswJobInfo);
    }

    /**
     * 批量删除工单
     *
     * @param ids 需要删除的工单ID
     * @return 结果
     */
    @Override
    public int deleteHswJobInfoByIds(Long[] ids) {
        return hswJobInfoMapper.deleteHswJobInfoByIds(ids);
    }

    /**
     * 删除工单信息
     *
     * @param id 工单ID
     * @return 结果
     */
    @Override
    public int deleteHswJobInfoById(Long id) {
        return hswJobInfoMapper.deleteHswJobInfoById(id);
    }

    @Override
    public boolean existFaultId(Long faultId) {
        return this.hswJobInfoMapper.selectCountByFaultId(faultId) > 0;
    }

    /**
     * 接单
     */
    @Override
    public int accept(HswJobInfo hswJobInfo) {

        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            SysUser user = SecurityUtils.getLoginUser().getUser();
            SysUser sysUser = this.sysUserMapper.selectUserById(jobViewDto.getSendUid());
            hswJobInfo.setReceiverTime(DateUtils.getDateMr(new Date()));
            hswJobInfo.setStatus(JobStatusEnum.WXZ.getValue());
            hswJobInfo.setHandleStatus(HandleStatusEnum.YJD.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);
            // 接单成功
            if (update > 0) {

                this.hswFaultInfoMapper.updateStatusById(hswJobInfo.getFaultId(), JobStatusEnum.WXZ.getValue(), user.getNickName());

                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(JobStatusEnum.WXZ.getValue());
                hswJobLog.setHandleStatus(HandleStatusEnum.YJD.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(hswJobInfo.getReceiverTime());
                hswJobLog.setHandleReason("维修员接单");
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                Map<String, Object> map = new HashMap<>();
                map.put("job_no", jobViewDto.getJobNo());
                map.put("name", user.getNickName());
                map.put("send_name", user.getNickName());
                map.put("receiver_id", jobViewDto.getSendUid());
                map.put("receiver_name", sysUser.getNickName());

                sendMsg("TPL_MSG_JS", map);
            }
            return update;
        }

        return 0;
    }

    /**
     * 拒绝派单
     */
    @Override
    public int refuse(HswJobInfo hswJobInfo) {

        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            SysUser user = SecurityUtils.getLoginUser().getUser();
            SysUser sysUser = this.sysUserMapper.selectUserById(jobViewDto.getSendUid());
            hswJobInfo.setHandleStatus(HandleStatusEnum.YJJ.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId());
                hswJobLog.setJobNo(jobViewDto.getJobNo());
                hswJobLog.setJobStatus(jobViewDto.getStatus());
                hswJobLog.setHandleStatus(HandleStatusEnum.YJJ.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                Map<String, Object> map = new HashMap<>();
                map.put("job_no", jobViewDto.getJobNo());
                map.put("name", user.getNickName());
                map.put("send_name", user.getNickName());
                map.put("receiver_id", jobViewDto.getSendUid());
                map.put("receiver_name", sysUser.getNickName());
                map.put("reason", hswJobInfo.getRejection());

                sendMsg("TPL_MSG_JJ", map);
            }

            return update;
        }

        return 0;
    }

    /**
     * 申请改派
     */
    @Override
    public Map<String, Object> applyChangeAssign(HswJobInfo hswJobInfo) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        SysUser user = SecurityUtils.getLoginUser().getUser();

        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());
        if (jobViewDto != null) {
            hswJobInfo.setHandleStatus(HandleStatusEnum.SQGP.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(hswJobInfo.getStatus());
                hswJobLog.setHandleStatus(HandleStatusEnum.SQGP.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("sendUid", jobViewDto.getSendUid());
            }
        }

        return map;
    }

    /**
     * 改派工单
     */
    @Override
    public Map<String, Object> reAssign(HswJobInfo hswJobInfo, Long receiverId) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());
        if (jobViewDto != null) {
            Long oldReceiverId = jobViewDto.getReceiverId();
            HswJobLog hswJobLog = new HswJobLog();
            hswJobLog.setOldReceiverId(hswJobInfo.getReceiverId());

            SysUser user = SecurityUtils.getLoginUser().getUser();

            hswJobInfo.setSendTime(DateUtils.getDateMr(new Date()));
            hswJobInfo.setSendUid(user.getUserId());
            hswJobInfo.setHandleStatus(HandleStatusEnum.YGP.getValue());
            hswJobInfo.setReceiverId(receiverId);
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(JobStatusEnum.WPD.getValue());
                hswJobLog.setHandleStatus(HandleStatusEnum.YGP.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(hswJobInfo.getSendTime());
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("oldReceiverId", oldReceiverId);

            }
        }

        return map;
    }

    /**
     * 拒绝改派
     */
    @Override
    public Map<String, Object> refuseAssign(HswJobInfo hswJobInfo) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());
        if (jobViewDto != null) {
            HswJobLog hswJobLog = new HswJobLog();
            SysUser user = SecurityUtils.getLoginUser().getUser();

            hswJobInfo.setHandleStatus(HandleStatusEnum.BHGP.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                hswJobLog.setJobId(jobViewDto.getId());
                hswJobLog.setJobNo(jobViewDto.getJobNo());
                hswJobLog.setJobStatus(jobViewDto.getStatus());
                hswJobLog.setHandleStatus(HandleStatusEnum.BHGP.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("receiverId", jobViewDto.getReceiverId());
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());

            }
        }

        return map;
    }

    /**
     * 维修员维修后反馈
     */
    @Override
    public Map<String, Object> repair(HswJobInfo hswJobInfo) {
        SysUser user = SecurityUtils.getLoginUser().getUser();

        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());
        if (jobViewDto != null) {
            if (jobViewDto.getReceiverId().equals(user.getUserId())) {
                hswJobInfo.setRepairTime(DateUtils.getDateMr(new Date()));
                hswJobInfo.setStatus(JobStatusEnum.YXF.getValue());
                hswJobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY);
                hswJobInfo.setUpdateBy(user.getNickName());
                hswJobInfo.setUpdateTime(new Date());
                int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);
                if (update > 0) {
                    HswFaultInfo faultInfo = new HswFaultInfo();
                    if (jobViewDto.getType().equals(FaultTypeEnum.GZBWD.getValue()) || jobViewDto.getType().equals(FaultTypeEnum.GZBWD_DQGZ.getValue())) {
                        faultInfo.setId(jobViewDto.getFaultId());
                        faultInfo.setStatus(JobStatusEnum.YXF.getValue().toString());
                        faultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                        faultInfo.setRepairTime(hswJobInfo.getRepairTime());
                        faultInfo.setZigzagStatus(HandleStatusEnum.YJD.getValue());
                        faultInfo.setUpdateBy(user.getNickName());
                        faultInfo.setUpdateTime(new Date());
                        this.hswFaultInfoMapper.updateHswFaultInfo(faultInfo);
                    } else {
                        faultInfo.setId(jobViewDto.getFaultId());
                        faultInfo.setStatus(JobStatusEnum.YXF.getValue().toString());
                        faultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                        faultInfo.setRepairTime(hswJobInfo.getRepairTime());
                        faultInfo.setUpdateBy(user.getNickName());
                        faultInfo.setUpdateTime(new Date());
                        this.hswFaultInfoMapper.updateHswFaultInfo(faultInfo);
                    }

                    HswJobLog hswJobLog = new HswJobLog();
                    hswJobLog.setJobId(hswJobInfo.getId());
                    hswJobLog.setJobNo(hswJobInfo.getJobNo());
                    hswJobLog.setJobStatus(hswJobInfo.getStatus());
                    hswJobLog.setHandleStatus(HandleStatusEnum.YWC.getValue());
                    hswJobLog.setHandleUid(user.getUserId());
                    hswJobLog.setHandleUname(user.getNickName());
                    hswJobLog.setHandleTime(hswJobInfo.getRepairTime());
                    hswJobLog.setHandleReason(hswJobInfo.getRejection());
                    hswJobLog.setCreateBy(user.getNickName());
                    hswJobLog.setCreateTime(new Date());
                    this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                    map.put("code", update);
                    map.put("jobNo", jobViewDto.getJobNo());
                    map.put("sendUid", jobViewDto.getSendUid());
                    map.put("regionName", jobViewDto.getRegionName());
                    map.put("takeTime", jobViewDto.getTakeTime());
                    map.put("cuId", jobViewDto.getCuId());
                }
            }
        }

        return map;
    }

    /**
     * 申请挂起
     */
    @Override
    public Map<String, Object> applyHangUp(HswJobInfo hswJobInfo) {

        SysUser user = SecurityUtils.getLoginUser().getUser();

        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());
        if (jobViewDto != null) {
            hswJobInfo.setHandleStatus(HandleStatusEnum.SQGQ.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(hswJobInfo.getStatus());
                hswJobLog.setHandleStatus(HandleStatusEnum.SQGQ.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("sendUid", jobViewDto.getSendUid());
            }
        }

        return map;
    }

    /**
     * 0=未派单；1=待接单；2=在修； 3=已修复；4=挂起
     * 挂起工单
     */
    @Override
    public Map<String, Object> hangUp(HswJobInfo hswJobInfo) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        SysUser user = SecurityUtils.getLoginUser().getUser();
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            hswJobInfo.setStatus(JobStatusEnum.YGQ.getValue());
            hswJobInfo.setHandleStatus(HandleStatusEnum.YGQ.getValue());
            hswJobInfo.setHangUpTime(DateUtils.getDateMr(new Date()));
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                // 更新故障
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                hswFaultInfo.setStatus(JobStatusEnum.YGQ.getValue().toString()); // 故障状态
                hswFaultInfo.setUpdateBy(user.getNickName());
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(JobStatusEnum.YGQ.getValue());
                hswJobLog.setHandleStatus(HandleStatusEnum.YGQ.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getHangUpReason());
                hswJobLog.setOldReceiverId(jobViewDto.getReceiverId());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("receiverId", jobViewDto.getReceiverId());
            }
        }

        return map;
    }

    /**
     * 0=未派单；1=待接单；2=在修； 3=已修复；4=挂起
     * 拒绝挂起工单
     */
    @Override
    public Map<String, Object> refuseHangUp(HswJobInfo hswJobInfo) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        SysUser user = SecurityUtils.getLoginUser().getUser();
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            hswJobInfo.setHandleStatus(HandleStatusEnum.BHGQ.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(hswJobInfo.getStatus());
                hswJobLog.setHandleStatus(HandleStatusEnum.BHGQ.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getHangUpReason());

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("receiverId", jobViewDto.getReceiverId());
            }
        }

        return map;
    }

    /**
     * 撤回挂起
     */
    @Override
    public Map<String, Object> resume(HswJobInfo hswJobInfo) {

        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        SysUser user = SecurityUtils.getLoginUser().getUser();
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            hswJobInfo.setStatus(JobStatusEnum.WPD.getValue());
            hswJobInfo.setStatus(JobStatusEnum.WXZ.getValue());
            hswJobInfo.setResumeTime(DateUtils.getDateMr(new Date()));
            hswJobInfo.setReceiverTime(DateUtils.getDateMr(new Date()));
            hswJobInfo.setHandleStatus(HandleStatusEnum.YCHGQ.getValue());
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                //更新故障信息的状态
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setId(hswJobInfo.getFaultId());
                hswFaultInfo.setStatus(JobStatusEnum.WXZ.getValue().toString());
                hswFaultInfo.setUpdateBy(user.getNickName());
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);

                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(JobStatusEnum.WXZ.getValue());
                hswJobLog.setHandleStatus(HandleStatusEnum.YCHGQ.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("receiverId", hswJobInfo.getReceiverId());
            }
        }

        return map;
    }

    /**
     * 撤销工单
     */
    @Override
    public Map<String, Object> revoke(HswJobInfo hswJobInfo) {

        Map<String, Object> map = new HashMap<>();
        map.put("code", 0);
        SysUser user = SecurityUtils.getLoginUser().getUser();
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(hswJobInfo.getId());

        if (jobViewDto != null) {
            hswJobInfo.setStatus(JobStatusEnum.YCD.getValue());
            hswJobInfo.setHandleStatus(HandleStatusEnum.YCD.getValue());
            hswJobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY);
            hswJobInfo.setUpdateBy(user.getNickName());
            hswJobInfo.setUpdateTime(new Date());
            int update = this.hswJobInfoMapper.updateHswJobInfo(hswJobInfo);

            if (update > 0) {
                //更新故障信息的状态
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setId(hswJobInfo.getFaultId());
                hswFaultInfo.setStatus(JobStatusEnum.YCD.getValue().toString());
                hswFaultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                hswFaultInfo.setUpdateBy(user.getNickName());
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);

                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(hswJobInfo.getId());
                hswJobLog.setJobNo(hswJobInfo.getJobNo());
                hswJobLog.setJobStatus(JobStatusEnum.YCD.getValue());
                hswJobLog.setHandleStatus(HandleStatusEnum.YCD.getValue());
                hswJobLog.setHandleUid(user.getUserId());
                hswJobLog.setHandleUname(user.getNickName());
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date()));
                hswJobLog.setHandleReason(hswJobInfo.getRejection());
                hswJobLog.setCreateBy(user.getNickName());
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);

                map.put("code", update);
                map.put("jobNo", jobViewDto.getJobNo());
                map.put("cuId", jobViewDto.getCuId());
                map.put("receiverId", jobViewDto.getReceiverId());
            }
        }

        return map;
    }

    @Override
    public List<JobViewDto> selectJobViewList(JobViewDto jobViewDto) {
        return this.hswJobInfoMapper.selectJobViewList(jobViewDto);
    }

    @Override
    public JobViewDto selectJobViewById(Long id) {
        return this.hswJobInfoMapper.selectJobViewById(id);
    }

    /**
     * app改派工单 同意/拒绝
     */
    @Override
    public Map<String, Object> changeAssignForApp(Long id, Long userId, Long receiverId, String reason, String nickName) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            Long oldReceiverId = jobViewDto.getReceiverId();
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setSendTime(DateUtils.getDateMr(new Date())); // 派单时间
            jobInfo.setSendUid(userId); // 派单人
            jobInfo.setReceiverId(receiverId); // 接单人
            jobInfo.setHandleStatus(HandleStatusEnum.YGP.getValue()); // 操作状态
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "改派成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("oldReceiverId", oldReceiverId);
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.WPD.getValue()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.YGP.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(jobInfo.getSendTime()); // 操作时间
                hswJobLog.setOldReceiverId(oldReceiverId); // 原接单人
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "改派失败：改派工单失败");
                return msg;
            }
        } else {
            msg.put("msg", "改派失败:找不到要改派的故障单");
            return msg;
        }
    }

    /**
     * app改派工单 拒绝
     */
    @Override
    public Map<String, Object> refuseChangeAssignForApp(Long id, String reason, Long userId, String nickName) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setHandleStatus(HandleStatusEnum.BHGP.getValue()); // 操作状态
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "拒绝改派成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("receiverId", jobViewDto.getReceiverId());
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(jobViewDto.getStatus()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.BHGP.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                hswJobLog.setHandleReason(reason); // 操作原因
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "拒绝改派失败：拒绝改派工单失败");
                return msg;
            }
        } else {
            msg.put("msg", "拒绝改派失败：未找到该工单");
            return msg;
        }
    }

    /**
     * app申请改派
     */
    @Override
    public Map<String, Object> applyChangeAssignForApp(Long id, Long userId, String nickName, String handleReason) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            if (jobViewDto.getReceiverId().equals(userId)) {
                HswJobInfo jobInfo = new HswJobInfo();
                jobInfo.setId(id);
                jobInfo.setHandleStatus(HandleStatusEnum.SQGP.getValue()); // 操作状态
                jobInfo.setUpdateBy(nickName);
                jobInfo.setUpdateTime(new Date());
                int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
                if (res > 0) {
                    msg.put("code", 1);
                    msg.put("msg", "申请成功");
                    msg.put("jobNo", jobViewDto.getJobNo());
                    msg.put("cuId", jobViewDto.getCuId());
                    msg.put("sendUid", jobViewDto.getSendUid());
                    HswJobLog hswJobLog = new HswJobLog();
                    hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                    hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                    hswJobLog.setJobStatus(jobViewDto.getStatus()); // 工单状态
                    hswJobLog.setHandleStatus(HandleStatusEnum.SQGP.getValue()); // 操作状态
                    hswJobLog.setHandleUid(userId); // 操作人id
                    hswJobLog.setHandleUname(nickName); // 操作人姓名
                    hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                    hswJobLog.setHandleReason(handleReason); // 操作原因
                    hswJobLog.setCreateBy(nickName);
                    hswJobLog.setCreateTime(new Date());
                    this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                    return msg;
                } else {
                    msg.put("msg", "申请失败：申请改派失败");
                    return msg;
                }
            } else {
                msg.put("msg", "申请失败：非法参数，该工单未派单于您");
                return msg;
            }
        } else {
            msg.put("msg", "申请失败：未找到该工单");
            return msg;
        }
    }

    /**
     * app申请挂起
     */
    @Override
    public Map<String, Object> applyHangUpForApp(Long id, Long userId, String nickName, String handleReason) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            if (jobViewDto.getReceiverId().equals(userId)) {
                HswJobInfo jobInfo = new HswJobInfo();
                jobInfo.setId(id);
                jobInfo.setHandleStatus(HandleStatusEnum.SQGQ.getValue()); // 操作状态
                jobInfo.setUpdateBy(nickName);
                jobInfo.setUpdateTime(new Date());
                int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
                if (res > 0) {
                    msg.put("code", 1);
                    msg.put("msg", "申请挂起成功");
                    msg.put("jobNo", jobViewDto.getJobNo());
                    msg.put("cuId", jobViewDto.getCuId());
                    msg.put("sendUid", jobViewDto.getSendUid());
                    HswJobLog hswJobLog = new HswJobLog();
                    hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                    hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                    hswJobLog.setJobStatus(jobViewDto.getStatus()); // 工单状态
                    hswJobLog.setHandleStatus(HandleStatusEnum.SQGQ.getValue()); // 操作状态
                    hswJobLog.setHandleUid(userId); // 操作人id
                    hswJobLog.setHandleUname(nickName); // 操作人姓名
                    hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                    hswJobLog.setHandleReason(handleReason); // 操作原因
                    hswJobLog.setCreateBy(nickName);
                    hswJobLog.setCreateTime(new Date());
                    this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                    return msg;
                } else {
                    msg.put("msg", "申请失败：申请挂起失败");
                    return msg;
                }
            } else {
                msg.put("msg", "申请挂起失败：非法参数，该工单未派单于您");
                return msg;
            }
        } else {
            msg.put("msg", "申请挂起失败：未找到该工单");
            return msg;
        }
    }

    /**
     * app挂起 同意
     */
    @Override
    public Map<String, Object> hangUpForApp(Long id, Long userId, String nickName, String reason) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            Long oldReceiverId = jobViewDto.getReceiverId();
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setStatus(JobStatusEnum.YGQ.getValue()); // 工单状态
            jobInfo.setHangUpReason(reason); // 挂起原因
            jobInfo.setHandleStatus(HandleStatusEnum.YGQ.getValue()); // 操作状态
            jobInfo.setHangUpTime(DateUtils.getDateMr(new Date())); // 挂起时间
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "挂起成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("receiverId", jobViewDto.getReceiverId());
                // 更新故障
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setStatus(JobStatusEnum.YGQ.getValue().toString());
                hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                hswFaultInfo.setUpdateBy(nickName);
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.YGQ.getValue()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.YGQ.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                hswJobLog.setHandleReason(reason); // 操作原因
                hswJobLog.setOldReceiverId(oldReceiverId); // 原接单人
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "申请失败：申请挂起失败");
                return msg;
            }
        } else {
            msg.put("msg", "申请挂起失败：未找到该工单");
            return msg;
        }
    }

    /**
     * app 拒绝挂起
     */
    @Override
    public Map<String, Object> refuseHangUpForApp(Long id, Long userId, String nickName, String reason) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setHandleStatus(HandleStatusEnum.BHGQ.getValue()); // 操作状态
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "拒绝挂起成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("receiverId", jobViewDto.getReceiverId());
                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(jobViewDto.getStatus()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.BHGQ.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                hswJobLog.setHandleReason(reason); // 操作原因
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "拒绝失败：拒绝挂起失败");
                return msg;
            }
        } else {
            msg.put("msg", "拒绝挂起失败：未找到该工单");
            return msg;
        }
    }

    /**
     * app撤回挂起
     */
    @Override
    public Map<String, Object> resumeForApp(Long id, Long userId, String nickName, String reason, Long receiverId) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        // TODO:
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setStatus(JobStatusEnum.WXZ.getValue()); // 工单状态
            jobInfo.setResumeTime(DateUtils.getDateMr(new Date())); // 建立时间
            jobInfo.setReceiverTime(DateUtils.getDateMr(new Date())); // 接单时间
            jobInfo.setReceiverId(receiverId); // 接单人id
            jobInfo.setHandleStatus(HandleStatusEnum.YCHGQ.getValue()); // 操作状态
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "撤回挂起成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("receiverId", receiverId);
                // 更新故障
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setStatus(JobStatusEnum.WXZ.getValue().toString());
                hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                hswFaultInfo.setUpdateBy(nickName);
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.WXZ.getValue()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.YCHGQ.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                hswJobLog.setHandleReason(reason); // 操作原因
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "撤回挂起失败");
                return msg;
            }
        } else {
            msg.put("msg", "撤回挂起失败：未找到该工单");
            return msg;
        }
    }

    /**
     * 撤销工单
     */
    @Override
    public Map<String, Object> revokeForApp(Long id, Long userId, String nickName, String handleReason) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setId(id);
            jobInfo.setStatus(JobStatusEnum.YCD.getValue()); // 工单状态
            jobInfo.setHandleStatus(HandleStatusEnum.YCD.getValue()); // 操作状态
            jobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY); // 归档状态
            jobInfo.setUpdateBy(nickName);
            jobInfo.setUpdateTime(new Date());
            int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
            if (res > 0) {
                msg.put("code", 1);
                msg.put("msg", "撤销工单成功");
                msg.put("jobNo", jobViewDto.getJobNo());
                msg.put("cuId", jobViewDto.getCuId());
                msg.put("receiverId", jobViewDto.getReceiverId());
                // 更新故障
                HswFaultInfo hswFaultInfo = new HswFaultInfo();
                hswFaultInfo.setStatus(JobStatusEnum.YCD.getValue().toString());
                hswFaultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                hswFaultInfo.setUpdateBy(nickName);
                hswFaultInfo.setUpdateTime(new Date());
                this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                // 添加工单日志
                HswJobLog hswJobLog = new HswJobLog();
                hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                hswJobLog.setJobStatus(JobStatusEnum.YCD.getValue()); // 工单状态
                hswJobLog.setHandleStatus(HandleStatusEnum.YCD.getValue()); // 操作状态
                hswJobLog.setHandleUid(userId); // 操作人id
                hswJobLog.setHandleUname(nickName); // 操作人姓名
                hswJobLog.setHandleTime(DateUtils.getDateMr(new Date())); // 操作时间
                hswJobLog.setHandleReason(handleReason); // 操作原因
                hswJobLog.setCreateBy(nickName);
                hswJobLog.setCreateTime(new Date());
                this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                return msg;
            } else {
                msg.put("msg", "撤销工单失败");
                return msg;
            }
        } else {
            msg.put("msg", "撤销工单失败：未找到该工单");
            return msg;
        }
    }

    /**
     * 结单
     */
    @Override
    public Map<String, Object> repairForApp(Long id, Long userId, String nickName, String repairRecord) {
        Map<String, Object> msg = new HashMap<>();
        msg.put("code", 0);
        msg.put("url", "");
        msg.put("data", "");
        msg.put("wait", 3);
        JobViewDto jobViewDto = this.hswJobInfoMapper.selectJobViewById(id);
        if (jobViewDto != null) {
            if (jobViewDto.getReceiverId().equals(userId)) {
                HswJobInfo jobInfo = new HswJobInfo();
                jobInfo.setId(id);
                jobInfo.setStatus(JobStatusEnum.YXF.getValue()); // 工单状态
                jobInfo.setRepairTime(DateUtils.getDateMr(new Date())); // 修复时间
                jobInfo.setRepairRecord(repairRecord); // 维修记录
                jobInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY); // 归档
                jobInfo.setUpdateBy(nickName);
                jobInfo.setUpdateTime(new Date());
                int res = this.hswJobInfoMapper.updateHswJobInfo(jobInfo);
                if (res > 0) {
                    msg.put("code", 1);
                    msg.put("msg", "撤销工单成功");
                    msg.put("jobNo", jobViewDto.getJobNo());
                    msg.put("sendUid", jobViewDto.getSendUid());
                    msg.put("regionName", jobViewDto.getRegionName());
                    msg.put("takeTime", jobViewDto.getTakeTime());
                    msg.put("cuId", jobViewDto.getCuId());
                    if (jobViewDto.getType().equals(FaultTypeEnum.GZBWD.getValue()) || jobViewDto.getType().equals(FaultTypeEnum.GZBWD_DQGZ.getValue())) {
                        // 更新故障
                        HswFaultInfo hswFaultInfo = new HswFaultInfo();
                        hswFaultInfo.setStatus(JobStatusEnum.YXF.getValue().toString());
                        hswFaultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                        hswFaultInfo.setRepairTime(jobInfo.getRepairTime()); // 修复时间
                        hswFaultInfo.setZigzagStatus(CommonConstant.ZIGZAG_STATUS_PROCESSED); // 颠簸状态
                        hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                        hswFaultInfo.setUpdateBy(nickName);
                        hswFaultInfo.setUpdateTime(new Date());
                        this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                    } else {
                        // 更新故障
                        HswFaultInfo hswFaultInfo = new HswFaultInfo();
                        hswFaultInfo.setStatus(JobStatusEnum.YXF.getValue().toString());
                        hswFaultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
                        hswFaultInfo.setRepairTime(jobInfo.getRepairTime()); // 修复时间
                        hswFaultInfo.setId(jobViewDto.getFaultId()); // 故障id
                        hswFaultInfo.setUpdateBy(nickName);
                        hswFaultInfo.setUpdateTime(new Date());
                        this.hswFaultInfoMapper.updateHswFaultInfo(hswFaultInfo);
                    }

                    // 添加工单日志
                    HswJobLog hswJobLog = new HswJobLog();
                    hswJobLog.setJobId(jobViewDto.getId()); // 工单id
                    hswJobLog.setJobNo(jobViewDto.getJobNo()); // 工单编号
                    hswJobLog.setJobStatus(jobViewDto.getStatus());
                    hswJobLog.setHandleStatus(HandleStatusEnum.YWC.getValue()); // 操作状态
                    hswJobLog.setHandleUid(userId); // 操作人id
                    hswJobLog.setHandleUname(nickName); // 操作人姓名
                    hswJobLog.setHandleTime(jobInfo.getRepairTime()); // 操作时间
                    hswJobLog.setHandleReason(repairRecord); // 操作原因
                    hswJobLog.setCreateBy(nickName);
                    hswJobLog.setCreateTime(new Date());
                    this.hswJobLogMapper.insertHswJobLog(hswJobLog);
                    return msg;
                } else {
                    msg.put("msg", "结单失败");
                    return msg;
                }
            } else {
                msg.put("msg", "结单失败：非法参数，该工单未派单于您");
                return msg;
            }
        } else {
            msg.put("msg", "结单失败：未找到该工单");
            return msg;
        }
    }

    /**
     * 根据维修队和运维单位分组，通过分工id和时间范围查询维修队工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<JobTeamStatisticsVo> selectJobTeamByDivideWorkIdsAndDate(Long[] divideWorkIds, Long startDate, Long endDate) {

        if (startDate == null) {
            return null;
        }

        if (endDate == null) {
            return null;
        }

        List<JobTeamStatisticsVo> jobTeamStatisticsList = hswJobInfoMapper.selectJobTeamByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate);

        if (CollectionUtils.isEmpty(jobTeamStatisticsList)) {
            return null;
        }

        DecimalFormat df = new DecimalFormat("#.00");

        for (JobTeamStatisticsVo jobTeam : jobTeamStatisticsList) {

            // 完成数为0时，平均时长也为0
            if (!jobTeam.getFinishCount().equals(0)) {
                jobTeam.setAvg(Double.valueOf(df.format(jobTeam.getTotalRepairTime() / jobTeam.getFinishCount() / 3600D)));
            }

            // 工单数为0时，完成率为0
            if (jobTeam.getAssignCount().equals(0)) {
                jobTeam.setFinishRate(0D);
            } else {
                jobTeam.setFinishRate(Double.valueOf(df.format(jobTeam.getFinishCount() * 100D / jobTeam.getAssignCount())));
            }
        }

        return jobTeamStatisticsList;
    }

    @Override
    public List<JobTeamStatisticsVo> selectJobTeamByDate(Long pid, Long startDate, Long endDate) {


        List<JobTeamStatisticsVo> jobTeamStatisticsList = hswJobInfoMapper.selectJobTeamByDate(pid, startDate, endDate);

        if (CollectionUtils.isEmpty(jobTeamStatisticsList)) {
            return new ArrayList<JobTeamStatisticsVo>();
        }

        DecimalFormat df = new DecimalFormat("#.00");

        for (JobTeamStatisticsVo jobTeam : jobTeamStatisticsList) {

            // 完成数为0时，平均时长也为0
            if (!jobTeam.getFinishCount().equals(0)) {
                jobTeam.setAvg(Double.valueOf(df.format(jobTeam.getTotalRepairTime() / jobTeam.getFinishCount() / 3600D)));
            }

            // 工单数为0时，完成率为0
            if (jobTeam.getAssignCount().equals(0)) {
                jobTeam.setFinishRate(0D);
            } else {
                jobTeam.setFinishRate(Double.valueOf(df.format(jobTeam.getFinishCount() * 100D / jobTeam.getAssignCount())));
            }
        }

        return jobTeamStatisticsList;
    }

    /**
     * 根据维修队和运维单位和维修员工分组，通过分工id和时间范围查询维修队员工工单统计信息
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<JobStaffStatisticsVo> selectJobStaffByDivideWorkIdsAndDate(Long[] divideWorkIds, Long startDate, Long endDate) {

        if (startDate == null) {
            return null;
        }

        if (endDate == null) {
            return null;
        }

        List<JobStaffStatisticsVo> jobStaffStatisticsList = hswJobInfoMapper.selectJobStaffByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate);

        if (CollectionUtils.isEmpty(jobStaffStatisticsList)) {
            return null;
        }

        DecimalFormat df = new DecimalFormat("#.00");

        for (JobStaffStatisticsVo jobStaff : jobStaffStatisticsList) {

            // 完成数为0时，平均时长也为0
            if (!jobStaff.getFinishCount().equals(0)) {
                jobStaff.setAvg(Double.valueOf(df.format(jobStaff.getTotalRepairTime() / jobStaff.getFinishCount() / 3600D)));
            }

            // 工单数为0时，完成率为0
            if (jobStaff.getAssignCount().equals(0)) {
                jobStaff.setFinishRate(0D);
            } else {
                jobStaff.setFinishRate(Double.valueOf(df.format(jobStaff.getFinishCount() * 100D / jobStaff.getAssignCount())));
            }

            // 挂起数
            int hungCount = hswJobLogMapper.selectCountByOldReceiverIdAndHandleStatus(jobStaff.getReceiverId(), 6, startDate, endDate);

            // 转单数
            int changeAssignCount = hswJobLogMapper.selectCountByOldReceiverIdAndHandleStatus(jobStaff.getReceiverId(), 4, startDate, endDate);

            jobStaff.setHungCount(hungCount);
            jobStaff.setChangeAssignCount(changeAssignCount);
        }

        return jobStaffStatisticsList;
    }

    /**
     * 根据维修队和运维单位和维修员工分组，通过时间范围查询维修队员工工单统计信息
     *
     * @param startDate
     * @param endDate
     * @return
     */
    @Override
    public List<JobStaffStatisticsVo> selectJobStaffByDate(Long pid, Long startDate, Long endDate) {

        List<JobStaffStatisticsVo> jobStaffStatisticsList = hswJobInfoMapper.selectJobStaffByDate(pid, startDate, endDate);

        if (CollectionUtils.isEmpty(jobStaffStatisticsList)) {
            return new ArrayList<JobStaffStatisticsVo>();
        }

        DecimalFormat df = new DecimalFormat("#.00");

        for (JobStaffStatisticsVo jobStaff : jobStaffStatisticsList) {

            // 完成数为0时，平均时长也为0
            if (!jobStaff.getFinishCount().equals(0)) {
                jobStaff.setAvg(Double.valueOf(df.format(jobStaff.getTotalRepairTime() / jobStaff.getFinishCount() / 3600D)));
            }

            // 工单数为0时，完成率为0
            if (jobStaff.getAssignCount().equals(0)) {
                jobStaff.setFinishRate(0D);
            } else {
                jobStaff.setFinishRate(Double.valueOf(df.format(jobStaff.getFinishCount() * 100D / jobStaff.getAssignCount())));
            }

            // 挂起数
            int hungCount = hswJobLogMapper.selectCountByOldReceiverIdAndHandleStatus(jobStaff.getReceiverId(), 6, startDate, endDate);

            // 转单数
            int changeAssignCount = hswJobLogMapper.selectCountByOldReceiverIdAndHandleStatus(jobStaff.getReceiverId(), 4, startDate, endDate);

            jobStaff.setHungCount(hungCount);
            jobStaff.setChangeAssignCount(changeAssignCount);
        }

        return jobStaffStatisticsList;
    }

    /**
     * 统计工单数量
     *
     * @param jobViewDto
     * @return
     */
    @Override
    public Integer selectJobViewCount(JobViewDto jobViewDto) {
        return this.hswJobInfoMapper.selectJobViewCount(jobViewDto);
    }

    /**
     * 推送消息通知
     *
     * @param tplKey 消息模版key 见系统配置
     * @param args   需要替换的参数  必须带有工单号
     */
    @Async
    @Override
    public void sendMsg(String tplKey, Map<String, Object> args) {

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(tplKey);
        String title = "消息提醒";
        String content = "您有一条消息需要处理，请点击查看详情";
        if (sysConfig != null) {
            title = sysConfig.getConfigName();
            content = sysConfig.getConfigValue();
            Set<String> keySet = args.keySet();
            for (String key : keySet) {
                content = content.replace("${" + key + "}", args.get(key).toString());
            }
        }
        // 添加系统消息
        HswSysMsg hswSysMsg = new HswSysMsg();
        hswSysMsg.setTitle(title);
        hswSysMsg.setContent(content);
        hswSysMsg.setCreateBy(args.get("send_name").toString());
        hswSysMsg.setCreateTime(new Date());
        hswSysMsg.setToUids(args.get("receiver_id").toString());
        hswSysMsg.setJobNo((String) args.get("job_no"));
        int res = this.sysMsgService.insertHswSysMsg(hswSysMsg);

        if (res > 0) {
            HswUserMsg userMsg = new HswUserMsg();
            userMsg.setMid(hswSysMsg.getId());
            userMsg.setUid(Long.valueOf(args.get("receiver_id").toString()));
            userMsg.setStatus(CommonConstant.STATUS_UNREAD);
            userMsg.setReadTime(0);
            userMsg.setUname(args.get("receiver_name").toString());
            userMsg.setCreateBy(args.get("send_name").toString());
            userMsg.setCreateTime(new Date());
            this.userMsgService.insertHswUserMsg(userMsg);
        }
    }

    /**
     * 查询活动工单列表
     *
     * @return 工单集合
     */
    @Override
    public List<HswJobInfo> selectHswJobInfoListByIp(String ip) {
        List<HswJobInfo> hswJobInfos = this.hswJobInfoMapper.selectHswJobInfoListByIp(ip);
        if (!hswJobInfos.isEmpty()) {
            hswJobInfos.forEach(jobInfo -> {
                if (jobInfo.getSendTime() > 0) {
                    if (jobInfo.getStatus() == JobStatusEnum.WXZ.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (DateUtils.getDateMr(new Date()) - jobInfo.getSendTime()) / (60 * 60D))));
                    } else if (jobInfo.getStatus() == JobStatusEnum.YXF.getValue()) {
                        jobInfo.setRepairedTime(Double.valueOf(String.format("%.2f", (jobInfo.getRepairTime() - jobInfo.getSendTime()) / (60 * 60D))));
                    }
                } else {
                    jobInfo.setRepairedTime(0D);
                }
            });
        }
        return hswJobInfos;
    }
}
