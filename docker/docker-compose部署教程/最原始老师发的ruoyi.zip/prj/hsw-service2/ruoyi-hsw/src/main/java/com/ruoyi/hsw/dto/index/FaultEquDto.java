package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 故障设备分布Dto
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 12:00
 */
@Data
public class FaultEquDto implements Serializable {

    // 诊断器故障
    private Integer diagnosisDeviceFault;

    // 摄像机链路故障+摄像机故障
    private Integer cameraFault;

    //光纤收发器故障
    private Integer opticalTransceiverFault;
}
