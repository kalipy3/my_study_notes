package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.domain.HswOtherDevice;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 其他设备Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public interface HswOtherDeviceMapper {
    /**
     * 查询其他设备
     *
     * @param id 其他设备ID
     * @return 其他设备
     */
    public HswOtherDevice selectHswOtherDeviceById(Long id);

    /**
     * 查询其他设备列表
     *
     * @param hswOtherDevice 其他设备
     * @return 其他设备集合
     */
    public List<HswOtherDevice> selectHswOtherDeviceList(HswOtherDevice hswOtherDevice);

    /**
     * 新增其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    public int insertHswOtherDevice(HswOtherDevice hswOtherDevice);

    /**
     * 修改其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    public int updateHswOtherDevice(HswOtherDevice hswOtherDevice);

    /**
     * 删除其他设备
     *
     * @param id 其他设备ID
     * @return 结果
     */
    public int deleteHswOtherDeviceById(Long id);

    /**
     * 批量删除其他设备
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswOtherDeviceByIds(Long[] ids);

    /**
     * 根据诊断器ip删除其他设备
     *
     * @param ip
     * @return
     */
    public int deleteHswOtherDeviceByIp(String ip);

    /**
     * 根据所属诊断器ip获取其他设备数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    public int selectOtherDeviceCountByIp(String ip);

    /**
     * 更新安装时间
     */
    public int finish(@Param("ip") String ip, @Param("time") Long time);

    /**
     * 根据项目id删除
     *
     * @param pid 项目id
     * @return
     */
    public int deleteHswOtherDeviceByPid(Long pid);

    /**
     * 根据项目id统计其他设备数量
     *
     * @param pids
     * @return
     */
    public int selectCountByPid(Long[] pids);

    /**
     * 根据所属诊断器ip修改其他设备所属诊断器ip
     *
     * @param newIp 修改后的ip
     * @param oldIp 原ip
     * @return
     */
    int updateIpByIp(@Param("newIp") String newIp, @Param("oldIp") String oldIp);
}
