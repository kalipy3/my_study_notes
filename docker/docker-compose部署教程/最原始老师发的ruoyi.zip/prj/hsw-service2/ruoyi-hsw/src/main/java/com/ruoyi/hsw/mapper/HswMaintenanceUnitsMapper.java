package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.domain.HswMaintenanceUnits;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 运维单位Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswMaintenanceUnitsMapper {
    /**
     * 查询运维单位
     *
     * @param id 运维单位ID
     * @return 运维单位
     */
    public HswMaintenanceUnits selectHswMaintenanceUnitsById(Long id);

    /**
     * 查询运维单位列表
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 运维单位集合
     */
    public List<HswMaintenanceUnits> selectHswMaintenanceUnitsList(HswMaintenanceUnits hswMaintenanceUnits);

    public List<HswMaintenanceUnits> selectTree(Long[] ids);

    /**
     * 新增运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    public int insertHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits);

    /**
     * 修改运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    public int updateHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits);

    /**
     * 删除运维单位
     *
     * @param id 运维单位ID
     * @return 结果
     */
    public int deleteHswMaintenanceUnitsById(Long id);

    /**
     * 批量删除运维单位
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswMaintenanceUnitsByIds(Long[] ids);

    /**
     * 查询运维单位数量
     */
    public int selectCount();
}
