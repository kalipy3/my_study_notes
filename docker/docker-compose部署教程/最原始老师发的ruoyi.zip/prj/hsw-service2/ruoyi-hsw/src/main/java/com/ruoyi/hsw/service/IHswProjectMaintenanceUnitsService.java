package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswProjectMaintenanceUnits;
import com.ruoyi.hsw.dto.ProjectMaintenanceUnitsViewDto;

import java.util.List;

/**
 * 项目与运维单位关系Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswProjectMaintenanceUnitsService {
    /**
     * 查询项目与运维单位关系
     *
     * @param pid 项目与运维单位关系ID
     * @return 项目与运维单位关系
     */
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsById(Long pid);

    /**
     * 查询项目与运维单位关系列表
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 项目与运维单位关系集合
     */
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsList(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 新增项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    public int insertHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 修改项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    public int updateHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 批量删除项目与运维单位关系
     *
     * @param pids 需要删除的项目与运维单位关系ID
     * @return 结果
     */
    public int deleteHswProjectMaintenanceUnitsByIds(Long[] pids);

    /**
     * 删除项目与运维单位关系信息
     *
     * @param pid 项目与运维单位关系ID
     * @return 结果
     */
    public int deleteHswProjectMaintenanceUnitsById(Long pid);

    /**
     * 取得项目运维单位列表
     *
     * @param pid
     * @return
     */
    List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewList(Long pid);

    /**
     * 取得项目运维单位列表
     *
     * @param pids
     * @return
     */
    List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewListByPids(Long[] pids);

    /**
     * 取得项目运维单位列表
     *
     * @param pids
     * @return
     */
    List<ProjectMaintenanceUnitsViewDto> selectListByPids(List<Long> pids);

    /**
     * 取得项目运维单位列表
     *
     * @param projectMaintenanceUnitsViewDto
     * @return
     */
    List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewList(ProjectMaintenanceUnitsViewDto projectMaintenanceUnitsViewDto);
}
