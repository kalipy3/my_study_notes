package com.ruoyi.hsw.domain.vo;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 维修队工单统计
 *
 * @author zyj
 * @date 2020/11/16 13:49
 */
@Data
public class JobTeamStatisticsVo implements Serializable {

    // 运维单位名称
    @Excel(name = "运维单位", sort = 1, type = Excel.Type.EXPORT)
    private String maintenanceUnitsName;

    // 维修队名称
    @Excel(name = "维修队名称", sort = 2, type = Excel.Type.EXPORT)
    private String maintenanceTeamName;

    // 故障总数
    @Excel(name = "故障总数", sort = 3, type = Excel.Type.EXPORT)
    private Integer total = 0;

    // 工单数
    @Excel(name = "工单数", sort = 4, type = Excel.Type.EXPORT)
    private Integer assignCount = 0;

    // 完成数
    @Excel(name = "完成数", sort = 5, type = Excel.Type.EXPORT)
    private Integer finishCount = 0;

    // 挂起数
    @Excel(name = "挂起数", sort = 6, type = Excel.Type.EXPORT)
    private Integer hungCount = 0;

    // 总时长
    private Long totalRepairTime;

    // 超时数
    @Excel(name = "超时数", sort = 7, type = Excel.Type.EXPORT)
    private Integer timeoutCount = 0;

    // 完成率
    @Excel(name = "完成率(%)", sort = 8, type = Excel.Type.EXPORT)
    private Double finishRate;

    // 平均时长
    @Excel(name = "平均时长", sort = 9, type = Excel.Type.EXPORT)
    private Double avg;
}
