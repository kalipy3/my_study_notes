package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.domain.HswUserMsg;
import com.ruoyi.hsw.dto.MyMsgPageableDto;
import com.ruoyi.hsw.dto.UserMsgView;
import com.ruoyi.hsw.mapper.HswUserMsgMapper;
import com.ruoyi.hsw.service.IHswUserMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 消息发送信息Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswUserMsgServiceImpl implements IHswUserMsgService {
    @Autowired
    private HswUserMsgMapper hswUserMsgMapper;

    /**
     * 查询消息发送信息
     *
     * @param mid 消息发送信息ID
     * @return 消息发送信息
     */
    @Override
    public HswUserMsg selectHswUserMsgById(Long mid) {
        return hswUserMsgMapper.selectHswUserMsgById(mid);
    }

    /**
     * 查询消息发送信息列表
     *
     * @param hswUserMsg 消息发送信息
     * @return 消息发送信息
     */
    @Override
    public List<HswUserMsg> selectHswUserMsgList(HswUserMsg hswUserMsg) {
        return hswUserMsgMapper.selectHswUserMsgList(hswUserMsg);
    }

    /**
     * 新增消息发送信息
     *
     * @param hswUserMsg 消息发送信息
     * @return 结果
     */
    @Override
    public int insertHswUserMsg(HswUserMsg hswUserMsg) {
        hswUserMsg.setCreateTime(DateUtils.getNowDate());
        return hswUserMsgMapper.insertHswUserMsg(hswUserMsg);
    }

    /**
     * 修改消息发送信息
     *
     * @param hswUserMsg 消息发送信息
     * @return 结果
     */
    @Override
    public int updateHswUserMsg(HswUserMsg hswUserMsg) {
        hswUserMsg.setUpdateTime(DateUtils.getNowDate());
        return hswUserMsgMapper.updateHswUserMsg(hswUserMsg);
    }

    /**
     * 批量删除消息发送信息
     *
     * @param mids 需要删除的消息发送信息ID
     * @return 结果
     */
    @Override
    public int deleteHswUserMsgByIds(Long[] mids) {
        return hswUserMsgMapper.deleteHswUserMsgByIds(mids);
    }

    /**
     * 删除消息发送信息信息
     *
     * @param mid 消息发送信息ID
     * @return 结果
     */
    @Override
    public int deleteHswUserMsgById(Long mid) {
        return hswUserMsgMapper.deleteHswUserMsgById(mid);
    }

    /**
     * 查询用户消息视图列表
     */
    @Override
    public List<UserMsgView> selectUserMsgView(MyMsgPageableDto myMsgPageableDto) {
        return this.hswUserMsgMapper.selectUserMsgView(myMsgPageableDto);
    }

    /**
     * 全部标记已读
     */
    @Override
    public int allRead(Integer status, Long userId, Long readTime) {
        return this.hswUserMsgMapper.allRead(status, userId, readTime);
    }

    /**
     * 标记单个已读
     */
    @Override
    public int read(Integer status, Long userId, Long mid, Long readTime) {
        return this.hswUserMsgMapper.read(status, userId, mid, readTime);
    }

    /**
     * 根据用户id查询是否存在未读信息
     */
    @Override
    public boolean existCountByUserId(Long userId, Integer status) {
        return this.hswUserMsgMapper.selectCountByUserId(userId, status) > 0;
    }
}
