package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 设备区域分布信息
 *
 * @author zyj
 * @date 2020/11/23 10:35
 */
@Data
public class DeviceAreaDto implements Serializable {

    // 诊断器数量
    private Integer diagnosisDeviceCount = 0;

    // 光纤收发器数量
    private Integer opticalTransceiverCount = 0;

    // 摄像机数量
    private Integer cameraCount = 0;

    // 其他设备数量
    private Integer otherCount = 0;

    // 正常监测点数
    private Integer cameraOkCount = 0;

    // 故障监视点数
    private Integer cameraFaultCount = 0;

    // 在线率
    private Double onlineRateEle;

}
