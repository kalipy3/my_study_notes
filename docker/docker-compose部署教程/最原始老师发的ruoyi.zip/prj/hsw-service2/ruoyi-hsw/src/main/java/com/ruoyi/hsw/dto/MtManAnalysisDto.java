package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 维修员分析
 *
 * @author xiongxiangpeng
 * @create 2020-11-17 9:27
 */
@Data
public class MtManAnalysisDto implements Serializable {

    // 运维单位id
    private Long muId;

    // 运维队id
    private Long mtId;

    // 接单人id
    private Long receiverId;

    // 运维单位名称
    private String maintenanceUnitsName;

    // 运维队名称
    private String maintenanceTeamName;

    // 工单总数
    private Integer totalOrder=0;

    // 完成修复花费的时间总数
    private Long totalRepairTime=0L;

    // 超时完成修复完成数量
    private Integer repairTimeoutCount=0;

    //完成派单花费的时间总数
    private Long totalSendTime=0L;

    //派单超时数量
    private Integer sendTimeoutCount=0;

    // 按时完成数
    private Integer effectiveOrder=0;

    // 正常派单数
    private Integer sendCount=0;

    // 维修员
    private String realName;

    // 维修超时数
    private Integer repaireTimeoutCount=0;

    // 维修超时率
    private Double timeoutRate=0D;

    // 维修率
    private Double repairRate=0D;

    // 平均修复时长(小时)
    private Double repairAvg=0D;
}
