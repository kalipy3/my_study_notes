package com.ruoyi.hsw.mapper;

import java.util.List;

import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.domain.vo.TreeVo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 项目Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswProjectMapper {
    /**
     * 查询项目
     *
     * @param id 项目ID
     * @return 项目
     */
    public HswProject selectHswProjectById(Long id);

    /**
     * 查询项目列表
     *
     * @param hswProject 项目
     * @return 项目集合
     */
    public List<HswProject> selectHswProjectList(HswProject hswProject);

    /**
     * 新增项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    public int insertHswProject(HswProject hswProject);

    /**
     * 修改项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    public int updateHswProject(HswProject hswProject);

    /**
     * 删除项目
     *
     * @param id 项目ID
     * @return 结果
     */
    public int deleteHswProjectById(Long id);

    /**
     * 批量删除项目
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswProjectByIds(Long[] ids);

    /**
     * 根据名称查询数量
     */
    public int selectCountByTitle(String name);

    /**
     * 竣工
     */
    public int finish(@Param("id") Long id, @Param("time") Long time);

    /**
     * 根据建设单位和项目id查询项目列表
     *
     * @param cuId
     * @param pids
     * @return
     */
    public List<HswProject> selectHswProjectListByCuIdAndPids(@Param("cuId") Long cuId, @Param("pids") Long[] pids);

    /**
     * 获取项目id集合
     */
    public List<Long> selectPids();

    /**
     * 根据建设单位id获取项目id集合
     */
    public List<Long> selectPidsByCuId(@Param("cuId") Long cuId);

    /**
     * 根据所属市和项目id获取项目
     *
     * @param city
     * @param pids
     * @return
     */
    public List<TreeVo> selectByCityAndPids(@Param("city") String city, @Param("pids") Long[] pids);

    /**
     * 查询入驻建设单位数量
     */
    public List<Long> selectCuCount();

    /**
     * 根据id列表查询列表
     *
     * @param ids
     * @return
     */
    public List<HswProject> selectHswProjectIds(Long[] ids);
}
