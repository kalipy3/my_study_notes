package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswUserMsg;
import com.ruoyi.hsw.dto.MyMsgPageableDto;
import com.ruoyi.hsw.dto.UserMsgView;

import java.util.List;

/**
 * 消息发送信息Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswUserMsgService {
    /**
     * 查询消息发送信息
     *
     * @param mid 消息发送信息ID
     * @return 消息发送信息
     */
    public HswUserMsg selectHswUserMsgById(Long mid);

    /**
     * 查询消息发送信息列表
     *
     * @param hswUserMsg 消息发送信息
     * @return 消息发送信息集合
     */
    public List<HswUserMsg> selectHswUserMsgList(HswUserMsg hswUserMsg);

    /**
     * 新增消息发送信息
     *
     * @param hswUserMsg 消息发送信息
     * @return 结果
     */
    public int insertHswUserMsg(HswUserMsg hswUserMsg);

    /**
     * 修改消息发送信息
     *
     * @param hswUserMsg 消息发送信息
     * @return 结果
     */
    public int updateHswUserMsg(HswUserMsg hswUserMsg);

    /**
     * 批量删除消息发送信息
     *
     * @param mids 需要删除的消息发送信息ID
     * @return 结果
     */
    public int deleteHswUserMsgByIds(Long[] mids);

    /**
     * 删除消息发送信息信息
     *
     * @param mid 消息发送信息ID
     * @return 结果
     */
    public int deleteHswUserMsgById(Long mid);

    /**
     * 查询用户消息视图列表
     */
    public List<UserMsgView> selectUserMsgView(MyMsgPageableDto myMsgPageableDto);

    /**
     * 全部标记已读
     */
    public int allRead(Integer status, Long userId, Long readTime);

    /**
     * 标记单个已读
     */
    public int read(Integer status, Long userId, Long mid, Long readTime);

    /**
     * 根据用户id查询是否存在未读信息
     */
    public boolean existCountByUserId(Long userId, Integer status);
}
