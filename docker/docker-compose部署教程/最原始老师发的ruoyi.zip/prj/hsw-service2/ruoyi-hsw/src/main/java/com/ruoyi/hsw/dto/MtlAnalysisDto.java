package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 维修队长分析
 *
 * @author xiongxiangpeng
 * @create 2020-11-17 10:35
 */
@Data
public class MtlAnalysisDto implements Serializable {

    // 用户id
    private Long userId=0L;

    // 姓名
    private String realName;

    // 运维单位id
    private Long muId;

    // 维修队id
    private Long mtId;

    // 运维单位名称
    private String maintenanceUnitsName;

    // 运维队名称
    private String maintenanceTeamName;

    // 自修单数
    private Integer totalRepairOrder=0;

    // 按时完成数
    private Integer effectiveOrder=0;

    // 按时派单数
    private Integer sendCount;

    // 完成修复花费的时间总数
    private Long totalRepairTime=0L;

    // 超时完成修复完成数量
    private Integer repairTimeoutCount=0;

    // 维修队长工单总数
    private Integer totalSendOrder=0;

    // 完成派单花费的时间总数
    private Long totalSendTime=0L;

    // 派单超时数量
    private Integer sendTimeoutCount=0;

    // 平均修复时长(小时)
    private Double repairAvg=0D;

    // 平均派单时长(小时)
    private Double sendAvg=0D;

    // 维修效率
    private Double repairRate=0D;

    // 派单效率
    private Double sendRate=0D;

    // 未派单总数
    private Integer noSend=0;

    // 维修工单总数
    private Integer totalOrder=0;

    // 维修超时数
    private Integer repaireTimeoutCount=0;

    // 维修超时率
    private Double timeoutRate=0D;
}
