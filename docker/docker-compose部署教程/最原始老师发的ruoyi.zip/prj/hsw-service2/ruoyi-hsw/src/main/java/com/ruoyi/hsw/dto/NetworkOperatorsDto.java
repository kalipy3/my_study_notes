package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 运营商分析Dto
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 13:49
 */
@Data
public class NetworkOperatorsDto implements Serializable {

    // 项目id
    private Long pid;

    // 项目名称
    private String projectTitle;

    // 运营商
    private String communicationsOperations;

    // 故障发生次数
    private Integer faultCount=0;

    // 总修复时间
    private Long totalRepairTime=0L;

    // 平均修复时间(小时)
    private Double rate=0D;
}
