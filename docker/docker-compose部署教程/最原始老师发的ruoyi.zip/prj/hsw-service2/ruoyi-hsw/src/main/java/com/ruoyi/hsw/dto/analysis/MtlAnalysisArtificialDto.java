package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 维修队长分析-人工修复
 *
 * @author xiongxiangpeng
 */
@Data
public class MtlAnalysisArtificialDto implements Serializable {

    // 用户id
    private Long userId;

    // 姓名
    @Excel(name = "维修队长", sort = 1)
    private String realName;

    // 运维单位id
    private Long muId;

    // 维修队id
    private Long mtId;

    // 运维单位名称
    @Excel(name = "所属运维单位/维修队", sort = 2)
    private String maintenanceUnitsName = "";

    // 运维队名称
    private String maintenanceTeamName = "";

    // 工单总数
    @Excel(name = "工单总数", sort = 3)
    private Integer totalSendOrder=0;

    // 自修单数
    @Excel(name = "自修单数", sort = 4)
    private Integer totalRepairOrder=0;

    // 完成修复花费的时间总数
    private Long totalRepairTime=0L;

    // 超时完成修复完成数量
    private Integer repairTimeoutCount=0;

    // 完成派单花费的时间总数
    private Long totalSendTime=0L;

    // 派单超时数量
    private Integer sendTimeoutCount=0;

    // 按时完成数
    @Excel(name = "按时完成数", sort = 5)
    private Integer effectiveOrder=0;

    // 按时派单数
    @Excel(name = "按时派单数", sort = 6)
    private Integer sendCount;

    // 平均修复时长(小时)
    @Excel(name = "平均修复时长(小时)", sort = 7)
    private Double repairAvg=0D;

    // 平均派单时长(小时)
    @Excel(name = "平均派单时长(小时)", sort = 8)
    private Double sendAvg=0D;

    // 维修效率
    private Double repairRate=0D;

    // 派单效率
    private Double sendRate=0D;

    // 维修效率 + %
    @Excel(name = "维修效率", sort = 9)
    private String repairRateString;

    // 派单效率 + %
    @Excel(name = "派单效率", sort = 10)
    private String sendRateString;
}
