package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 电力运营商分析
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 15:19
 */
@Data
public class PowerOperatorsDto implements Serializable {

    // 项目名称
    private String projectTitle;

    // 供电公司
    private String electricityOperating;

    // 停电次数
    private Integer faultCount=0;

    // 停电总时间
    private Long totalRepairTime=0L;

    // 项目id
    private Long pid;

    // 平均停电时长(小时)
    private Double rate=0D;
}
