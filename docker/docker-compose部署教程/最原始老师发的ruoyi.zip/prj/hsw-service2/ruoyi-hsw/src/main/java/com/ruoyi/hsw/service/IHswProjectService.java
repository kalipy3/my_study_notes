package com.ruoyi.hsw.service;

import java.util.List;

import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.domain.vo.ProjectTreeVo;
import com.ruoyi.hsw.domain.vo.TreeVo;

/**
 * 项目Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswProjectService {
    /**
     * 查询项目
     *
     * @param id 项目ID
     * @return 项目
     */
    public HswProject selectHswProjectById(Long id);

    /**
     * 查询项目列表
     *
     * @param hswProject 项目
     * @return 项目集合
     */
    public List<HswProject> selectHswProjectList(HswProject hswProject);

    /**
     * 新增项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    public int insertHswProject(HswProject hswProject);

    /**
     * 修改项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    public int updateHswProject(HswProject hswProject);

    /**
     * 批量删除项目
     *
     * @param ids 需要删除的项目ID
     * @return 结果
     */
    public int deleteHswProjectByIds(Long[] ids);

    /**
     * 删除项目信息
     *
     * @param id 项目ID
     * @return 结果
     */
    public int deleteHswProjectById(Long id);

    /**
     * 项目名称是否相同
     */
    public boolean existTitle(String name);

    /**
     * 竣工
     */
    public int finish(Long id);

    /**
     * App使用
     * 通过用户实体获取所管辖的项目列表，返回数据参照返回类型参数说明
     *
     * @param sysUser
     * @return
     */
    Long[] getProjectIdsByUser(SysUser sysUser);

    /**
     * App使用
     * 通过用户实体获取所管辖的项目列表，返回数据参照返回类型参数说明
     */
    List<Long> getPIdsByUser(SysUser sysUser);

    /**
     * App使用
     * 通过用户实体获取所管辖的项目列表，返回数据参照返回类型参数说明
     *
     * @param sysUser
     * @return
     */
    List<HswProject> getProjectsByUser(SysUser sysUser);

    /**
     * 根据建设单位和获取项目树形结构
     *
     * @return
     */
    List<ProjectTreeVo> getTreeByCuId();

    /**
     * 根据当前用户类型获取项目id集合
     */
    List<Long> findPidByUser();

    /**
     * 根据区域获取项目树形结构
     *
     * @return
     */
    List<TreeVo> getTreeByArea();

    /**
     * 查询入驻建设单位数量
     */
    List<Long> selectCuCount();

    /**
     * 根据当前登录用户获取项目列表
     *
     * @return
     */
    List<HswProject> selectProjectByUser();

    /**
     * 获取用户数据权限
     */
    public HswProject dataPermission(HswProject hswProject);

    /**
     * 根据id列表查询列表
     *
     * @param ids
     * @return
     */
    public List<HswProject> selectHswProjectIds(Long[] ids);
}
