package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 设备厂家分析Dto
 *
 * @author xiongxiangpeng
 */
@Data
public class EquAnalysis1Dto implements Serializable {

    // 生产厂家
    @Excel(name = "设备厂商", sort = 1)
    private String manufacturer;

    // 设备数量
    @Excel(name = "设备数量", sort = 3)
    private Integer deviceCount=0;

    // 故障类型
    @Excel(name = "故障类型", sort = 2)
    private String faultType;

    // 故障设备数
    @Excel(name = "故障设备数", sort = 4)
    private Integer faultCount=0;

    // 故障设备占比
    private Double faultRate=0D;

    // 故障设备占比 + %
    @Excel(name = "故障设备占比", sort = 5)
    private String faultRateString;
}
