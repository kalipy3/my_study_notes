package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 电力运营商分析
 *
 * @author xiongxiangpeng
 */
@Data
public class PowerOperators1Dto implements Serializable {

    // 项目名称
    @Excel(name = "项目名称", sort = 1)
    private String projectTitle;

    // 供电公司
    @Excel(name = "供电公司", sort = 2)
    private String electricityOperating;

    // 停电次数
    @Excel(name = "停电次数", sort = 3)
    private Integer faultCount=0;

    // 停电总时间
    private Long totalRepairTime=0L;

    // 项目id
    private Long pid;

    // 平均停电时长(小时)
    @Excel(name = "平均停电时长(小时)", sort = 4)
    private Double rate=0D;
}
