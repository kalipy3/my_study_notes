package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 触发故障更新
 *
 * @author youyong
 * @date 2020/11/9 0009
 */
@Data
public class UpdateFaultDto implements Serializable {

    // 视点IP
    private String ip;

    // 端口号，非摄像机故障为0
    private Integer port = 0;

    // 故障类型（旧的）
    private String oldType = "0";

    // 故障类型（新的）
    private String newType = "0";

    // 故障描述
    private String descr;

    // 颠簸故障类型（同故障状态，除工作不稳定2种）
    private Integer zigzagType = 0;

    // 颠簸次数
    private Integer zigzagCount = 0;
}
