package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 派单员查询参数
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 17:09
 */
@Data
public class DispatcherPageableDto implements Serializable {

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 派单时长
    private Double sendHour;

    // 是否超时(0=超时，1=未超时)
    private Integer sendTimeout;

    // 派单员id
    private Long userId;

    // 派单员id集合
    private List<Long> userIds;
}
