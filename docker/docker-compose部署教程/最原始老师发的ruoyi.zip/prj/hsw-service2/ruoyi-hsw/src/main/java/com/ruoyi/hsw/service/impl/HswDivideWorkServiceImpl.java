package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.domain.vo.DivideWorkTreeVo;
import com.ruoyi.hsw.domain.vo.TreeVo;
import com.ruoyi.hsw.mapper.HswDivideWorkMapper;
import com.ruoyi.hsw.mapper.HswProjectMapper;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 分工职责Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswDivideWorkServiceImpl implements IHswDivideWorkService {
    @Autowired
    private HswDivideWorkMapper hswDivideWorkMapper;

    @Autowired
    private HswProjectMapper hswProjectMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询分工职责
     *
     * @param id 分工职责ID
     * @return 分工职责
     */
    @Override
    public HswDivideWork selectHswDivideWorkById(Long id) {
        return hswDivideWorkMapper.selectHswDivideWorkById(id);
    }

    /**
     * 查询分工职责列表
     *
     * @param hswDivideWork 分工职责
     * @return 分工职责
     */
    @Override
    public List<HswDivideWork> selectHswDivideWorkList(HswDivideWork hswDivideWork) {
        return hswDivideWorkMapper.selectHswDivideWorkList(hswDivideWork);
    }

    /**
     * 新增分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    @Override
    public int insertHswDivideWork(HswDivideWork hswDivideWork) {
        hswDivideWork.setCreateBy(SecurityUtils.getUsername());
        hswDivideWork.setCreateTime(DateUtils.getNowDate());
        return hswDivideWorkMapper.insertHswDivideWork(hswDivideWork);
    }

    /**
     * 修改分工职责
     *
     * @param hswDivideWork 分工职责
     * @return 结果
     */
    @Override
    public int updateHswDivideWork(HswDivideWork hswDivideWork) {
        hswDivideWork.setUpdateBy(SecurityUtils.getUsername());
        hswDivideWork.setUpdateTime(DateUtils.getNowDate());
        return hswDivideWorkMapper.updateHswDivideWork(hswDivideWork);
    }

    /**
     * 批量删除分工职责
     *
     * @param ids 需要删除的分工职责ID
     * @return 结果
     */
    @Override
    public int deleteHswDivideWorkByIds(Long[] ids) {
        return hswDivideWorkMapper.deleteHswDivideWorkByIds(ids);
    }

    /**
     * 删除分工职责信息
     *
     * @param id 分工职责ID
     * @return 结果
     */
    @Override
    public int deleteHswDivideWorkById(Long id) {
        return hswDivideWorkMapper.deleteHswDivideWorkById(id);
    }

    @Override
    public boolean existArea(String area, Long pid) {
        return this.hswDivideWorkMapper.selectCountByArea(area, pid) > 0;
    }

    @Override
    public boolean existAreaWithNeId(String area, Long pid, Long id) {
        return this.hswDivideWorkMapper.selectCountByAreaWithNeId(area, pid, id) > 0;
    }

    @Override
    public List<HswDivideWork> selectHswDivideWorkByPid(Long pid) {
        if (pid == null) {
            return null;
        }

        return hswDivideWorkMapper.selectHswDivideWorkByPid(pid);
    }

    /**
     * 根据项目id获取分工树形结构
     *
     * @return
     */
    @Override
    public List<DivideWorkTreeVo> selectTreeByPid() {

        // 当前登录用户可查看的项目
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            return null;
        }

        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        List<HswProject> projectList = hswProjectMapper.selectHswProjectIds(pids);

        if (CollectionUtils.isEmpty(projectList)) {
            return null;
        }

        List<DivideWorkTreeVo> divideWorkTreeVoList = new ArrayList<>();
        projectList.forEach(p -> {
            List<HswDivideWork> hswDivideWorkList = hswDivideWorkMapper.selectHswDivideWorkByPid(p.getId());
            DivideWorkTreeVo divideWorkTreeVo = new DivideWorkTreeVo();
            divideWorkTreeVo.setProjectTitle(p.getTitle());
            divideWorkTreeVo.setDivideWorkList(hswDivideWorkList);

            divideWorkTreeVoList.add(divideWorkTreeVo);
        });


        return divideWorkTreeVoList;
    }

    /**
     * 通过项目列表获取分工
     *
     * @param pids
     * @return
     */
    @Override
    public List<HswDivideWork> selectHswDivideWorkByPids(Long[] pids) {
        return hswDivideWorkMapper.selectHswDivideWorkByPids(pids);
    }

    /**
     * 根据项目获取分工树
     *
     * @return
     */
    @Override
    public List<TreeVo> getTreeByPid() {
        // 当前登录用户可查看的项目
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            return null;
        }

        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        List<HswProject> projectList = hswProjectMapper.selectHswProjectIds(pids);

        if (CollectionUtils.isEmpty(projectList)) {
            return null;
        }

        List<TreeVo> treeList = new ArrayList<>();
        projectList.forEach(p -> {
            List<TreeVo> wTreeList = hswDivideWorkMapper.selectTreeByPid(p.getId());
            wTreeList.forEach(w -> w.setType(3));
            TreeVo pTree = new TreeVo();
            pTree.setId(p.getId());
            pTree.setLabel(p.getTitle());
            pTree.setType(2);
            pTree.setChildren(wTreeList);

            treeList.add(pTree);
        });

        return treeList;
    }
}
