package com.ruoyi.hsw.domain.vo;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 故障状态统计Vo
 *
 * @author zyj
 * @date 2020/11/14 16:18
 */
@Data
public class FaultStatusVo implements Serializable {

    // 所属分工id
    private Long divideWorkId;

    // 区域
    @Excel(name = "区域", sort = 1, type = Excel.Type.EXPORT)
    private String area;

    // 故障总数
    @Excel(name = "故障总数", sort = 2, type = Excel.Type.EXPORT)
    private Integer total = 0;

    // 工单数
    @Excel(name = "工单数", sort = 3, type = Excel.Type.EXPORT)
    private Integer assignCount = 0;

    // 完成数
    @Excel(name = "完成数", sort = 4, type = Excel.Type.EXPORT)
    private Integer finishCount = 0;

    // 自动修复数
    private Integer autoRepareCount = 0;

    // 撤回数
    private Integer revokeCount = 0;

    // 挂起数
    @Excel(name = "挂起数", sort = 5, type = Excel.Type.EXPORT)
    private Integer hungCount = 0;

    // 总时长
    private Long totalRepairTime;

    // 完成率
    @Excel(name = "完成率(%)", sort = 6, type = Excel.Type.EXPORT)
    private Double finishRate = 0D;

    // 平均时长
    @Excel(name = "平均时长", sort = 7, type = Excel.Type.EXPORT)
    private Double avg;

}
