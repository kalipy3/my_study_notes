package com.ruoyi.hsw.service;

import java.util.List;

import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.domain.vo.TreeVo;
import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.DiagnosisDeviceViewDto;

/**
 * 诊断器Service接口
 *
 * @author ruoyi
 * @date 2020-11-05
 */
public interface IHswDiagnosisDeviceService {
    /**
     * 查询诊断器
     *
     * @param id 诊断器ID
     * @return 诊断器
     */
    public HswDiagnosisDevice selectHswDiagnosisDeviceById(Long id);

    /**
     * 查询诊断器列表
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 诊断器集合
     */
    public List<HswDiagnosisDevice> selectHswDiagnosisDeviceList(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 新增诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    public int insertHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 修改诊断器
     *
     * @param hswDiagnosisDevice 诊断器
     * @return 结果
     */
    public int updateHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 批量删除诊断器
     *
     * @param ids 需要删除的诊断器ID
     * @return 结果
     */
    public int deleteHswDiagnosisDeviceByIds(Long[] ids);

    /**
     * 删除诊断器信息
     *
     * @param id 诊断器ID
     * @return 结果
     */
    public int deleteHswDiagnosisDeviceById(Long id);

    /**
     * 校验ip是否唯一
     *
     * @param hswDiagnosisDevice
     * @return
     */
    public String checkIpUnique(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 根据ip查询诊断器
     *
     * @param ip
     * @return
     */
    public HswDiagnosisDevice selectHswDiagnosisDeviceByIp(String ip);

    /**
     * 根据项目id删除
     *
     * @param pid
     * @return
     */
    public int deleteByPid(Long pid);

    public int finish(Long pid, Long time);

    /**
     * 导入诊断器数据
     *
     * @param list            诊断器列表
     * @param isUpdateSupport 是否更新支持，如果已存在，则进行更新数据
     * @param operName        操作用户
     * @param pid             所属项目id
     * @return 结果
     */
    public String importDiagnosisDevice(List<HswDiagnosisDevice> list, Boolean isUpdateSupport, String operName, Long pid);

    /**
     * 校验
     *
     * @param hswDiagnosisDevice
     * @return
     */
    public String checkValid(HswDiagnosisDevice hswDiagnosisDevice, Long pid);

    /**
     * 根据项目id分组统计设备信息
     *
     * @param pids
     * @return
     */
    List<DeviceCountDto> selectGroupByPidCount(Long[] pids);

    /**
     * 统计设备信息
     *
     * @return
     */
    List<DeviceCountDto> selectGroupCount(Long pid);

    /**
     * 根据项目id统计设备总数
     *
     * @param pids
     * @return
     */
    DeviceCountDto selectByPidCountAll(Long[] pids);

    /**
     * 根据逻辑地址取
     *
     * @param diagnosisDevice
     * @return
     */
    HswDiagnosisDevice selectDiagnosisDeviceForApi(HswDiagnosisDevice diagnosisDevice);

    /**
     * 查询VIEW
     *
     * @param id VIEWID
     * @return VIEW
     */
    public DiagnosisDeviceViewDto selectDiagnosisDeviceViewById(Long id);

    /**
     * 查询VIEW列表
     *
     * @param diagnosisDeviceView VIEW
     * @return VIEW集合
     */
    public List<DiagnosisDeviceViewDto> selectDiagnosisDeviceViewList(DiagnosisDeviceViewDto diagnosisDeviceView);


    DiagnosisDeviceViewDto selectDiagnosisDeviceViewByIpForApp(String ip);

    List<DeviceCountDto> selectDeviceCountList(Long[] pids);

    /**
     * 校验逻辑地址是否唯一
     *
     * @param hswDiagnosisDevice
     * @return
     */
    public String checkLogicalAddrUnique(HswDiagnosisDevice hswDiagnosisDevice);

    /**
     * 根据项目获取诊断器树
     */
    public List<TreeVo> getTreeByPid();
}
