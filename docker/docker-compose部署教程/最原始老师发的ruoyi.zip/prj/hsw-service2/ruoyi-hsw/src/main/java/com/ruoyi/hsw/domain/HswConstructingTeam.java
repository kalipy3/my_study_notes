package com.ruoyi.hsw.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * 施工队对象 hsw_constructing_team
 * 
 * @author ruoyi
 * @date 2020-11-05
 */
public class HswConstructingTeam extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 名称 */
    @Excel(name = "名称")
    private String name;

    /** 负责人 */
    @Excel(name = "负责人")
    private String leader;

    /** 电话 */
    @Excel(name = "电话")
    private String tel;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    @NotBlank(message = "名称不能为空")
    public String getName() 
    {
        return name;
    }
    public void setLeader(String leader) 
    {
        this.leader = leader;
    }

    @NotBlank(message = "负责人不能为空")
    public String getLeader() 
    {
        return leader;
    }
    public void setTel(String tel) 
    {
        this.tel = tel;
    }

    @NotBlank(message = "电话不能为空")
    public String getTel() 
    {
        return tel;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("name", getName())
            .append("leader", getLeader())
            .append("tel", getTel())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }
}
