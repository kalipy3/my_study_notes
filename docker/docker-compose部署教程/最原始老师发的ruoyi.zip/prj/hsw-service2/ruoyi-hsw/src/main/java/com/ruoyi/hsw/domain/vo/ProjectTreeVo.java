package com.ruoyi.hsw.domain.vo;

import com.ruoyi.hsw.domain.HswProject;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 项目树形结构（根据建设单位）
 *
 * @author zyj
 * @date 2020/11/12 19:47
 */
@Data
public class ProjectTreeVo implements Serializable {

    // 建设单位名称
    private String cuName;

    // 项目列表
    private List<HswProject> projectList;

}
