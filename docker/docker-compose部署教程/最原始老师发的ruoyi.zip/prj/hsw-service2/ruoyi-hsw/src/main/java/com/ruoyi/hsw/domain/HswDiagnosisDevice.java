package com.ruoyi.hsw.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 诊断器对象 hsw_diagnosis_device
 *
 * @author ruoyi
 * @date 2020-11-05
 */
public class HswDiagnosisDevice extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 序列号
     */
    @Excel(name = "序列号", sort = 4)
    private String sn;

    /**
     * 所属分工
     */
    private Long divideWorkId;

    /**
     * 详细地址
     */
    @Excel(name = "详细地址", sort = 1, prompt = "不需要加省市信息")
    private String address;

    /**
     * 生产厂商
     */
    @Excel(name = "生产厂商", sort = 10)
    private String manufacturer;

    /**
     * 型号
     */
    @Excel(name = "型号", sort = 5)
    private String model;

    /**
     * IP
     */
    @Excel(name = "IP", sort = 8)
    private String ip;

    /**
     * 安装时间Long类型
     */
    private Long installTime;

    /**
     * 所属项目
     */
    private Long pid;

    /**
     * 逻辑地址
     */
    @Excel(name = "逻辑地址", sort = 3)
    private String logicalAddr;

    /**
     * 版本
     */
    @Excel(name = "版本", sort = 6)
    private String ver;

    /**
     * 上行端口
     */
    @Excel(name = "上行端口", sort = 2, dictType = "hsw_uplink_port")
    private Integer uplinkPort;

    /**
     * 摄像头数量
     */
    @Excel(name = "摄像头数量", type = Excel.Type.EXPORT)
    private Integer cameraCount;

    /**
     * 质保期(年)
     */
    @Excel(name = "质保期(年)", sort = 11)
    private Integer warranty;

    /**
     * 距指挥中心距离(KM)
     */
    @Excel(name = "距指挥中心距离(KM)", sort = 12, prompt = "设备距离建设单位指挥中心的大致距离")
    private Integer distance;

    /**
     * 网络运营商
     */
    @Excel(name = "网络运营商", sort = 13, dictType = "hsw_network_operator")
    private String network;

    /**
     * 经度
     */
    @Excel(name = "经度", type = Excel.Type.EXPORT)
    private String longitude;

    /**
     * 纬度
     */
    @Excel(name = "纬度", type = Excel.Type.EXPORT)
    private String latitude;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private String delFlag;

    /**
     * 所属项目名称
     */
    @Excel(name = "所属项目", type = Excel.Type.EXPORT)
    private String projectTitle;

    /**
     * 安装时间Date类型
     */
    @Excel(name = "安装时间", width = 30, dateFormat = "yyyy-MM-dd", sort = 9, prompt = "时间格式为yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date installDate;

    /**
     * 省
     */
    private String provinceLabel;

    /**
     * 市
     */
    private String cityLabel;

    /**
     * 区
     */
    private String districtLabel;

    /**
     * 分工区域
     */
    @Excel(name = "所属分工区域", sort = 7)
    private String workAddress;

    /**
     * 建设单位名称
     */
    private String cuName;

    /**
     * 运维单位名称
     */
    private String muName;

    /**
     * 维修队名称
     */
    private String mtName;

    /**
     * 发生故障数
     */
    private Integer faultCount;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    @NotBlank(message = "序列号不能为空")
    public String getSn() {
        return sn;
    }

    public void setDivideWorkId(Long divideWorkId) {
        this.divideWorkId = divideWorkId;
    }

    @NotNull(message = "所属分工不能为空")
    public Long getDivideWorkId() {
        return divideWorkId;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @NotBlank(message = "详细地址不能为空")
    public String getAddress() {
        return address;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @NotBlank(message = "型号不能为空")
    public String getModel() {
        return model;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @NotBlank(message = "ip不能为空")
    public String getIp() {
        return ip;
    }

    public void setInstallTime(Long installTime) {
        this.installTime = installTime;
    }

    public Long getInstallTime() {
        return installTime;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    @NotNull(message = "所属项目不能为空")
    public Long getPid() {
        return pid;
    }

    public void setLogicalAddr(String logicalAddr) {
        this.logicalAddr = logicalAddr;
    }

    @NotBlank(message = "逻辑地址不能为空")
    public String getLogicalAddr() {
        return logicalAddr;
    }

    public void setVer(String ver) {
        this.ver = ver;
    }

    @NotBlank(message = "版本不能为空")
    public String getVer() {
        return ver;
    }

    public void setUplinkPort(Integer uplinkPort) {
        this.uplinkPort = uplinkPort;
    }

    @NotNull(message = "上行端口不能为空")
    public Integer getUplinkPort() {
        return uplinkPort;
    }

    public void setCameraCount(Integer cameraCount) {
        this.cameraCount = cameraCount;
    }

    public Integer getCameraCount() {
        return cameraCount;
    }

    public void setWarranty(Integer warranty) {
        this.warranty = warranty;
    }

    @NotNull(message = "质保期不能为空")
    public Integer getWarranty() {
        return warranty;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    @NotBlank(message = "网络运营商不能为空")
    public String getNetwork() {
        return network;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    @NotNull(message = "安装时间不能为空")
    public Date getInstallDate() {
        return installDate;
    }

    public String getProvinceLabel() {
        return provinceLabel;
    }

    public void setProvinceLabel(String provinceLabel) {
        this.provinceLabel = provinceLabel;
    }

    public String getCityLabel() {
        return cityLabel;
    }

    public void setCityLabel(String cityLabel) {
        this.cityLabel = cityLabel;
    }

    public String getDistrictLabel() {
        return districtLabel;
    }

    public void setDistrictLabel(String districtLabel) {
        this.districtLabel = districtLabel;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("sn", getSn())
                .append("divideWorkId", getDivideWorkId())
                .append("address", getAddress())
                .append("manufacturer", getManufacturer())
                .append("model", getModel())
                .append("ip", getIp())
                .append("installTime", getInstallTime())
                .append("pid", getPid())
                .append("logicalAddr", getLogicalAddr())
                .append("ver", getVer())
                .append("uplinkPort", getUplinkPort())
                .append("cameraCount", getCameraCount())
                .append("warranty", getWarranty())
                .append("distance", getDistance())
                .append("network", getNetwork())
                .append("longitude", getLongitude())
                .append("latitude", getLatitude())
                .append("delFlag", getDelFlag())
                .append("projectTitle", getProjectTitle())
                .append("installDate", getInstallDate())
                .append("provinceLabel", getProvinceLabel())
                .append("cityLabel", getCityLabel())
                .append("districtLabel", getDistrictLabel())
                .append("workAddress", getWorkAddress())
                .append("pids", getPids())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }

    public String getMuName() {
        return muName;
    }

    public void setMuName(String muName) {
        this.muName = muName;
    }

    public String getMtName() {
        return mtName;
    }

    public void setMtName(String mtName) {
        this.mtName = mtName;
    }

    public Integer getFaultCount() {
        return faultCount;
    }

    public void setFaultCount(Integer faultCount) {
        this.faultCount = faultCount;
    }
}
