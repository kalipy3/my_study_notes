package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 工单记录
 *
 * @author xiongxiangpeng
 * @create 2020-11-18 9:22
 */
@Data
public class OrdersPageableDto implements Serializable {

    // 项目id
    private Long pid;

    // 运维单位id
    private Long muId;

    // 运维队id
    private Long mtId;

    // 派单人id
    private Long sendUid;

    // 接单人id
    private Long receiverId;

    // 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
    private Integer status;

    // 距离范围
    private String timeoutLevel;

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 项目id集合
    private List<Long> pIds;

    //
    private Integer repairTimeout;

    //
    private Integer sendTimeout;

    // 分析类型
    private Integer analysisType;
}
