package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.HswConstructingUnits;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.mapper.HswConstructingUnitsMapper;
import com.ruoyi.hsw.mapper.HswDivideWorkMapper;
import com.ruoyi.hsw.mapper.HswProjectMaintenanceUnitsMapper;
import com.ruoyi.hsw.mapper.HswProjectMapper;
import com.ruoyi.hsw.service.IHswConstructingUnitsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 建设单位Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswConstructingUnitsServiceImpl implements IHswConstructingUnitsService {
    @Autowired
    private HswConstructingUnitsMapper hswConstructingUnitsMapper;

    @Autowired
    private HswDivideWorkMapper hswDivideWorkMapper;

    @Autowired
    private HswProjectMapper hswProjectMapper;

    @Autowired
    private HswProjectMaintenanceUnitsMapper hswProjectMaintenanceUnitsMapper;

    /**
     * 查询建设单位
     *
     * @param id 建设单位ID
     * @return 建设单位
     */
    @Override
    public HswConstructingUnits selectHswConstructingUnitsById(Long id) {
        return hswConstructingUnitsMapper.selectHswConstructingUnitsById(id);
    }

    /**
     * 查询建设单位列表
     *
     * @param hswConstructingUnits 建设单位
     * @return 建设单位
     */
    @Override
    public List<HswConstructingUnits> selectHswConstructingUnitsList(HswConstructingUnits hswConstructingUnits) {
        return hswConstructingUnitsMapper.selectHswConstructingUnitsList(hswConstructingUnits);
    }

    /**
     * 新增建设单位
     *
     * @param hswConstructingUnits 建设单位
     * @return 结果
     */
    @Override
    public int insertHswConstructingUnits(HswConstructingUnits hswConstructingUnits) {
        hswConstructingUnits.setCreateTime(DateUtils.getNowDate());
        return hswConstructingUnitsMapper.insertHswConstructingUnits(hswConstructingUnits);
    }

    /**
     * 修改建设单位
     *
     * @param hswConstructingUnits 建设单位
     * @return 结果
     */
    @Override
    public int updateHswConstructingUnits(HswConstructingUnits hswConstructingUnits) {
        hswConstructingUnits.setUpdateTime(DateUtils.getNowDate());
        return hswConstructingUnitsMapper.updateHswConstructingUnits(hswConstructingUnits);
    }

    /**
     * 批量删除建设单位
     *
     * @param ids 需要删除的建设单位ID
     * @return 结果
     */
    @Override
    public int deleteHswConstructingUnitsByIds(Long[] ids) {
        return hswConstructingUnitsMapper.deleteHswConstructingUnitsByIds(ids);
    }

    /**
     * 删除建设单位信息
     *
     * @param id 建设单位ID
     * @return 结果
     */
    @Override
    public int deleteHswConstructingUnitsById(Long id) {
        return hswConstructingUnitsMapper.deleteHswConstructingUnitsById(id);
    }

    /**
     * 通过当前登录用户获取id列表
     *
     * @return
     */
    @Override
    public List<Long> findIdByUser() {
        SysUser user = SecurityUtils.getLoginUser().getUser();

        List<Long> defaultIds = new ArrayList<>();
        defaultIds.add(-1L);

        switch (user.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM:
                // 用户类型为系统管理员
                return new ArrayList<>();
            case CommonConstant.USER_TYPE_CU:
                // 用户类型为建设单位,获取用户的建设单位id
                List<Long> ids = new ArrayList<>();
                ids.add(user.getConstructingUnitsId());
                return ids;
            case CommonConstant.USER_TYPE_MU:
                // 用户类型为运维单位
                if (user.getTeamId() != null && user.getTeamId() > 0) {
                    // 从分工中获取到的项目id列表
                    List<Long> pids = this.hswDivideWorkMapper.selectPidsByAtId(user.getTeamId());
                    if (pids.isEmpty()) {
                        return defaultIds;
                    }
                    Long[] pidsArr = new Long[pids.size()];
                    pids.toArray(pidsArr);

                    List<HswProject> projectList = hswProjectMapper.selectHswProjectIds(pidsArr);
                    List<Long> cuIds = projectList.stream().map(p -> p.getCuId()).collect(Collectors.toList());
                    return cuIds;
                } else {
                    // 未勾选维修队时
                    // 从项目与运维单位关系中获取到项目id列表
                    List<Long> pids = this.hswProjectMaintenanceUnitsMapper.selectPidsByMuId(user.getMaintenanceUnitsId());
                    if (pids.isEmpty()) {
                        return defaultIds;
                    }
                    Long[] pidsArr = new Long[pids.size()];
                    pids.toArray(pidsArr);

                    List<HswProject> projectList = hswProjectMapper.selectHswProjectIds(pidsArr);
                    List<Long> cuIds = projectList.stream().map(p -> p.getCuId()).collect(Collectors.toList());
                    return cuIds;
                }
            default:
                return defaultIds;
        }
    }

    /**
     * 判断建设单位是否存在
     */
    @Override
    public boolean existCount() {
        return this.hswConstructingUnitsMapper.selectCount() > 0;
    }
}
