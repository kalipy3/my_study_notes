package com.ruoyi.hsw.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/11 0011
 */
@Data
public class JobViewDto implements Serializable {
    /** 主键 */
    private Long id;

    /** 工单编号 */
    @Excel(name = "工单编号")
    private String jobNo;

    /** 故障id */
    @Excel(name = "故障id")
    private Long faultId;

    /** 故障编号 */
    @Excel(name = "故障编号")
    private String faultNo;

    /** 派单时间 */
    @Excel(name = "派单时间")
    private Long sendTime;

    /** 派单人id */
    @Excel(name = "派单人id")
    private Long sendUid;

    /** 接单人id */
    @Excel(name = "接单人id")
    private Long receiverId;

    /** 接单时间 */
    @Excel(name = "接单时间")
    private Integer receiverTime;

    /** 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起） */
    @Excel(name = "工单状态", readConverterExp = "0==未派单；1=待接单；2=在修；,3==已修复；4=挂起")
    private Integer status;

    /** 修复时间 */
    @Excel(name = "修复时间")
    private Long repairTime;

    /** 维修记录 */
    @Excel(name = "维修记录")
    private String repairRecord;

    /** 归档状态（0=活动工单；1=历史工单；） */
    @Excel(name = "归档状态", readConverterExp = "0==活动工单；1=历史工单；")
    private Integer flagStatus;

    /** 视点位置 */
    @Excel(name = "视点位置")
    private String regionName;

    /** 视点IP */
    @Excel(name = "视点IP")
    private String ip;

    /** 端口号，非摄像机故障为0 */
    @Excel(name = "端口号，非摄像机故障为0")
    private Integer port;

    /** 发生时间 */
    @Excel(name = "发生时间")
    private Long takeTime;

    /** 维修队id */
    @Excel(name = "维修队id")
    private Long mtId;

    /** 来源于设备对应分工区域名称（乡镇/街道/小区），便于查询 */
    @Excel(name = "来源于设备对应分工区域名称", readConverterExp = "乡=镇/街道/小区")
    private String area;

    /** 省 */
    @Excel(name = "省")
    private Integer province;

    /** 市 */
    @Excel(name = "市")
    private Integer city;

    /** 区 */
    @Excel(name = "区")
    private Integer district;

    /** 故障类型 */
    @Excel(name = "故障类型")
    private Integer type;

    /** 运维单位id */
    @Excel(name = "运维单位id")
    private Long muId;

    /** 名称 */
    @Excel(name = "名称")
    private String projectTitle;

    /** 建设单位id */
    @Excel(name = "建设单位id")
    private Long cuId;

    /** 挂起时间 */
    @Excel(name = "挂起时间")
    private Long hangUpTime;

    /** 挂起原因 */
    @Excel(name = "挂起原因")
    private String hangUpReason;

    /** 运维单位名称 */
    @Excel(name = "运维单位名称")
    private String maintenanceUnitsName;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Integer resumeTime;

    /** 操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派 */
    @Excel(name = "操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派")
    private Integer handleStatus;

    /** 颠簸状态（0=未处理；1=已处理） */
    @Excel(name = "颠簸状态", readConverterExp = "0==未处理；1=已处理")
    private Integer zigzagStatus;

    /** 颠簸故障类型（同故障状态，除工作不稳定2种） */
    @Excel(name = "颠簸故障类型", readConverterExp = "同=故障状态，除工作不稳定2种")
    private Integer zigzagType;

    /** 影响摄像机数量 */
    @Excel(name = "影响摄像机数量")
    private Integer influenceCameraCount;

    /** 颠簸次数 */
    @Excel(name = "颠簸次数")
    private Integer zigzagCount;

    /** 故障所属分工区域id */
    @Excel(name = "故障所属分工区域id")
    private Long divideWorkId;

    /** 仅对摄像机故障有效，一天该摄像机发生的第几次故障 */
    @Excel(name = "仅对摄像机故障有效，一天该摄像机发生的第几次故障")
    private Long todayTakeCount;

    /** 所属项目 */
    @Excel(name = "所属项目")
    private Long pid;

    /** $column.columnComment */
    @Excel(name = "所属项目")
    private String datestr;

    /** $column.columnComment */
    @Excel(name = "所属项目")
    private String monthstr;

    /** 运维队名称 */
    @Excel(name = "运维队名称")
    private String maintenanceTeamName;

    /** 范围距离 */
    @Excel(name = "范围距离")
    private Long timeoutLevel;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Integer startDistance;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Integer endDistance;

    /** $column.columnComment */
    @Excel(name = "名称")
    private BigDecimal sendWorkOrderLimit;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Integer deviceDistance;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Integer timeoutHour;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Long repairTimeCount;

    /** $column.columnComment */
    @Excel(name = "名称")
    private Long sendTimeCount;

    /** 网络运营商 */
    @Excel(name = "网络运营商")
    private String network;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private String remark;

    private String hangupTimeStr;
    private String hangUpTimeHour;
    private String repairTimeHour;

    private String taketimeStr;
    private String taketimeHour;

    private String otherBtn;
    private String statusText;
    private String typeText;
    private String handleStatusText;

    private String lng;
    private String lat;

    private Integer userType;
    private Long groupId;
    private String sender;
    private String receiver;
    private String sendTimeStr;
    private String repairTimeStr;
    private String takeTimeText;
    private String zigzagTypeText;

    private Long starttime;
    private Long endtime;
    private String fuzzy;

    // 项目id组，查询用
    private Long[] pids;
}
