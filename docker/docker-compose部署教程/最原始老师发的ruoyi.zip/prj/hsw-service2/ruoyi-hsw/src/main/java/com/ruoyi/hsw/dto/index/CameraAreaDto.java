package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 摄像机区域分布DTO
 *
 * @author zyj
 * @date 2020/11/20 20:58
 */
@Data
public class CameraAreaDto implements Serializable {

    // 市
    private String city;

    // 县/区
    private String district;

    // 数量
    private Integer count;

}
