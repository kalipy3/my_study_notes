package com.ruoyi.hsw.mapper;

import com.ruoyi.hsw.domain.HswProjectMaintenanceUnits;
import com.ruoyi.hsw.dto.ProjectMaintenanceUnitsViewDto;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 项目与运维单位关系Mapper接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Repository
public interface HswProjectMaintenanceUnitsMapper {
    /**
     * 查询项目与运维单位关系
     *
     * @param pid 项目与运维单位关系ID
     * @return 项目与运维单位关系
     */
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsById(Long pid);

    /**
     * 查询项目与运维单位关系列表
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 项目与运维单位关系集合
     */
    public List<HswProjectMaintenanceUnits> selectHswProjectMaintenanceUnitsList(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 新增项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    public int insertHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 修改项目与运维单位关系
     *
     * @param hswProjectMaintenanceUnits 项目与运维单位关系
     * @return 结果
     */
    public int updateHswProjectMaintenanceUnits(HswProjectMaintenanceUnits hswProjectMaintenanceUnits);

    /**
     * 删除项目与运维单位关系
     *
     * @param pid 项目与运维单位关系ID
     * @return 结果
     */
    public int deleteHswProjectMaintenanceUnitsById(Long pid);

    /**
     * 批量删除项目与运维单位关系
     *
     * @param pids 需要删除的数据ID
     * @return 结果
     */
    public int deleteHswProjectMaintenanceUnitsByIds(Long[] pids);

    /**
     * 批量添加目与运维单位关系
     *
     * @param list 需要添加的数据id集合
     * @return 结果
     */
    public int batchProjectMaintenanceUnits(List<HswProjectMaintenanceUnits> list);

    /**
     * 根据运维单位id获取项目id集合
     */
    public List<Long> selectPidsByMuId(Long muId);

    /**
     * 根据项目id获取运维单位id集合
     */
    public List<Long> selectMuIdsByPid(@Param("pid") Long pid);

    /**
     * 根据项目集合获取运维单位id集合
     */
    public List<Long> selectPids(@Param("pIds") List<Long> pIds);

    List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewList(ProjectMaintenanceUnitsViewDto projectMaintenanceUnitsViewDto);

    List<ProjectMaintenanceUnitsViewDto> selectProjectMaintenanceUnitsViewListByPids(@Param("pIds") Long[] pids);

    List<ProjectMaintenanceUnitsViewDto> selectListByPids(@Param("pIds") List<Long> pids);
}
