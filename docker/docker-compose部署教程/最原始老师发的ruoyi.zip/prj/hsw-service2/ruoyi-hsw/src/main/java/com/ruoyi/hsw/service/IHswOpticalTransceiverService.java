package com.ruoyi.hsw.service;

import java.util.List;

import com.ruoyi.hsw.domain.HswOpticalTransceiver;
import com.ruoyi.hsw.dto.OpticalTransceiverViewDto;

/**
 * 光纤收发器Service接口
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public interface IHswOpticalTransceiverService {
    /**
     * 查询光纤收发器
     *
     * @param id 光纤收发器ID
     * @return 光纤收发器
     */
    public HswOpticalTransceiver selectHswOpticalTransceiverById(Long id);

    /**
     * 查询光纤收发器列表
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 光纤收发器集合
     */
    public List<HswOpticalTransceiver> selectHswOpticalTransceiverList(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 新增光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    public int insertHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 修改光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    public int updateHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 批量删除光纤收发器
     *
     * @param ids 需要删除的光纤收发器ID
     * @return 结果
     */
    public int deleteHswOpticalTransceiverByIds(Long[] ids);

    /**
     * 删除光纤收发器信息
     *
     * @param id 光纤收发器ID
     * @return 结果
     */
    public int deleteHswOpticalTransceiverById(Long id);

    /**
     * 根据所属诊断器ip删除光纤收发器
     *
     * @param ip
     * @return
     */
    public int deleteHswOpticalTransceiverByIp(String ip);

    /**
     * 校验所属诊断器ip是否唯一
     *
     * @param hswOpticalTransceiver
     * @return
     */
    public String checkIpUnique(HswOpticalTransceiver hswOpticalTransceiver);

    /**
     * 根据所属诊断器ip获取光纤收发器数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    public int selectOpticalTransceiverCountByIp(String ip);

    /**
     * 导入光纤收发器数据
     *
     * @param list     光纤收发器列表
     * @param operName 操作用户
     * @return 结果
     */
    public String importOpticalTransceiver(List<HswOpticalTransceiver> list, String operName);

    /**
     * 校验
     *
     * @param hswOpticalTransceiver
     * @param list
     * @return
     */
    public String checkValid(HswOpticalTransceiver hswOpticalTransceiver, List<HswOpticalTransceiver> list);

    /**
     * 根据所属诊断器ip获取光纤收发器
     *
     * @param ip
     * @return
     */
    public HswOpticalTransceiver selectOpticalTransceiverByIp(String ip);

    /**
     * 查询VIEW
     *
     * @param id VIEWID
     * @return VIEW
     */
    public OpticalTransceiverViewDto selectOpticalTransceiverViewById(Long id);

    /**
     * 查询VIEW列表
     *
     * @param opticalTransceiverViewDto VIEW
     * @return VIEW集合
     */
    public List<OpticalTransceiverViewDto> selectOpticalTransceiverViewList(OpticalTransceiverViewDto opticalTransceiverViewDto);

    OpticalTransceiverViewDto selectOpticalTransceiverViewByIpForApp(String ip);
}
