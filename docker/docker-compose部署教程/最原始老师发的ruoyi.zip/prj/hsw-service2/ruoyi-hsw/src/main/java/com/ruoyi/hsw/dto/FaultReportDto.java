package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/12/2 0002
 */
@Data
public class FaultReportDto implements Serializable {
    private Integer typeCount1 = 0;

    private Integer typeCount2 = 0;

    private Integer typeCount3 = 0;

    private Integer typeCount4 = 0;

    private Integer typeCount5 = 0;

    private Integer typeCount6 = 0;

    private Integer typeCount7 = 0;

    private Integer typeCount8 = 0;

    private Integer typeCount9 = 0;

    private Integer typeCount10 = 0;

    private Integer typeCount11 = 0;

    private Integer typeCount12 = 0;

    private Integer cameraFaultCount = 0;
}
