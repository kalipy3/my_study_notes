package com.ruoyi.hsw.domain;

import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 分工职责对象 hsw_divide_work
 * 
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswDivideWork extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 所属项目id */
    @Excel(name = "所属项目id")
    private Long pid;

    /** 区域 */
    @Excel(name = "区域")
    private String area;

    /** 运维队id */
    @Excel(name = "运维队id")
    private Long atId;

    /** 运维单位 */
    @Excel(name = "运维单位")
    private Long muId;

    /** 运维单位对象 */
    @Excels({
            @Excel(name = "运维单位名称", targetAttr = "maintenanceUnitsName", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceUnits maintenanceUnits;

    /** 运维队对象 */
    @Excels({
            @Excel(name = "运维队名称", targetAttr = "maintenanceTeamName", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceTeam maintenanceTeam;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setPid(Long pid) 
    {
        this.pid = pid;
    }

    public Long getPid() 
    {
        return pid;
    }
    public void setArea(String area) 
    {
        this.area = area;
    }

    public String getArea() 
    {
        return area;
    }
    public void setAtId(Long atId) 
    {
        this.atId = atId;
    }

    public Long getAtId() 
    {
        return atId;
    }
    public void setMuId(Long muId) 
    {
        this.muId = muId;
    }

    public Long getMuId() 
    {
        return muId;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("pid", getPid())
            .append("area", getArea())
            .append("atId", getAtId())
            .append("muId", getMuId())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public HswMaintenanceUnits getMaintenanceUnits() {
        return maintenanceUnits;
    }

    public void setMaintenanceUnits(HswMaintenanceUnits maintenanceUnits) {
        this.maintenanceUnits = maintenanceUnits;
    }

    public HswMaintenanceTeam getMaintenanceTeam() {
        return maintenanceTeam;
    }

    public void setMaintenanceTeam(HswMaintenanceTeam maintenanceTeam) {
        this.maintenanceTeam = maintenanceTeam;
    }
}
