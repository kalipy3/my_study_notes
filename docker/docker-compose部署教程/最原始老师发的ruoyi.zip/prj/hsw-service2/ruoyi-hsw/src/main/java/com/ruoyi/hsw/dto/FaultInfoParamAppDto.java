package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/14 0014
 */
@Data
public class FaultInfoParamAppDto implements Serializable {
    private String ip;
    private Integer port;
    private Long takeStartTime;
    private Long takeEndTime;
}
