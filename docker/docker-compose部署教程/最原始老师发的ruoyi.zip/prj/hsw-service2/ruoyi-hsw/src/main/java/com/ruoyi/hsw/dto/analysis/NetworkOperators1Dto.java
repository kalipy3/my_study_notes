package com.ruoyi.hsw.dto.analysis;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 网络运营商分析Dto
 *
 * @author xiongxiangpeng
 */
@Data
public class NetworkOperators1Dto implements Serializable {

    // 项目id
    private Long pid;

    // 项目名称
    @Excel(name = "所属项目", sort = 1)
    private String projectTitle;

    // 运营商
    @Excel(name = "网络运营商", sort = 2)
    private String communicationsOperations;

    // 故障发生次数
    @Excel(name = "故障发生次数", sort = 3)
    private Integer faultCount=0;

    // 总修复时间
    private Long totalRepairTime=0L;

    // 平均修复时间(小时)
    @Excel(name = "平均修复时间(小时)", sort = 4)
    private Double rate=0D;
}
