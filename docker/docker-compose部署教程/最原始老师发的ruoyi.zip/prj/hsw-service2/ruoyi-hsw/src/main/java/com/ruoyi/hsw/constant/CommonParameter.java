package com.ruoyi.hsw.constant;

/**
 * 描述:
 * 字典数据类型和系统参数常量
 *
 * @author xiongxiangpeng
 * @create 2020-12-17 10:18
 */
public interface CommonParameter {

    // 字典类型-摄像头类型
    String HSW_CAMERA_TYPE = "hsw_camera_type";

    // 字典类型-摄像头生产厂商
    String HSW_CAMERA_MANUFACTURER = "hsw_camera_manufacturer";

    // 字典类型-网络运营商
    String HSW_NETWORK_OPERATOR = "hsw_network_operator";

    // 字典类型-电力运营商
    String HSW_POWER_OPERATION = "hsw_power_operation";

    // 字典类型-故障级别
    String HSW_FAULT_LEVEL = "hsw_fault_level";

    // 字典类型-用户类型
    String SYS_USER_TYPE = "sys_user_type";

    // 字典类型-上行端口
    String HSW_UPLINK_PORT = "hsw_uplink_port";

    // 字典类型-故障类型
    String HSW_FAULT_TYPE = "hsw_fault_type";

    // 字典类型-故障与工单状态
    String HSW_FAULT_JOB_STATUS = "hsw_fault_job_status";

    // 字典类型-工单流转状态
    String HSW_HANDLE_STATUS = "hsw_handle_status";

    // 字典类型-摄像机端口号
    String HSW_CAMERA_PORT = "hsw_camera_port";

    // 字段类型-项目区域
    String HSW_PROJECT_AREA = "hsw_project_area";

    // 系统参数-短信开关
    String SMS_OPEN = "SMS_OPEN";

    // 项目区域的字典类型的Labl
    String AREA = "area";

    // 项目区域的字典类型的Labl
    String AREA_CODE = "areaCode";
}