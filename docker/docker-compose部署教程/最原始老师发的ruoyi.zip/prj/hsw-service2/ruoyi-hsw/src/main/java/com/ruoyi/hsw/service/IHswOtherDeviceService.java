package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswOtherDevice;

import java.util.List;

/**
 * 其他设备Service接口
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public interface IHswOtherDeviceService {
    /**
     * 查询其他设备
     *
     * @param id 其他设备ID
     * @return 其他设备
     */
    public HswOtherDevice selectHswOtherDeviceById(Long id);

    /**
     * 查询其他设备列表
     *
     * @param hswOtherDevice 其他设备
     * @return 其他设备集合
     */
    public List<HswOtherDevice> selectHswOtherDeviceList(HswOtherDevice hswOtherDevice);

    /**
     * 新增其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    public int insertHswOtherDevice(HswOtherDevice hswOtherDevice);

    /**
     * 修改其他设备
     *
     * @param hswOtherDevice 其他设备
     * @return 结果
     */
    public int updateHswOtherDevice(HswOtherDevice hswOtherDevice);

    /**
     * 批量删除其他设备
     *
     * @param ids 需要删除的其他设备ID
     * @return 结果
     */
    public int deleteHswOtherDeviceByIds(Long[] ids);

    /**
     * 删除其他设备信息
     *
     * @param id 其他设备ID
     * @return 结果
     */
    public int deleteHswOtherDeviceById(Long id);

    /**
     * 根据诊断器ip删除其他设备
     *
     * @param ip
     * @return
     */
    public int deleteHswOtherDeviceByIp(String ip);

    /**
     * 根据所属诊断器ip获取其他设备数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    public int selectOtherDeviceCountByIp(String ip);

    /**
     * 导入其他设备数据
     *
     * @param list     其他设备列表
     * @param operName 操作用户
     * @return 结果
     */
    public String importOtherDevice(List<HswOtherDevice> list, String operName);

    /**
     * 校验
     *
     * @param hswOtherDevice
     * @param list
     * @return
     */
    public String checkValid(HswOtherDevice hswOtherDevice, List<HswOtherDevice> list);
}
