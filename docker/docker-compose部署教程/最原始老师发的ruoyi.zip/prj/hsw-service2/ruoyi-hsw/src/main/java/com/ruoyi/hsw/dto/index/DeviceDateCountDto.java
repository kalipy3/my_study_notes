package com.ruoyi.hsw.dto.index;

import lombok.Data;

import java.io.Serializable;

/**
 * 设备按时间统计
 *
 * @author zyj
 * @date 2020/12/1 16:30
 */
@Data
public class DeviceDateCountDto implements Serializable {

    // 时间
    private String dateStr;

    // 数量
    private Integer count = 0;

    // 比率
    private Double rate;

}
