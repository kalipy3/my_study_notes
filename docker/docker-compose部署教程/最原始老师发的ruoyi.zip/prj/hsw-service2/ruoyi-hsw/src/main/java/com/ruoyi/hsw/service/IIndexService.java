package com.ruoyi.hsw.service;

import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.JobViewDto;
import com.ruoyi.hsw.dto.index.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 描述:
 * 首页大屏
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 10:38
 */
public interface IIndexService {
    /**
     * 近一周故障类型分布
     */
    FaultTypeDto faultTypeDistribution(EquFaultPageableDto equFaultPageableDto);

    /**
     * 近一周故障设备分布
     */
    FaultEquDto faultEquDistribution(EquFaultPageableDto equFaultPageableDto);

    /**
     * 活动工单
     */
    List<JobViewDto> activeJobList(EquFaultPageableDto equFaultPageableDto);

    /**
     * 活动故障
     */
    List<FaultViewDto> activeFaultList(EquFaultPageableDto equFaultPageableDto);

    /**
     * 频繁故障视点
     */
    List<FaultViewDto> frequentFaultSiteList(EquFaultPageableDto equFaultPageableDto);

    /**
     * 实施项目数
     */
    Integer projectCount();

    /**
     * 入驻建设单位
     */
    Integer constructingUnitsCount();

    /**
     * 近6个月工单统计
     */
    List<ChartDto> monthJobData();

    /**
     * 近一个月维修队工单统计
     */
    List<JobMtDataDto> monthJobMtData(EquFaultPageableDto equFaultPageableDto);

    /**
     * 近一周在线率（当天在线率获取最后一条数据）
     */
    List<FaultTypeDto> onlineRate(EquFaultPageableDto equFaultPageableDto);

    /**
     * 设备数量
     *
     * @param equFaultPageableDto
     * @return
     */
    DeviceAreaDto deviceCount(EquFaultPageableDto equFaultPageableDto);

    /**
     * 根据市分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    List<CameraAreaDto> cameraCountGroupByCity(EquFaultPageableDto equFaultPageableDto);

    /**
     * 根据县/区分组统计摄像机的数量
     *
     * @param equFaultPageableDto
     * @return
     */
    List<CameraAreaDto> cameraCountGroupByDistrict(EquFaultPageableDto equFaultPageableDto);

    /**
     * 设备数量-App
     *
     * @param equFaultPageableDto
     * @return
     */
    DeviceAreaDto deviceCountForApi(EquFaultPageableDto equFaultPageableDto);

    /**
     * 故障趋势
     *
     * @param equFaultPageableDto
     * @return
     */
    List<FaultTypeDto> faultTrend(EquFaultPageableDto equFaultPageableDto);

    /**
     * 绩效综合对比
     *
     * @param equFaultPageableDto
     * @return
     */
    List<PerformanceDto> performanceComparison(EquFaultPageableDto equFaultPageableDto);
}
