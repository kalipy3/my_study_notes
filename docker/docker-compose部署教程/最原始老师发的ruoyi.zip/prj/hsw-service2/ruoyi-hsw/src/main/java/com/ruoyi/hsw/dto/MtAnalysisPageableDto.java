package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 运维队分析查询参数
 *
 * @author xiongxiangpeng
 * @create 2020-11-17 13:35
 */
@Data
public class MtAnalysisPageableDto implements Serializable {

    // 分析类型
    private Integer analysisType;

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 项目id
    private Long pid;

    // 运维单位id
    private Long muId;

    // 维修队id
    private Long mtId;

    // 距离范围
    private String timeoutLevel;

    // 项目id集合
    private List<Long> pIds;
}
