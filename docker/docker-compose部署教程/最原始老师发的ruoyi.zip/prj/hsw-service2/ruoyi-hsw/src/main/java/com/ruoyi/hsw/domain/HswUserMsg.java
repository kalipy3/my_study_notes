package com.ruoyi.hsw.domain;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 消息发送信息对象 hsw_user_msg
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Data
public class HswUserMsg extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 消息id
     */
    private Long mid;

    /**
     * 用户id
     */
    private Long uid;

    /**
     * 创建时间
     */
    @Excel(name = "创建时间")
    private Integer readTime;

    /**
     * 状态(0=未读；1=已读；3=归档)
     */
    @Excel(name = "状态(0=未读；1=已读；3=归档)")
    private Integer status;

    /**
     * $column.columnComment
     */
    @Excel(name = "状态(0=未读；1=已读；3=归档)")
    private String uname;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private String delFlag;

}
