package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 设备厂家分析Dto
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 10:34
 */
@Data
public class EquAnalysisDto implements Serializable {
    // 生产厂家
    private String manufacturer;

    // 设备数量
    private Integer deviceCount=0;

    // 故障类型
    private String faultType;

    // 故障设备数
    private Integer faultCount=0;

    // 故障设备占比
    private Double faultRate=0D;

}
