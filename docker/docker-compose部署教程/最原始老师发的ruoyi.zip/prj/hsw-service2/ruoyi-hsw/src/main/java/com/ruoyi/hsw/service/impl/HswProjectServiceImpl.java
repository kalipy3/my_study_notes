package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.constant.AreaConstant;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.*;
import com.ruoyi.hsw.domain.vo.ProjectTreeVo;
import com.ruoyi.hsw.domain.vo.TreeVo;
import com.ruoyi.hsw.mapper.*;
import com.ruoyi.hsw.service.IHswConstructingUnitsService;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 项目Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Service
@Transactional
public class HswProjectServiceImpl implements IHswProjectService {
    @Autowired
    private HswProjectMapper hswProjectMapper;

    @Autowired
    private HswProjectMaintenanceUnitsMapper hswProjectMaintenanceUnitsMapper;

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private HswCameraMapper hswCameraMapper;

    @Autowired
    private HswOpticalTransceiverMapper hswOpticalTransceiverMapper;

    @Autowired
    private HswOtherDeviceMapper hswOtherDeviceMapper;

    @Autowired
    private HswDivideWorkMapper hswDivideWorkMapper;

    @Autowired
    private HswFaultInfoMapper hswFaultInfoMapper;

    @Autowired
    private IHswConstructingUnitsService hswConstructingUnitsService;

    /**
     * 查询项目
     *
     * @param id 项目ID
     * @return 项目
     */
    @Override
    public HswProject selectHswProjectById(Long id) {
        return hswProjectMapper.selectHswProjectById(id);
    }

    /**
     * 查询项目列表
     *
     * @param hswProject 项目
     * @return 项目
     */
    @Override
    public List<HswProject> selectHswProjectList(HswProject hswProject) {
        return hswProjectMapper.selectHswProjectList(hswProject);
    }

    /**
     * 新增项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    @Override
    public int insertHswProject(HswProject hswProject) {
        hswProject.setCreateTime(DateUtils.getNowDate());
        hswProject.setBuildTime(DateUtils.getDateMr(hswProject.getBuildDateTime()));
        int rows = hswProjectMapper.insertHswProject(hswProject);
        // 新增项目与运维单位关联
        insertProjectMaintenanceUnits(hswProject);
        return rows;
    }

    /**
     * 修改项目
     *
     * @param hswProject 项目
     * @return 结果
     */
    @Override
    public int updateHswProject(HswProject hswProject) {
        // 删除项目与运维单位关联
        this.hswProjectMaintenanceUnitsMapper.deleteHswProjectMaintenanceUnitsById(hswProject.getId());
        // 新增项目与运维单位关联
        insertProjectMaintenanceUnits(hswProject);

        hswProject.setUpdateTime(DateUtils.getNowDate());
        return hswProjectMapper.updateHswProject(hswProject);
    }

    /**
     * 批量删除项目
     *
     * @param ids 需要删除的项目ID
     * @return 结果
     */
    @Override
    public int deleteHswProjectByIds(Long[] ids) {
        return hswProjectMapper.deleteHswProjectByIds(ids);
    }

    /**
     * 删除项目信息
     *
     * @param id 项目ID
     * @return 结果
     */
    @Override
    public int deleteHswProjectById(Long id) {
        // 删除项目与运维单位关联
        this.hswProjectMaintenanceUnitsMapper.deleteHswProjectMaintenanceUnitsById(id);
        this.hswDiagnosisDeviceService.deleteByPid(id);
        this.hswDivideWorkMapper.deleteByPid(id);
        this.hswFaultInfoMapper.deleteByPid(id);
        return hswProjectMapper.deleteHswProjectById(id);
    }

    @Override
    public boolean existTitle(String name) {
        return hswProjectMapper.selectCountByTitle(name) > 0;
    }

    @Override
    public int finish(Long id) {
        Long finishTime = DateUtils.getDateMr(new Date());
        // 添加竣工时间
        int finish = this.hswProjectMapper.finish(id, finishTime);
        if (finish > 0) {
            // 添加安装时间
            int diagnosis = this.hswDiagnosisDeviceService.finish(id, finishTime);
            if (diagnosis > 0) {
                HswDiagnosisDevice hswDiagnosisDevice = new HswDiagnosisDevice();
                hswDiagnosisDevice.setPid(id);
                List<HswDiagnosisDevice> hswDiagnosisDevices = this.hswDiagnosisDeviceService.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
                if (!hswDiagnosisDevices.isEmpty()) {
                    hswDiagnosisDevices.forEach(diagnosisDevice -> {
                        this.hswCameraMapper.finish(diagnosisDevice.getIp(), finishTime);
                        this.hswOpticalTransceiverMapper.finish(diagnosisDevice.getIp(), finishTime);
                        this.hswOtherDeviceMapper.finish(diagnosisDevice.getIp(), finishTime);
                    });
                }
            }
        }
        return finish;
    }

    @Override
    public Long[] getProjectIdsByUser(SysUser sysUser) {
        List<Long> pids = new ArrayList<>();
        HswProject project = new HswProject();
        List<HswProject> projects = this.hswProjectMapper.selectHswProjectList(project);

        switch (sysUser.getType()) {

            case CommonConstant.USER_TYPE_SYSTEM: // 系统管理员
                pids = projects.stream().map(p -> p.getId()).collect(Collectors.toList());
                break;
            case CommonConstant.USER_TYPE_CU: // 建设单位用户
                pids = projects.stream().filter(p -> p.getCuId().equals(sysUser.getConstructingUnitsId())).map(p -> p.getId()).collect(Collectors.toList());
                break;
            case CommonConstant.USER_TYPE_MU: // 运维单位用户
                //未勾选哪个维修队,可能是运维单位领导
                if (sysUser.getTeamId() == 0) {
                    pids = projects.stream().filter(p -> p.getMuId().equals(sysUser.getMaintenanceUnitsId())).map(p -> p.getId()).collect(Collectors.toList());
                } else {
                    HswDivideWork divideWork = new HswDivideWork();
                    List<HswDivideWork> divideWorks = hswDivideWorkMapper.selectHswDivideWorkList(divideWork);
                    pids = divideWorks.stream().filter(d -> d.getAtId().equals(sysUser.getTeamId())).map(d -> d.getPid()).collect(Collectors.toList());
                }
                break;
        }

        Long[] pidsArr = new Long[pids.size()];
        pids.toArray(pidsArr);
        return pidsArr;
    }

    /**
     * App使用
     * 通过用户实体获取所管辖的项目列表，返回数据参照返回类型参数说明
     */
    @Override
    public List<Long> getPIdsByUser(SysUser sysUser) {
        List<Long> pids = new ArrayList<>();
        HswProject project = new HswProject();
        List<HswProject> projects = this.hswProjectMapper.selectHswProjectList(project);

        switch (sysUser.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM: // 系统管理员
                pids = projects.stream().map(p -> p.getId()).collect(Collectors.toList());
                break;
            case CommonConstant.USER_TYPE_CU: // 建设单位用户
                pids = projects.stream().filter(p -> p.getCuId().equals(sysUser.getConstructingUnitsId())).map(p -> p.getId()).collect(Collectors.toList());
                break;
            case CommonConstant.USER_TYPE_MU: // 运维单位用户
                //未勾选哪个维修队,可能是运维单位领导
                if (sysUser.getTeamId() == 0) {
                    pids = projects.stream().filter(p -> p.getMuId().equals(sysUser.getMaintenanceUnitsId())).map(p -> p.getId()).collect(Collectors.toList());
                } else {
                    HswDivideWork divideWork = new HswDivideWork();
                    List<HswDivideWork> divideWorks = hswDivideWorkMapper.selectHswDivideWorkList(divideWork);
                    pids = divideWorks.stream().filter(d -> d.getAtId().equals(sysUser.getTeamId())).map(d -> d.getPid()).collect(Collectors.toList());
                }
                break;
        }

        return pids;
    }

    @Override
    public List<HswProject> getProjectsByUser(SysUser sysUser) {
        HswProject project = new HswProject();
        List<HswProject> projects = this.hswProjectMapper.selectHswProjectList(project);

        switch (sysUser.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM: // 系统管理员
                break;
            case CommonConstant.USER_TYPE_CU: // 建设单位用户
                projects = projects.stream().filter(p -> p.getCuId().equals(sysUser.getConstructingUnitsId())).collect(Collectors.toList());
                break;
            case CommonConstant.USER_TYPE_MU: // 运维单位用户
                //未勾选哪个维修队,可能是运维单位领导
                if (sysUser.getTeamId() == 0) {
                    projects = projects.stream().filter(p -> p.getMuId().equals(sysUser.getMaintenanceUnitsId())).collect(Collectors.toList());
                } else {
                    HswDivideWork divideWork = new HswDivideWork();
                    List<HswDivideWork> divideWorks = hswDivideWorkMapper.selectHswDivideWorkList(divideWork);
                    List<Long> pids = divideWorks.stream().filter(d -> d.getAtId().equals(sysUser.getTeamId())).map(d -> d.getPid()).collect(Collectors.toList());

                    projects = projects.stream().filter(p -> pids.contains(p.getId())).collect(Collectors.toList());
                }
                break;
        }

        return projects;
    }

    /**
     * 根据建设单位获取项目树形结构
     *
     * @return
     */
    @Override
    public List<ProjectTreeVo> getTreeByCuId() {

        // 获取当前登录用户可获取的建设单位
        List<HswConstructingUnits> hswConstructingUnits = hswConstructingUnitsService.selectHswConstructingUnitsList(new HswConstructingUnits());

        if (CollectionUtils.isEmpty(hswConstructingUnits)) {
            return null;
        }

        List<ProjectTreeVo> projectTreeList = new ArrayList<>();

        // 获取当前登录用户可获取的项目id
        List<Long> pids = this.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        Long[] pidsArr = new Long[pids.size()];
        pids.toArray(pidsArr);

        hswConstructingUnits.forEach(c -> {
            List<HswProject> projectList = hswProjectMapper.selectHswProjectListByCuIdAndPids(c.getId(), pidsArr);
            ProjectTreeVo projectTree = new ProjectTreeVo();
            projectTree.setCuName(c.getName());
            projectTree.setProjectList(projectList);

            projectTreeList.add(projectTree);
        });

        return projectTreeList;
    }

    /**
     * 新增项目运维单位关系信息
     */
    public void insertProjectMaintenanceUnits(HswProject hswProject) {

        Long[] maintenanceUnitsIds = hswProject.getMaintenanceUnitsIds();
        if (StringUtils.isNotNull(maintenanceUnitsIds)) {

            List<HswProjectMaintenanceUnits> list = new ArrayList<>();
            for (Long maintenanceUnitsId : maintenanceUnitsIds) {
                HswProjectMaintenanceUnits hswProjectMaintenanceUnits = new HswProjectMaintenanceUnits();
                hswProjectMaintenanceUnits.setPid(hswProject.getId());
                hswProjectMaintenanceUnits.setMuId(maintenanceUnitsId);
                list.add(hswProjectMaintenanceUnits);
            }

            if (list.size() > 0) {
                this.hswProjectMaintenanceUnitsMapper.batchProjectMaintenanceUnits(list);
            }
        }
    }

    @Override
    public List<Long> findPidByUser() {

        SysUser user = SecurityUtils.getLoginUser().getUser();

        switch (user.getType()) {
            case CommonConstant.USER_TYPE_ADMIN:
                return this.hswProjectMapper.selectPids();
            case CommonConstant.USER_TYPE_SYSTEM:
                return this.hswProjectMapper.selectPids();
            case CommonConstant.USER_TYPE_CU:
                return this.hswProjectMapper.selectPidsByCuId(user.getConstructingUnitsId());
            case CommonConstant.USER_TYPE_MU:
                if (user.getTeamId() != null && user.getTeamId() > 0) {
                    return this.hswDivideWorkMapper.selectPidsByAtId(user.getTeamId());
                } else {
                    return this.hswProjectMaintenanceUnitsMapper.selectPidsByMuId(user.getMaintenanceUnitsId());
                }
            default:
                return new ArrayList<>();
        }
    }

    @Override
    public List<TreeVo> getTreeByArea() {

        List<Long> pidByUser = this.findPidByUser();

        if (CollectionUtils.isEmpty(pidByUser)) {
            return null;
        }

        List<TreeVo> treeList = new ArrayList<>();

        TreeVo ncTree = new TreeVo();
        ncTree.setLabel(AreaConstant.NC_AREA.getName());
        ncTree.setType(1);
        ncTree.setCode(AreaConstant.NC_AREA.getCode());
        ncTree.setLongitude(AreaConstant.NC_AREA.getLongitude());
        ncTree.setLatitude(AreaConstant.NC_AREA.getLatitude());

        TreeVo jdzTree = new TreeVo();
        jdzTree.setLabel(AreaConstant.JDZ_AREA.getName());
        jdzTree.setType(1);
        jdzTree.setCode(AreaConstant.JDZ_AREA.getCode());
        jdzTree.setLongitude(AreaConstant.JDZ_AREA.getLongitude());
        jdzTree.setLatitude(AreaConstant.JDZ_AREA.getLatitude());

        TreeVo pxTree = new TreeVo();
        pxTree.setLabel(AreaConstant.PX_AREA.getName());
        pxTree.setType(1);
        pxTree.setCode(AreaConstant.PX_AREA.getCode());
        pxTree.setLongitude(AreaConstant.PX_AREA.getLongitude());
        pxTree.setLatitude(AreaConstant.PX_AREA.getLatitude());

        TreeVo jjTree = new TreeVo();
        jjTree.setLabel(AreaConstant.JJ_AREA.getName());
        jjTree.setType(1);
        jjTree.setCode(AreaConstant.JJ_AREA.getCode());
        jjTree.setLongitude(AreaConstant.JJ_AREA.getLongitude());
        jjTree.setLatitude(AreaConstant.JJ_AREA.getLatitude());

        TreeVo xyTree = new TreeVo();
        xyTree.setLabel(AreaConstant.XY_AREA.getName());
        xyTree.setType(1);
        xyTree.setCode(AreaConstant.XY_AREA.getCode());
        xyTree.setLongitude(AreaConstant.XY_AREA.getLongitude());
        xyTree.setLatitude(AreaConstant.XY_AREA.getLatitude());

        TreeVo ytTree = new TreeVo();
        ytTree.setLabel(AreaConstant.YT_AREA.getName());
        ytTree.setType(1);
        ytTree.setCode(AreaConstant.YT_AREA.getCode());
        ytTree.setLongitude(AreaConstant.YT_AREA.getLongitude());
        ytTree.setLatitude(AreaConstant.YT_AREA.getLatitude());

        TreeVo gzTree = new TreeVo();
        gzTree.setLabel(AreaConstant.GZ_AREA.getName());
        gzTree.setType(1);
        gzTree.setCode(AreaConstant.GZ_AREA.getCode());
        gzTree.setLongitude(AreaConstant.GZ_AREA.getLongitude());
        gzTree.setLatitude(AreaConstant.GZ_AREA.getLatitude());

        TreeVo jaTree = new TreeVo();
        jaTree.setLabel(AreaConstant.JA_AREA.getName());
        jaTree.setType(1);
        jaTree.setCode(AreaConstant.JA_AREA.getCode());
        jaTree.setLongitude(AreaConstant.JA_AREA.getLongitude());
        jaTree.setLatitude(AreaConstant.JA_AREA.getLatitude());

        TreeVo ycTree = new TreeVo();
        ycTree.setLabel(AreaConstant.YC_AREA.getName());
        ycTree.setType(1);
        ycTree.setCode(AreaConstant.YC_AREA.getCode());
        ycTree.setLongitude(AreaConstant.YC_AREA.getLongitude());
        ycTree.setLatitude(AreaConstant.YC_AREA.getLatitude());

        TreeVo fzTree = new TreeVo();
        fzTree.setLabel(AreaConstant.FZ_AREA.getName());
        fzTree.setType(1);
        fzTree.setCode(AreaConstant.FZ_AREA.getCode());
        fzTree.setLongitude(AreaConstant.FZ_AREA.getLongitude());
        fzTree.setLatitude(AreaConstant.FZ_AREA.getLatitude());

        TreeVo srTree = new TreeVo();
        srTree.setLabel(AreaConstant.SR_AREA.getName());
        srTree.setType(1);
        srTree.setCode(AreaConstant.SR_AREA.getCode());
        srTree.setLongitude(AreaConstant.SR_AREA.getLongitude());
        srTree.setLatitude(AreaConstant.SR_AREA.getLatitude());

        treeList.add(ncTree);
        treeList.add(jdzTree);
        treeList.add(pxTree);
        treeList.add(jjTree);
        treeList.add(xyTree);
        treeList.add(ytTree);
        treeList.add(gzTree);
        treeList.add(jaTree);
        treeList.add(ycTree);
        treeList.add(fzTree);
        treeList.add(srTree);

        Long[] pids = pidByUser.toArray(new Long[pidByUser.size()]);

        List<TreeVo> list = new ArrayList<>();
        treeList.forEach(t -> {
            List<TreeVo> pTreeList = hswProjectMapper.selectByCityAndPids(t.getCode(), pids);
            if (!CollectionUtils.isEmpty(pTreeList)) {
                t.setChildren(pTreeList);

                pTreeList.forEach(p -> {
                    p.setType(2);
                    List<TreeVo> wTreeList = hswDivideWorkMapper.selectTreeByPid(p.getId());
                    wTreeList.forEach(w -> w.setType(3));

                    p.setChildren(wTreeList);
                });
                list.add(t);
            }
        });

        return list;
    }

    /**
     * 查询入驻建设单位数量
     */
    @Override
    public List<Long> selectCuCount() {
        return this.hswProjectMapper.selectCuCount();
    }

    /**
     * 根据当前登录用户获取项目列表
     *
     * @return
     */
    @Override
    public List<HswProject> selectProjectByUser() {
        List<Long> pidByUser = this.findPidByUser();
        if (pidByUser.isEmpty()) {
            return new ArrayList<>();
        }

        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        return hswProjectMapper.selectHswProjectIds(pids);
    }

    /**
     * 获取用户数据权限
     */
    public HswProject dataPermission(HswProject hswProject) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        //1=系统管理员用户；2=建设单位用户；3=运维单位用户
        switch (user.getType()) {
            case CommonConstant.USER_TYPE_CU:
                // 建设单位id
                hswProject.setCuId(user.getConstructingUnitsId());
                break;
            case CommonConstant.USER_TYPE_MU:
                // 运维单位id
                hswProject.setMuId(user.getMaintenanceUnitsId());
                if (user.getTeamId() != null && user.getTeamId() != 0) {
                    // 运维队id
                    hswProject.setMtId(user.getTeamId());
                }
                break;
            default:
                break;
        }

        return hswProject;
    }

    @Override
    public List<HswProject> selectHswProjectIds(Long[] ids) {
        if (ArrayUtils.isEmpty(ids)) {
            return new ArrayList<>();
        }

        return hswProjectMapper.selectHswProjectIds(ids);
    }
}
