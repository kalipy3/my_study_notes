package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.domain.HswConstructingTeam;
import com.ruoyi.hsw.mapper.HswConstructingTeamMapper;
import com.ruoyi.hsw.service.IHswConstructingTeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 施工队Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-05
 */
@Service
@Transactional
public class HswConstructingTeamServiceImpl implements IHswConstructingTeamService {
    @Autowired
    private HswConstructingTeamMapper hswConstructingTeamMapper;

    /**
     * 查询施工队
     *
     * @param id 施工队ID
     * @return 施工队
     */
    @Override
    public HswConstructingTeam selectHswConstructingTeamById(Long id) {
        return hswConstructingTeamMapper.selectHswConstructingTeamById(id);
    }

    /**
     * 查询施工队列表
     *
     * @param hswConstructingTeam 施工队
     * @return 施工队
     */
    @Override
    public List<HswConstructingTeam> selectHswConstructingTeamList(HswConstructingTeam hswConstructingTeam) {
        return hswConstructingTeamMapper.selectHswConstructingTeamList(hswConstructingTeam);
    }

    /**
     * 新增施工队
     *
     * @param hswConstructingTeam 施工队
     * @return 结果
     */
    @Override
    public int insertHswConstructingTeam(HswConstructingTeam hswConstructingTeam) {
        hswConstructingTeam.setCreateTime(DateUtils.getNowDate());
        return hswConstructingTeamMapper.insertHswConstructingTeam(hswConstructingTeam);
    }

    /**
     * 修改施工队
     *
     * @param hswConstructingTeam 施工队
     * @return 结果
     */
    @Override
    public int updateHswConstructingTeam(HswConstructingTeam hswConstructingTeam) {
        hswConstructingTeam.setUpdateTime(DateUtils.getNowDate());
        return hswConstructingTeamMapper.updateHswConstructingTeam(hswConstructingTeam);
    }

    /**
     * 批量删除施工队
     *
     * @param ids 需要删除的施工队ID
     * @return 结果
     */
    @Override
    public int deleteHswConstructingTeamByIds(Long[] ids) {
        return hswConstructingTeamMapper.deleteHswConstructingTeamByIds(ids);
    }

    /**
     * 删除施工队信息
     *
     * @param id 施工队ID
     * @return 结果
     */
    @Override
    public int deleteHswConstructingTeamById(Long id) {
        return hswConstructingTeamMapper.deleteHswConstructingTeamById(id);
    }

    /**
     * 判断施工单位是否存在
     */
    @Override
    public boolean existCount() {
        return this.hswConstructingTeamMapper.selectCount() > 0;
    }
}
