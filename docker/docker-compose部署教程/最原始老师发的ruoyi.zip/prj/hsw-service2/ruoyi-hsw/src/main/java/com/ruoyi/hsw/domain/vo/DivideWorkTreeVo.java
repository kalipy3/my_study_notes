package com.ruoyi.hsw.domain.vo;

import com.ruoyi.hsw.domain.HswDivideWork;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 分工树形结构
 *
 * @author zyj
 * @date 2020/11/16 16:29
 */
@Data
public class DivideWorkTreeVo implements Serializable {

    // 项目名称
    private String projectTitle;

    // 分工列表
    private List<HswDivideWork> divideWorkList;

}
