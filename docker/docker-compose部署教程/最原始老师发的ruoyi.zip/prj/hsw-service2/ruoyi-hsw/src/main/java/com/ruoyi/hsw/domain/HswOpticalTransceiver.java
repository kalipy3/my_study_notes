package com.ruoyi.hsw.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 光纤收发器对象 hsw_optical_transceiver
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public class HswOpticalTransceiver extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 序列号
     */
    @Excel(name = "序列号", sort = 2)
    private String sn;

    /**
     * 生产厂商
     */
    @Excel(name = "生产厂商", sort = 5)
    private String manufacturer;

    /**
     * 型号
     */
    @Excel(name = "型号", sort = 1)
    private String model;

    /**
     * 所属诊断器ip
     */
    @Excel(name = "所属诊断器ip", sort = 3)
    private String ip;

    /**
     * 安装时间
     */
    private Long installTime;

    /**
     * 质保期(年)
     */
    @Excel(name = "质保期(年)", sort = 6)
    private Integer warranty;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private String delFlag;

    /**
     * 安装时间Date类型
     */
    @Excel(name = "安装时间", width = 30, dateFormat = "yyyy-MM-dd", sort = 4, prompt = "时间格式为yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date installDate;

    /**
     * 所属项目名称
     */
    @Excel(name = "所属项目", type = Excel.Type.EXPORT)
    private String projectTitle;

    /**
     * 项目id
     */
    private Long projectId;

    /**
     * 分工区域
     */
    @Excel(name = "所属分工区域", type = Excel.Type.EXPORT)
    private String workAddress;

    /**
     * 距指挥中心距离(KM)
     */
    private Integer distance;

    /**
     * 摄像头数量
     */
    private Integer cameraCount;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getSn() {
        return sn;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @NotBlank(message = "所属诊断器ip不能为空")
    public String getIp() {
        return ip;
    }

    public void setInstallTime(Long installTime) {
        this.installTime = installTime;
    }

    public Long getInstallTime() {
        return installTime;
    }

    public void setWarranty(Integer warranty) {
        this.warranty = warranty;
    }

    @NotNull(message = "质保期不能为空")
    public Integer getWarranty() {
        return warranty;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    @NotNull(message = "安装日期不能为空")
    public Date getInstallDate() {
        return installDate;
    }

    public void setProjectTitle(String projectTitle) {
        this.projectTitle = projectTitle;
    }

    public String getProjectTitle() {
        return projectTitle;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public Integer getCameraCount() {
        return cameraCount;
    }

    public void setCameraCount(Integer cameraCount) {
        this.cameraCount = cameraCount;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("sn", getSn())
                .append("manufacturer", getManufacturer())
                .append("model", getModel())
                .append("ip", getIp())
                .append("installTime", getInstallTime())
                .append("warranty", getWarranty())
                .append("delFlag", getDelFlag())
                .append("installDate", getInstallDate())
                .append("projectTitle", getProjectTitle())
                .append("projectId", getProjectId())
                .append("workAddress", getWorkAddress())
                .append("cameraCount", getCameraCount())
                .append("distance", getDistance())
                .append("pids", getPids())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
