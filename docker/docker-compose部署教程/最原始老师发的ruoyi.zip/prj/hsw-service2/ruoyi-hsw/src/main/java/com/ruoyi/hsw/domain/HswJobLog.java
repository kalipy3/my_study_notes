package com.ruoyi.hsw.domain;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.util.List;

/**
 * 工单日志对象 hsw_job_log
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Data
public class HswJobLog extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 对应工单id */
    @Excel(name = "对应工单id")
    private Long jobId;

    /** 对应工单编号 */
    @Excel(name = "对应工单编号")
    private String jobNo;

    /** 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起） */
    @Excel(name = "工单状态", readConverterExp = "0==未派单；1=待接单；2=在修；,3==已修复；4=挂起")
    private Integer jobStatus;

    /** 操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派 */
    @Excel(name = "操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派")
    private Integer handleStatus;

    /** 操作人id */
    @Excel(name = "操作人id")
    private Long handleUid;

    /** 操作人姓名 */
    @Excel(name = "操作人姓名")
    private String handleUname;

    /** 操作时间 */
    @Excel(name = "操作时间")
    private Long handleTime;

    /** 操作原因 */
    @Excel(name = "操作原因")
    private String handleReason;

    /** 前接单人id */
    @Excel(name = "前接单人id")
    private Long oldReceiverId;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    private String statusText;

    private String time;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setJobId(Long jobId)
    {
        this.jobId = jobId;
    }

    public Long getJobId()
    {
        return jobId;
    }
    public void setJobNo(String jobNo)
    {
        this.jobNo = jobNo;
    }

    public String getJobNo()
    {
        return jobNo;
    }
    public void setJobStatus(Integer jobStatus)
    {
        this.jobStatus = jobStatus;
    }

    public Integer getJobStatus()
    {
        return jobStatus;
    }
    public void setHandleStatus(Integer handleStatus)
    {
        this.handleStatus = handleStatus;
    }

    public Integer getHandleStatus()
    {
        return handleStatus;
    }
    public void setHandleUid(Long handleUid)
    {
        this.handleUid = handleUid;
    }

    public Long getHandleUid()
    {
        return handleUid;
    }
    public void setHandleUname(String handleUname)
    {
        this.handleUname = handleUname;
    }

    public String getHandleUname()
    {
        return handleUname;
    }
    public void setHandleTime(Long handleTime)
    {
        this.handleTime = handleTime;
    }

    public Long getHandleTime()
    {
        return handleTime;
    }
    public void setHandleReason(String handleReason)
    {
        this.handleReason = handleReason;
    }

    public String getHandleReason()
    {
        return handleReason;
    }
    public void setOldReceiverId(Long oldReceiverId)
    {
        this.oldReceiverId = oldReceiverId;
    }

    public Long getOldReceiverId()
    {
        return oldReceiverId;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("jobId", getJobId())
            .append("jobNo", getJobNo())
            .append("jobStatus", getJobStatus())
            .append("handleStatus", getHandleStatus())
            .append("handleUid", getHandleUid())
            .append("handleUname", getHandleUname())
            .append("handleTime", getHandleTime())
            .append("handleReason", getHandleReason())
            .append("oldReceiverId", getOldReceiverId())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
