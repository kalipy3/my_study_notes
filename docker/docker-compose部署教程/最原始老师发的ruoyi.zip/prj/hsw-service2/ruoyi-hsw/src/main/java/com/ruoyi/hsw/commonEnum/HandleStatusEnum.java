package com.ruoyi.hsw.commonEnum;

public enum HandleStatusEnum {
    YPD(0, "已派单"),
    YJD(1, "已接单"),
    YJJ(2, "已拒绝"),
    SQGP(3, "申请改派"),
    YGP(4, "已改派"),
    SQGQ(5, "申请挂起"),
    YGQ(6, "已挂起"),
    YCHGQ(7, "已撤回挂起"),
    YCQ(8, "已撤销"),
    YWC(9, "已结单"),
    BHGQ(10, "驳回挂起"),
    BHGP(11, "驳回改派"),
    ZDXF(12, "自动恢复"),
    YCD(13, "已撤单"),
    NULL(9999, "未知状态");

    private Integer value;
    private String label;

    HandleStatusEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getLabel() {
        return this.label;
    }

    public static HandleStatusEnum valueOf(int value) {
        switch (value) {
            /**
             * 已派单
             */
            case 0:
                return YPD;

            /**
             * 已接单
             */
            case 1:
                return YJD;
            /**
             * 已拒绝
             */
            case 2:
                return YJJ;
            /**
             * 申请改派
             */
            case 3:
                return SQGP;
            /**
             * 已改派
             */
            case 4:
                return YGP;
            /**
             * 申请挂起
             */
            case 5:
                return SQGQ;
            /**
             * 已挂起
             */
            case 6:
                return YGQ;
            /**
             * 已撤回挂起
             */
            case 7:
                return YCHGQ;
            /**
             * 已撤销
             */
            case 8:
                return YCQ;
            /**
             * 已结单
             */
            case 9:
                return YWC;
            /**
             * 驳回挂起
             */
            case 10:
                return BHGQ;
            /**
             * 驳回改派
             */
            case 11:
                return BHGP;
            /**
             * 自动恢复
             */
            case 12:
                return ZDXF;
            /**
             * 已撤单
             */
            case 13:
                return YCD;

            default:
                return NULL;

        }
    }
}
