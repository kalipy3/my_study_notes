package com.ruoyi.hsw.dto.index;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 描述:
 * 故障类型分布
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 11:11
 */
@Data
public class FaultTypeDto implements Serializable {

    // 发生时间
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date datestr;

    // 市电断电故障
    private Integer type1_count;

    // 光纤链路故障
    private Integer type2_count;

    // 光纤收发器故障
    private Integer type3_count;

    // 摄像机链路故障
    private Integer type4_count;

    // 摄像机故障
    private Integer type5_count;

    // 主光缆故障
    private Integer type6_count;

    // 诊断器故障
    private Integer type7_count;

    // 诊断信号输出不正常
    private Integer type8_count;

    // 工作不稳定-当前正常
    private Integer type9_count;

    // 工作不稳定-当前故障
    private Integer type10_count;

    // ONU链路故障
    private Integer type11_count;

    // 诊断器电源适配器故障
    private Integer type12_count;

    // 故障数量
    private Integer camera_fault_count;

    // 在线率
    private Double onlineRate;
}
