package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.analysis.*;
import com.ruoyi.hsw.mapper.AnalysisMapper;
import com.ruoyi.hsw.mapper.HswProjectMaintenanceUnitsMapper;
import com.ruoyi.hsw.service.IAnalysisService;
import com.ruoyi.system.mapper.SysDictDataMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 描述:
 * 绩效考核
 *
 * @author xiongxiangpeng
 * @create 2020-11-14 15:18
 */
@Service
@Transactional
public class AnalysisServiceImpl implements IAnalysisService {

    @Autowired
    private AnalysisMapper analysisMapper;

    @Autowired
    private HswProjectMaintenanceUnitsMapper hswProjectMaintenanceUnitsMapper;

    @Resource
    private SysDictDataMapper sysDictDataMapper;

    @Autowired
    private HswProjectServiceImpl hswProjectService;

    /**
     * 运维单位分析-人工修复
     */
    @Override
    public List<MuAnalysisArtificialDto> muAnalysis1(MuAnalysisPageableDto muAnalysisPageableDto) {
        if (muAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                muAnalysisPageableDto.setPIds(pIds);
                if (muAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        muAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (muAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(muAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    muAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }

        List<MuAnalysisArtificialDto> muAnalysisDtos = this.analysisMapper.muAnalysis1(muAnalysisPageableDto);
        if (!muAnalysisDtos.isEmpty()) {
            muAnalysisDtos.forEach(muAnalysisDto -> {
                // 有效完成数
                muAnalysisDto.setEffectiveOrder(muAnalysisDto.getTotalOrder() - muAnalysisDto.getRepairTimeoutCount());
                // 有效派单数
                muAnalysisDto.setSendCount(muAnalysisDto.getTotalOrder() - muAnalysisDto.getSendTimeoutCount());
                // 平均修复时长(小时)
                if (muAnalysisDto.getTotalRepairTime() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairAvg(0D);
                } else {
                    muAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", muAnalysisDto.getTotalRepairTime()/(muAnalysisDto.getTotalOrder()*3600d))));
                }
                // 平均派单时长
                if (muAnalysisDto.getTotalSendTime() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setSendAvg(0D);
                } else {
                    muAnalysisDto.setSendAvg(Double.valueOf(String.format("%.2f", muAnalysisDto.getTotalSendTime()/(muAnalysisDto.getTotalOrder()*3600d))));
                }
                // 维修效率
                if (muAnalysisDto.getEffectiveOrder() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairRate(0D);
                } else {
                    muAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", muAnalysisDto.getEffectiveOrder()*100d/muAnalysisDto.getTotalOrder())));
                }
                // 派单效率
                if (muAnalysisDto.getSendCount() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setSendRate(0D);
                } else {
                    muAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", muAnalysisDto.getSendCount()*100d/muAnalysisDto.getTotalOrder())));
                }
            });
        }

        return muAnalysisDtos;
    }

    /**
     * 运维单位分析-自动修复
     */
    @Override
    public List<MuAnalysisAutoDto> muAnalysis2(MuAnalysisPageableDto muAnalysisPageableDto) {
        if (muAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                muAnalysisPageableDto.setPIds(pIds);
                if (muAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        muAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (muAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(muAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    muAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }

        List<MuAnalysisAutoDto> muAnalysisDtos = this.analysisMapper.muAnalysis2(muAnalysisPageableDto);
        if (!muAnalysisDtos.isEmpty()) {
            muAnalysisDtos.forEach(muAnalysisDto -> {
                // 平均修复时长(小时)
                if (muAnalysisDto.getTotalAutoRepairTime() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairAvg(0D);
                } else {
                    muAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", muAnalysisDto.getTotalAutoRepairTime()/(muAnalysisDto.getTotalOrder()*3600d))));
                }
                // 占比
                if (muAnalysisDto.getAutoRepairCount() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairRate(0D);
                } else {
                    muAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", muAnalysisDto.getAutoRepairCount()*100d/muAnalysisDto.getTotalOrder())));
                }
            });
        }

        return muAnalysisDtos;
    }

    /**
     * 运维单位分析-未派单
     */
    @Override
    public List<MuAnalysisUndeliveredDto> muAnalysis3(MuAnalysisPageableDto muAnalysisPageableDto) {
        if (muAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                muAnalysisPageableDto.setPIds(pIds);
                if (muAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        muAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (muAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(muAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    muAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }

        List<MuAnalysisUndeliveredDto> muAnalysisDtos = this.analysisMapper.muAnalysis3(muAnalysisPageableDto);
        if (!muAnalysisDtos.isEmpty()) {
            muAnalysisDtos.forEach(muAnalysisDto -> {
                // 超时率
                if (muAnalysisDto.getSendTimeoutCount() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairRate(0D);
                } else {
                    muAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", muAnalysisDto.getSendTimeoutCount()*100d/muAnalysisDto.getTotalOrder())));
                }
            });
        }

        return muAnalysisDtos;
    }

    /**
     * 运维单位分析-维修中
     */
    @Override
    public List<MuAnalysisUnderRepairDto> muAnalysis4(MuAnalysisPageableDto muAnalysisPageableDto) {
        if (muAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                muAnalysisPageableDto.setPIds(pIds);
                if (muAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        muAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (muAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(muAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    muAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }

        List<MuAnalysisUnderRepairDto> muAnalysisDtos = this.analysisMapper.muAnalysis4(muAnalysisPageableDto);
        if (!muAnalysisDtos.isEmpty()) {
            muAnalysisDtos.forEach(muAnalysisDto -> {
                // 超时率
                if (muAnalysisDto.getRepaireTimeoutCount() == 0 || muAnalysisDto.getTotalOrder() == 0) {
                    muAnalysisDto.setRepairRate(0D);
                } else {
                    muAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", muAnalysisDto.getRepaireTimeoutCount()*100d/muAnalysisDto.getTotalOrder())));
                }
            });
        }

        return muAnalysisDtos;
    }

    /**
     * 运维单位分析-人工修复总数
     */
    @Override
    public MuAnalysisArtificialDto muAnalysisSum1(MuAnalysisPageableDto muAnalysisPageableDto) {
        List<MuAnalysisArtificialDto> muAnalysisDtos = this.muAnalysis1(muAnalysisPageableDto);
        MuAnalysisArtificialDto muAnalysisDto = new MuAnalysisArtificialDto();
        if (!muAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalOrder = muAnalysisDtos.stream().mapToInt(MuAnalysisArtificialDto::getTotalOrder).sum();
            muAnalysisDto.setTotalOrder(totalOrder);
            // 总计-桉时完成时
            Integer effectiveOrder = muAnalysisDtos.stream().mapToInt(MuAnalysisArtificialDto::getEffectiveOrder).sum();
            muAnalysisDto.setEffectiveOrder(effectiveOrder);
            // 总计-按时派单数
            Integer sendCount = muAnalysisDtos.stream().mapToInt(MuAnalysisArtificialDto::getSendCount).sum();
            muAnalysisDto.setSendCount(sendCount);
            // 总计-平均修复时长(小时)
            Double repairAvg = muAnalysisDtos.stream().mapToDouble(MuAnalysisArtificialDto::getRepairAvg).sum();
            List<MuAnalysisArtificialDto> repairAvgs = muAnalysisDtos.stream().filter(mu -> mu.getRepairAvg() > 0).collect(Collectors.toList());
            if (repairAvgs.size() > 0) {
                muAnalysisDto.setRepairAvg(repairAvg / repairAvgs.size());
            } else {
                muAnalysisDto.setRepairAvg(repairAvg);
            }
            // 总计-平均派单时长(小时)
            Double sendAvg = muAnalysisDtos.stream().mapToDouble(MuAnalysisArtificialDto::getSendAvg).sum();
            List<MuAnalysisArtificialDto> sendAvgs = muAnalysisDtos.stream().filter(mu -> mu.getSendAvg() > 0).collect(Collectors.toList());
            if (sendAvgs.size() > 0) {
                muAnalysisDto.setSendAvg(sendAvg / sendAvgs.size());
            } else {
                muAnalysisDto.setSendAvg(sendAvg);
            }
            // 总计-维修效率
            Double repairRate = muAnalysisDtos.stream().mapToDouble(MuAnalysisArtificialDto::getRepairRate).sum();
            List<MuAnalysisArtificialDto> repairRates = muAnalysisDtos.stream().filter(mu -> mu.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                muAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                muAnalysisDto.setRepairRate(repairRate);
            }
            // 总计-派单效率
            Double sendRate = muAnalysisDtos.stream().mapToDouble(MuAnalysisArtificialDto::getSendRate).sum();
            List<MuAnalysisArtificialDto> sendRates = muAnalysisDtos.stream().filter(mu -> mu.getRepairRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                muAnalysisDto.setSendRate(sendRate / sendRates.size());
            } else {
                muAnalysisDto.setSendRate(sendRate);
            }
        }
        return muAnalysisDto;
    }

    /**
     * 运维单位分析-自动修复总数
     */
    @Override
    public MuAnalysisAutoDto muAnalysisSum2(MuAnalysisPageableDto muAnalysisPageableDto) {
        List<MuAnalysisAutoDto> muAnalysisDtos = this.muAnalysis2(muAnalysisPageableDto);
        MuAnalysisAutoDto muAnalysisDto = new MuAnalysisAutoDto();
        if (!muAnalysisDtos.isEmpty()) {
            // 总计-故障总数
            Integer totalOrder = muAnalysisDtos.stream().mapToInt(MuAnalysisAutoDto::getTotalOrder).sum();
            muAnalysisDto.setTotalOrder(totalOrder);
            // 总计-自动修复数
            Integer autoRepairCount = muAnalysisDtos.stream().mapToInt(MuAnalysisAutoDto::getAutoRepairCount).sum();
            muAnalysisDto.setAutoRepairCount(autoRepairCount);
            // 总计-平均修复时长(小时)
            Double repairAvg = muAnalysisDtos.stream().mapToDouble(MuAnalysisAutoDto::getRepairAvg).sum();
            List<MuAnalysisAutoDto> repairAvgs = muAnalysisDtos.stream().filter(mu -> mu.getRepairAvg() > 0).collect(Collectors.toList());
            if (repairAvgs.size() > 0) {
                muAnalysisDto.setRepairAvg(repairAvg / repairAvgs.size());
            } else {
                muAnalysisDto.setRepairAvg(repairAvg);
            }

            // 总计-占比
            Double repairRate = muAnalysisDtos.stream().mapToDouble(MuAnalysisAutoDto::getRepairRate).sum();
            List<MuAnalysisAutoDto> repairRates = muAnalysisDtos.stream().filter(mu -> mu.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                muAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                muAnalysisDto.setRepairRate(repairRate);
            }
        }

        return muAnalysisDto;
    }

    /**
     * 运维单位分析-未派单总数
     */
    @Override
    public MuAnalysisUndeliveredDto muAnalysisSum3(MuAnalysisPageableDto muAnalysisPageableDto) {
        List<MuAnalysisUndeliveredDto> muAnalysisDtos = this.muAnalysis3(muAnalysisPageableDto);
        MuAnalysisUndeliveredDto muAnalysisDto = new MuAnalysisUndeliveredDto();
        if (!muAnalysisDtos.isEmpty()) {
            // 总计-未派单数
            Integer totalOrder = muAnalysisDtos.stream().mapToInt(MuAnalysisUndeliveredDto::getTotalOrder).sum();
            muAnalysisDto.setTotalOrder(totalOrder);
            // 总计-超时数
            Integer sendTimeoutCount = muAnalysisDtos.stream().mapToInt(MuAnalysisUndeliveredDto::getSendTimeoutCount).sum();
            muAnalysisDto.setSendTimeoutCount(sendTimeoutCount);
            // 总计-占比
            Double repairRate = muAnalysisDtos.stream().mapToDouble(MuAnalysisUndeliveredDto::getRepairRate).sum();
            List<MuAnalysisUndeliveredDto> repairRates = muAnalysisDtos.stream().filter(mu -> mu.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                muAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                muAnalysisDto.setRepairRate(repairRate);
            }
        }

        return muAnalysisDto;
    }

    /**
     * 运维单位分析-维修中总数
     */
    @Override
    public MuAnalysisUnderRepairDto muAnalysisSum4(MuAnalysisPageableDto muAnalysisPageableDto) {
        List<MuAnalysisUnderRepairDto> muAnalysisDtos = this.muAnalysis4(muAnalysisPageableDto);
        MuAnalysisUnderRepairDto muAnalysisDto = new MuAnalysisUnderRepairDto();
        if (!muAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalOrder = muAnalysisDtos.stream().mapToInt(MuAnalysisUnderRepairDto::getTotalOrder).sum();
            muAnalysisDto.setTotalOrder(totalOrder);
            // 总计-超时数
            Integer repaireTimeoutCount = muAnalysisDtos.stream().mapToInt(MuAnalysisUnderRepairDto::getRepaireTimeoutCount).sum();
            muAnalysisDto.setRepaireTimeoutCount(repaireTimeoutCount);
            // 总计-占比
            Double repairRate = muAnalysisDtos.stream().mapToDouble(MuAnalysisUnderRepairDto::getRepairRate).sum();
            List<MuAnalysisUnderRepairDto> repairRates = muAnalysisDtos.stream().filter(mu -> mu.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                muAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                muAnalysisDto.setRepairRate(repairRate);
            }
        }

        return muAnalysisDto;
    }

    /**
     * 维修队分析-人工修复
     */
    @Override
    public List<MtAnalysisArtificialDto> mtAnalysis1(MtAnalysisPageableDto mtAnalysisPageableDto) {
        if (mtAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtAnalysisPageableDto.setPIds(pIds);
            }
        }

        List<MtAnalysisArtificialDto> mtAnalysisDtos = this.analysisMapper.mtAnalysis1(mtAnalysisPageableDto);
        if (!mtAnalysisDtos.isEmpty()) {
            mtAnalysisDtos.forEach(mtAnalysisDto -> {
                // 有效完成数
                mtAnalysisDto.setEffectiveOrder(mtAnalysisDto.getTotalOrder() - mtAnalysisDto.getRepairTimeoutCount());
                // 有效派单数
                mtAnalysisDto.setSendCount(mtAnalysisDto.getTotalOrder() - mtAnalysisDto.getSendTimeoutCount());
                // 平均修复时长(小时)
                if (mtAnalysisDto.getTotalRepairTime() == 0 || mtAnalysisDto.getTotalOrder() == 0) {
                    mtAnalysisDto.setRepairAvg(0D);
                } else {
                    mtAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", mtAnalysisDto.getTotalRepairTime()/(mtAnalysisDto.getTotalOrder()*3600d))));
                }
                // 平均派单时长(小时)
                if (mtAnalysisDto.getTotalSendTime() == 0 || mtAnalysisDto.getTotalOrder() == 0) {
                    mtAnalysisDto.setSendAvg(0D);
                } else {
                    mtAnalysisDto.setSendAvg(Double.valueOf(String.format("%.2f", mtAnalysisDto.getTotalSendTime()/(mtAnalysisDto.getTotalOrder()*3600d))));
                }
                // 维修效率
                if (mtAnalysisDto.getEffectiveOrder() == 0 || mtAnalysisDto.getTotalOrder() == 0) {
                    mtAnalysisDto.setRepairRate(0D);
                } else {
                    mtAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", mtAnalysisDto.getEffectiveOrder()*100d/mtAnalysisDto.getTotalOrder())));
                }
                // 派单效率
                if (mtAnalysisDto.getSendCount() == 0 || mtAnalysisDto.getTotalOrder() == 0) {
                    mtAnalysisDto.setSendRate(0D);
                } else {
                    mtAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", mtAnalysisDto.getSendCount()*100d/mtAnalysisDto.getTotalOrder())));
                }
            });
        }

        return mtAnalysisDtos;
    }

    /**
     * 维修队分析-自动修复
     */
    @Override
    public List<MtAnalysisAutoDto> mtAnalysis2(MtAnalysisPageableDto mtAnalysisPageableDto) {
        if (mtAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtAnalysisPageableDto.setPIds(pIds);
            }
        }
        List<MtAnalysisAutoDto> mtAnalysisDtos = this.analysisMapper.mtAnalysis2(mtAnalysisPageableDto);
        if (!mtAnalysisDtos.isEmpty()) {
            mtAnalysisDtos.forEach(mtAnalysisDto -> {
                // 平均修复时长(小时)
                if (mtAnalysisDto.getTotalAutoRepairTime() == 0 || mtAnalysisDto.getAutoRepairCount() == 0) {
                    mtAnalysisDto.setRepairAvg(0D);
                } else {
                    mtAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", mtAnalysisDto.getTotalAutoRepairTime()/(mtAnalysisDto.getAutoRepairCount()*3600d))));
                }
                // 占比
                if (mtAnalysisDto.getAutoRepairCount() == 0 || mtAnalysisDto.getTotalFault() == 0) {
                    mtAnalysisDto.setRepairRate(0D);
                } else {
                    mtAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", mtAnalysisDto.getAutoRepairCount()*100d/mtAnalysisDto.getTotalFault())));
                }
            });
        }

        return mtAnalysisDtos;
    }

    /**
     * 维修队分析-未派单
     */
    @Override
    public List<MtAnalysisUndeliveredDto> mtAnalysis3(MtAnalysisPageableDto mtAnalysisPageableDto) {
        if (mtAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtAnalysisPageableDto.setPIds(pIds);
            }
        }

        List<MtAnalysisUndeliveredDto> mtAnalysisDtos = this.analysisMapper.mtAnalysis3(mtAnalysisPageableDto);
        if (!mtAnalysisDtos.isEmpty()) {
            mtAnalysisDtos.forEach(mtAnalysisDto -> {
                // 超时率
                if (mtAnalysisDto.getSendTimeoutCount() == 0 || mtAnalysisDto.getNosend() == 0) {
                    mtAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", mtAnalysisDto.getSendTimeoutCount()*100d/mtAnalysisDto.getNosend())));
                }
            });
        }

        return mtAnalysisDtos;
    }

    /**
     * 维修队分析-维修中
     */
    @Override
    public List<MtAnalysisUnderRepairDto> mtAnalysis4(MtAnalysisPageableDto mtAnalysisPageableDto) {
        if (mtAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtAnalysisPageableDto.setPIds(pIds);
            }
        }
        List<MtAnalysisUnderRepairDto> mtAnalysisDtos = this.analysisMapper.mtAnalysis4(mtAnalysisPageableDto);
        if (!mtAnalysisDtos.isEmpty()) {
            mtAnalysisDtos.forEach(mtAnalysisDto -> {
                // 超时率
                if (mtAnalysisDto.getRepairTimeoutCount() == 0 || mtAnalysisDto.getTotalOrder() == 0) {
                    mtAnalysisDto.setSendRate(0D);
                } else {
                    mtAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", mtAnalysisDto.getRepairTimeoutCount()*100d/mtAnalysisDto.getTotalOrder())));
                }
            });
        }

        return mtAnalysisDtos;
    }

    /**
     * 维修队分析-人工修复总数
     */
    @Override
    public MtAnalysisArtificialDto mtAnalysisSum1(MtAnalysisPageableDto mtAnalysisPageableDto) {
        List<MtAnalysisArtificialDto> mtAnalysisDtos = this.mtAnalysis1(mtAnalysisPageableDto);
        MtAnalysisArtificialDto mtAnalysisDto = new MtAnalysisArtificialDto();
        if (!mtAnalysisDtos.isEmpty()){
            // 总计-工单总数
            Integer totalOrder = mtAnalysisDtos.stream().mapToInt(MtAnalysisArtificialDto::getTotalOrder).sum();
            mtAnalysisDto.setTotalOrder(totalOrder);
            // 总计-有效完成数
            Integer effectiveOrder = mtAnalysisDtos.stream().mapToInt(MtAnalysisArtificialDto::getEffectiveOrder).sum();
            mtAnalysisDto.setEffectiveOrder(effectiveOrder);
            // 总计-有效派单数
            Integer sendCount = mtAnalysisDtos.stream().mapToInt(MtAnalysisArtificialDto::getSendCount).sum();
            mtAnalysisDto.setSendCount(sendCount);
            // 总计-平均修复时长(小时)
            Double repairAvg = mtAnalysisDtos.stream().mapToDouble(MtAnalysisArtificialDto::getRepairAvg).sum();
            List<MtAnalysisArtificialDto> repairAvgs = mtAnalysisDtos.stream().filter(mt -> mt.getRepairAvg() > 0).collect(Collectors.toList());
            if (repairAvgs.size() > 0) {
                mtAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", repairAvg / repairAvgs.size())));
            } else {
                mtAnalysisDto.setRepairAvg(repairAvg);
            }

            // 总计-平均派单时长(小时)
            Double sendAvg = mtAnalysisDtos.stream().mapToDouble(MtAnalysisArtificialDto::getSendAvg).sum();
            List<MtAnalysisArtificialDto> sendAvgs = mtAnalysisDtos.stream().filter(mt -> mt.getSendAvg() > 0).collect(Collectors.toList());
            if (sendAvgs.size() > 0) {
                mtAnalysisDto.setSendAvg(Double.valueOf(String.format("%.2f", sendAvg / sendAvgs.size())));
            } else {
                mtAnalysisDto.setSendAvg(sendAvg);
            }

            // 总计-维修效率
            Double repairRate = mtAnalysisDtos.stream().mapToDouble(MtAnalysisArtificialDto::getRepairRate).sum();
            List<MtAnalysisArtificialDto> repairRates = mtAnalysisDtos.stream().filter(mt -> mt.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                mtAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", repairRate / repairRates.size())));
            } else {
                mtAnalysisDto.setRepairRate(repairRate);
            }

            // 总计-派单效率
            Double sendRate = mtAnalysisDtos.stream().mapToDouble(MtAnalysisArtificialDto::getSendRate).sum();
            List<MtAnalysisArtificialDto> sendRates = mtAnalysisDtos.stream().filter(mt -> mt.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                mtAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", sendRate / sendRates.size())));
            } else {
                mtAnalysisDto.setSendRate(sendRate);
            }
        }

        return mtAnalysisDto;
    }

    /**
     * 维修队分析-自动修复总数
     */
    @Override
    public MtAnalysisAutoDto mtAnalysisSum2(MtAnalysisPageableDto mtAnalysisPageableDto) {
        List<MtAnalysisAutoDto> mtAnalysisDtos = this.mtAnalysis2(mtAnalysisPageableDto);
        MtAnalysisAutoDto mtAnalysisDto = new MtAnalysisAutoDto();
        if (!mtAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalFault = mtAnalysisDtos.stream().mapToInt(MtAnalysisAutoDto::getTotalFault).sum();
            mtAnalysisDto.setTotalFault(totalFault);
            // 总计-自动修复数
            Integer autoRepairCount = mtAnalysisDtos.stream().mapToInt(MtAnalysisAutoDto::getAutoRepairCount).sum();
            mtAnalysisDto.setAutoRepairCount(autoRepairCount);
            // 总计-平均修复时长(小时)
            Double repairAvg = mtAnalysisDtos.stream().mapToDouble(MtAnalysisAutoDto::getRepairAvg).sum();
            List<MtAnalysisAutoDto> repairAvgs = mtAnalysisDtos.stream().filter(mt -> mt.getRepairAvg() > 0).collect(Collectors.toList());
            if (repairAvgs.size() > 0) {
                mtAnalysisDto.setRepairAvg(repairAvg / repairAvgs.size());
            } else {
                mtAnalysisDto.setRepairAvg(repairAvg);
            }
            // 总计-占比
            Double repairRate = mtAnalysisDtos.stream().mapToDouble(MtAnalysisAutoDto::getRepairRate).sum();
            List<MtAnalysisAutoDto> repairRates = mtAnalysisDtos.stream().filter(mt -> mt.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                mtAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                mtAnalysisDto.setRepairRate(repairRate);
            }
        }

        return mtAnalysisDto;
    }

    /**
     * 维修队分析-未派单总数
     */
    @Override
    public MtAnalysisUndeliveredDto mtAnalysisSum3(MtAnalysisPageableDto mtAnalysisPageableDto) {
        List<MtAnalysisUndeliveredDto> mtAnalysisDtos = this.mtAnalysis3(mtAnalysisPageableDto);
        MtAnalysisUndeliveredDto mtAnalysisDto = new MtAnalysisUndeliveredDto();
        if(!mtAnalysisDtos.isEmpty()) {
            // 总计-未派单数
            Integer nosend = mtAnalysisDtos.stream().collect(Collectors.summingInt(MtAnalysisUndeliveredDto::getNosend));
            mtAnalysisDto.setNosend(nosend);
            // 总计-超时数（派单超时）
            Integer sendTimeoutCount = mtAnalysisDtos.stream().collect(Collectors.summingInt(MtAnalysisUndeliveredDto::getSendTimeoutCount));
            mtAnalysisDto.setSendTimeoutCount(sendTimeoutCount);
            // 总计-超时率
            Double sendRate = mtAnalysisDtos.stream().collect(Collectors.summingDouble(MtAnalysisUndeliveredDto::getSendRate));
            List<MtAnalysisUndeliveredDto> sendRates = mtAnalysisDtos.stream().filter(mt -> mt.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                mtAnalysisDto.setSendRate(sendRate / sendRates.size());
            } else {
                mtAnalysisDto.setSendRate(sendRate);
            }
        }

        return mtAnalysisDto;
    }

    /**
     * 维修队分析-维修中总数
     */
    @Override
    public MtAnalysisUnderRepairDto mtAnalysisSum4(MtAnalysisPageableDto mtAnalysisPageableDto) {
        List<MtAnalysisUnderRepairDto> mtAnalysisDtos = this.mtAnalysis4(mtAnalysisPageableDto);
        MtAnalysisUnderRepairDto mtAnalysisDto = new MtAnalysisUnderRepairDto();
        if (!mtAnalysisDtos.isEmpty()) {
            // 总计-工单总数(维修中)
            Integer totalOrder = mtAnalysisDtos.stream().mapToInt(MtAnalysisUnderRepairDto::getTotalOrder).sum();
            mtAnalysisDto.setTotalOrder(totalOrder);
            // 总计-超时数（维修中超时）
            Integer repairTimeoutCount = mtAnalysisDtos.stream().mapToInt(MtAnalysisUnderRepairDto::getRepairTimeoutCount).sum();
            mtAnalysisDto.setRepairTimeoutCount(repairTimeoutCount);
            // 总计-超时率
            Double sendRate = mtAnalysisDtos.stream().mapToDouble(MtAnalysisUnderRepairDto::getSendRate).sum();
            List<MtAnalysisUnderRepairDto> sendRates = mtAnalysisDtos.stream().filter(mt -> mt.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                mtAnalysisDto.setSendRate(sendRate / sendRates.size());
            } else {
                mtAnalysisDto.setSendRate(sendRate);
            }
        }

        return mtAnalysisDto;
    }

    /**
     * 维修队长分析-人工修复
     */
    @Override
    public List<MtlAnalysisArtificialDto> mtlAnalysis1(MtlAnalysisPageableDto mtlAnalysisPageableDto) {

        if (mtlAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtlAnalysisPageableDto.setPIds(pIds);
            }
        }
        // 添加用户集合
        List<Long> userIds = this.analysisMapper.selectUserId(mtlAnalysisPageableDto);
        if (!userIds.isEmpty()) {
            mtlAnalysisPageableDto.setUserIds(userIds);
        }

        List<MtlAnalysisArtificialDto> mtlAnalysisDtos = this.analysisMapper.mtlAnalysis1(mtlAnalysisPageableDto);
        if (!mtlAnalysisDtos.isEmpty()) {
            mtlAnalysisDtos.forEach(mtlAnalysisDto -> {
                // 按时完成数
                mtlAnalysisDto.setEffectiveOrder(mtlAnalysisDto.getTotalRepairOrder() - mtlAnalysisDto.getRepairTimeoutCount());
                // 按时派单数
                mtlAnalysisDto.setSendCount(mtlAnalysisDto.getTotalSendOrder() - mtlAnalysisDto.getSendTimeoutCount());
                // 平均修复时长(小时)
                if (mtlAnalysisDto.getTotalRepairTime() == 0 || mtlAnalysisDto.getTotalRepairOrder() == 0) {
                    mtlAnalysisDto.setRepairAvg(0D);
                } else {
                    mtlAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", mtlAnalysisDto.getTotalRepairTime()/(mtlAnalysisDto.getTotalRepairOrder()*3600d))));
                }
                // 平均派单时长(小时)
                if (mtlAnalysisDto.getTotalSendTime() == 0 || mtlAnalysisDto.getTotalSendOrder() == 0) {
                    mtlAnalysisDto.setSendAvg(0D);
                } else {
                    mtlAnalysisDto.setSendAvg(Double.valueOf(String.format("%.2f", mtlAnalysisDto.getTotalSendTime()/(mtlAnalysisDto.getTotalSendOrder()*3600d))));
                }
                // 维修效率
                if ((mtlAnalysisDto.getTotalRepairOrder()-mtlAnalysisDto.getRepairTimeoutCount()) == 0 || mtlAnalysisDto.getTotalRepairOrder() == 0) {
                    mtlAnalysisDto.setRepairRate(0D);
                } else {
                    Double repairRate = (mtlAnalysisDto.getTotalRepairOrder()-mtlAnalysisDto.getRepairTimeoutCount())*100d/mtlAnalysisDto.getTotalRepairOrder();
                    mtlAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", repairRate)));
                }
                // 派单效率
                if ((mtlAnalysisDto.getTotalSendOrder()-mtlAnalysisDto.getSendTimeoutCount()) == 0 || mtlAnalysisDto.getTotalSendOrder() == 0) {
                    mtlAnalysisDto.setSendRate(0D);
                } else {
                    Double sendRate = (mtlAnalysisDto.getTotalSendOrder()-mtlAnalysisDto.getSendTimeoutCount())*100d/mtlAnalysisDto.getTotalSendOrder();
                    mtlAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", sendRate)));
                }
            });
        }

        return mtlAnalysisDtos;
    }

    /**
     * 维修队长分析-未派单
     */
    @Override
    public List<MtlAnalysisUndeliveredDto> mtlAnalysis3(MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        if (mtlAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtlAnalysisPageableDto.setPIds(pIds);
            }
        }
        // 添加用户集合
        List<Long> userIds = this.analysisMapper.selectUserId(mtlAnalysisPageableDto);
        if (!userIds.isEmpty()) {
            mtlAnalysisPageableDto.setUserIds(userIds);
        }

        List<MtlAnalysisUndeliveredDto> mtlAnalysisDtos = this.analysisMapper.mtlAnalysis3(mtlAnalysisPageableDto);
        if (!mtlAnalysisDtos.isEmpty()) {
            mtlAnalysisDtos.forEach(mtlAnalysisDto -> {
               // 超时率
                if (mtlAnalysisDto.getSendTimeoutCount() == 0 || mtlAnalysisDto.getNoSend() == 0) {
                    mtlAnalysisDto.setSendRate(0D);
                } else {
                    Double sendRate = mtlAnalysisDto.getSendTimeoutCount() * 100D/mtlAnalysisDto.getNoSend() ;
                    mtlAnalysisDto.setSendRate(Double.valueOf(String.format("%.2f", sendRate)));
                }
            });
        }
        return mtlAnalysisDtos;
    }

    /**
     * 维修队长分析-维修中
     */
    @Override
    public List<MtlAnalysisUnderRepairDto> mtlAnalysis4(MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        if (mtlAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtlAnalysisPageableDto.setPIds(pIds);
            }
        }
        // 添加用户集合
        List<Long> userIds = this.analysisMapper.selectUserId(mtlAnalysisPageableDto);
        if (!userIds.isEmpty()) {
            mtlAnalysisPageableDto.setUserIds(userIds);
        }

        List<MtlAnalysisUnderRepairDto> mtlAnalysisDtos = this.analysisMapper.mtlAnalysis4(mtlAnalysisPageableDto);
        if (!mtlAnalysisDtos.isEmpty()) {
            mtlAnalysisDtos.forEach(mtlAnalysisDto -> {
                // 维修超时率
                if (mtlAnalysisDto.getRepaireTimeoutCount() == 0 || mtlAnalysisDto.getTotalOrder() == 0) {
                    mtlAnalysisDto.setTimeoutRate(0D);
                } else {
                    Double timeoutRate = mtlAnalysisDto.getRepaireTimeoutCount()*100d/ mtlAnalysisDto.getTotalOrder();
                    mtlAnalysisDto.setTimeoutRate(Double.valueOf(String.format("%.2f", timeoutRate)));
                }
            });
        }

        return mtlAnalysisDtos;
    }

    /**
     * 维修队长分析-人工修复-总数
     */
    @Override
    public MtlAnalysisArtificialDto mtlAnalysisSum1(MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        List<MtlAnalysisArtificialDto> mtlAnalysisDtos = this.mtlAnalysis1(mtlAnalysisPageableDto);
        MtlAnalysisArtificialDto mtlAnalysisDto = new MtlAnalysisArtificialDto();
        if (!mtlAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalSendOrder = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisArtificialDto::getTotalSendOrder).sum();
            mtlAnalysisDto.setTotalSendOrder(totalSendOrder);
            // 总计-自修单数
            Integer totalRepairOrder = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisArtificialDto::getTotalRepairOrder).sum();
            mtlAnalysisDto.setTotalRepairOrder(totalRepairOrder);
            // 总计-按时完成数
            Integer effectiveOrder = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisArtificialDto::getEffectiveOrder).sum();
            mtlAnalysisDto.setEffectiveOrder(effectiveOrder);
            // 总计-按时派单数
            Integer sendCount = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisArtificialDto::getSendCount).sum();
            mtlAnalysisDto.setSendCount(sendCount);
            // 总计-平均修复时长(小时)
            Double repairAvg = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisArtificialDto::getRepairAvg).sum();
            List<MtlAnalysisArtificialDto> repairAvgs = mtlAnalysisDtos.stream().filter(mtl -> mtl.getRepairAvg() > 0).collect(Collectors.toList());
            if (repairAvgs.size() > 0) {
                mtlAnalysisDto.setRepairAvg(repairAvg / repairAvgs.size());
            } else {
                mtlAnalysisDto.setRepairAvg(repairAvg);
            }
            // 总计-平均派单时长(小时)
            Double sendAvg = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisArtificialDto::getSendAvg).sum();
            List<MtlAnalysisArtificialDto> sendAvgs = mtlAnalysisDtos.stream().filter(mtl -> mtl.getSendAvg() > 0).collect(Collectors.toList());
            if (sendAvgs.size() > 0) {
                mtlAnalysisDto.setSendAvg(sendAvg / sendAvgs.size());
            } else {
                mtlAnalysisDto.setSendAvg(sendAvg);
            }
            // 总计-维修效率
            Double repairRate = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisArtificialDto::getRepairRate).sum();
            List<MtlAnalysisArtificialDto> repairRates = mtlAnalysisDtos.stream().filter(mtl -> mtl.getRepairRate() > 0).collect(Collectors.toList());
            if (repairRates.size() > 0) {
                mtlAnalysisDto.setRepairRate(repairRate / repairRates.size());
            } else {
                mtlAnalysisDto.setRepairRate(repairRate);
            }
            // 总计-派单效率
            Double sendRate = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisArtificialDto::getSendRate).sum();
            List<MtlAnalysisArtificialDto> sendRates = mtlAnalysisDtos.stream().filter(mtl -> mtl.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                mtlAnalysisDto.setSendRate(sendRate / sendRates.size());
            } else {
                mtlAnalysisDto.setSendRate(sendRate);
            }
        }

        return mtlAnalysisDto;
    }

    /**
     * 维修队长分析-未派单-总数
     */
    @Override
    public MtlAnalysisUndeliveredDto mtlAnalysisSum3(MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        List<MtlAnalysisUndeliveredDto> mtlAnalysisDtos = this.mtlAnalysis3(mtlAnalysisPageableDto);
        MtlAnalysisUndeliveredDto mtlAnalysisDto = new MtlAnalysisUndeliveredDto();
        if (!mtlAnalysisDtos.isEmpty()) {
            // 总计-未派单总数
            Integer nosend = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisUndeliveredDto::getNoSend).sum();
            mtlAnalysisDto.setNoSend(nosend);
            // 总计-派单超时数量
            Integer sendTimeoutCount = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisUndeliveredDto::getSendTimeoutCount).sum();
            mtlAnalysisDto.setSendTimeoutCount(sendTimeoutCount);
            // 总计-派单效率
            Double sendRate = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisUndeliveredDto::getSendRate).sum();
            List<MtlAnalysisUndeliveredDto> sendRates = mtlAnalysisDtos.stream().filter(mtl -> mtl.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                mtlAnalysisDto.setSendRate(sendRate / sendRates.size());
            } else {
                mtlAnalysisDto.setSendRate(sendRate);
            }
        }

        return mtlAnalysisDto;
    }

    /**
     * 维修队长分析-维修中-总数
     */
    @Override
    public MtlAnalysisUnderRepairDto mtlAnalysisSum4(MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        List<MtlAnalysisUnderRepairDto> mtlAnalysisDtos = this.mtlAnalysis4(mtlAnalysisPageableDto);
        MtlAnalysisUnderRepairDto mtlAnalysisDto = new MtlAnalysisUnderRepairDto();
        if (!mtlAnalysisDtos.isEmpty()) {
            // 总计-工单总数(维修中)
            Integer totalOrder = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisUnderRepairDto::getTotalOrder).sum();
            mtlAnalysisDto.setTotalOrder(totalOrder);
            // 总计-超时数(维修中超时)
            Integer repaireTimeoutCount = mtlAnalysisDtos.stream().mapToInt(MtlAnalysisUnderRepairDto::getRepaireTimeoutCount).sum();
            mtlAnalysisDto.setRepaireTimeoutCount(repaireTimeoutCount);
            // 总计-超时率
            Double timeoutRate = mtlAnalysisDtos.stream().mapToDouble(MtlAnalysisUnderRepairDto::getTimeoutRate).sum();
            List<MtlAnalysisUnderRepairDto> timeoutRates = mtlAnalysisDtos.stream().filter(mtl -> mtl.getTimeoutRate() > 0).collect(Collectors.toList());
            if (timeoutRates.size() > 0) {
                mtlAnalysisDto.setTimeoutRate(timeoutRate / timeoutRates.size());
            } else {
                mtlAnalysisDto.setTimeoutRate(timeoutRate);
            }
        }

        return mtlAnalysisDto;
    }

    /**
     * 维修员分析-人工修复
     */
    @Override
    public List<MtManAnalysisArtificialDto> mtManAnalysis1(MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        if (mtManAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtManAnalysisPageableDto.setPIds(pIds);
                if (mtManAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        mtManAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (mtManAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(mtManAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    mtManAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }
        List<MtManAnalysisArtificialDto> mtManAnalysisDtos = this.analysisMapper.mtManAnalysis1(mtManAnalysisPageableDto);
        if (!mtManAnalysisDtos.isEmpty()) {
            mtManAnalysisDtos.forEach(mtManAnalysisDto -> {
                // 按时完成数 = 工单总数 - 超时完成修复完成数量
                mtManAnalysisDto.setEffectiveOrder(mtManAnalysisDto.getTotalOrder()- mtManAnalysisDto.getRepairTimeoutCount());
                // 正常派单数 = 工单总数 - 派单超时数量
                mtManAnalysisDto.setSendCount(mtManAnalysisDto.getTotalOrder()- mtManAnalysisDto.getSendTimeoutCount());
                // 维修效率 = 按时完成数 / 工单总数 * 100
                if (mtManAnalysisDto.getEffectiveOrder() == 0 || mtManAnalysisDto.getTotalOrder() == 0) {
                    mtManAnalysisDto.setRepairRate(0D);
                } else {
                    Double repairRate = mtManAnalysisDto.getEffectiveOrder()*100d/ mtManAnalysisDto.getTotalOrder();
                    mtManAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", repairRate)));
                }
                // 平均修复时长(小时) = 完成修复花费的时间总数(修复时间-派单时间) / 工单总数 * 3600
                if (mtManAnalysisDto.getTotalRepairTime() == 0 || mtManAnalysisDto.getTotalOrder() == 0) {
                    mtManAnalysisDto.setRepairAvg(0D);
                } else {
                    mtManAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", mtManAnalysisDto.getTotalRepairTime()/(mtManAnalysisDto.getTotalOrder()*3600d))));
                }
            });
        }

        if (mtManAnalysisPageableDto.getPid() == null) {
            // 取所有的维修员及队长
            List<MtManAnalysisArtificialDto> allManAnalysisDtos = this.analysisMapper.mtManAnalysis1ForAll();
            Iterator<MtManAnalysisArtificialDto> iterator = allManAnalysisDtos.iterator();
            while (iterator.hasNext()) {
                MtManAnalysisArtificialDto allDto = iterator.next();
                for( MtManAnalysisArtificialDto d : mtManAnalysisDtos) {
                    if (d.getUserId().equals(allDto.getUserId())) {
                        BeanUtils.copyProperties(d, allDto, "userId");
                        break;
                    }
                }
            }

            allManAnalysisDtos.sort((o1, o2) -> o2.getTotalOrder().compareTo(o1.getTotalOrder()));
            return allManAnalysisDtos;
        }

        return mtManAnalysisDtos;
    }

    /**
     * 维修员分析-维修中
     */
    @Override
    public List<MtManAnalysisUnderRepairDto> mtManAnalysis4(MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        if (mtManAnalysisPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                mtManAnalysisPageableDto.setPIds(pIds);
                if (mtManAnalysisPageableDto.getMuId() == null) {
                    List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectPids(pIds);
                    if (!muIds.isEmpty()) {
                        mtManAnalysisPageableDto.setMuIds(muIds);
                    }
                }
            }
        } else {
            if (mtManAnalysisPageableDto.getMuId() == null) {
                List<Long> muIds = this.hswProjectMaintenanceUnitsMapper.selectMuIdsByPid(mtManAnalysisPageableDto.getPid());
                if (!muIds.isEmpty()) {
                    mtManAnalysisPageableDto.setMuIds(muIds);
                }
            }
        }

        List<MtManAnalysisUnderRepairDto> mtManAnalysisDtos = this.analysisMapper.mtManAnalysis4(mtManAnalysisPageableDto);
        if (!mtManAnalysisDtos.isEmpty()) {
            mtManAnalysisDtos.forEach(mtManAnalysisDto -> {
                // 维修超时率
                if (mtManAnalysisDto.getRepaireTimeoutCount() == 0 || mtManAnalysisDto.getTotalOrder() == 0) {
                    mtManAnalysisDto.setTimeoutRate(0D);
                } else {
                    Double timeoutRate = mtManAnalysisDto.getRepaireTimeoutCount()*100d/ mtManAnalysisDto.getTotalOrder();
                    mtManAnalysisDto.setTimeoutRate(Double.valueOf(String.format("%.2f", timeoutRate)));
                }
            });
        }

        return mtManAnalysisDtos;
    }

    /**
     * 维修员分析-人工修复-总数
     */
    @Override
    public MtManAnalysisArtificialDto mtManAnalysisSum1(MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        List<MtManAnalysisArtificialDto> mtManAnalysisDtos = this.mtManAnalysis1(mtManAnalysisPageableDto);
        MtManAnalysisArtificialDto mtManAnalysisDto = new MtManAnalysisArtificialDto();
        if (!mtManAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalOrder = mtManAnalysisDtos.stream().mapToInt(MtManAnalysisArtificialDto::getTotalOrder).sum();
            mtManAnalysisDto.setTotalOrder(totalOrder);
            // 总计-按时完成数
            Integer effectiveOrder = mtManAnalysisDtos.stream().mapToInt(MtManAnalysisArtificialDto::getEffectiveOrder).sum();
            mtManAnalysisDto.setEffectiveOrder(effectiveOrder);

            // 总计-维修效率 = 按时完成数 / 工单总数 * 100
            if (effectiveOrder <=0 || totalOrder <=0) {
                mtManAnalysisDto.setRepairRate(0D);
            } else {
                mtManAnalysisDto.setRepairRate(Double.valueOf(String.format("%.2f", effectiveOrder * 100d / totalOrder)));
            }

            // 总计- 平均修复时长(小时) = 完成修复花费的时间总数(修复时间-派单时间) / 工单总数 * 3600
            double totalRepairTime = mtManAnalysisDtos.stream().mapToDouble(MtManAnalysisArtificialDto::getTotalRepairTime).sum();
            if (totalRepairTime <= 0 || totalOrder <= 0) {
                mtManAnalysisDto.setRepairAvg(0D);
            } else {
                mtManAnalysisDto.setRepairAvg(Double.valueOf(String.format("%.2f", totalRepairTime / (totalOrder * 3600d))));
            }
        }

        return mtManAnalysisDto;
    }

    /**
     * 维修员分析-维修中-总数
     */
    @Override
    public MtManAnalysisUnderRepairDto mtManAnalysisSum4(MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        List<MtManAnalysisUnderRepairDto> mtManAnalysisDtos = this.mtManAnalysis4(mtManAnalysisPageableDto);
        MtManAnalysisUnderRepairDto mtManAnalysisDto = new MtManAnalysisUnderRepairDto();
        if (!mtManAnalysisDtos.isEmpty()) {
            // 总计-工单总数
            Integer totalOrder = mtManAnalysisDtos.stream().mapToInt(MtManAnalysisUnderRepairDto::getTotalOrder).sum();
            mtManAnalysisDto.setTotalOrder(totalOrder);
            // 总计-超时数
            Integer repaireTimeoutCount = mtManAnalysisDtos.stream().mapToInt(MtManAnalysisUnderRepairDto::getRepaireTimeoutCount).sum();
            mtManAnalysisDto.setRepaireTimeoutCount(repaireTimeoutCount);
            // 总计-超时率
            Double timeoutRate = mtManAnalysisDtos.stream().mapToDouble(MtManAnalysisUnderRepairDto::getTimeoutRate).sum();
            List<MtManAnalysisUnderRepairDto> timeoutRates = mtManAnalysisDtos.stream().filter(mtMan -> mtMan.getTimeoutRate() > 0).collect(Collectors.toList());
            if (timeoutRates.size() > 0) {
                mtManAnalysisDto.setTimeoutRate(timeoutRate / timeoutRates.size());
            } else {
                mtManAnalysisDto.setTimeoutRate(timeoutRate);
            }
        }

        return mtManAnalysisDto;
    }

    /**
     * 设备厂商分析
     */
    @Override
    public List<EquAnalysis1Dto> equAnalysis(EquAnalysisPageableDto equAnalysisPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equAnalysisPageableDto.setPIds(pIds);
        }

         List<SysDictData> dictDatas = this.sysDictDataMapper.selectDictDataByType("hsw_camera_manufacturer");
         List<EquAnalysis1Dto> equAnalysisDtos = new ArrayList<>();

         if (!dictDatas.isEmpty()) {
             dictDatas.forEach(dictData -> {
                 if ("光纤收发器".equals(equAnalysisPageableDto.getDeviceType())) {
                     EquAnalysis1Dto equAnalysisDto = new EquAnalysis1Dto();
                     // 获取设备数
                     int deviceCount = this.analysisMapper.selectDeviceCount(dictData.getDictValue(), equAnalysisPageableDto);
                     // 获取故障设备数
                     int faultCount = this.analysisMapper.selectFaultCount(dictData.getDictValue(), equAnalysisPageableDto);
                     if (faultCount == 0 || deviceCount == 0) {
                         equAnalysisDto.setFaultRate(0d); // 设备故障占比
                     } else {
                         equAnalysisDto.setFaultRate(Double.valueOf(String.format("%.2f", faultCount*100d/deviceCount))); // 设备故障占比
                     }

                     equAnalysisDto.setManufacturer(dictData.getDictLabel()); // 生产厂家
                     equAnalysisDto.setDeviceCount(deviceCount); // 设备数
                     equAnalysisDto.setFaultCount(faultCount); // 故障设备数
                     equAnalysisDto.setFaultType("光纤收发器故障");

                     equAnalysisDtos.add(equAnalysisDto);
                 } else {

                     if (equAnalysisPageableDto.getManufacturer() != null && equAnalysisPageableDto.getManufacturer() != "") {
                         if (equAnalysisPageableDto.getManufacturer().equals(dictData.getDictLabel())) {
                             EquAnalysis1Dto equAnalysisDto = new EquAnalysis1Dto();
                             // 获取设备数
                             int deviceCount = this.analysisMapper.selectDeviceCountByDeviceType(dictData.getDictValue(), equAnalysisPageableDto);
                             // 获取故障设备数
                             int faultCount = this.analysisMapper.selectFaultCountByDeviceType(dictData.getDictValue(), equAnalysisPageableDto);
                             if (faultCount == 0 || deviceCount == 0) {
                                 equAnalysisDto.setFaultRate(0d); // 设备故障占比
                             } else {
                                 equAnalysisDto.setFaultRate(Double.valueOf(String.format("%.2f", faultCount*100d/deviceCount))); // 设备故障占比
                             }

                             equAnalysisDto.setManufacturer(dictData.getDictLabel()); // 生产厂家
                             equAnalysisDto.setDeviceCount(deviceCount); // 设备数
                             equAnalysisDto.setFaultCount(faultCount); // 故障设备数
                             equAnalysisDto.setFaultType("摄像机故障");

                             equAnalysisDtos.add(equAnalysisDto);
                         }
                     } else {
                         EquAnalysis1Dto equAnalysisDto = new EquAnalysis1Dto();
                         // 获取设备数
                         int deviceCount = this.analysisMapper.selectDeviceCountByDeviceType(dictData.getDictValue(), equAnalysisPageableDto);
                         // 获取故障设备数
                         int faultCount = this.analysisMapper.selectFaultCountByDeviceType(dictData.getDictValue(), equAnalysisPageableDto);
                         if (faultCount == 0 || deviceCount == 0) {
                             equAnalysisDto.setFaultRate(0d); // 设备故障占比
                         } else {
                             equAnalysisDto.setFaultRate(Double.valueOf(String.format("%.2f", faultCount*100d/deviceCount))); // 设备故障占比
                         }

                         equAnalysisDto.setManufacturer(dictData.getDictLabel()); // 生产厂家
                         equAnalysisDto.setDeviceCount(deviceCount); // 设备数
                         equAnalysisDto.setFaultCount(faultCount); // 故障设备数
                         equAnalysisDto.setFaultType("摄像机故障");

                         equAnalysisDtos.add(equAnalysisDto);
                     }
                 }
             });
         }

        return equAnalysisDtos;
    }

    /**
     * 设备厂商分析-总数
     */
    @Override
    public EquAnalysis1Dto equAnalysisSum(EquAnalysisPageableDto equAnalysisPageableDto) {
        List<EquAnalysis1Dto> equAnalysisDtos = this.equAnalysis(equAnalysisPageableDto);
        EquAnalysis1Dto equAnalysisDto = new EquAnalysis1Dto();
        if (!equAnalysisDtos.isEmpty()) {
            // 总计-设备数
            Integer deviceCount = equAnalysisDtos.stream().mapToInt(EquAnalysis1Dto::getDeviceCount).sum();
            equAnalysisDto.setDeviceCount(deviceCount);
            // 总计-故障设备数
            Integer faultCount = equAnalysisDtos.stream().mapToInt(EquAnalysis1Dto::getFaultCount).sum();
            equAnalysisDto.setFaultCount(faultCount);
            // 总计-设备故障占比
            Double faultRate = equAnalysisDtos.stream().mapToDouble(EquAnalysis1Dto::getFaultRate).sum();
            List<EquAnalysis1Dto> faultRates = equAnalysisDtos.stream().filter(equ -> equ.getFaultRate() > 0).collect(Collectors.toList());
            if (faultRates.size() > 0) {
                equAnalysisDto.setFaultRate(faultRate / faultRates.size());
            } else {
                equAnalysisDto.setFaultRate(faultRate);
            }
        }

        return equAnalysisDto;
    }

    /**
     * 网络运营商分析
     */
    @Override
    public List<NetworkOperators1Dto> networkOperators(NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        if (networkOperatorsPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                networkOperatorsPageableDto.setPIds(pIds);
            }
        }

        List<NetworkOperators1Dto> networkOperatorsDtoList = this.analysisMapper.networkOperators(networkOperatorsPageableDto);
        if (!networkOperatorsDtoList.isEmpty()) {
            networkOperatorsDtoList.forEach(networkOperatorsDto -> {
                // 平均修复时间
                if (networkOperatorsDto.getTotalRepairTime() == 0 || networkOperatorsDto.getFaultCount() == 0) {
                    networkOperatorsDto.setRate(0D);
                } else {
                    Double timeoutRate = networkOperatorsDto.getTotalRepairTime() / (networkOperatorsDto.getFaultCount() * 3600D);
                    networkOperatorsDto.setRate(Double.valueOf(String.format("%.2f", timeoutRate)));
                }
            });
        }

        return networkOperatorsDtoList;
    }

    /**
     * 网络运营商分析-总数
     */
    @Override
    public NetworkOperators1Dto networkOperatorsSum(NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        List<NetworkOperators1Dto> networkOperatorsDtos = this.networkOperators(networkOperatorsPageableDto);
        NetworkOperators1Dto networkOperatorsDto = new NetworkOperators1Dto();
        if (!networkOperatorsDtos.isEmpty()) {
            // 总计-故障发生次数
            Integer faultCount = networkOperatorsDtos.stream().mapToInt(NetworkOperators1Dto::getFaultCount).sum();
            networkOperatorsDto.setFaultCount(faultCount);
            // 总计-平均修复时间(小时)
            Double rate = networkOperatorsDtos.stream().mapToDouble(NetworkOperators1Dto::getRate).sum();
            List<NetworkOperators1Dto> rates = networkOperatorsDtos.stream().filter(equ -> equ.getRate() > 0).collect(Collectors.toList());
            if (rates.size() > 0) {
                networkOperatorsDto.setRate(rate / rates.size());
            } else {
                networkOperatorsDto.setRate(rate);
            }
        }

        return networkOperatorsDto;
    }

    /**
     * 电力运营商分析
     */
    @Override
    public List<PowerOperators1Dto> powerOperators(PowerOperatorsPageableDto powerOperatorsPageableDto) {
        if (powerOperatorsPageableDto.getPid()== null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                powerOperatorsPageableDto.setPIds(pIds);
            }
        }

        List<PowerOperators1Dto> powerOperatorsDtoList = this.analysisMapper.powerOperators(powerOperatorsPageableDto);
        if (!powerOperatorsDtoList.isEmpty()) {
            powerOperatorsDtoList.forEach(powerOperatorsDto -> {
                // 平均停电时长(小时)
                if (powerOperatorsDto.getTotalRepairTime() == 0 || powerOperatorsDto.getFaultCount() == 0) {
                    powerOperatorsDto.setRate(0D);
                } else {
                    Double timeoutRate = powerOperatorsDto.getTotalRepairTime() / (powerOperatorsDto.getFaultCount() * 3600D);
                    powerOperatorsDto.setRate(Double.valueOf(String.format("%.2f", timeoutRate)));
                }
            });
        }

        return powerOperatorsDtoList;
    }

    /**
     * 电力运营商分析-总数
     */
    @Override
    public PowerOperators1Dto powerOperatorsSum(PowerOperatorsPageableDto powerOperatorsPageableDto) {
        List<PowerOperators1Dto> powerOperatorsDtoList = this.powerOperators(powerOperatorsPageableDto);
        PowerOperators1Dto powerOperatorsDto = new PowerOperators1Dto();
        if (!powerOperatorsDtoList.isEmpty()) {
            // 总计-停电次数
            Integer faultCount = powerOperatorsDtoList.stream().mapToInt(PowerOperators1Dto::getFaultCount).sum();
            powerOperatorsDto.setFaultCount(faultCount);
            // 总计-平均停电时长(小时)
            Double rate = powerOperatorsDtoList.stream().mapToDouble(PowerOperators1Dto::getRate).sum();
            List<PowerOperators1Dto> rates = powerOperatorsDtoList.stream().filter(equ -> equ.getRate() > 0).collect(Collectors.toList());
            if (rates.size() > 0) {
                powerOperatorsDto.setRate(rate / rates.size());
            } else {
                powerOperatorsDto.setRate(rate);
            }
        }

        return powerOperatorsDto;
    }

    /**
     * 派单员分析
     */
    @Override
    public List<Dispatcher1Dto> dispatcher(DispatcherPageableDto dispatcherPageableDto) {
        List<Dispatcher1Dto> dispatcherDtos = this.analysisMapper.dispatcher(dispatcherPageableDto);
        if (!dispatcherDtos.isEmpty()) {
            dispatcherDtos.forEach(dispatcherDto -> {
                // 有效派单数
                dispatcherDto.setSendOk(dispatcherDto.getTotalSendOrder()-dispatcherDto.getSendTimeout());
                // 平均派单时长
                if (dispatcherDto.getSendTimeCount() == 0 || dispatcherDto.getTotalSendOrder() == 0) {
                    dispatcherDto.setSendAvg(0D);
                } else {
                    dispatcherDto.setSendAvg(Double.valueOf(String.format("%.2f", dispatcherDto.getSendTimeCount()/(3600d*dispatcherDto.getTotalSendOrder()))));
                }
                // 派单效率
                if (dispatcherDto.getSendOk() == 0 || dispatcherDto.getTotalSendOrder() == 0) {
                    dispatcherDto.setSendRate(0D);
                } else {
                    dispatcherDto.setSendRate(Double.valueOf(String.format("%.2f", 100d*dispatcherDto.getSendOk()/dispatcherDto.getTotalSendOrder())));
                }
            });
        }

        return dispatcherDtos;
    }

    /**
     * 派单员分析-总数
     */
    @Override
    public Dispatcher1Dto dispatcherSum(DispatcherPageableDto dispatcherPageableDto) {
        List<Dispatcher1Dto> dispatcherDtos = this.dispatcher(dispatcherPageableDto);
        Dispatcher1Dto dispatcherDto = new Dispatcher1Dto();
        if (!dispatcherDtos.isEmpty()) {
            // 总计-派单数
            Integer totalSendOrder = dispatcherDtos.stream().mapToInt(Dispatcher1Dto::getTotalSendOrder).sum();
            dispatcherDto.setTotalSendOrder(totalSendOrder);
            // 总计-有效派单数
            Integer sendOk = dispatcherDtos.stream().mapToInt(Dispatcher1Dto::getSendOk).sum();
            dispatcherDto.setSendOk(sendOk);
            // 总计-平均派单时长(小时)
            Double sendAvg = dispatcherDtos.stream().mapToDouble(Dispatcher1Dto::getSendAvg).sum();
            List<Dispatcher1Dto> sendAvgs = dispatcherDtos.stream().filter(equ -> equ.getSendAvg() > 0).collect(Collectors.toList());
            if (sendAvgs.size() > 0) {
                dispatcherDto.setSendAvg(sendAvg / sendAvgs.size());
            } else {
                dispatcherDto.setSendAvg(sendAvg);
            }
            // 总计-派单效率
            Double sendRate = dispatcherDtos.stream().mapToDouble(Dispatcher1Dto::getSendRate).sum();
            List<Dispatcher1Dto> sendRates = dispatcherDtos.stream().filter(equ -> equ.getSendRate() > 0).collect(Collectors.toList());
            if (sendRates.size() > 0) {
                dispatcherDto.setSendRate(sendRate / sendRates.size());
            } else {
                dispatcherDto.setSendRate(sendRate);
            }
        }

        return dispatcherDto;
    }

    /**
     * 工单记录-列表
     */
    @Override
    public List<JobViewDto> ordersList(OrdersPageableDto ordersPageableDto) {
        return this.analysisMapper.ordersList(ordersPageableDto);
    }

    /**
     * 工单记录-饼状图
     */
    @Override
    public PicChartDto ordersPieChart(OrdersPageableDto ordersPageableDto) {
        if (ordersPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                ordersPageableDto.setPIds(pIds);
            }
        }
        return this.analysisMapper.ordersPieChart(ordersPageableDto);
    }

    /**
     * 派单记录-列表
     */
    @Override
    public List<JobViewDto> sendOrdersList(OrdersPageableDto ordersPageableDto) {
        return this.analysisMapper.sendOrdersList(ordersPageableDto);
    }

    /**
     * 派单记录-饼状图
     */
    @Override
    public PicChartDto sendOrdersPieChart(OrdersPageableDto ordersPageableDto) {
        if (ordersPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                ordersPageableDto.setPIds(pIds);
            }
        }
        return this.analysisMapper.sendOrdersPieChart(ordersPageableDto);
    }

    /**
     * * 自动恢复记录-列表
     */
    @Override
    public List<FaultViewDto> autoRepairFaultList(OrdersPageableDto ordersPageableDto) {
        return this.analysisMapper.autoRepairFaultList(ordersPageableDto);
    }

    /**
     * 自动恢复记录-饼状图
     */
    @Override
    public PicChartDto autoRepairFaultPieChart(OrdersPageableDto ordersPageableDto) {
        if (ordersPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                ordersPageableDto.setPIds(pIds);
            }
        }
        return this.analysisMapper.autoRepairFaultPieChart(ordersPageableDto);
    }

    /**
     * 未派单记录-列表
     */
    @Override
    public List<FaultViewDto> noSendFaultList(OrdersPageableDto ordersPageableDto) {
        return this.analysisMapper.noSendFaultList(ordersPageableDto);
    }

    /**
     * 未派单记录-饼状图
     */
    @Override
    public PicChartDto noSendFaultPieChart(OrdersPageableDto ordersPageableDto) {
        if (ordersPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                ordersPageableDto.setPIds(pIds);
            }
        }
        return this.analysisMapper.noSendFaultPieChart(ordersPageableDto);
    }

    /**
     * 维修中记录-列表
     */
    @Override
    public List<JobViewDto> underRepairList(OrdersPageableDto ordersPageableDto) {
        return this.analysisMapper.underRepairList(ordersPageableDto);
    }

    /**
     * 维修中记录-饼状图
     */
    @Override
    public PicChartDto underRepairPieChart(OrdersPageableDto ordersPageableDto) {
        if (ordersPageableDto.getPid() == null) {
            List<Long> pIds = this.hswProjectService.findPidByUser();
            if (!pIds.isEmpty()) {
                ordersPageableDto.setPIds(pIds);
            }
        }
        return this.analysisMapper.underRepairPieChart(ordersPageableDto);
    }

    /**
     * 设备-故障设备记录-光纤收发器-列表
     */
    @Override
    public List<FaultOpticalTransceiverDto> faultDevicesList(EquAnalysisPageableDto equAnalysisPageableDto) {
        return this.analysisMapper.faultDevicesList(equAnalysisPageableDto);
    }

    /**
     * 设备-故障设备记录-摄像机-列表
     */
    @Override
    public List<FaultCameraDto> faultDevicesCameraList(EquAnalysisPageableDto equAnalysisPageableDto) {
        return this.analysisMapper.faultDevicesCameraList(equAnalysisPageableDto);
    }

    /**
     * 设备-故障设备记录-设备类型-饼状图
     */
    @Override
    public PicChartDto faultDevicesTypePieChart(EquAnalysisPageableDto equAnalysisPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equAnalysisPageableDto.setPIds(pIds);
        }

        return this.analysisMapper.faultDevicesTypePieChart(equAnalysisPageableDto);
    }

    /**
     * 设备-故障设备记录-维修效率-饼状图
     */
    @Override
    public PicCharEquDto faultDevicesPieChart(EquAnalysisPageableDto equAnalysisPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equAnalysisPageableDto.setPIds(pIds);
        }

        return this.analysisMapper.faultDevicesPieChart(equAnalysisPageableDto);
    }

    /**
     *  网络运营商故障记录-列表
     */
    @Override
    public List<FaultProjectDto> netWorkFaultList(NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        return this.analysisMapper.netWorkFaultList(networkOperatorsPageableDto);
    }

    /**
     * 网络运营商故障记录-饼状图
     */
    @Override
    public PicCharEquDto netWorkFaultPieChart(NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        return this.analysisMapper.netWorkFaultPieChart(networkOperatorsPageableDto);
    }

    /**
     *  电力运营商故障记录-列表
     */
    @Override
    public List<FaultProjectDto> powerCompanyFaultList(PowerOperatorsPageableDto powerOperatorsPageableDto) {
        return this.analysisMapper.powerCompanyFaultList(powerOperatorsPageableDto);
    }

    /**
     * 电力运营商故障记录-饼状图
     */
    @Override
    public PicCharEquDto powerCompanyFaultPieChart(PowerOperatorsPageableDto powerOperatorsPageableDto) {
        return this.analysisMapper.powerCompanyFaultPieChart(powerOperatorsPageableDto);
    }

    /**
     *  派单员派单记录-列表
     */
    @Override
    public List<JobViewDto> senderOrderList(DispatcherPageableDto dispatcherPageableDto) {
        return this.analysisMapper.senderOrderList(dispatcherPageableDto);
    }

    /**
     * 派单员派单记录-饼状图
     */
    @Override
    public PicChartDto senderOrderPieChart(DispatcherPageableDto dispatcherPageableDto) {
        return this.analysisMapper.senderOrderPieChart(dispatcherPageableDto);
    }

    /**
     * app 运维单位人工修复
     */
    @Override
    public List<MuAnalysisArtificialDto> MUByArtificialRepair1(String sql) {
        return this.analysisMapper.MUByArtificialRepair1(sql);
    }
}
