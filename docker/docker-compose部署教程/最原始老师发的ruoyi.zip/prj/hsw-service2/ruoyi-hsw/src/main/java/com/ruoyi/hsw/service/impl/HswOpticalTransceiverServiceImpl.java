package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.exception.CustomException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.domain.HswOpticalTransceiver;
import com.ruoyi.hsw.dto.OpticalTransceiverViewDto;
import com.ruoyi.hsw.mapper.HswDiagnosisDeviceMapper;
import com.ruoyi.hsw.mapper.HswOpticalTransceiverMapper;
import com.ruoyi.hsw.service.IHswOpticalTransceiverService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 光纤收发器Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Service
@Transactional
public class HswOpticalTransceiverServiceImpl implements IHswOpticalTransceiverService {

    private static final Logger log = LoggerFactory.getLogger(HswOpticalTransceiver.class);

    @Autowired
    private HswOpticalTransceiverMapper hswOpticalTransceiverMapper;

    @Autowired
    private HswDiagnosisDeviceMapper hswDiagnosisDeviceMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询光纤收发器
     *
     * @param id 光纤收发器ID
     * @return 光纤收发器
     */
    @Override
    public HswOpticalTransceiver selectHswOpticalTransceiverById(Long id) {
        return hswOpticalTransceiverMapper.selectHswOpticalTransceiverById(id);
    }

    /**
     * 查询光纤收发器列表
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 光纤收发器
     */
    @Override
    public List<HswOpticalTransceiver> selectHswOpticalTransceiverList(HswOpticalTransceiver hswOpticalTransceiver) {
        return hswOpticalTransceiverMapper.selectHswOpticalTransceiverList(hswOpticalTransceiver);
    }

    /**
     * 新增光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    @Override
    public int insertHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver) {
        hswOpticalTransceiver.setCreateTime(DateUtils.getNowDate());
        return hswOpticalTransceiverMapper.insertHswOpticalTransceiver(hswOpticalTransceiver);
    }

    /**
     * 修改光纤收发器
     *
     * @param hswOpticalTransceiver 光纤收发器
     * @return 结果
     */
    @Override
    public int updateHswOpticalTransceiver(HswOpticalTransceiver hswOpticalTransceiver) {
        hswOpticalTransceiver.setUpdateTime(DateUtils.getNowDate());
        return hswOpticalTransceiverMapper.updateHswOpticalTransceiver(hswOpticalTransceiver);
    }

    /**
     * 批量删除光纤收发器
     *
     * @param ids 需要删除的光纤收发器ID
     * @return 结果
     */
    @Override
    public int deleteHswOpticalTransceiverByIds(Long[] ids) {
        return hswOpticalTransceiverMapper.deleteHswOpticalTransceiverByIds(ids);
    }

    /**
     * 删除光纤收发器信息
     *
     * @param id 光纤收发器ID
     * @return 结果
     */
    @Override
    public int deleteHswOpticalTransceiverById(Long id) {
        return hswOpticalTransceiverMapper.deleteHswOpticalTransceiverById(id);
    }

    /**
     * 根据所属诊断器ip删除光纤收发器
     *
     * @param ip
     * @return
     */
    @Override
    public int deleteHswOpticalTransceiverByIp(String ip) {
        if (StringUtils.isNotEmpty(ip)) {
            return this.hswOpticalTransceiverMapper.deleteHswOpticalTransceiverByIp(ip);
        }

        return 0;
    }

    /**
     * 校验所属诊断器ip是否唯一
     *
     * @param hswOpticalTransceiver
     * @return
     */
    @Override
    public String checkIpUnique(HswOpticalTransceiver hswOpticalTransceiver) {
        Long id = StringUtils.isNull(hswOpticalTransceiver.getId()) ? -1L : hswOpticalTransceiver.getId();
        HswOpticalTransceiver info = hswOpticalTransceiverMapper.checkIpUnique(hswOpticalTransceiver.getIp());
        if (StringUtils.isNotNull(info) && info.getId().longValue() != id.longValue()) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }

    /**
     * 根据所属诊断器ip获取光纤收发器数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    @Override
    public int selectOpticalTransceiverCountByIp(String ip) {
        return hswOpticalTransceiverMapper.selectOpticalTransceiverCountByIp(ip);
    }


    /**
     * 导入光纤收发器数据
     *
     * @param list     光纤收发器列表
     * @param operName 操作用户
     * @return
     */
    @Override
    public String importOpticalTransceiver(List<HswOpticalTransceiver> list, String operName) {
        if (StringUtils.isNull(list) || list.size() == 0) {
            throw new CustomException("导入光纤收发器数据不能为空！");
        }
        int successNum = 0;
        int failureNum = 0;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        for (HswOpticalTransceiver opticalTransceiver : list) {
            try {
                opticalTransceiver.setCreateBy(operName);
                opticalTransceiver.setInstallTime(DateUtils.getDateMr(opticalTransceiver.getInstallDate()));
                this.insertHswOpticalTransceiver(opticalTransceiver);
                successNum++;
                successMsg.append("<br/>第" + successNum + " 导入成功");
            } catch (Exception e) {
                failureNum++;
                String msg = "<br/>第" + failureNum + " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                log.error(msg, e);
            }
        }
        if (failureNum > 0) {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            throw new CustomException(failureMsg.toString());
        } else {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }

    /**
     * 校验
     *
     * @param hswOpticalTransceiver
     * @param list
     * @return
     */
    @Override
    public String checkValid(HswOpticalTransceiver hswOpticalTransceiver, List<HswOpticalTransceiver> list) {
        StringBuilder validMsg = new StringBuilder();

        if (hswOpticalTransceiver == null) {
            return "光纤收发器不能为空";
        }

        if (StringUtils.isEmpty(hswOpticalTransceiver.getIp())) {
            return "所属诊断器ip不能为空";
        }

        // 列表中该诊断器ip下光纤收发器的数量
        Long countIp = list.stream().filter(l -> hswOpticalTransceiver.getIp().equals(l.getIp())).count();
        // 诊断器最多只能添加1个光纤收发器
        if (countIp > 1) {
            return "所属诊断器ip'" + hswOpticalTransceiver.getIp() + "'下不可重复添加光纤收发器";
        }

        // 数据库中该诊断器ip下光纤收发器的数量
        int countSqlIp = this.selectOpticalTransceiverCountByIp(hswOpticalTransceiver.getIp());
        // 诊断器最多只能添加1个光纤收发器
        if (countSqlIp > 1) {
            return "所属诊断器ip'" + hswOpticalTransceiver.getIp() + "'下已添加光纤收发器";
        }

        if (StringUtils.isNull(hswOpticalTransceiver.getInstallDate())) {
            validMsg.append("<br/>" + "请输入正确格式的安装日期");
        }

        if (StringUtils.isNull(hswOpticalTransceiver.getWarranty())) {
            validMsg.append("<br/>" + "请输入正确格式的质保期");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(hswOpticalTransceiver.getIp()))) {
            validMsg.append("<br/>" + "所属诊断器ip'" + hswOpticalTransceiver.getIp() + "'不存在");
        }

        return validMsg.toString();
    }

    /**
     * 根据所属诊断器ip获取光纤收发器
     *
     * @param ip
     * @return
     */
    @Override
    public HswOpticalTransceiver selectOpticalTransceiverByIp(String ip) {
        if (StringUtils.isNotEmpty(ip)) {
            return hswOpticalTransceiverMapper.selectOpticalTransceiverByIp(ip);
        }
        return null;
    }

    @Override
    public OpticalTransceiverViewDto selectOpticalTransceiverViewById(Long id) {
        return this.hswOpticalTransceiverMapper.selectOpticalTransceiverViewById(id);
    }

    @Override
    public List<OpticalTransceiverViewDto> selectOpticalTransceiverViewList(OpticalTransceiverViewDto opticalTransceiverViewDto) {
        return this.hswOpticalTransceiverMapper.selectOpticalTransceiverViewList(opticalTransceiverViewDto);
    }

    @Override
    public OpticalTransceiverViewDto selectOpticalTransceiverViewByIpForApp(String ip) {
        if (StringUtils.isBlank(ip)) {
            return null;
        }

        OpticalTransceiverViewDto opticalTransceiverViewDto = new OpticalTransceiverViewDto();
        opticalTransceiverViewDto.setIp(ip);
        List<OpticalTransceiverViewDto> opticalTransceiverViewDtos = this.hswOpticalTransceiverMapper.selectOpticalTransceiverViewList(opticalTransceiverViewDto);
        return opticalTransceiverViewDtos.size() > 0 ? opticalTransceiverViewDtos.get(0) : null;
    }
}
