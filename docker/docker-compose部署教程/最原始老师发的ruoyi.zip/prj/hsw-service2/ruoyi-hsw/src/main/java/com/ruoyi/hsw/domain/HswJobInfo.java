package com.ruoyi.hsw.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.util.Date;
import java.util.List;

/**
 * 工单对象 hsw_job_info
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public class HswJobInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Long id;

    /** 工单编号 */
    @Excel(name = "工单编号")
    private String jobNo;

    /** 故障id */
    private Long faultId;

    /** 故障编号 */
    @Excel(name = "故障编号")
    private String faultNo;

    /** 派单时间 */
    private Long sendTime;

    /** 派单时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "派单时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date sendDate;

    /** 派单人id */
    private Long sendUid;

    /** 派单人名称 */
    @Excel(name = "派单人")
    private String sendName;

    /** 接单人id */
    private Long receiverId;

    /** 接单人名称 */
    @Excel(name = "接单人")
    private String receiverName;

    /** 接单时间 */
    private Long receiverTime;

    /** 接单时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "接单时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date receiverDate;

    /** 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起） */
    private Integer status;

    /** 工单状态-状态名称*/
    @Excel(name = "工单状态")
    private String statusText;

    /** 修复时间 */
    private Long repairTime;

    /** 修复时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修复时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date repairDate;

    /** 维修记录 */
    @Excel(name = "维修记录")
    private String repairRecord;

    /** 归档状态（0=活动工单；1=历史工单；） */
    private Integer flagStatus;

    /** 挂起时间 */
    private Long hangUpTime;

    /** 挂起时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "挂起时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date hangUpDate;

    /** 挂起原因 */
    @Excel(name = "挂起原因")
    private String hangUpReason;

    /** 撤回挂起时间 */
    private Long resumeTime;

    /** 撤回挂起时间-时间格式 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "撤回挂起时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date resumeDate;

    /** 操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派 */
    private Integer handleStatus;

    /** 操作状态-状态名称 */
    @Excel(name = "操作状态")
    private String handleStatusText;

    /** 删除标志（0代表存在 2代表删除） */
    private String delFlag;

    /** 项目档案对象 */
    @Excels({
            @Excel(name = "项目名称", targetAttr = "title", type = Excel.Type.EXPORT)
    })
    private HswProject project;

    /** 运维单位对象 */
    @Excels({
            @Excel(name = "运维单位名称", targetAttr = "name", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceUnits maintenanceUnits;

    /** 运维队对象 */
    @Excels({
            @Excel(name = "运维队名称", targetAttr = "name", type = Excel.Type.EXPORT)
    })
    private HswMaintenanceTeam maintenanceTeam;

    /** 工单日志对象 */
    private List<HswJobLog> jobLogs;

    /** 故障对象 */
    private HswFaultInfo faultInfo;

    /** 分工对象 */
    private HswDivideWork divideWork;

    /** 原因 */
    private String rejection;

    /** 发生时间-开始时间 */
    private Long takeStartTime;

    /** 发生时间-结束时间 */
    private Long takeEndTime;

    /** 省 */
    private Integer province;

    /** 市 */
    private Integer city;

    /** 县区 */
    private Integer district;

    /** ip */
    private String ip;

    /** 故障类型 */
    private Integer type;

    /** 项目id */
    private Long pid;

    /** 维修时长 */
    private Double repairedTime;

    /** 建设单位id */
    private Long cuId;

    /** 运维单位 */
    private Long muId;

    /** 维修队id */
    private Long mtId;

    public HswJobInfo() {
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }
    public void setJobNo(String jobNo)
    {
        this.jobNo = jobNo;
    }

    public String getJobNo()
    {
        return jobNo;
    }
    public void setFaultId(Long faultId)
    {
        this.faultId = faultId;
    }

    public Long getFaultId()
    {
        return faultId;
    }
    public void setFaultNo(String faultNo)
    {
        this.faultNo = faultNo;
    }

    public String getFaultNo()
    {
        return faultNo;
    }
    public void setSendTime(Long sendTime)
    {
        this.sendTime = sendTime;
    }

    public Long getSendTime()
    {
        return sendTime;
    }
    public void setSendUid(Long sendUid)
    {
        this.sendUid = sendUid;
    }

    public Long getSendUid()
    {
        return sendUid;
    }
    public void setReceiverId(Long receiverId)
    {
        this.receiverId = receiverId;
    }

    public Long getReceiverId()
    {
        return receiverId;
    }
    public void setReceiverTime(Long receiverTime)
    {
        this.receiverTime = receiverTime;
    }

    public Long getReceiverTime()
    {
        return receiverTime;
    }
    public void setStatus(Integer status)
    {
        this.status = status;
    }

    public Integer getStatus()
    {
        return status;
    }
    public void setRepairTime(Long repairTime)
    {
        this.repairTime = repairTime;
    }

    public Long getRepairTime()
    {
        return repairTime;
    }
    public void setRepairRecord(String repairRecord)
    {
        this.repairRecord = repairRecord;
    }

    public String getRepairRecord()
    {
        return repairRecord;
    }
    public void setFlagStatus(Integer flagStatus)
    {
        this.flagStatus = flagStatus;
    }

    public Integer getFlagStatus()
    {
        return flagStatus;
    }
    public void setHangUpTime(Long hangUpTime)
    {
        this.hangUpTime = hangUpTime;
    }

    public Long getHangUpTime()
    {
        return hangUpTime;
    }
    public void setHangUpReason(String hangUpReason)
    {
        this.hangUpReason = hangUpReason;
    }

    public String getHangUpReason()
    {
        return hangUpReason;
    }
    public void setResumeTime(Long resumeTime)
    {
        this.resumeTime = resumeTime;
    }

    public Long getResumeTime()
    {
        return resumeTime;
    }
    public void setHandleStatus(Integer handleStatus)
    {
        this.handleStatus = handleStatus;
    }

    public Integer getHandleStatus()
    {
        return handleStatus;
    }
    public void setDelFlag(String delFlag)
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag()
    {
        return delFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("jobNo", getJobNo())
            .append("faultId", getFaultId())
            .append("faultNo", getFaultNo())
            .append("sendTime", getSendTime())
            .append("sendUid", getSendUid())
            .append("receiverId", getReceiverId())
            .append("receiverTime", getReceiverTime())
            .append("status", getStatus())
            .append("repairTime", getRepairTime())
            .append("repairRecord", getRepairRecord())
            .append("remark", getRemark())
            .append("flagStatus", getFlagStatus())
            .append("hangUpTime", getHangUpTime())
            .append("hangUpReason", getHangUpReason())
            .append("resumeTime", getResumeTime())
            .append("handleStatus", getHandleStatus())
            .append("delFlag", getDelFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }

    public HswProject getProject() {
        return project;
    }

    public void setProject(HswProject project) {
        this.project = project;
    }

    public HswMaintenanceUnits getMaintenanceUnits() {
        return maintenanceUnits;
    }

    public void setMaintenanceUnits(HswMaintenanceUnits maintenanceUnits) {
        this.maintenanceUnits = maintenanceUnits;
    }

    public HswMaintenanceTeam getMaintenanceTeam() {
        return maintenanceTeam;
    }

    public void setMaintenanceTeam(HswMaintenanceTeam maintenanceTeam) {
        this.maintenanceTeam = maintenanceTeam;
    }

    public String getRejection() {
        return rejection;
    }

    public void setRejection(String rejection) {
        this.rejection = rejection;
    }

    public Long getTakeStartTime() {
        return takeStartTime;
    }

    public void setTakeStartTime(Long takeStartTime) {
        this.takeStartTime = takeStartTime;
    }

    public Long getTakeEndTime() {
        return takeEndTime;
    }

    public void setTakeEndTime(Long takeEndTime) {
        this.takeEndTime = takeEndTime;
    }

    public Integer getProvince() {
        return province;
    }

    public void setProvince(Integer province) {
        this.province = province;
    }

    public Integer getCity() {
        return city;
    }

    public void setCity(Integer city) {
        this.city = city;
    }

    public Integer getDistrict() {
        return district;
    }

    public void setDistrict(Integer district) {
        this.district = district;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public List<HswJobLog> getJobLogs() {
        return jobLogs;
    }

    public void setJobLogs(List<HswJobLog> jobLogs) {
        this.jobLogs = jobLogs;
    }

    public HswFaultInfo getFaultInfo() {
        return faultInfo;
    }

    public void setFaultInfo(HswFaultInfo faultInfo) {
        this.faultInfo = faultInfo;
    }

    public HswDivideWork getDivideWork() {
        return divideWork;
    }

    public void setDivideWork(HswDivideWork divideWork) {
        this.divideWork = divideWork;
    }

    public Double getRepairedTime() {
        return repairedTime;
    }

    public void setRepairedTime(Double repairedTime) {
        this.repairedTime = repairedTime;
    }

    public Long getCuId() {
        return cuId;
    }

    public void setCuId(Long cuId) {
        this.cuId = cuId;
    }

    public Long getMuId() {
        return muId;
    }

    public void setMuId(Long muId) {
        this.muId = muId;
    }

    public Long getMtId() {
        return mtId;
    }

    public void setMtId(Long mtId) {
        this.mtId = mtId;
    }

    public String getSendName() {
        return sendName;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }

    public Date getReceiverDate() {
        return receiverDate;
    }

    public void setReceiverDate(Date receiverDate) {
        this.receiverDate = receiverDate;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public Date getRepairDate() {
        return repairDate;
    }

    public void setRepairDate(Date repairDate) {
        this.repairDate = repairDate;
    }

    public Date getHangUpDate() {
        return hangUpDate;
    }

    public void setHangUpDate(Date hangUpDate) {
        this.hangUpDate = hangUpDate;
    }

    public Date getResumeDate() {
        return resumeDate;
    }

    public void setResumeDate(Date resumeDate) {
        this.resumeDate = resumeDate;
    }

    public String getHandleStatusText() {
        return handleStatusText;
    }

    public void setHandleStatusText(String handleStatusText) {
        this.handleStatusText = handleStatusText;
    }
}
