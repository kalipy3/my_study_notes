package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 描述:
 * 派单员分析
 *
 * @author xiongxiangpeng
 * @create 2020-11-16 15:57
 */
@Data
public class DispatcherDto implements Serializable {

    // 姓名
    private String realName;

    // 用户id
    private Long userId;

    // 总派单时间
    private Long sendTimeCount=0L;

    // 延期数
    private Integer sendTimeout=0;

    // 派单数
    private Integer totalSendOrder=0;

    // 有效派单数
    private Integer sendOk=0;

    // 平均派单时长(小时)
    private Double sendAvg=0D;

    // 派单效率
    private Double sendRate=0D;
}
