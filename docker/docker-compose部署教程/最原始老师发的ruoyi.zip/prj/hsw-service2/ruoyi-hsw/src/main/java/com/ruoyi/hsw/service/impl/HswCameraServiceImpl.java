package com.ruoyi.hsw.service.impl;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.exception.CustomException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.dto.CameraViewDto;
import com.ruoyi.hsw.mapper.HswCameraMapper;
import com.ruoyi.hsw.mapper.HswDiagnosisDeviceMapper;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 摄像机Service业务层处理
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Service
@Transactional
public class HswCameraServiceImpl implements IHswCameraService {

    private static final Logger log = LoggerFactory.getLogger(HswCamera.class);

    @Autowired
    private HswCameraMapper hswCameraMapper;

    @Autowired
    private HswDiagnosisDeviceMapper hswDiagnosisDeviceMapper;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询摄像机
     *
     * @param id 摄像机ID
     * @return 摄像机
     */
    @Override
    public HswCamera selectHswCameraById(Long id) {
        return hswCameraMapper.selectHswCameraById(id);
    }

    /**
     * 查询摄像机列表
     *
     * @param hswCamera 摄像机
     * @return 摄像机
     */
    @Override
    public List<HswCamera> selectHswCameraList(HswCamera hswCamera) {
        return hswCameraMapper.selectHswCameraList(hswCamera);
    }

    /**
     * 新增摄像机
     *
     * @param hswCamera 摄像机
     * @return 结果
     */
    @Override
    public int insertHswCamera(HswCamera hswCamera) {

        hswCamera.setCreateTime(DateUtils.getNowDate());
        int row = hswCameraMapper.insertHswCamera(hswCamera);

        // 新增摄像机成功，修改诊断器摄像机数量
        return updateCameraCount(hswCamera, row);
    }

    /**
     * 修改摄像机
     *
     * @param hswCamera 摄像机
     * @return 结果
     */
    @Override
    public int updateHswCamera(HswCamera hswCamera) {
        hswCamera.setUpdateTime(DateUtils.getNowDate());
        return hswCameraMapper.updateHswCamera(hswCamera);
    }

    /**
     * 批量删除摄像机
     *
     * @param ids 需要删除的摄像机ID
     * @return 结果
     */
    @Override
    public int deleteHswCameraByIds(Long[] ids) {
        int i = 0;
        for (Long id : ids) {
            i = i + 1;
            int row = deleteHswCameraById(id);

            if (row <= 0) {
                throw new CustomException(String.format("第%1$s项不存在", i));
            }
        }

        return 1;
    }

    /**
     * 删除摄像机信息
     *
     * @param id 摄像机ID
     * @return 结果
     */
    @Override
    public int deleteHswCameraById(Long id) {
        HswCamera hswCamera = hswCameraMapper.selectHswCameraById(id);

        int row = hswCameraMapper.deleteHswCameraById(id);

        // 删除摄像头成功，修改诊断器摄像头数量
        return updateCameraCount(hswCamera, row);
    }

    /**
     * 通过所属诊断器ip删除摄像机
     *
     * @param ip
     * @return
     */
    @Override
    public int deleteHswCameraByIp(String ip) {
        if(StringUtils.isNotEmpty(ip)){
            return this.hswCameraMapper.deleteHswCameraByIp(ip);
        }

        return 0;
    }

    /**
     * 根据所属诊断器ip获取摄像机数量
     *
     * @param ip 所属诊断器ip
     * @return
     */
    @Override
    public int selectCameraCountByIp(String ip) {
        return hswCameraMapper.selectCameraCountByIp(ip);
    }

    /**
     * 校验自身IP是否唯一
     *
     * @param hswCamera
     * @return
     */
    @Override
    public String checkSelfIpUnique(HswCamera hswCamera) {
        Long id = StringUtils.isNull(hswCamera.getId()) ? -1L : hswCamera.getId();
        HswCamera info = hswCameraMapper.checkSelfIpUnique(hswCamera.getSelfIp());
        if (StringUtils.isNotNull(info) && info.getId().longValue() != id.longValue()) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }

    /**
     * 根据诊断器ip校验端口号是否唯一
     *
     * @param hswCamera
     * @return
     */
    @Override
    public String checkPortUniqueByIp(HswCamera hswCamera) {
        Long id = StringUtils.isNull(hswCamera.getId()) ? -1L : hswCamera.getId();
        HswCamera info = hswCameraMapper.checkPortUniqueByIp(hswCamera.getIp(), hswCamera.getPort());
        if (StringUtils.isNotNull(info) && info.getId().longValue() != id.longValue()) {
            return UserConstants.NOT_UNIQUE;
        }
        return UserConstants.UNIQUE;
    }

    /**
     * 修改诊断器摄像头数量
     *
     * @param hswCamera
     * @param row
     * @return
     */
    private int updateCameraCount(HswCamera hswCamera, int row) {
        if (row > 0) {
            int count = hswCameraMapper.selectCameraCountByIp(hswCamera.getIp());

            HswDiagnosisDevice hswDiagnosisDevice = new HswDiagnosisDevice();
            hswDiagnosisDevice.setIp(hswCamera.getIp());
            hswDiagnosisDevice.setCameraCount(count); // 摄像头数量

            hswDiagnosisDeviceMapper.updateHswDiagnosisDeviceByIp(hswDiagnosisDevice);
        }

        return row;
    }

    /**
     * 导入摄像机数据
     *
     * @param list     摄像机列表
     * @param operName 操作用户
     * @return
     */
    @Override
    public String importCamera(List<HswCamera> list, String operName) {
        if (StringUtils.isNull(list) || list.size() == 0) {
            throw new CustomException("导入摄像机数据不能为空！");
        }
        int successNum = 0;
        int failureNum = 0;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        for (HswCamera camera : list) {
            try {
                camera.setCreateBy(operName);
                camera.setInstallTime(DateUtils.getDateMr(camera.getInstallDate()));
                this.insertHswCamera(camera);
                successNum++;
                successMsg.append("<br/>第" + successNum + " 导入成功");
            } catch (Exception e) {
                failureNum++;
                String msg = "<br/>第" + failureNum + " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                log.error(msg, e);
            }
        }
        if (failureNum > 0) {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            throw new CustomException(failureMsg.toString());
        } else {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }

    /**
     * 校验
     *
     * @param hswCamera
     * @param list
     * @return
     */
    @Override
    public String checkValid(HswCamera hswCamera, List<HswCamera> list) {
        StringBuilder validMsg = new StringBuilder();

        if (hswCamera == null) {
            return "摄像机不能为空";
        }

        if (StringUtils.isEmpty(hswCamera.getIp())) {
            return "所属诊断器ip不能为空";
        }

        // 列表中该诊断器ip下摄像机的数量
        Long countIp = list.stream().filter(l -> hswCamera.getIp().equals(l.getIp())).count();

        // 数据库中该诊断器ip下摄像机的数量
        int countSqlIp = this.selectCameraCountByIp(hswCamera.getIp());

        // 诊断器最多只能添加4个摄像头
        if ((countIp + countSqlIp) > 4) {
            return "所属诊断器ip'" + hswCamera.getIp() + "'下已添加'" + countSqlIp + "'个摄像头，最多可新增'" + (4 - countSqlIp) + "'个,excel中有'" + countIp + "'个";
        }

        if (StringUtils.isEmpty(hswCamera.getSelfIp())) {
            return "自身ip不能为空";
        }

        // 判断excel中自身ip是否重复
        long countSelfIp = list.stream().filter(l -> hswCamera.getSelfIp().equals(l.getSelfIp())).count();

        if (countSelfIp > 1) {
            return "excel中自身ip不能重复";
        }

        if (StringUtils.isNull(hswCamera.getPort())) {
            return "端口号不能为空";
        }

        // 判断excel中端口号是否重复
        long countPort = list.stream().filter(l -> hswCamera.getPort().equals(l.getPort()) && hswCamera.getIp().equals(l.getIp())).count();

        if (countPort > 1) {
            return "excel中所属诊断器ip'" + hswCamera.getIp() + "'下端口号不能重复";
        }

        if (StringUtils.isEmpty(hswCamera.getPosition())) {
            validMsg.append("<br/>" + "方位不能为空");
        }

        if (StringUtils.isNull(hswCamera.getDeviceType())) {
            validMsg.append("<br/>" + "类型不能为空");
        }

        if (StringUtils.isEmpty(hswCamera.getLongitude())) {
            validMsg.append("<br/>" + "经度不能为空");
        }

        if (StringUtils.isEmpty(hswCamera.getLatitude())) {
            validMsg.append("<br/>" + "纬度不能为空");
        }

        if (StringUtils.isNull(hswCamera.getInstallDate())) {
            validMsg.append("<br/>" + "请输入正确格式的安装日期");
        }

        if (StringUtils.isNull(hswCamera.getWarranty())) {
            validMsg.append("<br/>" + "请输入正确格式的质保期");
        }

        if (UserConstants.NOT_UNIQUE.equals(this.checkSelfIpUnique(hswCamera))) {
            validMsg.append("<br/>" + "自身IP'" + hswCamera.getSelfIp() + "'已经存在");
        }

        if (UserConstants.NOT_UNIQUE.equals(this.checkPortUniqueByIp(hswCamera))) {
            validMsg.append("<br/>" + "端口'" + hswCamera.getPort() + "'已经存在");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(hswCamera.getIp()))) {
            validMsg.append("<br/>" + "所属诊断器ip'" + hswCamera.getIp() + "'不存在");
        }

        HswDiagnosisDevice hswDiagnosisDevice = hswDiagnosisDeviceMapper.selectHswDiagnosisDeviceByIp(hswCamera.getIp());

        // 诊断器上行端口为电口1，代表诊断器已占用端口1，摄像机不允许端口为1
        if (hswDiagnosisDevice.getUplinkPort().equals(3)) {
            if (hswCamera.getPort().equals(1)) {
                validMsg.append("<br/>" + "端口'" + hswCamera.getPort() + "'已被诊断器占用");
            }
        }

        return validMsg.toString();
    }

    /**
     * 根据所属诊断器ip和端口号查询摄像机
     *
     * @param ip
     * @param port
     * @return
     */
    @Override
    public HswCamera selectHswCameraByIpAndPort(String ip, String port) {
        if (StringUtils.isNotEmpty(ip) && StringUtils.isNotEmpty(port)) {
            return hswCameraMapper.selectHswCameraByIpAndPort(ip, port);
        }
        return null;
    }

    @Override
    public CameraViewDto selectCameraViewById(Long id) {
        return this.hswCameraMapper.selectCameraViewById(id);
    }

    @Override
    public List<CameraViewDto> selectCameraViewList(CameraViewDto cameraView) {
        return this.hswCameraMapper.selectCameraViewList(cameraView);
    }

    @Override
    public CameraViewDto selectCameraViewByIpAndPortForApp(String ip, Integer port) {
        if (StringUtils.isBlank(ip) && port == null) {
            return null;
        }

        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setIp(ip);
        cameraViewDto.setPort(port);
        List<CameraViewDto> cameraViewDtos = this.hswCameraMapper.selectCameraViewList(cameraViewDto);
        return cameraViewDtos.size() > 0 ? cameraViewDtos.get(0) : null;
    }

    @Override
    public List<CameraViewDto> selectCameraViewListByIpAndPortForApp(String ip, Integer port) {
        if (StringUtils.isBlank(ip) && port == null) {
            return null;
        }

        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setIp(ip);
        cameraViewDto.setPort(port);
        List<CameraViewDto> cameraViewDtos = this.hswCameraMapper.selectCameraViewList(cameraViewDto);
        return cameraViewDtos;
    }

    @Override
    public int updateHswCameraBySelfIp(String selfIp, String longitude, String latitude) {
        return this.hswCameraMapper.updateHswCameraBySelfIp(selfIp, longitude, latitude);
    }

    @Override
    public int updateHswCameraByIp(String ip, String longitude, String latitude) {
        return this.hswCameraMapper.updateHswCameraByIp(ip ,longitude, latitude);
    }

    /**
     * 根据所属诊断器ip查询摄像机列表
     *
     * @param ip
     * @return
     */
    @Override
    public List<HswCamera> selectCameraListByIp(String ip) {
        if(StringUtils.isEmpty(ip)){
            return null;
        }

        return this.hswCameraMapper.selectCameraListByIp(ip);
    }
}
