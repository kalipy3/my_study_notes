package com.ruoyi.hsw.service;

import com.ruoyi.common.core.domain.AjaxResult;

import java.util.Map;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/19 0019
 */
public interface ISmsService {
    /**
     * 发送短信
     *
     * @param cuId          建设单位id
     * @param tel           接受者手机号
     * @param templateCode  短信模版编号
     * @param templateParam 短信模版变量数组
     * @param args          其他参数数组 ["title"=>'',"send_name"=>'',"receiver_id"=>0,"receiver_name"=>'',"job_no"=>'','tpl_key'=>'TPL_MSG_PD'],该参数必填,tpl_key为本地存储大于短信模版，不用再去阿里那边查询模版生成短信发送内容
     */
    AjaxResult sendSMS(Long cuId, String tel, String templateCode, Map<String, Object> templateParam, Map<String, Object> args);
}
