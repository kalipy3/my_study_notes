package com.ruoyi.hsw.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 描述:
 * 维修队长分析查询参数
 *
 * @author xiongxiangpeng
 * @create 2020-11-17 10:36
 */
@Data
public class MtlAnalysisPageableDto implements Serializable {

    // 分析类型
    private Integer analysisType;

    // 用户id
    private Long userId;

    // 开始日期
    private Long startTime;

    // 结束时间
    private Long endTime;

    // 项目id
    private Long pid;

    // 运维单位id
    private Long muId;

    // 维修队id
    private Long mtId;

    // 距离范围
    private String timeoutLevel;

    // 项目id集合
    private List<Long> pIds;

    // 用户id集合
    private List<Long> userIds;
}
