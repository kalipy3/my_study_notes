package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswMaintenanceUnits;

import java.util.List;

/**
 * 运维单位Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswMaintenanceUnitsService {
    /**
     * 查询运维单位
     *
     * @param id 运维单位ID
     * @return 运维单位
     */
    public HswMaintenanceUnits selectHswMaintenanceUnitsById(Long id);

    /**
     * 查询运维单位列表
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 运维单位集合
     */
    public List<HswMaintenanceUnits> selectHswMaintenanceUnitsList(HswMaintenanceUnits hswMaintenanceUnits);

    /**
     * 新增运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    public int insertHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits);

    /**
     * 修改运维单位
     *
     * @param hswMaintenanceUnits 运维单位
     * @return 结果
     */
    public int updateHswMaintenanceUnits(HswMaintenanceUnits hswMaintenanceUnits);

    /**
     * 批量删除运维单位
     *
     * @param ids 需要删除的运维单位ID
     * @return 结果
     */
    public int deleteHswMaintenanceUnitsByIds(Long[] ids);

    /**
     * 删除运维单位信息
     *
     * @param id 运维单位ID
     * @return 结果
     */
    public int deleteHswMaintenanceUnitsById(Long id);

    /**
     * 根据运维单位id数组获取运维单位
     *
     * @param ids
     * @return
     */
    public List<HswMaintenanceUnits> treeList(Long[] ids);

    /**
     * 判断运维单位是否存在
     */
    public boolean existCount();
}
