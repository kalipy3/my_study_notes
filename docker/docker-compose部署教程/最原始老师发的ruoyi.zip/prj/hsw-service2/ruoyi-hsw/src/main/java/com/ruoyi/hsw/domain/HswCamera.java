package com.ruoyi.hsw.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excels;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * 摄像机对象 hsw_camera
 *
 * @author ruoyi
 * @date 2020-11-06
 */
public class HswCamera extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 序列号
     */
    @Excel(name = "序列号", sort = 3)
    private String sn;

    /**
     * 方位
     */
    @Excel(name = "方位", sort = 1)
    private String position;

    /**
     * 生产厂商
     */
    @Excel(name = "生产厂商", sort = 11, dictType = "hsw_camera_manufacturer")
    private String manufacturer;

    /**
     * 经度
     */
    @Excel(name = "经度", sort = 7)
    private String longitude;

    /**
     * 纬度
     */
    @Excel(name = "纬度", sort = 8)
    private String latitude;

    /**
     * 型号
     */
    @Excel(name = "型号", sort = 4)
    private String model;

    /**
     * 所属诊断器ip
     */
    @Excel(name = "所属诊断器ip", sort = 5)
    private String ip;

    /**
     * 安装时间Long类型
     */
    private Long installTime;

    /**
     * 类型
     */
    @Excel(name = "类型", sort = 2, dictType = "hsw_camera_type")
    private String deviceType;

    /**
     * 端口号
     */
    @Excel(name = "端口号", sort = 9, dictType = "hsw_camera_port")
    private Integer port;

    /**
     * 自身IP
     */
    @Excel(name = "自身IP", sort = 6)
    private String selfIp;

    /**
     * 质保期(年)
     */
    @Excel(name = "质保期(年)", sort = 12)
    private Integer warranty;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    private String delFlag;

    /**
     * 安装时间Date类型
     */
    @Excel(name = "安装时间", width = 30, dateFormat = "yyyy-MM-dd", sort = 10, prompt = "时间格式为yyyy/MM/dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date installDate;

    /**
     * 诊断器对象
     */
    @Excels({
            @Excel(name = "地址", targetAttr = "address", type = Excel.Type.EXPORT),
            @Excel(name = "所属项目", targetAttr = "projectTitle", type = Excel.Type.EXPORT),
            @Excel(name = "所属分工区域", targetAttr = "workAddress", type = Excel.Type.EXPORT)
    })
    private HswDiagnosisDevice hswDiagnosisDevice;

    /**
     * 项目id
     */
    private Long projectId;

    /**
     * 摄像机总数
     */
    private Integer cameraCountAll;

    // 项目id列表（用于查询使用）
    private List<Long> pids;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getSn() {
        return sn;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @NotBlank(message = "方位不能为空")
    public String getPosition() {
        return position;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @NotBlank(message = "经度不能为空")
    public String getLongitude() {
        return longitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @NotBlank(message = "纬度不能为空")
    public String getLatitude() {
        return latitude;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @NotBlank(message = "所属诊断器ip不能为空")
    public String getIp() {
        return ip;
    }

    public void setInstallTime(Long installTime) {
        this.installTime = installTime;
    }

    public Long getInstallTime() {
        return installTime;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    @NotBlank(message = "类型不能为空")
    public String getDeviceType() {
        return deviceType;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @NotNull(message = "端口号不能为空")
    public Integer getPort() {
        return port;
    }

    public void setSelfIp(String selfIp) {
        this.selfIp = selfIp;
    }

    @NotBlank(message = "自身ip不能为空")
    public String getSelfIp() {
        return selfIp;
    }

    public void setWarranty(Integer warranty) {
        this.warranty = warranty;
    }

    @NotNull(message = "质保期不能为空")
    public Integer getWarranty() {
        return warranty;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    @NotNull(message = "安装日期不能为空")
    public Date getInstallDate() {
        return installDate;
    }

    public void setHswDiagnosisDevice(HswDiagnosisDevice hswDiagnosisDevice) {
        this.hswDiagnosisDevice = hswDiagnosisDevice;
    }

    public HswDiagnosisDevice getHswDiagnosisDevice() {
        return hswDiagnosisDevice;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public Integer getCameraCountAll() {
        return cameraCountAll;
    }

    public void setCameraCountAll(Integer cameraCountAll) {
        this.cameraCountAll = cameraCountAll;
    }

    public List<Long> getPids() {
        return pids;
    }

    public void setPids(List<Long> pids) {
        this.pids = pids;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("id", getId())
                .append("sn", getSn())
                .append("position", getPosition())
                .append("manufacturer", getManufacturer())
                .append("longitude", getLongitude())
                .append("latitude", getLatitude())
                .append("model", getModel())
                .append("ip", getIp())
                .append("installTime", getInstallTime())
                .append("deviceType", getDeviceType())
                .append("port", getPort())
                .append("selfIp", getSelfIp())
                .append("warranty", getWarranty())
                .append("delFlag", getDelFlag())
                .append("installDate", getInstallDate())
                .append("hswDiagnosisDevice", getHswDiagnosisDevice())
                .append("projectId", getProjectId())
                .append("cameraCountAll", getCameraCountAll())
                .append("pids", getPids())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}
