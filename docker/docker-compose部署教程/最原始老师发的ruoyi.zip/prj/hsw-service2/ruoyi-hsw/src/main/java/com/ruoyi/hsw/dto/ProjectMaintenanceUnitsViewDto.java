package com.ruoyi.hsw.dto;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/13 0013
 */
@Data
public class ProjectMaintenanceUnitsViewDto implements Serializable {
    /** 项目id */
    @Excel(name = "项目id")
    private Long pid;

    /** 运维单位id */
    @Excel(name = "运维单位id")
    private Long muId;

    /** 名称 */
    @Excel(name = "名称")
    private String title;

    /** 名称 */
    @Excel(name = "名称")
    private String name;
}
