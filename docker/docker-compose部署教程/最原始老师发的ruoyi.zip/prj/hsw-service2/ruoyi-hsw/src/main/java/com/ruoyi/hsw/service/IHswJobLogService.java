package com.ruoyi.hsw.service;

import com.ruoyi.hsw.domain.HswJobLog;

import java.util.List;

/**
 * 工单日志Service接口
 *
 * @author ruoyi
 * @date 2020-11-04
 */
public interface IHswJobLogService {
    /**
     * 查询工单日志
     *
     * @param id 工单日志ID
     * @return 工单日志
     */
    public HswJobLog selectHswJobLogById(Long id);

    /**
     * 查询工单日志列表
     *
     * @param hswJobLog 工单日志
     * @return 工单日志集合
     */
    public List<HswJobLog> selectHswJobLogList(HswJobLog hswJobLog);

    /**
     * 新增工单日志
     *
     * @param hswJobLog 工单日志
     * @return 结果
     */
    public int insertHswJobLog(HswJobLog hswJobLog);

    /**
     * 修改工单日志
     *
     * @param hswJobLog 工单日志
     * @return 结果
     */
    public int updateHswJobLog(HswJobLog hswJobLog);

    /**
     * 批量删除工单日志
     *
     * @param ids 需要删除的工单日志ID
     * @return 结果
     */
    public int deleteHswJobLogByIds(Long[] ids);

    /**
     * 删除工单日志信息
     *
     * @param id 工单日志ID
     * @return 结果
     */
    public int deleteHswJobLogById(Long id);
}
