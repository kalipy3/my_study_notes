package com.ruoyi.hsw.commonEnum;
/**
 * 描述:
 * 工单状态
 *
 * @author xiongxiangpeng
 * @create 2020-12-17 11:49
 */
public enum JobStatusEnum {

    WPD(0, "未派单"),
    DJD(1, "待接单"),
    WXZ(2, "维修中"),
    YXF(3, "已修复"),
    YGQ(4, "已挂起"),
    ZDHF(5, "自动恢复"),
    YCD(6, "已撤单");

    private Integer value;
    private String label;

    JobStatusEnum(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getLabel() {
        return this.label;
    }

    public static JobStatusEnum valueOf(int value) {
        switch (value) {
            /**
             * 未派单
             */
            case 0:
                return WPD;
            /**
             * 待接单
             */
            case 1:
                return DJD;
            /**
             * 维修中
             */
            case 2:
                return WXZ;
            /**
             * 已修复
             */
            case 3:
                return YXF;
            /**
             * 已挂起
             */
            case 4:
                return YGQ;
            /**
             * 自动恢复
             */
            case 5:
                return ZDHF;
            /**
             * 已撤单
             */
            case 6:
                return YCD;
            default:
                return null;
        }
    }
}
