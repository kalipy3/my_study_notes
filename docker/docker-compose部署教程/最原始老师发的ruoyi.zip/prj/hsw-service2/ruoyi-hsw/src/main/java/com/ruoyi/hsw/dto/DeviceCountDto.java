package com.ruoyi.hsw.dto;

import com.ruoyi.common.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备统计信息
 *
 * @author zyj
 * @date 2020/11/12 20:49
 */
@Data
public class DeviceCountDto implements Serializable {

    // 项目id
    private Long pid;

    // 建设单位id
    private Long cuId;

    // 项目名称
    @Excel(name = "项目名称", sort = 1, type = Excel.Type.EXPORT)
    private String projectTitle;

    // 诊断器数量
    @Excel(name = "诊断器", sort = 2, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer diagnosisCount;

    // 摄像机数量
    @Excel(name = "摄像机", sort = 3, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer cameraCount;

    // 光纤收发器数量
    @Excel(name = "光纤收发器", sort = 4, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer opticalTransceiverCount;

    // 其他设备数量
    @Excel(name = "其他设备", sort = 5, type = Excel.Type.EXPORT, isStatistics = true)
    private Integer otherDeviceCount;

    // 诊断器总数
    private Integer diagnosisAllCount;

    // 摄像机总数
    private Integer cameraAllCount;

    // 光纤收发器总数
    private Integer opticalAllCount;

    // 其他设备总数
    private Integer otherAllCount;

}
