package com.ruoyi.framework.interceptor;

import com.alibaba.fastjson.JSON;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.AesUtils;
import com.ruoyi.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * 物联网平台调用签名拦截器
 *
 * @author youyong
 * @date 2020/11/16 0016
 */
@Component
@Slf4j
public class AppSignInterceptor implements HandlerInterceptor {
    private static Map<String, Object> config = new HashMap<>();

    public static class Config {
        public static String[] apptypes = new String[]{"ios", "android", "local"};  // APP类型
        public static Integer app_sign_time = 90;             // sign失效时间" +
        public static Integer app_sign_cache_time = 20; //sign 缓存失效时间
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String sign = request.getHeader("sign");
        String appType = request.getHeader("app-type");
        String did = request.getHeader("did");

        // 验证sign是否存在
        if (StringUtils.isBlank(sign)) {
            this.write(response, JSON.toJSONString(AjaxResult.error(400, "sign不存在")));
            return false;
        }

        //验证app-type类型是否合法
        if (StringUtils.isBlank(appType) || !ArrayUtils.contains(Config.apptypes, appType)) {
            this.write(response, JSON.toJSONString(AjaxResult.error(400, "app-type不合法")));
            return false;
        }

        //验证sign是否正确
        if (StringUtils.isBlank(did) || !this.checkSignPass(sign, did)) {
            this.write(response, JSON.toJSONString(AjaxResult.error(401, "授权码sign失败")));
            return false;
        }

        return true;
    }

    private boolean checkSignPass(String sign, String did) {
        String test = AesUtils.encrypt("did=1&app-type=local", "");

        try {
            //解密签名
            String decrypt = AesUtils.decrypt(sign, "");

            //解析加密参数
            if (StringUtils.isBlank(decrypt)) {
                return false;
            }

            String[] split = decrypt.split("&");
            //判断加密参数是否合法
            for (String s : split) {
                if (("did=" + did).equals(s)) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return false;
    }

    private void write(HttpServletResponse response, String value) throws IOException {
        //重置response
        response.reset();
        //设置编码格式
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter pw = response.getWriter();
        pw.write(value);
        pw.flush();
        pw.close();
    }
}
