package com.ruoyi.system.service;

import java.util.List;

import com.ruoyi.system.domain.SysRegion;
import com.ruoyi.system.domain.vo.RegionDto;

/**
 * 中国省市区数据库Service接口
 *
 * @author ruoyi
 * @date 2020-12-04
 */
public interface ISysRegionService {
    /**
     * 查询中国省市区数据库
     *
     * @param id 中国省市区数据库ID
     * @return 中国省市区数据库
     */
    public SysRegion selectSysRegionById(Long id);

    /**
     * 查询中国省市区数据库列表
     *
     * @param sysRegion 中国省市区数据库
     * @return 中国省市区数据库集合
     */
    public List<SysRegion> selectSysRegionList(SysRegion sysRegion);

    /**
     * 新增中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    public int insertSysRegion(SysRegion sysRegion);

    /**
     * 修改中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    public int updateSysRegion(SysRegion sysRegion);

    /**
     * 批量删除中国省市区数据库
     *
     * @param ids 需要删除的中国省市区数据库ID
     * @return 结果
     */
    public int deleteSysRegionByIds(Long[] ids);

    /**
     * 删除中国省市区数据库信息
     *
     * @param id 中国省市区数据库ID
     * @return 结果
     */
    public int deleteSysRegionById(Long id);

    List<RegionDto> selectCascadeList(String parentCode);
}
