package com.ruoyi.system.mapper;

import java.util.List;

import com.ruoyi.system.domain.SysRegion;

/**
 * 中国省市区数据库Mapper接口
 *
 * @author ruoyi
 * @date 2020-12-04
 */
public interface SysRegionMapper {
    /**
     * 查询中国省市区数据库
     *
     * @param id 中国省市区数据库ID
     * @return 中国省市区数据库
     */
    public SysRegion selectSysRegionById(Long id);

    /**
     * 查询中国省市区数据库列表
     *
     * @param sysRegion 中国省市区数据库
     * @return 中国省市区数据库集合
     */
    public List<SysRegion> selectSysRegionList(SysRegion sysRegion);

    /**
     * 新增中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    public int insertSysRegion(SysRegion sysRegion);

    /**
     * 修改中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    public int updateSysRegion(SysRegion sysRegion);

    /**
     * 删除中国省市区数据库
     *
     * @param id 中国省市区数据库ID
     * @return 结果
     */
    public int deleteSysRegionById(Long id);

    /**
     * 批量删除中国省市区数据库
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteSysRegionByIds(Long[] ids);
}
