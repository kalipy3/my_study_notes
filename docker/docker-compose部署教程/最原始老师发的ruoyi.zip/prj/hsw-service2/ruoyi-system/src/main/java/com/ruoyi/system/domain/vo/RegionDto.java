package com.ruoyi.system.domain.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

/**
 * 区域
 *
 * @author youyong
 * @date 2020/12/4 0004
 */
@Data
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class RegionDto {
    // 区划代码
    private String label;

    // 区域名称
    private String value;

    // 子区域
    private List<RegionDto> children;

}
