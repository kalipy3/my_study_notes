package com.ruoyi.system.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.system.domain.vo.RegionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.SysRegionMapper;
import com.ruoyi.system.domain.SysRegion;
import com.ruoyi.system.service.ISysRegionService;

/**
 * 中国省市区数据库Service业务层处理
 *
 * @author ruoyi
 * @date 2020-12-04
 */
@Service
public class SysRegionServiceImpl implements ISysRegionService {
    @Autowired
    private SysRegionMapper sysRegionMapper;

    /**
     * 查询中国省市区数据库
     *
     * @param id 中国省市区数据库ID
     * @return 中国省市区数据库
     */
    @Override
    public SysRegion selectSysRegionById(Long id) {
        return sysRegionMapper.selectSysRegionById(id);
    }

    /**
     * 查询中国省市区数据库列表
     *
     * @param sysRegion 中国省市区数据库
     * @return 中国省市区数据库
     */
    @Override
    public List<SysRegion> selectSysRegionList(SysRegion sysRegion) {
        return sysRegionMapper.selectSysRegionList(sysRegion);
    }

    /**
     * 新增中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    @Override
    public int insertSysRegion(SysRegion sysRegion) {
        return sysRegionMapper.insertSysRegion(sysRegion);
    }

    /**
     * 修改中国省市区数据库
     *
     * @param sysRegion 中国省市区数据库
     * @return 结果
     */
    @Override
    public int updateSysRegion(SysRegion sysRegion) {
        return sysRegionMapper.updateSysRegion(sysRegion);
    }

    /**
     * 批量删除中国省市区数据库
     *
     * @param ids 需要删除的中国省市区数据库ID
     * @return 结果
     */
    @Override
    public int deleteSysRegionByIds(Long[] ids) {
        return sysRegionMapper.deleteSysRegionByIds(ids);
    }

    /**
     * 删除中国省市区数据库信息
     *
     * @param id 中国省市区数据库ID
     * @return 结果
     */
    @Override
    public int deleteSysRegionById(Long id) {
        return sysRegionMapper.deleteSysRegionById(id);
    }

    @Override
    public List<RegionDto> selectCascadeList(String parentCode) {
        if (StringUtils.isBlank(parentCode)) {
            parentCode = "0";
        }

        SysRegion sysRegion = new SysRegion();
        List<SysRegion> sysRegions = this.selectSysRegionList(sysRegion);
        return getChildren(parentCode, sysRegions);
    }

    private List<RegionDto> getChildren(String parentCode, List<SysRegion> sysRegions) {
        List<RegionDto> regionDtos = new ArrayList<>();
        for(SysRegion sysRegion: sysRegions) {
            if (parentCode.equals(sysRegion.getParentCode())) {
                RegionDto regionDto = new RegionDto();
                regionDto.setLabel(sysRegion.getRegionName());
                regionDto.setValue(sysRegion.getRegionCode());
                if (sysRegion.getRegionLevel() <= 2) {
                    regionDto.setChildren(getChildren(sysRegion.getRegionCode(), sysRegions));
                }

                regionDtos.add(regionDto);
            }
        }

        return regionDtos;
    }
}
