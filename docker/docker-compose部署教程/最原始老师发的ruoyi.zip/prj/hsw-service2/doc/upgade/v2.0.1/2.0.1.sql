-- 添加字典和系统参数 2020-12-23
INSERT INTO `sys_config` VALUES ('116', '0', '短信开关', 'SMS_OPEN', '1', 'Y', 'admin', '2020-12-21 15:53:26', null, null, '1代表开启，0代表关闭');
INSERT INTO `sys_dict_type` VALUES ('116', '0', '项目区域', 'hsw_project_area', '0', 'admin', '2020-12-21 10:27:31', null, null, '项目区域，在登录和后台页面展示时使用');
INSERT INTO `sys_dict_data` VALUES ('195', '0', '1', 'area', '高安市', 'hsw_project_area', null, null, 'N', '0', 'admin', '2020-12-21 10:28:46', 'admin', '2020-12-22 20:51:25', null);
INSERT INTO `sys_dict_data` VALUES ('196', '0', '2', 'areaCode', '360983', 'hsw_project_area', null, null, 'N', '0', 'admin', '2020-12-21 11:43:34', 'admin', '2020-12-21 11:43:38', null);

-- 故障表修改op_state字段注释 2020-12-25
alter table hsw_fault_info  modify column op_state varchar(20) COMMENT '';