/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.0.196-mysql8-开发
 Source Server Type    : MySQL
 Source Server Version : 80017
 Source Host           : 192.168.0.196:3306
 Source Schema         : hsw-test

 Target Server Type    : MySQL
 Target Server Version : 80017
 File Encoding         : 65001

 Date: 17/12/2020 19:49:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for gen_table
-- ----------------------------
DROP TABLE IF EXISTS `gen_table`;
CREATE TABLE `gen_table`  (
  `table_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '表名称',
  `table_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '表描述',
  `class_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '实体类名称',
  `tpl_category` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `package_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '代码生成业务表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gen_table_column
-- ----------------------------
DROP TABLE IF EXISTS `gen_table_column`;
CREATE TABLE `gen_table_column`  (
  `column_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典类型',
  `sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '代码生成业务表字段' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_camera
-- ----------------------------
DROP TABLE IF EXISTS `hsw_camera`;
CREATE TABLE `hsw_camera`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `diagnosis_device_id` bigint(20) NULL DEFAULT NULL COMMENT '诊断器id',
  `sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '摄像机序列号',
  `position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '方位',
  `manufacturer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生产厂商',
  `longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '经度',
  `latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '纬度',
  `model` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '型号',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '所属诊断器ip',
  `install_time` bigint(20) NOT NULL COMMENT '安装时间',
  `device_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '类型(枪机=1,球机=2,半球机=3)',
  `port` int(8) NULL DEFAULT NULL COMMENT '端口号',
  `self_ip` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '摄像机IP',
  `warranty` int(8) NULL DEFAULT NULL COMMENT '质保期(年)',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '摄像机' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_constructing_team
-- ----------------------------
DROP TABLE IF EXISTS `hsw_constructing_team`;
CREATE TABLE `hsw_constructing_team`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '施工队名称',
  `leader` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '电话',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '施工队' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_constructing_units
-- ----------------------------
DROP TABLE IF EXISTS `hsw_constructing_units`;
CREATE TABLE `hsw_constructing_units`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '建设单位名称',
  `leader` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '电话',
  `access_key_id` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '短信AccessKey',
  `access_key_secret` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '短信AccessKeySecret',
  `sign_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '短信签名',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '建设单位' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_diagnosis_device
-- ----------------------------
DROP TABLE IF EXISTS `hsw_diagnosis_device`;
CREATE TABLE `hsw_diagnosis_device`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `sn` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '设备序列号',
  `divide_work_id` bigint(20) NULL DEFAULT NULL COMMENT '所属分工',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '详细地址',
  `manufacturer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生产厂商',
  `model` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '型号',
  `ip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '诊断器IP',
  `install_time` bigint(20) NOT NULL COMMENT '安装时间',
  `pid` bigint(20) NOT NULL COMMENT '所属项目',
  `logical_addr` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '逻辑地址',
  `ver` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '版本',
  `uplink_port` int(8) NULL DEFAULT NULL COMMENT '上行端口',
  `camera_count` int(8) NULL DEFAULT NULL COMMENT '摄像头数量',
  `warranty` int(8) NULL DEFAULT NULL COMMENT '质保期(年)',
  `distance` int(8) NULL DEFAULT NULL COMMENT '距指挥中心距离(KM)',
  `network` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '网络运营商',
  `longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '经度',
  `latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '纬度',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_ip`(`ip`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '诊断器' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_divide_work
-- ----------------------------
DROP TABLE IF EXISTS `hsw_divide_work`;
CREATE TABLE `hsw_divide_work`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `pid` bigint(20) NOT NULL COMMENT '所属项目id',
  `area` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '区域',
  `at_id` bigint(20) NOT NULL COMMENT '运维队id',
  `mu_id` bigint(20) NULL DEFAULT NULL COMMENT '运维单位',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '分工职责' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_fault_info
-- ----------------------------
DROP TABLE IF EXISTS `hsw_fault_info`;
CREATE TABLE `hsw_fault_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `fault_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '故障编号)',
  `region_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '视点位置',
  `ip` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0.0.0.0' COMMENT '视点IP',
  `sn` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '逻辑地址32位',
  `port` int(8) NULL DEFAULT NULL COMMENT '端口号，非摄像机故障为0',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '故障类型',
  `take_time` bigint(20) NOT NULL COMMENT '发生时间',
  `pid` bigint(20) NOT NULL COMMENT '所属项目',
  `descr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '故障描述',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '故障状态（0=未派单；1=待接单；2=维修中； 3=已修复；4=挂起; 5=自动修复; 6=已撤单）',
  `flag_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '归档状态（0=活动故障；1=历史故障；）',
  `repair_time` bigint(20) NOT NULL COMMENT '修复时间',
  `job_id` bigint(20) NOT NULL COMMENT '对应工单id',
  `job_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '对应工单编号',
  `mt_id` bigint(20) NULL DEFAULT NULL COMMENT '维修队id',
  `area` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '来源于设备对应分工区域名称（乡镇/街道/小区），便于查询',
  `mu_id` bigint(20) NULL DEFAULT NULL COMMENT '运维单位id',
  `today_take_count` int(11) NULL DEFAULT NULL COMMENT '仅对摄像机故障有效，一天该摄像机发生的第几次故障',
  `divide_work_id` bigint(20) NULL DEFAULT NULL COMMENT '故障所属分工区域id',
  `op_state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作状态(0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派)',
  `zigzag_count` int(8) NULL DEFAULT NULL COMMENT '颠簸次数',
  `influence_camera_count` int(8) NULL DEFAULT NULL COMMENT '影响摄像机数量',
  `zigzag_type` int(8) NULL DEFAULT NULL COMMENT '颠簸故障类型（同故障状态，除工作不稳定2种）',
  `zigzag_status` int(8) NULL DEFAULT NULL COMMENT '颠簸状态（0=未处理；1=已处理）',
  `timeout_level` int(11) NULL DEFAULT NULL COMMENT '超时档位',
  `start_distance` int(8) NULL DEFAULT NULL COMMENT '故障距离指挥中心位最小距离(KM)',
  `end_distance` int(8) NULL DEFAULT NULL COMMENT '故障距离指挥中心位最大距离(KM)',
  `timeout_hour` int(8) NULL DEFAULT NULL COMMENT '超时时长(小时)',
  `device_distance` int(8) NULL DEFAULT NULL COMMENT '距指挥中心距离(KM)',
  `send_work_order_limit` double(8, 1) NULL DEFAULT NULL COMMENT '派单要求时长',
  `network` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '网络运营商',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '故障信息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_job_info
-- ----------------------------
DROP TABLE IF EXISTS `hsw_job_info`;
CREATE TABLE `hsw_job_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `job_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '工单编号',
  `fault_id` bigint(20) NULL DEFAULT NULL COMMENT '故障id',
  `fault_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '故障编号',
  `send_time` bigint(10) NULL DEFAULT NULL COMMENT '派单时间',
  `send_uid` bigint(20) NULL DEFAULT NULL COMMENT '派单人id',
  `receiver_id` bigint(20) NULL DEFAULT NULL COMMENT '接单人id',
  `receiver_time` bigint(10) NULL DEFAULT NULL COMMENT '接单时间',
  `status` int(11) NOT NULL COMMENT '工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）',
  `repair_time` bigint(10) NULL DEFAULT NULL COMMENT '修复时间',
  `repair_record` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '维修记录',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `flag_status` int(11) NOT NULL COMMENT '归档状态（0=活动工单；1=历史工单；）',
  `hang_up_time` bigint(10) NULL DEFAULT NULL COMMENT '挂起时间',
  `hang_up_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '挂起原因',
  `resume_time` bigint(20) NULL DEFAULT NULL COMMENT '撤回挂起时间',
  `handle_status` int(11) NULL DEFAULT NULL COMMENT '操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '工单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_job_log
-- ----------------------------
DROP TABLE IF EXISTS `hsw_job_log`;
CREATE TABLE `hsw_job_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `job_id` bigint(20) NOT NULL COMMENT '对应工单id',
  `job_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '对应工单编号',
  `job_status` int(1) NOT NULL COMMENT '工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）',
  `handle_status` int(2) NOT NULL COMMENT '操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派',
  `handle_uid` bigint(20) NOT NULL COMMENT '操作人id',
  `handle_uname` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人姓名',
  `handle_time` bigint(10) NOT NULL COMMENT '操作时间',
  `handle_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作原因',
  `old_receiver_id` bigint(20) NULL DEFAULT NULL COMMENT '前接单人id',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '工单日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_maintenance_team
-- ----------------------------
DROP TABLE IF EXISTS `hsw_maintenance_team`;
CREATE TABLE `hsw_maintenance_team`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
  `leader` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '电话',
  `mu_id` bigint(20) NULL DEFAULT NULL COMMENT '运维单位id',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '维修队' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_maintenance_units
-- ----------------------------
DROP TABLE IF EXISTS `hsw_maintenance_units`;
CREATE TABLE `hsw_maintenance_units`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
  `leader` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `tel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '电话',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '地址',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '运维单位' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_optical_transceiver
-- ----------------------------
DROP TABLE IF EXISTS `hsw_optical_transceiver`;
CREATE TABLE `hsw_optical_transceiver`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `diagnosis_device_id` bigint(20) NULL DEFAULT NULL COMMENT '诊断器id',
  `sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '序列号',
  `manufacturer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生产厂商',
  `model` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '型号',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '所属诊断器ip',
  `install_time` bigint(20) NOT NULL COMMENT '安装时间',
  `warranty` int(8) NULL DEFAULT NULL COMMENT '质保期(年)',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '光端机' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_other_device
-- ----------------------------
DROP TABLE IF EXISTS `hsw_other_device`;
CREATE TABLE `hsw_other_device`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `diagnosis_device_id` bigint(20) NULL DEFAULT NULL COMMENT '诊断器id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '设备名称',
  `manufacturer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '生产厂商',
  `install_time` bigint(20) NOT NULL COMMENT '安装时间',
  `descr` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '描述',
  `model` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '型号',
  `sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '序列号',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '所属诊断器ip',
  `warranty` int(8) NULL DEFAULT NULL COMMENT '质保期(年)',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '其他设备' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_project
-- ----------------------------
DROP TABLE IF EXISTS `hsw_project`;
CREATE TABLE `hsw_project`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '项目名称',
  `build_time` bigint(20) NOT NULL COMMENT '建设时间',
  `cu_id` bigint(20) NOT NULL COMMENT '建设单位id',
  `ct_id` bigint(20) NOT NULL COMMENT '施工队id',
  `mt_id` bigint(20) NULL DEFAULT NULL COMMENT '运维队id',
  `pm_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '项目经理信息',
  `electricity_operating_contacts` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电力运营联系人',
  `communications_operations_contacts` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '通讯运营联系人',
  `province` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '省',
  `city` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '市',
  `district` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '区',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '地址',
  `attachments` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '项目附件（供上传图片使用，大致20张）',
  `province_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '省名称',
  `city_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '市名称',
  `district_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '区名称',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  `finish_time` bigint(20) NULL DEFAULT NULL COMMENT '竣工日期',
  `electricity_operating` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '电力运营单位',
  `communications_operations` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '通讯运营单位',
  `timeout_label1` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '超时档位1',
  `timeout_label2` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '超时档位2',
  `timeout_label3` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '超时档位3',
  `timeout_start1` int(8) NULL DEFAULT NULL COMMENT '最小距离(KM)1',
  `timeout_end1` int(8) NULL DEFAULT NULL COMMENT '最大距离(KM)1',
  `timeout_start2` int(8) NULL DEFAULT NULL COMMENT '最小距离(KM)2',
  `timeout_end2` int(8) NULL DEFAULT NULL COMMENT '最大距离(KM)2',
  `timeout_start3` int(8) NULL DEFAULT NULL COMMENT '最小距离(KM)3',
  `timeout_end3` int(8) NULL DEFAULT NULL COMMENT '最大距离(KM)3',
  `timeout_hour1` int(8) NULL DEFAULT NULL COMMENT '超时时长(小时)1',
  `timeout_hour2` int(8) NULL DEFAULT NULL COMMENT '超时时长(小时)2',
  `timeout_hour3` int(8) NULL DEFAULT NULL COMMENT '超时时长(小时)3',
  `send_work_order_limit` double(8, 1) NULL DEFAULT NULL COMMENT '派单要求时长（小时）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_project_maintenance_units
-- ----------------------------
DROP TABLE IF EXISTS `hsw_project_maintenance_units`;
CREATE TABLE `hsw_project_maintenance_units`  (
  `pid` bigint(20) NOT NULL COMMENT '项目id',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `mu_id` bigint(20) NOT NULL COMMENT '运维单位id',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '项目与运维单位关系表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_sys_msg
-- ----------------------------
DROP TABLE IF EXISTS `hsw_sys_msg`;
CREATE TABLE `hsw_sys_msg`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日志标题',
  `content` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '日志内容',
  `to_uids` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '接收者uid',
  `job_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关联工单编号',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统消息' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hsw_user_msg
-- ----------------------------
DROP TABLE IF EXISTS `hsw_user_msg`;
CREATE TABLE `hsw_user_msg`  (
  `mid` bigint(20) NOT NULL COMMENT '消息id',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `uid` bigint(20) NOT NULL COMMENT '用户id',
  `read_time` bigint(20) NOT NULL COMMENT '阅读时间',
  `status` int(11) NOT NULL COMMENT '状态(0=未读；1=已读；3=归档)',
  `uname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`mid`, `uid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '消息发送信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `blob_data` blob NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `calendar` blob NOT NULL,
  PRIMARY KEY (`sched_name`, `calendar_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cron_expression` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `time_zone_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `entry_id` varchar(95) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fired_time` bigint(13) NOT NULL,
  `sched_time` bigint(13) NOT NULL,
  `priority` int(11) NOT NULL,
  `state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `entry_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `job_class_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_durable` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_update_data` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_data` blob NULL,
  PRIMARY KEY (`sched_name`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lock_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`sched_name`, `lock_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`sched_name`, `trigger_group`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_checkin_time` bigint(13) NOT NULL,
  `checkin_interval` bigint(13) NOT NULL,
  PRIMARY KEY (`sched_name`, `instance_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `repeat_count` bigint(7) NOT NULL,
  `repeat_interval` bigint(12) NOT NULL,
  `times_triggered` bigint(10) NOT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `str_prop_1` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `str_prop_2` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `str_prop_3` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `int_prop_1` int(11) NULL DEFAULT NULL,
  `int_prop_2` int(11) NULL DEFAULT NULL,
  `long_prop_1` bigint(20) NULL DEFAULT NULL,
  `long_prop_2` bigint(20) NULL DEFAULT NULL,
  `dec_prop_1` decimal(13, 4) NULL DEFAULT NULL,
  `dec_prop_2` decimal(13, 4) NULL DEFAULT NULL,
  `bool_prop_1` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `bool_prop_2` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers`  (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `next_fire_time` bigint(13) NULL DEFAULT NULL,
  `prev_fire_time` bigint(13) NULL DEFAULT NULL,
  `priority` int(11) NULL DEFAULT NULL,
  `trigger_state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `start_time` bigint(13) NOT NULL,
  `end_time` bigint(13) NULL DEFAULT NULL,
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `misfire_instr` smallint(2) NULL DEFAULT NULL,
  `job_data` blob NULL,
  PRIMARY KEY (`sched_name`, `trigger_name`, `trigger_group`) USING BTREE,
  INDEX `qrtz_triggers_ibfk_1`(`sched_name`, `job_name`, `job_group`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `job_name`, `job_group`) REFERENCES `qrtz_job_details` (`sched_name`, `job_name`, `job_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config`  (
  `config_id` int(5) NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `config_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '参数键名',
  `config_value` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '参数配置表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_dept`;
CREATE TABLE `sys_dept`  (
  `dept_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '部门id',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父部门id',
  `ancestors` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '祖级列表',
  `dept_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '部门名称',
  `order_num` int(4) NULL DEFAULT 0 COMMENT '显示顺序',
  `leader` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '负责人',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '联系电话',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '部门状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '部门表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data`  (
  `dict_code` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `dict_sort` int(4) NULL DEFAULT 0 COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典数据表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `dict_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `dict_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  INDEX `dict_type`(`dict_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '字典类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_job
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job`  (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`job_id`, `job_name`, `job_group`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '定时任务调度表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_job_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log`  (
  `job_log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调用目标字符串',
  `job_message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '日志信息',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '异常信息',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '定时任务调度日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor`  (
  `info_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户账号',
  `ipaddr` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '提示消息',
  `login_time` datetime(0) NULL DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统访问记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `menu_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父菜单ID',
  `order_num` int(4) NULL DEFAULT 0 COMMENT '显示顺序',
  `path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '路由地址',
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '组件路径',
  `is_frame` int(1) NULL DEFAULT 1 COMMENT '是否为外链（0是 1否）',
  `is_cache` int(1) NULL DEFAULT 0 COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '显示状态（0显示 1隐藏）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '菜单权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_notice
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice`  (
  `notice_id` int(4) NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `notice_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告标题',
  `notice_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob NULL COMMENT '公告内容',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '通知公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log`  (
  `oper_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '模块标题',
  `business_type` int(2) NULL DEFAULT 0 COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '方法名称',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求方式',
  `operator_type` int(1) NULL DEFAULT 0 COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求URL',
  `oper_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作地点',
  `oper_param` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '请求参数',
  `json_result` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '返回参数',
  `status` int(1) NULL DEFAULT 0 COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '错误消息',
  `oper_time` datetime(0) NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '操作日志记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_post`;
CREATE TABLE `sys_post`  (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `post_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位编码',
  `post_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '岗位名称',
  `post_sort` int(4) NOT NULL COMMENT '显示顺序',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`post_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '岗位信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_region
-- ----------------------------
DROP TABLE IF EXISTS `sys_region`;
CREATE TABLE `sys_region`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号ID',
  `parent_id` int(11) NULL DEFAULT NULL COMMENT '父ID',
  `region_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
  `region_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '地区代码',
  `parent_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '上级地区代码',
  `region_level` int(11) NULL DEFAULT NULL COMMENT '层级',
  `region_sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `region_name_en` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '英文名称',
  `region_shortname_en` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '英文简称',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `Index_parent_id`(`parent_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '行政区划' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `role_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int(4) NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) NULL DEFAULT 1 COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) NULL DEFAULT 1 COMMENT '部门树选择项是否关联显示',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role_dept
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_dept`;
CREATE TABLE `sys_role_dept`  (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `dept_id` bigint(20) NOT NULL COMMENT '部门ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  PRIMARY KEY (`role_id`, `dept_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色和部门关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色和菜单关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  `dept_id` bigint(20) NULL DEFAULT NULL COMMENT '部门ID',
  `user_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户账号',
  `real_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `nick_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户昵称',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `sex` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '用户性别（0男 1女 2未知）',
  `avatar` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '头像地址',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '密码',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `type` int(10) NULL DEFAULT NULL COMMENT '1=系统管理员；2=建设单位用户；3=运维单位用户',
  `constructing_units_id` bigint(10) NULL DEFAULT NULL COMMENT '建设单位',
  `maintenance_units_id` bigint(10) NULL DEFAULT NULL COMMENT '运维单位',
  `team_id` bigint(20) NULL DEFAULT NULL COMMENT '运维队id',
  `del_flag` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '0' COMMENT '删除标志（0代表存在 2代表删除）',
  `login_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '最后登录IP',
  `login_date` datetime(0) NULL DEFAULT NULL COMMENT '最后登录时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '创建者',
  `create_time` datetime(0) NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '更新者',
  `update_time` datetime(0) NULL DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user_post
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_post`;
CREATE TABLE `sys_user_post`  (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `post_id` bigint(20) NOT NULL COMMENT '岗位ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  PRIMARY KEY (`user_id`, `post_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户与岗位关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `tenant_id` bigint(20) NULL DEFAULT 0 COMMENT '租户id',
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户和角色关联表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- View structure for hsw_camera_count
-- ----------------------------
DROP VIEW IF EXISTS `hsw_camera_count`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_camera_count` AS select `hsw_camera_view`.`pid` AS `pid`,`hsw_camera_view`.`project_title` AS `project_title`,count(`hsw_camera_view`.`id`) AS `camera_count`,`hsw_camera_view`.`cu_id` AS `cu_id` from `hsw_camera_view` group by `hsw_camera_view`.`pid`,`hsw_camera_view`.`project_title`,`hsw_camera_view`.`cu_id`;

-- ----------------------------
-- View structure for hsw_camera_count_by_city
-- ----------------------------
DROP VIEW IF EXISTS `hsw_camera_count_by_city`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_camera_count_by_city` AS select `hsw_camera_view`.`city` AS `city`,count(`hsw_camera_view`.`id`) AS `camera_count` from `hsw_camera_view` group by `hsw_camera_view`.`city`;

-- ----------------------------
-- View structure for hsw_camera_count_by_district
-- ----------------------------
DROP VIEW IF EXISTS `hsw_camera_count_by_district`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_camera_count_by_district` AS select `hsw_camera_view`.`city` AS `city`,`hsw_camera_view`.`district` AS `district`,count(`hsw_camera_view`.`id`) AS `camera_count` from `hsw_camera_view` group by `hsw_camera_view`.`city`,`hsw_camera_view`.`district`;

-- ----------------------------
-- View structure for hsw_camera_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_camera_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_camera_view` AS select `c`.`id` AS `id`,`c`.`sn` AS `sn`,`c`.`position` AS `position`,`c`.`manufacturer` AS `manufacturer`,`c`.`longitude` AS `longitude`,`c`.`latitude` AS `latitude`,`c`.`model` AS `model`,`c`.`ip` AS `ip`,`c`.`install_time` AS `install_time`,`c`.`device_type` AS `device_type`,`c`.`port` AS `PORT`,`ddv`.`divide_work_id` AS `divide_work_id`,`ddv`.`address` AS `address`,`ddv`.`cu_id` AS `cu_id`,`ddv`.`project_title` AS `project_title`,`ddv`.`divide_area` AS `divide_area`,`ddv`.`pid` AS `pid`,`c`.`self_ip` AS `self_ip`,`ddv`.`province` AS `province`,`ddv`.`city` AS `city`,`ddv`.`district` AS `district`,`ddv`.`logical_addr` AS `logical_addr`,`ddv`.`camera_count` AS `camera_count`,`c`.`warranty` AS `warranty`,`ddv`.`constructing_team_name` AS `constructing_team_name`,`ddv`.`maintenance_units_name` AS `maintenance_units_name`,`ddv`.`distance` AS `distance` from (`hsw_camera` `c` join `hsw_diagnosis_device_view` `ddv` on((`c`.`ip` = `ddv`.`ip`))) where (`c`.`del_flag` = '0');

-- ----------------------------
-- View structure for hsw_device_count
-- ----------------------------
DROP VIEW IF EXISTS `hsw_device_count`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_device_count` AS select `hsw_diagnosis_device_count`.`project_title` AS `project_title`,`hsw_diagnosis_device_count`.`diagnosis_count` AS `diagnosis_count`,`hsw_diagnosis_device_count`.`pid` AS `pid`,`hsw_diagnosis_device_count`.`cu_id` AS `cu_id`,`hsw_camera_count`.`camera_count` AS `camera_count`,`hsw_other_device_count`.`other_device_count` AS `other_device_count`,`hsw_optical_transceiver_count`.`optical_transceiver_count` AS `optical_transceiver_count` from (((`hsw_diagnosis_device_count` left join `hsw_camera_count` on(((`hsw_diagnosis_device_count`.`pid` = `hsw_camera_count`.`pid`) and (`hsw_diagnosis_device_count`.`cu_id` = `hsw_camera_count`.`cu_id`)))) left join `hsw_optical_transceiver_count` on(((`hsw_diagnosis_device_count`.`pid` = `hsw_optical_transceiver_count`.`pid`) and (`hsw_diagnosis_device_count`.`cu_id` = `hsw_optical_transceiver_count`.`cu_id`)))) left join `hsw_other_device_count` on(((`hsw_diagnosis_device_count`.`pid` = `hsw_other_device_count`.`pid`) and (`hsw_diagnosis_device_count`.`cu_id` = `hsw_other_device_count`.`cu_id`))));

-- ----------------------------
-- View structure for hsw_diagnosis_device_count
-- ----------------------------
DROP VIEW IF EXISTS `hsw_diagnosis_device_count`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_diagnosis_device_count` AS select `hsw_diagnosis_device_view`.`pid` AS `pid`,`hsw_diagnosis_device_view`.`project_title` AS `project_title`,count(`hsw_diagnosis_device_view`.`id`) AS `diagnosis_count`,`hsw_diagnosis_device_view`.`cu_id` AS `cu_id` from `hsw_diagnosis_device_view` group by `hsw_diagnosis_device_view`.`pid`,`hsw_diagnosis_device_view`.`project_title`,`hsw_diagnosis_device_view`.`cu_id`;

-- ----------------------------
-- View structure for hsw_diagnosis_device_count_by_city
-- ----------------------------
DROP VIEW IF EXISTS `hsw_diagnosis_device_count_by_city`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_diagnosis_device_count_by_city` AS select `hsw_diagnosis_device_view`.`city` AS `city`,count(`hsw_diagnosis_device_view`.`id`) AS `diagnosis_count` from `hsw_diagnosis_device_view` group by `hsw_diagnosis_device_view`.`city`;

-- ----------------------------
-- View structure for hsw_diagnosis_device_count_by_district
-- ----------------------------
DROP VIEW IF EXISTS `hsw_diagnosis_device_count_by_district`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_diagnosis_device_count_by_district` AS select `hsw_diagnosis_device_view`.`city` AS `city`,`hsw_diagnosis_device_view`.`district` AS `district`,count(`hsw_diagnosis_device_view`.`id`) AS `diagnosis_count` from `hsw_diagnosis_device_view` group by `hsw_diagnosis_device_view`.`city`,`hsw_diagnosis_device_view`.`district`;

-- ----------------------------
-- View structure for hsw_diagnosis_device_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_diagnosis_device_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_diagnosis_device_view` AS select `dw`.`area` AS `divide_area`,`p`.`province_label` AS `province_label`,`p`.`city_label` AS `city_label`,`p`.`district_label` AS `district_label`,`p`.`title` AS `project_title`,`dd`.`id` AS `id`,`dd`.`sn` AS `sn`,`dd`.`divide_work_id` AS `divide_work_id`,`dd`.`address` AS `address`,`dd`.`manufacturer` AS `manufacturer`,`dd`.`model` AS `model`,`dd`.`ip` AS `ip`,`dd`.`install_time` AS `install_time`,`dd`.`pid` AS `pid`,`dd`.`logical_addr` AS `logical_addr`,`dd`.`ver` AS `ver`,`dd`.`uplink_port` AS `uplink_port`,`dd`.`camera_count` AS `camera_count`,`mt`.`name` AS `constructing_team_name`,`dw`.`at_id` AS `at_id`,`p`.`cu_id` AS `cu_id`,`p`.`province` AS `province`,`p`.`city` AS `city`,`p`.`district` AS `district`,`dd`.`warranty` AS `warranty`,`mu`.`name` AS `maintenance_units_name`,`mu`.`id` AS `maintenance_units_id`,`dd`.`distance` AS `distance`,`dd`.`network` AS `network` from ((((`hsw_diagnosis_device` `dd` left join `hsw_project` `p` on((`dd`.`pid` = `p`.`id`))) left join `hsw_divide_work` `dw` on(((`dd`.`divide_work_id` = `dw`.`id`) and (`dw`.`del_flag` = '0')))) left join `hsw_maintenance_team` `mt` on(((`dw`.`at_id` = `mt`.`id`) and (`mt`.`del_flag` = '0')))) left join `hsw_maintenance_units` `mu` on(((`dw`.`mu_id` = `mu`.`id`) and (`mu`.`del_flag` = '0')))) where ((`dd`.`del_flag` = '0') and (`p`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_fault_camera
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_camera`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_camera` AS select `hsw_fault_info`.`id` AS `id`,`hsw_fault_info`.`fault_no` AS `fault_no`,`hsw_fault_info`.`region_name` AS `region_name`,`hsw_fault_info`.`ip` AS `ip`,`hsw_fault_info`.`sn` AS `sn`,`hsw_fault_info`.`port` AS `port`,`hsw_fault_info`.`type` AS `type`,`hsw_fault_info`.`take_time` AS `take_time`,`hsw_fault_info`.`pid` AS `pid`,`hsw_fault_info`.`descr` AS `descr`,`hsw_fault_info`.`status` AS `status`,`hsw_fault_info`.`flag_status` AS `flag_status`,`hsw_fault_info`.`repair_time` AS `repair_time`,`hsw_fault_info`.`job_id` AS `job_id`,`hsw_fault_info`.`job_no` AS `job_no`,`hsw_fault_info`.`mt_id` AS `mt_id`,`hsw_fault_info`.`area` AS `area`,`hsw_fault_info`.`mu_id` AS `mu_id`,`hsw_fault_info`.`today_take_count` AS `today_take_count`,`hsw_fault_info`.`divide_work_id` AS `divide_work_id`,`hsw_fault_info`.`op_state` AS `op_state`,`hsw_fault_info`.`zigzag_count` AS `zigzag_count`,`hsw_fault_info`.`influence_camera_count` AS `influence_camera_count`,`hsw_fault_info`.`zigzag_type` AS `zigzag_type`,`hsw_fault_info`.`zigzag_status` AS `zigzag_status`,`hsw_fault_info`.`timeout_level` AS `timeout_level`,`hsw_fault_info`.`start_distance` AS `start_distance`,`hsw_fault_info`.`end_distance` AS `end_distance`,`hsw_fault_info`.`timeout_hour` AS `timeout_hour`,`hsw_fault_info`.`device_distance` AS `device_distance`,`hsw_fault_info`.`send_work_order_limit` AS `send_work_order_limit`,`hsw_camera`.`manufacturer` AS `manufacturer`,`hsw_camera`.`device_type` AS `device_type`,(`hsw_fault_info`.`repair_time` - `hsw_fault_info`.`take_time`) AS `repair_time_count`,`hsw_fault_info`.`network` AS `network` from (`hsw_fault_info` join `hsw_camera` on(((`hsw_fault_info`.`ip` = `hsw_camera`.`ip`) and (`hsw_fault_info`.`port` = `hsw_camera`.`port`)))) where ((`hsw_fault_info`.`type` = 5) and (`hsw_fault_info`.`del_flag` = '0') and (`hsw_camera`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_fault_count_by_date
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_count_by_date`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_count_by_date` AS select `hsw_fault_view`.`datestr` AS `datestr`,sum((case `hsw_fault_view`.`type` when 1 then 1 else 0 end)) AS `type1_count`,sum((case `hsw_fault_view`.`type` when 2 then 1 else 0 end)) AS `type2_count`,sum((case `hsw_fault_view`.`type` when 3 then 1 else 0 end)) AS `type3_count`,sum((case `hsw_fault_view`.`type` when 4 then 1 else 0 end)) AS `type4_count`,sum((case `hsw_fault_view`.`type` when 5 then 1 else 0 end)) AS `type5_count`,sum((case `hsw_fault_view`.`type` when 6 then 1 else 0 end)) AS `type6_count`,sum((case `hsw_fault_view`.`type` when 7 then 1 else 0 end)) AS `type7_count`,sum((case `hsw_fault_view`.`type` when 8 then 1 else 0 end)) AS `type8_count`,sum((case `hsw_fault_view`.`type` when 9 then 1 else 0 end)) AS `type9_count` from `hsw_fault_view` group by `hsw_fault_view`.`datestr`;

-- ----------------------------
-- View structure for hsw_fault_count_by_job
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_count_by_job`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_count_by_job` AS select `hsw_fault_view`.`id` AS `id`,`hsw_fault_view`.`fault_no` AS `fault_no`,`hsw_fault_view`.`region_name` AS `region_name`,`hsw_fault_view`.`ip` AS `ip`,`hsw_fault_view`.`sn` AS `sn`,`hsw_fault_view`.`PORT` AS `port`,`hsw_fault_view`.`take_time` AS `take_time`,`hsw_fault_view`.`pid` AS `pid`,`hsw_fault_view`.`descr` AS `descr`,`hsw_fault_view`.`STATUS` AS `status`,`hsw_fault_view`.`flag_status` AS `flag_status`,`hsw_fault_view`.`repair_time` AS `repair_time`,`hsw_fault_view`.`job_id` AS `job_id`,`hsw_fault_view`.`job_no` AS `job_no`,`hsw_fault_view`.`mt_id` AS `mt_id`,`hsw_fault_view`.`area` AS `area`,`hsw_fault_view`.`province` AS `province`,`hsw_fault_view`.`city` AS `city`,`hsw_fault_view`.`district` AS `district`,`hsw_fault_view`.`type` AS `type`,`hsw_fault_view`.`project_title` AS `project_title`,`hsw_fault_view`.`mu_id` AS `mu_id`,`hsw_fault_view`.`maintenance_units_name` AS `maintenance_units_name`,`hsw_fault_view`.`maintenance_team_name` AS `maintenance_team_name`,`hsw_fault_view`.`cu_id` AS `cu_id`,`hsw_fault_view`.`today_take_count` AS `today_take_count`,`hsw_job_info`.`send_uid` AS `send_uid`,`hsw_job_info`.`receiver_id` AS `receiver_id`,`hsw_job_info`.`receiver_time` AS `receiver_time`,`hsw_job_info`.`send_time` AS `send_time`,`a`.`real_name` AS `send_name`,`b`.`real_name` AS `receiver_name`,`hsw_fault_view`.`divide_work_id` AS `divide_work_id` from (((`hsw_fault_view` left join `hsw_job_info` on(((`hsw_job_info`.`fault_id` = `hsw_fault_view`.`id`) and (`hsw_job_info`.`del_flag` = '0')))) left join `sys_user` `a` on(((`hsw_job_info`.`send_uid` = `a`.`user_id`) and (`a`.`del_flag` = '0')))) left join `sys_user` `b` on(((`hsw_job_info`.`receiver_id` = `b`.`user_id`) and (`b`.`del_flag` = '0')))) where (`hsw_job_info`.`del_flag` = '0');

-- ----------------------------
-- View structure for hsw_fault_optical_transceiver
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_optical_transceiver`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_optical_transceiver` AS select `hsw_fault_info`.`id` AS `id`,`hsw_fault_info`.`fault_no` AS `fault_no`,`hsw_fault_info`.`region_name` AS `region_name`,`hsw_fault_info`.`ip` AS `ip`,`hsw_fault_info`.`sn` AS `sn`,`hsw_fault_info`.`port` AS `port`,`hsw_fault_info`.`type` AS `type`,`hsw_fault_info`.`take_time` AS `take_time`,`hsw_fault_info`.`pid` AS `pid`,`hsw_fault_info`.`descr` AS `descr`,`hsw_fault_info`.`status` AS `status`,`hsw_fault_info`.`flag_status` AS `flag_status`,`hsw_fault_info`.`repair_time` AS `repair_time`,`hsw_fault_info`.`job_id` AS `job_id`,`hsw_fault_info`.`job_no` AS `job_no`,`hsw_fault_info`.`mt_id` AS `mt_id`,`hsw_fault_info`.`area` AS `area`,`hsw_fault_info`.`mu_id` AS `mu_id`,`hsw_fault_info`.`today_take_count` AS `today_take_count`,`hsw_fault_info`.`divide_work_id` AS `divide_work_id`,`hsw_fault_info`.`op_state` AS `op_state`,`hsw_fault_info`.`zigzag_count` AS `zigzag_count`,`hsw_fault_info`.`influence_camera_count` AS `influence_camera_count`,`hsw_fault_info`.`zigzag_type` AS `zigzag_type`,`hsw_fault_info`.`zigzag_status` AS `zigzag_status`,`hsw_fault_info`.`timeout_level` AS `timeout_level`,`hsw_fault_info`.`start_distance` AS `start_distance`,`hsw_fault_info`.`end_distance` AS `end_distance`,`hsw_fault_info`.`timeout_hour` AS `timeout_hour`,`hsw_fault_info`.`device_distance` AS `device_distance`,`hsw_fault_info`.`send_work_order_limit` AS `send_work_order_limit`,`hsw_optical_transceiver`.`manufacturer` AS `manufacturer`,(`hsw_fault_info`.`repair_time` - `hsw_fault_info`.`take_time`) AS `repair_time_count` from (`hsw_fault_info` join `hsw_optical_transceiver` on((`hsw_fault_info`.`ip` = `hsw_optical_transceiver`.`ip`))) where ((`hsw_fault_info`.`type` = 3) and (`hsw_fault_info`.`del_flag` = '0') and (`hsw_optical_transceiver`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_fault_project
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_project`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_project` AS select `hsw_fault_info`.`send_work_order_limit` AS `send_work_order_limit`,`hsw_fault_info`.`id` AS `id`,`hsw_fault_info`.`fault_no` AS `fault_no`,`hsw_fault_info`.`region_name` AS `region_name`,`hsw_fault_info`.`ip` AS `ip`,`hsw_fault_info`.`sn` AS `sn`,`hsw_fault_info`.`port` AS `port`,`hsw_fault_info`.`type` AS `type`,`hsw_fault_info`.`pid` AS `pid`,`hsw_fault_info`.`take_time` AS `take_time`,`hsw_fault_info`.`descr` AS `descr`,`hsw_fault_info`.`status` AS `status`,`hsw_fault_info`.`flag_status` AS `flag_status`,`hsw_fault_info`.`repair_time` AS `repair_time`,`hsw_fault_info`.`job_id` AS `job_id`,`hsw_fault_info`.`job_no` AS `job_no`,`hsw_fault_info`.`mt_id` AS `mt_id`,`hsw_fault_info`.`area` AS `area`,`hsw_fault_info`.`mu_id` AS `mu_id`,`hsw_fault_info`.`today_take_count` AS `today_take_count`,`hsw_fault_info`.`divide_work_id` AS `divide_work_id`,`hsw_fault_info`.`op_state` AS `op_state`,`hsw_fault_info`.`zigzag_count` AS `zigzag_count`,`hsw_fault_info`.`influence_camera_count` AS `influence_camera_count`,`hsw_fault_info`.`zigzag_type` AS `zigzag_type`,`hsw_fault_info`.`zigzag_status` AS `zigzag_status`,`hsw_fault_info`.`timeout_level` AS `timeout_level`,`hsw_fault_info`.`start_distance` AS `start_distance`,`hsw_fault_info`.`end_distance` AS `end_distance`,`hsw_fault_info`.`timeout_hour` AS `timeout_hour`,`hsw_fault_info`.`device_distance` AS `device_distance`,`hsw_project`.`electricity_operating` AS `electricity_operating`,`hsw_project`.`communications_operations` AS `communications_operations`,(`hsw_fault_info`.`repair_time` - `hsw_fault_info`.`take_time`) AS `repair_time_count`,`hsw_project`.`title` AS `title` from (`hsw_fault_info` join `hsw_project` on((`hsw_fault_info`.`pid` = `hsw_project`.`id`))) where ((`hsw_fault_info`.`del_flag` = '0') and (`hsw_project`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_fault_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_fault_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_fault_view` AS select `fi`.`id` AS `id`,`fi`.`fault_no` AS `fault_no`,`fi`.`region_name` AS `region_name`,`fi`.`ip` AS `ip`,`fi`.`sn` AS `sn`,`fi`.`port` AS `PORT`,`fi`.`take_time` AS `take_time`,`fi`.`pid` AS `pid`,`fi`.`descr` AS `descr`,`fi`.`status` AS `STATUS`,`fi`.`flag_status` AS `flag_status`,`fi`.`repair_time` AS `repair_time`,`fi`.`job_id` AS `job_id`,`fi`.`job_no` AS `job_no`,`fi`.`mt_id` AS `mt_id`,`fi`.`area` AS `area`,`fi`.`type` AS `type`,`fi`.`mu_id` AS `mu_id`,`fi`.`today_take_count` AS `today_take_count`,`fi`.`divide_work_id` AS `divide_work_id`,date_format(from_unixtime(`fi`.`take_time`),'%Y-%m-%d') AS `datestr`,date_format(from_unixtime(`fi`.`take_time`),'%Y-%m') AS `monthstr`,`fi`.`zigzag_count` AS `zigzag_count`,`fi`.`influence_camera_count` AS `influence_camera_count`,`fi`.`zigzag_type` AS `zigzag_type`,`fi`.`zigzag_status` AS `zigzag_status`,`fi`.`op_state` AS `op_state`,`fi`.`timeout_level` AS `timeout_level`,`fi`.`start_distance` AS `start_distance`,`fi`.`end_distance` AS `end_distance`,`fi`.`timeout_hour` AS `timeout_hour`,`fi`.`device_distance` AS `device_distance`,`fi`.`send_work_order_limit` AS `send_work_order_limit`,(`fi`.`repair_time` - `fi`.`take_time`) AS `auto_repair_time_count`,`fi`.`network` AS `network`,`p`.`province` AS `province`,`p`.`city` AS `city`,`p`.`district` AS `district`,`p`.`title` AS `project_title`,`mu`.`name` AS `maintenance_units_name`,`mt`.`name` AS `maintenance_team_name`,`p`.`cu_id` AS `cu_id` from (((`hsw_fault_info` `fi` left join `hsw_project` `p` on((`p`.`id` = `fi`.`pid`))) left join `hsw_maintenance_units` `mu` on(((`mu`.`id` = `fi`.`mu_id`) and (`mu`.`del_flag` = '0')))) left join `hsw_maintenance_team` `mt` on(((`mt`.`id` = `fi`.`mt_id`) and (`mt`.`del_flag` = '0')))) where ((`fi`.`del_flag` = '0') and (`p`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_job_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_job_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_job_view` AS select `ji`.`id` AS `id`,`ji`.`job_no` AS `job_no`,`ji`.`fault_id` AS `fault_id`,`ji`.`fault_no` AS `fault_no`,`ji`.`create_time` AS `create_time`,`ji`.`send_time` AS `send_time`,`ji`.`send_uid` AS `send_uid`,`ji`.`receiver_id` AS `receiver_id`,`ji`.`receiver_time` AS `receiver_time`,`ji`.`status` AS `STATUS`,`ji`.`repair_time` AS `repair_time`,`ji`.`repair_record` AS `repair_record`,`ji`.`remark` AS `remark`,`ji`.`flag_status` AS `flag_status`,`fv`.`region_name` AS `region_name`,`fv`.`ip` AS `ip`,`fv`.`PORT` AS `PORT`,`fv`.`take_time` AS `take_time`,`fv`.`mt_id` AS `mt_id`,`fv`.`area` AS `area`,`fv`.`province` AS `province`,`fv`.`city` AS `city`,`fv`.`district` AS `district`,`fv`.`type` AS `type`,`fv`.`mu_id` AS `mu_id`,`fv`.`project_title` AS `project_title`,`fv`.`cu_id` AS `cu_id`,`ji`.`hang_up_time` AS `hang_up_time`,`ji`.`hang_up_reason` AS `hang_up_reason`,`fv`.`maintenance_units_name` AS `maintenance_units_name`,`ji`.`resume_time` AS `resume_time`,`ji`.`handle_status` AS `handle_status`,`fv`.`zigzag_status` AS `zigzag_status`,`fv`.`zigzag_type` AS `zigzag_type`,`fv`.`influence_camera_count` AS `influence_camera_count`,`fv`.`zigzag_count` AS `zigzag_count`,`fv`.`divide_work_id` AS `divide_work_id`,`fv`.`today_take_count` AS `today_take_count`,`fv`.`pid` AS `pid`,`fv`.`datestr` AS `datestr`,`fv`.`monthstr` AS `monthstr`,`fv`.`maintenance_team_name` AS `maintenance_team_name`,`fv`.`timeout_level` AS `timeout_level`,`fv`.`start_distance` AS `start_distance`,`fv`.`end_distance` AS `end_distance`,`fv`.`send_work_order_limit` AS `send_work_order_limit`,`fv`.`device_distance` AS `device_distance`,`fv`.`timeout_hour` AS `timeout_hour`,(`ji`.`repair_time` - `ji`.`send_time`) AS `repair_time_count`,(`ji`.`send_time` - `fv`.`take_time`) AS `send_time_count`,`fv`.`network` AS `network` from (`hsw_job_info` `ji` join `hsw_fault_view` `fv` on((`ji`.`fault_id` = `fv`.`id`))) where (`ji`.`del_flag` = '0');

-- ----------------------------
-- View structure for hsw_optical_transceiver_count
-- ----------------------------
DROP VIEW IF EXISTS `hsw_optical_transceiver_count`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_optical_transceiver_count` AS select `hsw_optical_transceiver_view`.`project_title` AS `project_title`,`hsw_optical_transceiver_view`.`cu_id` AS `cu_id`,`hsw_optical_transceiver_view`.`pid` AS `pid`,count(`hsw_optical_transceiver_view`.`id`) AS `optical_transceiver_count` from `hsw_optical_transceiver_view` group by `hsw_optical_transceiver_view`.`pid`,`hsw_optical_transceiver_view`.`project_title`,`hsw_optical_transceiver_view`.`cu_id`;

-- ----------------------------
-- View structure for hsw_optical_transceiver_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_optical_transceiver_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_optical_transceiver_view` AS select `ot`.`id` AS `id`,`ot`.`sn` AS `sn`,`ot`.`manufacturer` AS `manufacturer`,`ot`.`model` AS `model`,`ot`.`ip` AS `ip`,`ot`.`install_time` AS `install_time`,`ddv`.`divide_area` AS `divide_area`,`ddv`.`project_title` AS `project_title`,`ddv`.`pid` AS `pid`,`ddv`.`address` AS `address`,`ddv`.`divide_work_id` AS `divide_work_id`,`ddv`.`at_id` AS `at_id`,`ddv`.`cu_id` AS `cu_id`,`ddv`.`camera_count` AS `camera_count`,`ot`.`warranty` AS `warranty`,`ddv`.`constructing_team_name` AS `constructing_team_name`,`ddv`.`maintenance_units_name` AS `maintenance_units_name`,`ddv`.`province` AS `province`,`ddv`.`city` AS `city`,`ddv`.`district` AS `district`,`ddv`.`distance` AS `distance` from (`hsw_optical_transceiver` `ot` join `hsw_diagnosis_device_view` `ddv` on((`ot`.`ip` = `ddv`.`ip`))) where (`ot`.`del_flag` = '0');

-- ----------------------------
-- View structure for hsw_other_device_count
-- ----------------------------
DROP VIEW IF EXISTS `hsw_other_device_count`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_other_device_count` AS select `hsw_other_device_view`.`pid` AS `pid`,`hsw_other_device_view`.`project_title` AS `project_title`,`hsw_other_device_view`.`cu_id` AS `cu_id`,count(`hsw_other_device_view`.`id`) AS `other_device_count` from `hsw_other_device_view` group by `hsw_other_device_view`.`pid`,`hsw_other_device_view`.`project_title`,`hsw_other_device_view`.`cu_id`;

-- ----------------------------
-- View structure for hsw_other_device_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_other_device_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_other_device_view` AS select `hsw_other_device`.`id` AS `id`,`hsw_other_device`.`name` AS `name`,`hsw_other_device`.`manufacturer` AS `manufacturer`,`hsw_other_device`.`install_time` AS `install_time`,`hsw_other_device`.`descr` AS `descr`,`hsw_other_device`.`model` AS `model`,`hsw_other_device`.`sn` AS `sn`,`hsw_other_device`.`ip` AS `ip`,`hsw_diagnosis_device_view`.`divide_area` AS `divide_area`,`hsw_diagnosis_device_view`.`project_title` AS `project_title`,`hsw_diagnosis_device_view`.`divide_work_id` AS `divide_work_id`,`hsw_diagnosis_device_view`.`address` AS `address`,`hsw_diagnosis_device_view`.`pid` AS `pid`,`hsw_diagnosis_device_view`.`at_id` AS `at_id`,`hsw_diagnosis_device_view`.`cu_id` AS `cu_id`,`hsw_diagnosis_device_view`.`province` AS `province`,`hsw_diagnosis_device_view`.`city` AS `city`,`hsw_diagnosis_device_view`.`district` AS `district`,`hsw_diagnosis_device_view`.`distance` AS `distance`,`hsw_other_device`.`warranty` AS `warranty` from (`hsw_other_device` join `hsw_diagnosis_device_view` on((`hsw_other_device`.`ip` = `hsw_diagnosis_device_view`.`ip`))) where (`hsw_other_device`.`del_flag` = '0');

-- ----------------------------
-- View structure for hsw_project_maintenance_units_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_project_maintenance_units_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_project_maintenance_units_view` AS select `hsw_project_maintenance_units`.`pid` AS `pid`,`hsw_project_maintenance_units`.`mu_id` AS `mu_id`,`hsw_project`.`title` AS `title`,`hsw_maintenance_units`.`name` AS `name` from ((`hsw_project_maintenance_units` join `hsw_project` on((`hsw_project_maintenance_units`.`pid` = `hsw_project`.`id`))) join `hsw_maintenance_units` on(((`hsw_project_maintenance_units`.`mu_id` = `hsw_maintenance_units`.`id`) and (`hsw_maintenance_units`.`del_flag` = '0')))) where ((`hsw_project_maintenance_units`.`del_flag` = '0') and (`hsw_project`.`del_flag` = '0'));

-- ----------------------------
-- View structure for hsw_user_msg_view
-- ----------------------------
DROP VIEW IF EXISTS `hsw_user_msg_view`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`%` SQL SECURITY DEFINER VIEW `hsw_user_msg_view` AS select `hsw_sys_msg`.`title` AS `title`,`hsw_sys_msg`.`content` AS `content`,`hsw_sys_msg`.`create_time` AS `create_time`,`hsw_sys_msg`.`create_by` AS `create_name`,`hsw_user_msg`.`uid` AS `uid`,`hsw_user_msg`.`mid` AS `mid`,`hsw_user_msg`.`read_time` AS `read_time`,`hsw_user_msg`.`status` AS `status`,`hsw_user_msg`.`uname` AS `uname`,`hsw_sys_msg`.`job_no` AS `job_no` from (`hsw_user_msg` join `hsw_sys_msg` on((`hsw_user_msg`.`mid` = `hsw_sys_msg`.`id`))) where ((`hsw_user_msg`.`del_flag` = '0') and (`hsw_sys_msg`.`del_flag` = '0'));

SET FOREIGN_KEY_CHECKS = 1;
