package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.dto.analysis.*;
import com.ruoyi.hsw.service.IAnalysisService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 描述:
 * 绩效考核
 *
 * @author xiongxiangpeng
 * @create 2020-11-11 16:10
 */
@Api("绩效考核Controller")
@RestController
@RequestMapping("/hsw/analysis")
public class AnalysisController extends BaseController {

    @Autowired
    private IAnalysisService analysisService;

    /**
     * 运维单位分析
     */
    @ApiOperation("运维单位分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:muAnalysis')")
    @PostMapping("/muAnalysis")
    public AjaxResult muAnalysis(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto) {

        switch(muAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                return this.muAnalysis1(muAnalysisPageableDto);
            case CommonConstant.AUTO:
                return this.muAnalysis2(muAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.muAnalysis3(muAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.muAnalysis4(muAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 运维单位分析-人工修复
     */
    public AjaxResult muAnalysis1(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysis1(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-自动修复
     */
    public AjaxResult muAnalysis2(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysis2(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-未派单
     */
    public AjaxResult muAnalysis3(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysis3(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-维修中
     */
    public AjaxResult muAnalysis4(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysis4(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-总数
     */
    @ApiOperation("运维单位分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:muAnalysis')")
    @PostMapping("/muAnalysisSum")
    public AjaxResult muAnalysisSum(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto) {
        switch(muAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                return this.muAnalysisSum1(muAnalysisPageableDto);
            case CommonConstant.AUTO:
                return this.muAnalysisSum2(muAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.muAnalysisSum3(muAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.muAnalysisSum4(muAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 运维单位分析-人工修复-总数
     */
    public AjaxResult muAnalysisSum1(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysisSum1(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-自动修复-总数
     */
    public AjaxResult muAnalysisSum2(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysisSum2(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-未派单-总数
     */
    public AjaxResult muAnalysisSum3(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysisSum3(muAnalysisPageableDto));
    }

    /**
     * 运维单位分析-维修中-总数
     */
    public AjaxResult muAnalysisSum4(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.muAnalysisSum4(muAnalysisPageableDto));
    }

    /**
     * 导出运维单位分析
     */
    @ApiOperation("导出运维单位分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:muAnalysis')")
    @PostMapping("/muAnalysisExport")
    public AjaxResult muAnalysisExport(@RequestBody MuAnalysisPageableDto muAnalysisPageableDto) {
        switch(muAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                List<MuAnalysisArtificialDto> list = (List<MuAnalysisArtificialDto>) this.muAnalysis1(muAnalysisPageableDto).get("data");
                MuAnalysisArtificialDto muAnalysisArtificialDto = (MuAnalysisArtificialDto)this.muAnalysisSum1(muAnalysisPageableDto).get("data");
                muAnalysisArtificialDto.setMaintenanceUnitsName("总计");
                list.add(muAnalysisArtificialDto);
                if (!list.isEmpty()) {
                    list.forEach(muAnalysisArtificial -> {
                        muAnalysisArtificial.setRepairRateString(muAnalysisArtificial.getRepairRate() + "%");
                        muAnalysisArtificial.setSendRateString(muAnalysisArtificial.getSendRate() + "%");
                    });
                }
                ExcelUtil<MuAnalysisArtificialDto> util = new ExcelUtil<>(MuAnalysisArtificialDto.class);
                return util.exportExcel(list, "运维单位统计分析");
            case CommonConstant.AUTO:
                List<MuAnalysisAutoDto> list2 = (List<MuAnalysisAutoDto>) this.muAnalysis2(muAnalysisPageableDto).get("data");
                MuAnalysisAutoDto muAnalysisAutoDto2 = (MuAnalysisAutoDto)this.muAnalysisSum2(muAnalysisPageableDto).get("data");
                muAnalysisAutoDto2.setMaintenanceUnitsName("总计");
                list2.add(muAnalysisAutoDto2);
                if (!list2.isEmpty()) {
                    list2.forEach(muAnalysisAuto -> {
                        muAnalysisAuto.setRepairRateString(muAnalysisAuto.getRepairRate() + "%");
                    });
                }
                ExcelUtil<MuAnalysisAutoDto> util2 = new ExcelUtil<>(MuAnalysisAutoDto.class);
                return util2.exportExcel(list2, "运维单位统计分析");
            case CommonConstant.UNDELIVERED:
                List<MuAnalysisUndeliveredDto> list3 = (List<MuAnalysisUndeliveredDto>) this.muAnalysis3(muAnalysisPageableDto).get("data");
                MuAnalysisUndeliveredDto muAnalysisUndeliveredDto3 = (MuAnalysisUndeliveredDto)this.muAnalysisSum3(muAnalysisPageableDto).get("data");
                muAnalysisUndeliveredDto3.setMaintenanceUnitsName("总计");
                list3.add(muAnalysisUndeliveredDto3);
                if (!list3.isEmpty()) {
                    list3.forEach(muAnalysisUndelivered -> {
                        muAnalysisUndelivered.setRepairRateString(muAnalysisUndelivered.getRepairRate() + "%");
                    });
                }
                ExcelUtil<MuAnalysisUndeliveredDto> util3 = new ExcelUtil<>(MuAnalysisUndeliveredDto.class);
                return util3.exportExcel(list3, "运维单位统计分析");
            case CommonConstant.UNDERREPAIR:
                List<MuAnalysisUnderRepairDto> list4 = (List<MuAnalysisUnderRepairDto>) this.muAnalysis4(muAnalysisPageableDto).get("data");
                MuAnalysisUnderRepairDto muAnalysisUnderRepairDto4 = (MuAnalysisUnderRepairDto)this.muAnalysisSum4(muAnalysisPageableDto).get("data");
                muAnalysisUnderRepairDto4.setMaintenanceUnitsName("总计");
                list4.add(muAnalysisUnderRepairDto4);
                if (!list4.isEmpty()) {
                    list4.forEach(muAnalysisArtificial -> {
                        muAnalysisArtificial.setRepairRateString(muAnalysisArtificial.getRepairRate() + "%");
                    });
                }
                ExcelUtil<MuAnalysisUnderRepairDto> util4 = new ExcelUtil<>(MuAnalysisUnderRepairDto.class);
                return util4.exportExcel(list4, "运维单位统计分析");
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修队分析
     */
    @ApiOperation("维修队分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtAnalysis')")
    @PostMapping("/mtAnalysis")
    public AjaxResult mtAnalysis(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        switch(mtAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                return this.mtAnalysis1(mtAnalysisPageableDto);
            case CommonConstant.AUTO:
                return this.mtAnalysis2(mtAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.mtAnalysis3(mtAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtAnalysis4(mtAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修队分析-人工修复
     */
    public AjaxResult mtAnalysis1(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysis1(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-自动修复
     */
    public AjaxResult mtAnalysis2(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysis2(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-未派单
     */
    public AjaxResult mtAnalysis3(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysis3(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-维修中
     */
    public AjaxResult mtAnalysis4(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysis4(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-总数
     */
    @ApiOperation("维修队分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtAnalysis')")
    @PostMapping("/mtAnalysisSum")
    public AjaxResult mtAnalysisSum(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        switch(mtAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                return this.mtAnalysisSum1(mtAnalysisPageableDto);
            case CommonConstant.AUTO:
                return this.mtAnalysisSum2(mtAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.mtAnalysisSum3(mtAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtAnalysisSum4(mtAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修队分析-人工修复-总数
     */
    public AjaxResult mtAnalysisSum1(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysisSum1(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-自动修复-总数
     */
    public AjaxResult mtAnalysisSum2(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysisSum2(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-未派单-总数
     */
    public AjaxResult mtAnalysisSum3(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysisSum3(mtAnalysisPageableDto));
    }

    /**
     * 维修队分析-维修中-总数
     */
    public AjaxResult mtAnalysisSum4(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtAnalysisSum4(mtAnalysisPageableDto));
    }

    /**
     * 导出维修队分析
     */
    @ApiOperation("导出维修队分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtAnalysis')")
    @PostMapping("/mtAnalysisExport")
    public AjaxResult mtAnalysisExport(@RequestBody MtAnalysisPageableDto mtAnalysisPageableDto) {
        switch(mtAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                List<MtAnalysisArtificialDto> list = (List<MtAnalysisArtificialDto>) this.mtAnalysis1(mtAnalysisPageableDto).get("data");
                MtAnalysisArtificialDto mtAnalysisArtificialDto = (MtAnalysisArtificialDto)this.mtAnalysisSum1(mtAnalysisPageableDto).get("data");
                mtAnalysisArtificialDto.setMaintenanceTeamName("总计");
                list.add(mtAnalysisArtificialDto);
                if (!list.isEmpty()) {
                    list.forEach(mtAnalysisArtificial -> {
                        mtAnalysisArtificial.setRepairRateString(mtAnalysisArtificial.getRepairRate() + "%");
                        mtAnalysisArtificial.setSendRateString(mtAnalysisArtificial.getSendRate() + "%");
                        mtAnalysisArtificial.setProjectTitle(mtAnalysisArtificial.getProjectTitle()
                                                            + mtAnalysisArtificial.getArea() + "/"
                                                            + mtAnalysisArtificial.getMaintenanceUnitsName());
                    });
                }
                ExcelUtil<MtAnalysisArtificialDto> util = new ExcelUtil<>(MtAnalysisArtificialDto.class);
                return util.exportExcel(list, "维修队统计分析");
            case CommonConstant.AUTO:
                List<MtAnalysisAutoDto> list2 = (List<MtAnalysisAutoDto>) this.mtAnalysis2(mtAnalysisPageableDto).get("data");
                MtAnalysisAutoDto mtAnalysisAutoDto2 = (MtAnalysisAutoDto)this.mtAnalysisSum2(mtAnalysisPageableDto).get("data");
                mtAnalysisAutoDto2.setMaintenanceTeamName("总计");
                list2.add(mtAnalysisAutoDto2);
                if (!list2.isEmpty()) {
                    list2.forEach(mtAnalysisAuto -> {
                        mtAnalysisAuto.setRepairRateString(mtAnalysisAuto.getRepairRate() + "%");
                        mtAnalysisAuto.setProjectTitle(mtAnalysisAuto.getProjectTitle()
                                                        + mtAnalysisAuto.getArea());
                    });
                }
                ExcelUtil<MtAnalysisAutoDto> util2 = new ExcelUtil<>(MtAnalysisAutoDto.class);
                return util2.exportExcel(list2, "维修队统计分析");
            case CommonConstant.UNDELIVERED:
                List<MtAnalysisUndeliveredDto> list3 = (List<MtAnalysisUndeliveredDto>) this.mtAnalysis3(mtAnalysisPageableDto).get("data");
                MtAnalysisUndeliveredDto mtAnalysisUndeliveredDto3 = (MtAnalysisUndeliveredDto)this.mtAnalysisSum3(mtAnalysisPageableDto).get("data");
                mtAnalysisUndeliveredDto3.setMaintenanceTeamName("总计");
                list3.add(mtAnalysisUndeliveredDto3);
                if (!list3.isEmpty()) {
                    list3.forEach(mtAnalysisUndelivered -> {
                        mtAnalysisUndelivered.setSendRateString(mtAnalysisUndelivered.getSendRate() + "%");
                    });
                }
                ExcelUtil<MtAnalysisUndeliveredDto> util3 = new ExcelUtil<>(MtAnalysisUndeliveredDto.class);
                return util3.exportExcel(list3, "维修队统计分析");
            case CommonConstant.UNDERREPAIR:
                List<MtAnalysisUnderRepairDto> list4 = (List<MtAnalysisUnderRepairDto>) this.mtAnalysis4(mtAnalysisPageableDto).get("data");
                MtAnalysisUnderRepairDto mtAnalysisUnderRepairDto4 = (MtAnalysisUnderRepairDto)this.mtAnalysisSum4(mtAnalysisPageableDto).get("data");
                mtAnalysisUnderRepairDto4.setMaintenanceTeamName("总计");
                list4.add(mtAnalysisUnderRepairDto4);
                if (!list4.isEmpty()) {
                    list4.forEach(mtAnalysisUnderRepair -> {
                        mtAnalysisUnderRepair.setSendRateString(mtAnalysisUnderRepair.getSendRate() + "%");
                    });
                }
                ExcelUtil<MtAnalysisUnderRepairDto> util4 = new ExcelUtil<>(MtAnalysisUnderRepairDto.class);
                return util4.exportExcel(list4, "维修队统计分析");
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }


    /**
     * 维修队长分析
     */
    @ApiOperation("维修队长分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtlAnalysis')")
    @PostMapping("/mtlAnalysis")
    public AjaxResult mtlAnalysis(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        switch (mtlAnalysisPageableDto.getAnalysisType()) {
            case CommonConstant.ARTIFICIAL:
                return this.mtlAnalysis1(mtlAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.mtlAnalysis3(mtlAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtlAnalysis4(mtlAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修队长分析-人工修复
     */
    public AjaxResult mtlAnalysis1(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysis1(mtlAnalysisPageableDto));
    }

    /**
     * 维修队长分析-未派单
     */
    public AjaxResult mtlAnalysis3(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysis3(mtlAnalysisPageableDto));
    }

    /**
     * 维修队长分析-维修中
     */
    public AjaxResult mtlAnalysis4(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysis4(mtlAnalysisPageableDto));
    }

    /**
     * 维修队长分析-总数
     */
    @ApiOperation("维修队长分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtlAnalysis')")
    @PostMapping("/mtlAnalysisSum")
    public AjaxResult mtlAnalysisSum(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        switch (mtlAnalysisPageableDto.getAnalysisType()) {
            case CommonConstant.ARTIFICIAL:
                return this.mtlAnalysisSum1(mtlAnalysisPageableDto);
            case CommonConstant.UNDELIVERED:
                return this.mtlAnalysisSum3(mtlAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtlAnalysisSum4(mtlAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修队长分析-人工修复-总数
     */
    public AjaxResult mtlAnalysisSum1(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysisSum1(mtlAnalysisPageableDto));
    }

    /**
     * 维修队长分析-未派单-总数
     */
    public AjaxResult mtlAnalysisSum3(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysisSum3(mtlAnalysisPageableDto));
    }

    /**
     * 维修队长分析-维修中-总数
     */
    public AjaxResult mtlAnalysisSum4(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtlAnalysisSum4(mtlAnalysisPageableDto));
    }

    /**
     * 导出维修队长分析
     */
    @ApiOperation("导出维修队长分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtlAnalysis')")
    @PostMapping("/mtlAnalysisExport")
    public AjaxResult mtlAnalysisExport(@RequestBody MtlAnalysisPageableDto mtlAnalysisPageableDto) {
        switch(mtlAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                List<MtlAnalysisArtificialDto> list = (List<MtlAnalysisArtificialDto>) this.mtlAnalysis1(mtlAnalysisPageableDto).get("data");
                MtlAnalysisArtificialDto mtlAnalysisArtificialDto = (MtlAnalysisArtificialDto)this.mtlAnalysisSum1(mtlAnalysisPageableDto).get("data");
                mtlAnalysisArtificialDto.setRealName("总计");
                list.add(mtlAnalysisArtificialDto);
                if (!list.isEmpty()) {
                    list.forEach(mtlAnalysisArtificial -> {
                        mtlAnalysisArtificial.setRepairRateString(mtlAnalysisArtificial.getRepairRate() + "%");
                        mtlAnalysisArtificial.setSendRateString(mtlAnalysisArtificial.getSendRate() + "%");
                        mtlAnalysisArtificial.setMaintenanceUnitsName(mtlAnalysisArtificial.getMaintenanceUnitsName() + "/" +
                                                                    mtlAnalysisArtificial.getMaintenanceTeamName());
                    });
                }
                ExcelUtil<MtlAnalysisArtificialDto> util = new ExcelUtil<>(MtlAnalysisArtificialDto.class);
                return util.exportExcel(list, "维修队长统计分析");
            case CommonConstant.UNDELIVERED:
                List<MtlAnalysisUndeliveredDto> list3 = (List<MtlAnalysisUndeliveredDto>) this.mtlAnalysis3(mtlAnalysisPageableDto).get("data");
                MtlAnalysisUndeliveredDto mtlAnalysisUndeliveredDto3 = (MtlAnalysisUndeliveredDto)this.mtlAnalysisSum3(mtlAnalysisPageableDto).get("data");
                mtlAnalysisUndeliveredDto3.setRealName("总计");
                list3.add(mtlAnalysisUndeliveredDto3);
                if (!list3.isEmpty()) {
                    list3.forEach(mtlAnalysisUndelivered -> {
                        mtlAnalysisUndelivered.setSendRateString(mtlAnalysisUndelivered.getSendRate() + "%");
                        mtlAnalysisUndelivered.setMaintenanceUnitsName(mtlAnalysisUndelivered.getMaintenanceUnitsName() + "/" +
                                mtlAnalysisUndelivered.getMaintenanceTeamName());
                    });
                }
                ExcelUtil<MtlAnalysisUndeliveredDto> util3 = new ExcelUtil<>(MtlAnalysisUndeliveredDto.class);
                return util3.exportExcel(list3, "维修队长统计分析");
            case CommonConstant.UNDERREPAIR:
                List<MtlAnalysisUnderRepairDto> list4 = (List<MtlAnalysisUnderRepairDto>) this.mtlAnalysis4(mtlAnalysisPageableDto).get("data");
                MtlAnalysisUnderRepairDto mtlAnalysisUnderRepairDto4 = (MtlAnalysisUnderRepairDto)this.mtlAnalysisSum4(mtlAnalysisPageableDto).get("data");
                mtlAnalysisUnderRepairDto4.setRealName("总计");
                list4.add(mtlAnalysisUnderRepairDto4);
                if (!list4.isEmpty()) {
                    list4.forEach(mtlAnalysisUnderRepair -> {
                        mtlAnalysisUnderRepair.setTimeoutRateString(mtlAnalysisUnderRepair.getTimeoutRate() + "%");
                        mtlAnalysisUnderRepair.setMaintenanceUnitsName(mtlAnalysisUnderRepair.getMaintenanceUnitsName() + "/" +
                                mtlAnalysisUnderRepair.getMaintenanceTeamName());
                    });
                }
                ExcelUtil<MtlAnalysisUnderRepairDto> util4 = new ExcelUtil<>(MtlAnalysisUnderRepairDto.class);
                return util4.exportExcel(list4, "维修队长统计分析");
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修员分析
     */
    @ApiOperation("维修员分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtManAnalysis')")
    @PostMapping("/mtManAnalysis")
    public AjaxResult mtManAnalysis(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        switch (mtManAnalysisPageableDto.getAnalysisType()) {
            case CommonConstant.ARTIFICIAL:
                return this.mtManAnalysis1(mtManAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtManAnalysis4(mtManAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修员分析-人工修复
     */
    public AjaxResult mtManAnalysis1(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtManAnalysis1(mtManAnalysisPageableDto));
    }

    /**
     * 维修员分析-维修中
     */
    public AjaxResult mtManAnalysis4(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtManAnalysis4(mtManAnalysisPageableDto));
    }

    /**
     * 维修员分析-总数
     */
    @ApiOperation("维修员分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtManAnalysis')")
    @PostMapping("/mtManAnalysisSum")
    public AjaxResult mtManAnalysisSum(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        switch (mtManAnalysisPageableDto.getAnalysisType()) {
            case CommonConstant.ARTIFICIAL:
                return this.mtManAnalysisSum1(mtManAnalysisPageableDto);
            case CommonConstant.UNDERREPAIR:
                return this.mtManAnalysisSum4(mtManAnalysisPageableDto);
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 维修员分析-人工修复-总数
     */
    public AjaxResult mtManAnalysisSum1(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtManAnalysisSum1(mtManAnalysisPageableDto));
    }

    /**
     * 维修员分析-维修中-总数
     */
    public AjaxResult mtManAnalysisSum4(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto)
    {
        return AjaxResult.success(this.analysisService.mtManAnalysisSum4(mtManAnalysisPageableDto));
    }

    /**
     * 导出维修员分析
     */
    @ApiOperation("导出维修员分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:mtManAnalysis')")
    @PostMapping("/mtManAnalysisExport")
    public AjaxResult mtManAnalysisExport(@RequestBody MtManAnalysisPageableDto mtManAnalysisPageableDto) {
        switch(mtManAnalysisPageableDto.getAnalysisType()){
            case CommonConstant.ARTIFICIAL:
                List<MtManAnalysisArtificialDto> list = (List<MtManAnalysisArtificialDto>) this.mtManAnalysis1(mtManAnalysisPageableDto).get("data");
                MtManAnalysisArtificialDto mtManAnalysisArtificialDto = (MtManAnalysisArtificialDto)this.mtManAnalysisSum1(mtManAnalysisPageableDto).get("data");
                mtManAnalysisArtificialDto.setRealName("总计");
                list.add(mtManAnalysisArtificialDto);
                if (!list.isEmpty()) {
                    list.forEach(mtManAnalysisArtificial -> {
                        mtManAnalysisArtificial.setRepairRateString(mtManAnalysisArtificial.getRepairRate() + "%");
                        mtManAnalysisArtificial.setMaintenanceUnitsName(mtManAnalysisArtificial.getMaintenanceUnitsName() + "/" +
                                mtManAnalysisArtificial.getMaintenanceTeamName());
                    });
                }
                ExcelUtil<MtManAnalysisArtificialDto> util = new ExcelUtil<>(MtManAnalysisArtificialDto.class);
                return util.exportExcel(list, "维修员统计分析");
            case CommonConstant.UNDERREPAIR:
                List<MtManAnalysisUnderRepairDto> list4 = (List<MtManAnalysisUnderRepairDto>) this.mtManAnalysis4(mtManAnalysisPageableDto).get("data");
                MtManAnalysisUnderRepairDto mtManAnalysisUnderRepairDto4 = (MtManAnalysisUnderRepairDto)this.mtManAnalysisSum4(mtManAnalysisPageableDto).get("data");
                mtManAnalysisUnderRepairDto4.setRealName("总计");
                list4.add(mtManAnalysisUnderRepairDto4);
                if (!list4.isEmpty()) {
                    list4.forEach(mtManAnalysisUnderRepair -> {
                        mtManAnalysisUnderRepair.setTimeoutRateString(mtManAnalysisUnderRepair.getTimeoutRate() + "%");
                        mtManAnalysisUnderRepair.setMaintenanceUnitsName(mtManAnalysisUnderRepair.getMaintenanceUnitsName() + "/" +
                                mtManAnalysisUnderRepair.getMaintenanceTeamName());
                    });
                }
                ExcelUtil<MtManAnalysisUnderRepairDto> util4 = new ExcelUtil<>(MtManAnalysisUnderRepairDto.class);
                return util4.exportExcel(list4, "维修员统计分析");
            default:
                return AjaxResult.error("分析类型不存在");
        }
    }

    /**
     * 设备厂家分析
     */
    @ApiOperation("设备厂家分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:equAnalysis')")
    @PostMapping("/equAnalysis")
    public AjaxResult equAnalysis(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {
        return AjaxResult.success(this.analysisService.equAnalysis(equAnalysisPageableDto));
    }

    /**
     * 设备厂家分析-总数
     */
    @ApiOperation("设备厂家分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:equAnalysis')")
    @PostMapping("/equAnalysisSum")
    public AjaxResult equAnalysisSum(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {
        return AjaxResult.success(this.analysisService.equAnalysisSum(equAnalysisPageableDto));
    }

    /**
     * 导出设备厂家分析
     */
    @ApiOperation("导出设备厂家分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:equAnalysis')")
    @PostMapping("/equAnalysisExport")
    public AjaxResult equAnalysisExport(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {

        List<EquAnalysis1Dto> list = this.analysisService.equAnalysis(equAnalysisPageableDto);
        EquAnalysis1Dto equAnalysis1Dto = this.analysisService.equAnalysisSum(equAnalysisPageableDto);
        equAnalysis1Dto.setManufacturer("总计");
        list.add(equAnalysis1Dto);
        if (!list.isEmpty()) {
            list.forEach(equAnalysis -> {
                equAnalysis.setFaultRateString(equAnalysis.getFaultRate() + "%");
            });
        }
        ExcelUtil<EquAnalysis1Dto> util = new ExcelUtil<>(EquAnalysis1Dto.class);
        return util.exportExcel(list, "设备厂家统计分析");
    }

    /**
     * 网络运营商分析
     */
    @ApiOperation("网络运营商分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:networkOperators')")
    @PostMapping("/networkOperators")
    public AjaxResult networkOperators(@RequestBody NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.networkOperators(networkOperatorsPageableDto));
    }

    /**
     * 网络运营商分析-总数
     */
    @ApiOperation("网络运营商分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:networkOperators')")
    @PostMapping("/networkOperatorsSum")
    public AjaxResult networkOperatorsSum(@RequestBody NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.networkOperatorsSum(networkOperatorsPageableDto));
    }

    /**
     * 导出网络运营商分析
     */
    @ApiOperation("导出网络运营商分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:networkOperators')")
    @PostMapping("/networkOperatorsExport")
    public AjaxResult networkOperatorsExport(@RequestBody NetworkOperatorsPageableDto networkOperatorsPageableDto) {

        List<NetworkOperators1Dto> list = this.analysisService.networkOperators(networkOperatorsPageableDto);
        NetworkOperators1Dto networkOperators1Dto = this.analysisService.networkOperatorsSum(networkOperatorsPageableDto);
        networkOperators1Dto.setProjectTitle("总计");
        list.add(networkOperators1Dto);
        ExcelUtil<NetworkOperators1Dto> util = new ExcelUtil<>(NetworkOperators1Dto.class);
        return util.exportExcel(list, "网络运营商统计分析");
    }

    /**
     * 电力运营商分析
     */
    @ApiOperation("电力运营商分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:powerOperators')")
    @PostMapping("/powerOperators")
    public AjaxResult powerOperators(@RequestBody PowerOperatorsPageableDto powerOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.powerOperators(powerOperatorsPageableDto));
    }

    /**
     * 电力运营商分析-总数
     */
    @ApiOperation("电力运营商分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:powerOperators')")
    @PostMapping("/powerOperatorsSum")
    public AjaxResult powerOperatorsSum(@RequestBody PowerOperatorsPageableDto powerOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.powerOperatorsSum(powerOperatorsPageableDto));
    }

    /**
     * 导出电力运营商分析
     */
    @ApiOperation("导出电力运营商分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:powerOperators')")
    @PostMapping("/powerOperatorsExport")
    public AjaxResult powerOperatorsExport(@RequestBody PowerOperatorsPageableDto powerOperatorsPageableDto) {

        List<PowerOperators1Dto> list = this.analysisService.powerOperators(powerOperatorsPageableDto);
        PowerOperators1Dto powerOperators1Dto = this.analysisService.powerOperatorsSum(powerOperatorsPageableDto);
        powerOperators1Dto.setProjectTitle("总计");
        list.add(powerOperators1Dto);
        ExcelUtil<PowerOperators1Dto> util = new ExcelUtil<>(PowerOperators1Dto.class);
        return util.exportExcel(list, "电力运营商统计分析");
    }

    /**
     * 派单员分析
     */
    @ApiOperation("派单员分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:dispatcher')")
    @PostMapping("/dispatcher")
    public AjaxResult dispatcher(@RequestBody DispatcherPageableDto dispatcherPageableDto) {
        return AjaxResult.success(this.analysisService.dispatcher(dispatcherPageableDto));
    }

    /**
     * 派单员分析-总数
     */
    @ApiOperation("派单员分析-总数")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:dispatcher')")
    @PostMapping("/dispatcherSum")
    public AjaxResult dispatcherSum(@RequestBody DispatcherPageableDto dispatcherPageableDto) {
        return AjaxResult.success(this.analysisService.dispatcherSum(dispatcherPageableDto));
    }

    /**
     * 导出派单员分析
     */
    @ApiOperation("导出派单员分析")
    @PreAuthorize("@ss.hasPermi('hsw:analysis:dispatcher')")
    @PostMapping("/dispatcherExport")
    public AjaxResult dispatcherExport(@RequestBody DispatcherPageableDto dispatcherPageableDto) {

        List<Dispatcher1Dto> list = this.analysisService.dispatcher(dispatcherPageableDto);
        Dispatcher1Dto dispatcher1Dto = this.analysisService.dispatcherSum(dispatcherPageableDto);
        dispatcher1Dto.setRealName("总计");
        list.add(dispatcher1Dto);
        if (!list.isEmpty()) {
            list.forEach(dispatcher -> {
                dispatcher.setSendRateString(dispatcher.getSendRate() + "%");
            });
        }
        ExcelUtil<Dispatcher1Dto> util = new ExcelUtil<>(Dispatcher1Dto.class);
        return util.exportExcel(list, "派单员统计分析");
    }

    /**
     * 工单记录-列表
     */
    @ApiOperation("工单记录-列表")
    @PostMapping("/ordersList")
    public TableDataInfo ordersList(@RequestBody OrdersPageableDto ordersPageableDto) {
        startPage();
        List<JobViewDto> list = this.analysisService.ordersList(ordersPageableDto);
        return getDataTable(list);
    }

    /**
     * 工单记录-饼状图
     */
    @ApiOperation("工单记录-饼状图")
    @PostMapping("/ordersPieChart")
    public AjaxResult ordersPieChart(@RequestBody OrdersPageableDto ordersPageableDto) {
        return AjaxResult.success(this.analysisService.ordersPieChart(ordersPageableDto));
    }

    /**
     * 派单记录-列表
     */
    @ApiOperation("派单记录-列表")
    @PostMapping("/sendOrdersList")
    public TableDataInfo sendOrdersList(@RequestBody OrdersPageableDto ordersPageableDto) {
        startPage();
        List<JobViewDto> list = this.analysisService.sendOrdersList(ordersPageableDto);
        return getDataTable(list);
    }

    /**
     * 派单记录-饼状图
     */
    @ApiOperation("派单记录-饼状图")
    @PostMapping("/sendOrdersPieChart")
    public AjaxResult sendOrdersPieChart(@RequestBody OrdersPageableDto ordersPageableDto) {
        return AjaxResult.success(this.analysisService.sendOrdersPieChart(ordersPageableDto));
    }

    /**
     * 自动恢复记录-列表
     */
    @ApiOperation("自动恢复记录-列表")
    @PostMapping("/autoRepairFaultList")
    public TableDataInfo autoRepairFaultList(@RequestBody OrdersPageableDto ordersPageableDto) {
        startPage();
        List<FaultViewDto> list = this.analysisService.autoRepairFaultList(ordersPageableDto);
        return getDataTable(list);
    }

    /**
     * 自动恢复记录-饼状图
     */
    @ApiOperation("自动恢复记录-饼状图")
    @PostMapping("/autoRepairFaultPieChart")
    public AjaxResult autoRepairFaultPieChart(@RequestBody OrdersPageableDto ordersPageableDto) {
        return AjaxResult.success(this.analysisService.autoRepairFaultPieChart(ordersPageableDto));
    }

    /**
     * 未派单记录-列表
     */
    @ApiOperation("未派单记录-列表")
    @PostMapping("/noSendFaultList")
    public TableDataInfo noSendFaultList(@RequestBody OrdersPageableDto ordersPageableDto) {
        startPage();
        List<FaultViewDto> list = this.analysisService.noSendFaultList(ordersPageableDto);
        return getDataTable(list);
    }

    /**
     * 未派单记录-饼状图
     */
    @ApiOperation("未派单记录-饼状图")
    @PostMapping("/noSendFaultPieChart")
    public AjaxResult noSendFaultPieChart(@RequestBody OrdersPageableDto ordersPageableDto) {
        return AjaxResult.success(this.analysisService.noSendFaultPieChart(ordersPageableDto));
    }

    /**
     * 维修中记录-列表
     */
    @ApiOperation("维修中记录-列表")
    @PostMapping("/underRepairList")
    public TableDataInfo underRepairList(@RequestBody OrdersPageableDto ordersPageableDto) {
        startPage();
        List<JobViewDto> list = this.analysisService.underRepairList(ordersPageableDto);
        return getDataTable(list);
    }

    /**
     * 维修中记录-饼状图
     */
    @ApiOperation("维修中记录-饼状图")
    @PostMapping("/underRepairPieChart")
    public AjaxResult underRepairPieChart(@RequestBody OrdersPageableDto ordersPageableDto) {
        return AjaxResult.success(this.analysisService.underRepairPieChart(ordersPageableDto));
    }

    /**
     * 设备-故障设备记录-列表
     */
    @ApiOperation("设备-故障设备记录-列表")
    @PostMapping("/faultDevicesList")
    public TableDataInfo faultDevicesList(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {
        startPage();
        if ("光纤收发器".equals(equAnalysisPageableDto.getDeviceType())) {
            List<FaultOpticalTransceiverDto> list = this.analysisService.faultDevicesList(equAnalysisPageableDto);
            return getDataTable(list);
        } else {
            List<FaultCameraDto> list = this.analysisService.faultDevicesCameraList(equAnalysisPageableDto);
            return getDataTable(list);
        }
    }

    /**
     * 设备-故障设备记录-设备类型-饼状图
     */
    @ApiOperation("设备-故障设备记录-设备类型-饼状图")
    @PostMapping("/faultDevicesTypePieChart")
    public AjaxResult faultDevicesTypePieChart(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {
        return AjaxResult.success(this.analysisService.faultDevicesTypePieChart(equAnalysisPageableDto));
    }

    /**
     * 设备-故障设备记录-维修效率-饼状图
     */
    @ApiOperation("设备-故障设备记录-维修效率-饼状图")
    @PostMapping("/faultDevicesPieChart")
    public AjaxResult faultDevicesPieChart(@RequestBody EquAnalysisPageableDto equAnalysisPageableDto) {
        return AjaxResult.success(this.analysisService.faultDevicesPieChart(equAnalysisPageableDto));
    }

    /**
     * 网络运营商故障记录-列表
     */
    @ApiOperation("网络运营商故障记录-列表")
    @PostMapping("/netWorkFaultList")
    public TableDataInfo netWorkFaultList(@RequestBody NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        startPage();
        List<FaultProjectDto> list = this.analysisService.netWorkFaultList(networkOperatorsPageableDto);
        return getDataTable(list);
    }

    /**
     * 网络运营商故障记录-饼状图
     */
    @ApiOperation("网络运营商故障记录-饼状图")
    @PostMapping("/netWorkFaultPieChart")
    public AjaxResult netWorkFaultPieChart(@RequestBody NetworkOperatorsPageableDto networkOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.netWorkFaultPieChart(networkOperatorsPageableDto));
    }

    /**
     * 电力运营商故障记录-列表
     */
    @ApiOperation("电力运营商故障记录-列表")
    @PostMapping("/powerCompanyFaultList")
    public TableDataInfo powerCompanyFaultList(@RequestBody PowerOperatorsPageableDto powerOperatorsPageableDto) {
        startPage();
        List<FaultProjectDto> list = this.analysisService.powerCompanyFaultList(powerOperatorsPageableDto);
        return getDataTable(list);
    }

    /**
     * 电力运营商故障记录-饼状图
     */
    @ApiOperation("电力运营商故障记录-饼状图")
    @PostMapping("/powerCompanyFaultPieChart")
    public AjaxResult powerCompanyFaultPieChart(@RequestBody PowerOperatorsPageableDto powerOperatorsPageableDto) {
        return AjaxResult.success(this.analysisService.powerCompanyFaultPieChart(powerOperatorsPageableDto));
    }

    /**
     * 派单员派单记录-列表
     */
    @ApiOperation("派单员派单记录-列表")
    @PostMapping("/senderOrderList")
    public TableDataInfo senderOrderList(@RequestBody DispatcherPageableDto dispatcherPageableDto) {
        startPage();
        List<JobViewDto> list = this.analysisService.senderOrderList(dispatcherPageableDto);
        return getDataTable(list);
    }

    /**
     * 派单员派单记录-饼状图
     */
    @ApiOperation("派单员派单记录-饼状图")
    @PostMapping("/senderOrderPieChart")
    public AjaxResult senderOrderPieChart(@RequestBody DispatcherPageableDto dispatcherPageableDto) {
        return AjaxResult.success(this.analysisService.senderOrderPieChart(dispatcherPageableDto));
    }
}
