package com.ruoyi.web.controller.hsw;

import java.util.List;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.core.domain.model.LoginUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.web.service.TokenService;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.hsw.domain.HswOpticalTransceiver;
import com.ruoyi.hsw.service.IHswOpticalTransceiverService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * 光纤收发器Controller
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Api("光纤收发器管理")
@RestController
@RequestMapping("/hsw/opticalTransceiver")
public class HswOpticalTransceiverController extends BaseController {
    @Autowired
    private IHswOpticalTransceiverService hswOpticalTransceiverService;

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询光纤收发器列表
     */
    @ApiOperation("查询光纤收发器列表")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswOpticalTransceiver hswOpticalTransceiver) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswOpticalTransceiver.setPids(pids);

        startPage();
        List<HswOpticalTransceiver> list = hswOpticalTransceiverService.selectHswOpticalTransceiverList(hswOpticalTransceiver);
        return getDataTable(list);
    }

    /**
     * 导出光纤收发器列表
     */
    @ApiOperation("导出光纤收发器列表")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:export')")
    @Log(title = "光纤收发器", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswOpticalTransceiver hswOpticalTransceiver) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswOpticalTransceiver.setPids(pids);

        List<HswOpticalTransceiver> list = hswOpticalTransceiverService.selectHswOpticalTransceiverList(hswOpticalTransceiver);
        ExcelUtil<HswOpticalTransceiver> util = new ExcelUtil<HswOpticalTransceiver>(HswOpticalTransceiver.class);
        return util.exportExcel(list, "光纤收发器列表");
    }

    /**
     * 获取光纤收发器详细信息
     */
    @ApiOperation("获取光纤收发器详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswOpticalTransceiverService.selectHswOpticalTransceiverById(id));
    }

    /**
     * 新增光纤收发器
     */
    @ApiOperation("新增光纤收发器")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:add')")
    @Log(title = "光纤收发器", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody HswOpticalTransceiver hswOpticalTransceiver) {
        if (UserConstants.NOT_UNIQUE.equals(hswOpticalTransceiverService.checkIpUnique(hswOpticalTransceiver))) {
            return AjaxResult.error("新增失败" + hswOpticalTransceiver.getIp() + "的诊断器已存在光纤收发器");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswOpticalTransceiver.getIp()))) {
            return AjaxResult.error("新增光纤收发器失败，所属诊断器ip'" + hswOpticalTransceiver.getIp() + "'不存在");
        }

        hswOpticalTransceiver.setCreateBy(SecurityUtils.getUsername());
        hswOpticalTransceiver.setInstallTime(DateUtils.getDateMr(hswOpticalTransceiver.getInstallDate()));
        return toAjax(hswOpticalTransceiverService.insertHswOpticalTransceiver(hswOpticalTransceiver));
    }

    /**
     * 修改光纤收发器
     */
    @ApiOperation("修改光纤收发器")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:edit')")
    @Log(title = "光纤收发器", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody HswOpticalTransceiver hswOpticalTransceiver) {
        if (UserConstants.NOT_UNIQUE.equals(hswOpticalTransceiverService.checkIpUnique(hswOpticalTransceiver))) {
            return AjaxResult.error("修改失败" + hswOpticalTransceiver.getIp() + "的诊断器已存在光纤收发器");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswOpticalTransceiver.getIp()))) {
            return AjaxResult.error("修改光纤收发器失败，所属诊断器ip'" + hswOpticalTransceiver.getIp() + "'不存在");
        }

        hswOpticalTransceiver.setUpdateBy(SecurityUtils.getUsername());
        hswOpticalTransceiver.setInstallTime(DateUtils.getDateMr(hswOpticalTransceiver.getInstallDate()));
        return toAjax(hswOpticalTransceiverService.updateHswOpticalTransceiver(hswOpticalTransceiver));
    }

    /**
     * 删除光纤收发器
     */
    @ApiOperation("删除光纤收发器")
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:remove')")
    @Log(title = "光纤收发器", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswOpticalTransceiverService.deleteHswOpticalTransceiverByIds(ids));
    }

    /**
     * 下载导入模板
     *
     * @return
     */
    @ApiOperation("下载导入模板")
    @GetMapping("/importTemplate")
    public AjaxResult importTemplate() {
        ExcelUtil<HswOpticalTransceiver> util = new ExcelUtil<HswOpticalTransceiver>(HswOpticalTransceiver.class);
        return util.importTemplateExcel("光纤收发器数据");
    }

    /**
     * 导入excel
     *
     * @param file 导入的excel文件
     * @return
     * @throws Exception
     */
    @ApiOperation("导入excel")
    @Log(title = "光纤收发器", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception {

        if (StringUtils.isNull(file)) {
            return AjaxResult.error("导入失败，导入文件不能为空");
        }

        ExcelUtil<HswOpticalTransceiver> util = new ExcelUtil<HswOpticalTransceiver>(HswOpticalTransceiver.class);
        List<HswOpticalTransceiver> hswOpticalTransceiverList = util.importExcel(file.getInputStream());
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String operName = loginUser.getUsername();

        int failureNum = 1;
        StringBuilder failureMsg = new StringBuilder();
        String resultMsg;
        for (HswOpticalTransceiver opticalTransceiver : hswOpticalTransceiverList) {
            failureNum++;
            resultMsg = hswOpticalTransceiverService.checkValid(opticalTransceiver, hswOpticalTransceiverList);
            if (StringUtils.isNotEmpty(resultMsg)) {
                failureMsg.append("<br/>第" + failureNum + "项" + resultMsg);
            }
        }

        if (StringUtils.isNotEmpty(failureMsg.toString())) {
            return AjaxResult.error(failureMsg.toString());
        }

        String message = hswOpticalTransceiverService.importOpticalTransceiver(hswOpticalTransceiverList, operName);
        return AjaxResult.success(message);
    }

    /**
     * 根据所属诊断器ip获取光纤收发器详细信息
     */
    @ApiOperation("根据所属诊断器ip获取光纤收发器详细信息")
//    @PreAuthorize("@ss.hasPermi('hsw:opticalTransceiver:queryByIp')")
    @GetMapping(value = "/getInfoByIp/{ip}")
    public AjaxResult getInfoByIp(@PathVariable("ip") String ip) {
        return AjaxResult.success(hswOpticalTransceiverService.selectOpticalTransceiverByIp(ip));
    }
}
