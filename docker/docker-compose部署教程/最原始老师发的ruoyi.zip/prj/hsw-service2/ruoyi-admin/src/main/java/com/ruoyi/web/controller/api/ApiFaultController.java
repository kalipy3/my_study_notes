package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.commonEnum.FaultTypeEnum;
import com.ruoyi.hsw.commonEnum.HandleStatusEnum;
import com.ruoyi.hsw.commonEnum.JobStatusEnum;
import com.ruoyi.hsw.constant.CommonSms;
import com.ruoyi.hsw.domain.*;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.service.ISysConfigService;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysUserService;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@Api("故障相关")
@RestController
@RequestMapping("/api/fault")
public class ApiFaultController extends BaseController {
    @Autowired
    private IHswFaultInfoService faultInfoService;

    @Autowired
    private IHswJobInfoService jobInfoService;

    @Autowired
    private IHswCameraService cameraService;

    @Autowired
    private IHswDiagnosisDeviceService diagnosisDeviceService;

    @Autowired
    private IHswOpticalTransceiverService opticalTransceiverService;

    @Autowired
    private IHswProjectService projectService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private IHswJobLogService jobLogService;

    @Autowired
    private IHswConstructingUnitsService constructingUnitsService;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private IHswUserMsgService userMsgService;

    @Autowired
    private IHswSysMsgService sysMsgService;

    @Autowired
    private ISmsService smsService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    /**
     * 活动故障 动态搜索条件：所属项目、时间范围、故障类型、故障状态
     */
    @ApiOperation("活动故障")
    @GetMapping("/activeFault")
    public TableDataInfo activeFault(@RequestParam(required = false) Long pid, @RequestParam(required = false) String reportrange, @RequestParam(required = false) Integer type, @RequestParam(required = false) Integer status, @RequestParam(required = false) String fuzzy) {
        ActiveFaultPageableDto activeFaultPageableDto = new ActiveFaultPageableDto();
        activeFaultPageableDto.setPid(pid);
        activeFaultPageableDto.setType(type);
        activeFaultPageableDto.setStatus(status);
        activeFaultPageableDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);
        activeFaultPageableDto.setFuzzy(fuzzy);

        if (StringUtils.isNotBlank(reportrange)) {
            String[] reportranges = reportrange.split("~");
            activeFaultPageableDto.setStarttime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd hh:mm:ss", reportranges[0] + " 00:00:00")));
            activeFaultPageableDto.setEndtime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd hh:mm:ss", reportranges[1] + " 23:59:59")));
        }

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        sysUser = this.sysUserService.selectUserById(sysUser.getUserId());
        //1=系统管理员；2=建设单位用户；3=运维单位用户
        switch (sysUser.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM://系统管理员用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(null);//运维单位
                activeFaultPageableDto.setCuId(null);//建设单位
                break;
            case CommonConstant.USER_TYPE_CU://建设单位用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(null);//运维单位
                activeFaultPageableDto.setCuId(sysUser.getConstructingUnitsId());//建设单位

                break;
            case CommonConstant.USER_TYPE_MU://运维单位用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(sysUser.getMaintenanceUnitsId());//运维单位
                activeFaultPageableDto.setCuId(null);//建设单位

                // 只有维修员用户才需要过滤自己的工单
                if (sysUser.getRoles().stream().anyMatch(r -> r.getRoleId().equals(CommonConstant.ROLE_MAINTENANCE_MAN))) {
                    activeFaultPageableDto.setReceiverId(sysUser.getUserId());
                }

                break;
            default:
                break;
        }

        startPage();
        List<FaultViewDto> list = this.faultInfoService.selectFaultViewListForApp(activeFaultPageableDto);
        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        for (FaultViewDto faultViewDto : list) {
            Date takeTime = DateUtils.parseSecondsToDate(faultViewDto.getTakeTime());
            faultViewDto.setTakeTimeStr(DateUtils.datetimeToStr(takeTime));
            Long currentTime = DateUtils.parseDateToSeconds(new Date());
            // 已发生时长
            faultViewDto.setTakeTimeHour(DateUtils.getHoursStrOrMinutesStr(currentTime - faultViewDto.getTakeTime()));

            faultViewDto.setStatusText(JobView.getStatusTextForApp(sysDictDataList, Integer.valueOf(faultViewDto.getStatus())));
            faultViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, Integer.valueOf(faultViewDto.getType())));
            faultViewDto.setUserType(sysUser.getType());
            faultViewDto.setGroupId(sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L);
            if (StringUtils.isNotBlank(faultViewDto.getJobNo())) {
                JobViewDto jobViewDto = new JobViewDto();
                jobViewDto.setFaultId(faultViewDto.getId());
                List<JobViewDto> jobViewDtos = this.jobInfoService.selectJobViewList(jobViewDto);
                jobViewDto = jobViewDtos.size() > 0 ? jobViewDtos.get(0) : null;
                if (jobViewDto != null) {
                    if (jobViewDto.getHangUpTime() > 0) {
                        jobViewDto.setHangupTimeStr(DateUtils.datetimeToStr(jobViewDto.getHangUpTime()));
                        jobViewDto.setHangUpTimeHour(DateUtils.getHoursStrOrMinutesStr(currentTime - jobViewDto.getHangUpTime())); //已挂起时长
                    }
                    if (jobViewDto.getSendTime() > 0) {
                        jobViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(currentTime - jobViewDto.getSendTime())); //已维修时长
                    }
                }

                faultViewDto.setWorkOrder(jobViewDto);
            } else {
                faultViewDto.setWorkOrder(null);
            }
        }

        return getDataTable(list);
    }

    /**
     * 历史故障  动态搜索条件：所属项目、时间范围、故障类型、故障状态
     */
    @ApiOperation("历史故障")
    @GetMapping("/historicalFault")
    public TableDataInfo historicalFault(@RequestParam(required = false) Long pid, @RequestParam(required = false) String reportrange, @RequestParam(required = false) Integer type, @RequestParam(required = false) Integer status, @RequestParam(required = false) String fuzzy) {
        ActiveFaultPageableDto activeFaultPageableDto = new ActiveFaultPageableDto();
        activeFaultPageableDto.setPid(pid);
        activeFaultPageableDto.setType(type);
        activeFaultPageableDto.setStatus(status);
        activeFaultPageableDto.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY);
        activeFaultPageableDto.setFuzzy(fuzzy);

        if (StringUtils.isNotBlank(reportrange)) {
            String[] reportranges = reportrange.split("~");
            activeFaultPageableDto.setStarttime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd hh:mm:ss", reportranges[0] + " 00:00:00")));
            activeFaultPageableDto.setEndtime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd hh:mm:ss", reportranges[1] + " 23:59:59")));
        }

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();

        //1=系统管理员；2=维修管理员；3=维修人员
        switch (sysUser.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM://系统管理员用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(null);//运维单位
                activeFaultPageableDto.setCuId(null);//建设单位
                break;
            case CommonConstant.USER_TYPE_CU://建设单位用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(null);//运维单位
                activeFaultPageableDto.setCuId(sysUser.getConstructingUnitsId());//建设单位

                break;
            case CommonConstant.USER_TYPE_MU://运维单位用户
                activeFaultPageableDto.setMtId(null);//维修队
                activeFaultPageableDto.setMuId(sysUser.getMaintenanceUnitsId());//运维单位
                activeFaultPageableDto.setCuId(null);//建设单位

                // 只有维修员用户才需要过滤自己的工单
                if (sysUser.getRoles().stream().anyMatch(r -> r.getRoleId().equals(CommonConstant.ROLE_MAINTENANCE_MAN))) {
                    activeFaultPageableDto.setReceiverId(sysUser.getUserId());
                }

                break;
            default:
                break;
        }

        startPage();
        List<FaultViewDto> list = this.faultInfoService.selectFaultViewListForApp(activeFaultPageableDto);
        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        for (FaultViewDto faultViewDto : list) {
            faultViewDto.setTakeTimeStr(DateUtils.datetimeToStr(faultViewDto.getTakeTime()));
            faultViewDto.setRepairTimeStr(DateUtils.datetimeToStr(faultViewDto.getRepairTime())); // 修复时间
            faultViewDto.setStatusText(JobView.getStatusTextForApp(sysDictDataList, Integer.valueOf(faultViewDto.getStatus())));
            faultViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, Integer.valueOf(faultViewDto.getType())));
            faultViewDto.setUserType(sysUser.getType());
            faultViewDto.setGroupId(sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L);

            if (StringUtils.isNotBlank(faultViewDto.getJobNo())) {
                JobViewDto jobViewDto = new JobViewDto();
                jobViewDto.setFaultId(faultViewDto.getId());
                List<JobViewDto> jobViewDtos = this.jobInfoService.selectJobViewList(jobViewDto);
                jobViewDto = jobViewDtos.size() > 0 ? jobViewDtos.get(0) : null;
                faultViewDto.setWorkOrder(jobViewDto);
            } else {
                faultViewDto.setWorkOrder(null);
            }

            switch (faultViewDto.getStatus()) {
                case CommonConstant.FAULT_ARTIFICIAL://人工修复
                    if (faultViewDto.getWorkOrder() != null) {
                        JobViewDto jobViewDto = faultViewDto.getWorkOrder();
                        faultViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(jobViewDto.getRepairTime() - jobViewDto.getSendTime()));
                    } else {
                        faultViewDto.setRepairTimeHour("--");
                    }

                    break;
                case CommonConstant.FAULT_AUTO:
                    Long seconds = faultViewDto.getRepairTime() - faultViewDto.getTakeTime();
                    faultViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStrOrSecondsstr(seconds));
                    break;//自动恢复
                case CommonConstant.FAULT_CANCELLED:
                    faultViewDto.setRepairTimeHour("--");
                    break;//已撤单
            }

            //考虑自动修复的情况
        }

        return getDataTable(list);
    }

    @ApiOperation("取摄像头信息")
    @GetMapping("/cameraInfo")
    public AjaxResult cameraInfo(@RequestParam(value = "id", required = false) Long id,
                                 @RequestParam(value = "ip", required = false) String ip,
                                 @RequestParam(value = "port", required = false) Integer port) {

        CameraViewDto cameraViewDto;
        if (id != null) {
            cameraViewDto = this.cameraService.selectCameraViewById(id);
        } else {
            cameraViewDto = this.cameraService.selectCameraViewByIpAndPortForApp(ip, port);
        }

        if (cameraViewDto != null) {
            Date installTime = new Date(cameraViewDto.getInstallTime());
            cameraViewDto.setInstallTimeStr(DateUtils.datetimeToStr(installTime));
            return AjaxResult.success(cameraViewDto);
        } else {
            return AjaxResult.error("未找到该设备信息");
        }
    }

    @ApiOperation("诊断器设备信息")
    @GetMapping("/diagnosisDeviceInfo")
    public AjaxResult diagnosisDeviceInfo(@RequestParam(value = "id", required = false) Long id,
                                          @RequestParam(value = "ip", required = false) String ip) {
        DiagnosisDeviceViewDto diagnosisDeviceViewDto;
        if (id != null) {
            diagnosisDeviceViewDto = diagnosisDeviceService.selectDiagnosisDeviceViewById(id);

        } else {
            diagnosisDeviceViewDto = diagnosisDeviceService.selectDiagnosisDeviceViewByIpForApp(ip);
        }

        if (diagnosisDeviceViewDto != null) {
            diagnosisDeviceViewDto.setInstallTimeStr(DateUtils.datetimeToStr(diagnosisDeviceViewDto.getInstallTime()));
            diagnosisDeviceViewDto.setCode(1);

            diagnosisDeviceViewDto.setUplinkPortText(CommonConstant.UPLINK_PORT_TEXT);
            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_UPLINK_PORT);
            for (SysDictData sysDictData : sysDictDataList) {
                if (sysDictData.getDictValue().equals(diagnosisDeviceViewDto.getUplinkPort().toString())) {
                    diagnosisDeviceViewDto.setUplinkPortText(sysDictData.getDictLabel());
                }
            }

            return AjaxResult.success(diagnosisDeviceViewDto);
        } else {
            return AjaxResult.error("未找到该设备信息");
        }
    }

    @ApiOperation("光端机设备信息")
    @GetMapping("/opticalTransceiverInfo")
    public AjaxResult opticalTransceiverInfo(@RequestParam(value = "id", required = false) Long id,
                                             @RequestParam(value = "ip", required = false) String ip) {
        OpticalTransceiverViewDto opticalTransceiverViewDto;
        if (id != null) {
            opticalTransceiverViewDto = this.opticalTransceiverService.selectOpticalTransceiverViewById(id);
        } else {
            opticalTransceiverViewDto = this.opticalTransceiverService.selectOpticalTransceiverViewByIpForApp(ip);
        }

        if (opticalTransceiverViewDto != null) {
            opticalTransceiverViewDto.setInstallTimeStr(DateUtils.datetimeToStr(opticalTransceiverViewDto.getInstallTime()));
            return AjaxResult.success(opticalTransceiverViewDto);
        } else {
            return AjaxResult.error("未找到该设备信息");
        }
    }

    /**
     * 诊断器列表|监视点列表
     */
    @ApiOperation("诊断器列表|监视点列表")
    @GetMapping("/diagnosisList")
    public TableDataInfo diagnosisList(@RequestParam(required = false) Long pid, @RequestParam(required = false) String fuzzy) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids = this.projectService.getProjectIdsByUser(sysUser);
        DiagnosisDeviceViewDto diagnosisDeviceViewDto = new DiagnosisDeviceViewDto();
        diagnosisDeviceViewDto.setPid(pid);
        diagnosisDeviceViewDto.setFuzzy(fuzzy);
        diagnosisDeviceViewDto.setPids(pids);
        startPage();
        List<DiagnosisDeviceViewDto> diagnosisDeviceViewDtos = this.diagnosisDeviceService.selectDiagnosisDeviceViewList(diagnosisDeviceViewDto);

        diagnosisDeviceViewDtos.forEach(ddv -> {
            Date installTime = new Date(ddv.getInstallTime());
            ddv.setInstallTimeStr(DateUtils.datetimeToStr(installTime));
            ddv.setUserType(sysUser.getType());
            ddv.setUserGroupId(sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L);
        });

        return getDataTable(diagnosisDeviceViewDtos);
    }

    /**
     * 所属项目
     */
    @ApiOperation("所属项目")
    @GetMapping("/getMyProjects")
    public AjaxResult getMyProjects() {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<HswProject> projects = this.projectService.getProjectsByUser(sysUser);
        return AjaxResult.success(projects);
    }

    @ApiOperation("我管理的摄像头")
    @GetMapping("/getMyManagerCameras")
    public AjaxResult getMyManagerCameras() {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids = this.projectService.getProjectIdsByUser(sysUser);
        if (pids.length > 0) {
            CameraViewDto cameraViewDto = new CameraViewDto();
            cameraViewDto.setPids(pids);
            List<CameraViewDto> cameraViewDtos = this.cameraService.selectCameraViewList(cameraViewDto);
            return AjaxResult.success(cameraViewDtos);
        } else {
            return AjaxResult.error("未找到摄像机信息");
        }
    }

    private int getFaultLevel(List<SysDictData> sysDictDatas, Integer type) {
        int level = CommonConstant.FAULT_LEVEL_ZERO;

        if (!sysDictDatas.isEmpty()) {
            for (SysDictData sysDictData : sysDictDatas) {
                if (sysDictData.getDictLabel().equals(type.toString())) {
                    level = Integer.valueOf(sysDictData.getDictValue());
                }
            }
        }

        return level;
    }

    @ApiOperation("getCameraMarker")
    @GetMapping("/getCameraMarker")
    public AjaxResult getCameraMarker() {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids = this.projectService.getProjectIdsByUser(sysUser);
        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setPids(pids);
        List<CameraViewDto> cameraViewDtos = this.cameraService.selectCameraViewList(cameraViewDto);//所管辖的所有摄像机

        FaultViewDto faultViewDto = new FaultViewDto();
        faultViewDto.setPids(pids);
        faultViewDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);

        // 获取故障级别字典
        List<SysDictData> faultLevelDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_LEVEL);

        List<FaultViewDto> faultViewDtos = this.faultInfoService.selectFaultViewList(faultViewDto);
        faultViewDtos.forEach(fault -> {
            if (fault.getInfluenceCameraCount() > 0) {
                if (fault.getPort() == CommonConstant.FAULT_POST) {
                    //该ip下所有摄像机当前都处于故障状态
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                } else {
                    cameraViewDtos.stream().forEach(cv -> {
                        if (fault.getIp().equals(cv.getIp()) && fault.getPort().equals(cv.getPort())) {
                            cv.setIsFault(CommonConstant.IS_FAULT_YES);
                            cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                        }
                    });
                }
            }
        });

        String localCity = "高安市";

        // 项目区域字典
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_PROJECT_AREA);

        for (SysDictData d : sysDictDatas) {
            if (CommonParameter.AREA.equals(d.getDictLabel())) {
                localCity = d.getDictValue();
            }
        }

//        switch (sysUser.getType()) {
//            case CommonConstant.USER_TYPE_SYSTEM://系统管理员
//                localCity = "高安市";
//                break;
//            default:
//                if (pids.length > 0)
//                    localCity = this.projectService.selectHswProjectById(pids[0]).getDistrictLabel();
//                else
//                    localCity = "高安市";
//                break;
//        }

        Map<String, Object> result = new HashMap<>();
        result.put("localCity", localCity);
        result.put("data", cameraViewDtos);
        return AjaxResult.success(cameraViewDtos);
    }

    /**
     * 获取故障的摄像机
     */
    @ApiOperation("获取故障的摄像机")
    @GetMapping("/getMyManagerFaultCameras")
    public AjaxResult getMyManagerFaultCameras() {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids = this.projectService.getProjectIdsByUser(sysUser);
        if (pids.length > 0) {
            FaultViewDto faultViewDto = new FaultViewDto();
            faultViewDto.setPids(pids);
            faultViewDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);
            List<FaultViewDto> faultViewDtos = this.faultInfoService.selectFaultViewList(faultViewDto);
            if (faultViewDtos.size() > 0) {
                return AjaxResult.success(faultViewDtos);
            }
        }

        return AjaxResult.error("未找到摄像机信息");
    }

    /**
     * 根据摄像机ip取得摄像机
     *
     * @param ip
     * @return
     */
    @ApiOperation("getCameras")
    @GetMapping("/getCameras")
    public AjaxResult getCameras(@RequestParam("ip") String ip) {
        List<CameraViewDto> cameraViewDtos = this.cameraService.selectCameraViewListByIpAndPortForApp(ip, null);
        if (!cameraViewDtos.isEmpty()) {
            return AjaxResult.success(cameraViewDtos);
        }

        return AjaxResult.error("未找到摄像机信息");
    }

    /**
     * 故障详情
     */
    @ApiOperation("故障详情")
    @GetMapping("/activeFaultInfo")
    public AjaxResult activeFaultInfo(@RequestParam("id") Long id) {
        FaultViewDto faultViewDto = this.faultInfoService.selectFaultViewById(id);
        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        JobViewDto workOrder = null;
        faultViewDto.setStatusText(JobView.getStatusTextForApp(sysDictDataList, faultViewDto.getStatus()));
        faultViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, faultViewDto.getType()));
        faultViewDto.setTakeTimeText(faultViewDto.getTakeTime() == 0 ? "0" : DateUtils.parseDateToStr("yyyy-MM-dd HH:mm:ss", DateUtils.parseSecondsToDate(faultViewDto.getTakeTime())));
        faultViewDto.setRepairTimeStr(faultViewDto.getRepairTime() == 0 ? "0" : DateUtils.parseDateToStr("yyyy-MM-dd HH:mm:ss", DateUtils.parseSecondsToDate(faultViewDto.getRepairTime())));
        faultViewDto.setZigzagTypeText(JobView.getTypeTextForApp(dictDataList, faultViewDto.getZigzagType()));
        if (StringUtils.isNotBlank(faultViewDto.getJobNo())) {
            JobViewDto jobViewDto = new JobViewDto();
            jobViewDto.setFaultId(faultViewDto.getId());
            List<JobViewDto> jobViewDtos = this.jobInfoService.selectJobViewList(jobViewDto);
            workOrder = jobViewDtos.size() > 0 ? jobViewDtos.get(0) : null;
            workOrder.setHangupTimeStr(DateUtils.parseDateToStr("yyyy-MM-dd HH:mm:ss", DateUtils.parseSecondsToDate((workOrder.getHangUpTime()))));
            Long seconds = DateUtils.parseDateToSeconds(new Date()) - workOrder.getSendTime();
            workOrder.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(seconds)); // 已维修时长

            faultViewDto.setWorkOrder(workOrder);
        } else {
            faultViewDto.setWorkOrder(null);
        }

        switch (faultViewDto.getStatus()) {
            case CommonConstant.FAULT_ARTIFICIAL://人工修复
                if (workOrder != null) {
                    faultViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(workOrder.getRepairTime() - workOrder.getSendTime()));
                } else {
                    faultViewDto.setRepairTimeHour("--");
                }

                break;
            case CommonConstant.FAULT_AUTO:
                faultViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStrOrSecondsstr(faultViewDto.getRepairTime() - faultViewDto.getTakeTime()));
                break;//自动恢复
            case CommonConstant.FAULT_CANCELLED:
                faultViewDto.setRepairTimeHour("--");
                break;//已撤单
        }

        return AjaxResult.success(faultViewDto);
    }

    /**
     * 活动工单
     */
    @ApiOperation("活动工单")
    @GetMapping("/activeJob")
    public TableDataInfo activeJob(
            Long pid,
            Integer status,
            Integer type,
            String fuzzy,
            @RequestParam(required = false) String reportrange) {
        JobViewDto jobViewDtoParam = new JobViewDto();
        jobViewDtoParam.setPid(pid);
        if (HandleStatusEnum.SQGQ.getValue().equals(status)) {
            jobViewDtoParam.setHandleStatus(status);
        } else {
            jobViewDtoParam.setStatus(status);
        }
        jobViewDtoParam.setType(type);
        jobViewDtoParam.setFuzzy(fuzzy);
        if (StringUtils.isNotBlank(reportrange)) {
            String[] times = reportrange.split("~");
            jobViewDtoParam.setStarttime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd HH:mm:ss", times[0] + " 00:00:00")));
            jobViewDtoParam.setEndtime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd HH:mm:ss", times[1] + " 23:59:59")));
        }

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        //1=系统管理员；2=维修管理员；3=维修人员
        Integer userType = sysUser.getType();
        switch (userType) {
            case CommonConstant.USER_TYPE_SYSTEM://系统管理员用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(null);//运维单位
                jobViewDtoParam.setCuId(null);//建设单位
                break;
            case CommonConstant.USER_TYPE_CU://建设单位用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(null);//运维单位
                jobViewDtoParam.setCuId(sysUser.getConstructingUnitsId());//建设单位

                break;
            case CommonConstant.USER_TYPE_MU://运维单位用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(sysUser.getMaintenanceUnitsId());//运维单位
                jobViewDtoParam.setCuId(null);//建设单位

                // 只有维修员用户才需要过滤自己的工单
                if (sysUser.getRoles().stream().anyMatch(r -> r.getRoleId().equals(CommonConstant.ROLE_MAINTENANCE_MAN))) {
                    jobViewDtoParam.setReceiverId(sysUser.getUserId());
                }
                break;
            default:
                break;
        }

        this.startPage();
        jobViewDtoParam.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);
        List<JobViewDto> jobViewDtos = this.jobInfoService.selectJobViewList(jobViewDtoParam);
        List<SysUser> sysUsers = this.sysUserService.selectUserList(new SysUser());
        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        List<SysDictData> handleList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
        for (JobViewDto jobViewDto : jobViewDtos) {
            jobViewDto.setTaketimeStr(DateUtils.datetimeToStr(jobViewDto.getTakeTime()));
            jobViewDto.setSendTimeStr(DateUtils.datetimeToStr(jobViewDto.getSendTime()));
            Long time = DateUtils.parseDateToSeconds(new Date());
            long disTime = time - jobViewDto.getTakeTime();
            jobViewDto.setTaketimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
            disTime = time - jobViewDto.getRepairTime();
            if (jobViewDto.getRepairTime() > 0) {
                jobViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
            }

            String statusText = JobView.getStatusText2ForApp(sysDictDataList, jobViewDto.getStatus());
            if (jobViewDto.getStatus() == JobStatusEnum.YGQ.getValue()) {
                if (jobViewDto.getHangUpTime() > 0) {
                    jobViewDto.setHangupTimeStr(DateUtils.datetimeToStr(jobViewDto.getHangUpTime()));
                    disTime = time - jobViewDto.getHangUpTime();
                    jobViewDto.setHangUpTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
                }
            }

            Map<String, String> optBtns = JobView.optBtns(jobViewDto.getStatus(), jobViewDto.getReceiverId(), jobViewDto.getHandleStatus(), sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L, userType, sysUser.getUserId());
            List<String> otherBtn = new ArrayList<>();
            optBtns.forEach((key, value) -> {
                otherBtn.add("<button type=\"button\" class=\"mui-btn mui-btn-outlined " + key + "\">" + value + "</button>");
            });

            otherBtn.add("<button type=\"button\" class=\"mui-btn mui-btn-outlined mui-btn-primary orderflow\">日志</button>");

            jobViewDto.setOtherBtn(otherBtn.stream().collect(Collectors.joining(" ")));
            jobViewDto.setStatusText(statusText);
            jobViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, jobViewDto.getType()));
            jobViewDto.setHandleStatusText(JobView.getHandleStatusTextForApp(handleList, jobViewDto.getHandleStatus()));

            CameraViewDto cameraViewDto;
            if ((jobViewDto.getType() == FaultTypeEnum.SXJLL.getValue() || jobViewDto.getType() == FaultTypeEnum.SXJ.getValue()) && jobViewDto.getPort() != CommonConstant.FAULT_POST) {
                cameraViewDto = this.cameraService.selectCameraViewByIpAndPortForApp(jobViewDto.getIp(), jobViewDto.getPort());
            } else {
                cameraViewDto = this.cameraService.selectCameraViewByIpAndPortForApp(jobViewDto.getIp(), null);
            }

            if (cameraViewDto != null) {
                jobViewDto.setLng(cameraViewDto.getLongitude());
                jobViewDto.setLat(cameraViewDto.getLatitude());
            } else {
                jobViewDto.setLng("0");
                jobViewDto.setLat("0");
            }

            jobViewDto.setUserType(sysUser.getType());
            jobViewDto.setGroupId(sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L);
            Optional<SysUser> user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getSendUid())).findFirst();
            if (user.isPresent()) {
                jobViewDto.setSender(user.get().getNickName());
            } else {
                jobViewDto.setSender("未知");
            }

            user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getReceiverId())).findFirst();
            if (user.isPresent()) {
                jobViewDto.setReceiver(user.get().getNickName());
            } else {
                jobViewDto.setReceiver("未知");
            }
        }

        return getDataTable(jobViewDtos);
    }

    /**
     * 历史工单
     */
    @ApiOperation("历史工单")
    @GetMapping("/historicalJob")
    public TableDataInfo historicalJob(
            Long pid,
            Integer status,
            Integer type,
            String fuzzy,
            @RequestParam(required = false) String reportrange) {
        JobViewDto jobViewDtoParam = new JobViewDto();
        jobViewDtoParam.setPid(pid);
        jobViewDtoParam.setStatus(status);
        jobViewDtoParam.setType(type);
        jobViewDtoParam.setFuzzy(fuzzy);
        if (StringUtils.isNotBlank(reportrange)) {
            String[] times = reportrange.split("~");
            jobViewDtoParam.setStarttime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd HH:mm:ss", times[0] + " 00:00:00")));
            jobViewDtoParam.setEndtime(DateUtils.parseDateToSeconds(DateUtils.dateTime("yyyy-MM-dd HH:mm:ss", times[1] + " 23:59:59")));
        }

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        //1=系统管理员；2=维修管理员；3=维修人员
        Integer userType = sysUser.getType();
        switch (userType) {
            case CommonConstant.USER_TYPE_SYSTEM://系统管理员用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(null);//运维单位
                jobViewDtoParam.setCuId(null);//建设单位
                break;
            case CommonConstant.USER_TYPE_CU://建设单位用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(null);//运维单位
                jobViewDtoParam.setCuId(sysUser.getConstructingUnitsId());//建设单位

                break;
            case CommonConstant.USER_TYPE_MU://运维单位用户
                jobViewDtoParam.setMtId(null);//维修队
                jobViewDtoParam.setMuId(sysUser.getMaintenanceUnitsId());//运维单位
                jobViewDtoParam.setCuId(null);//建设单位
                //只有维修员用户才需要过滤自己的工单
                if (sysUser.getRoles().stream().anyMatch(r -> r.getRoleId().equals(CommonConstant.ROLE_MAINTENANCE_MAN))) {
                    jobViewDtoParam.setReceiverId(sysUser.getUserId());
                }
                break;
            default:
                break;
        }

        this.startPage();
        jobViewDtoParam.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY);
        List<JobViewDto> jobViewDtos = this.jobInfoService.selectJobViewList(jobViewDtoParam);
        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysUser> sysUsers = this.sysUserService.selectUserList(new SysUser());
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        List<SysDictData> handleList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
        for (JobViewDto jobViewDto : jobViewDtos) {
            jobViewDto.setTaketimeStr(DateUtils.datetimeToStr(jobViewDto.getTakeTime()));
            jobViewDto.setSendTimeStr(DateUtils.datetimeToStr(jobViewDto.getSendTime()));
            if (jobViewDto.getStatus() == JobStatusEnum.YXF.getValue()) {
                jobViewDto.setRepairTimeStr(DateUtils.datetimeToStr(jobViewDto.getRepairTime()));
            } else {
                jobViewDto.setRepairTimeStr("--");
            }

            String statusText = JobView.getStatusText2ForApp(sysDictDataList, jobViewDto.getStatus());
            Map<String, String> optBtns = JobView.optBtns(jobViewDto.getStatus(), jobViewDto.getReceiverId(), jobViewDto.getHandleStatus(), sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L, userType, sysUser.getUserId());
            List<String> otherBtn = new ArrayList<>();
            optBtns.forEach((key, value) -> {
                otherBtn.add("<li><a href=\"/admin/" + key + "?id=" + jobViewDto.getId() + "\" data-target=\"#ajaxForm\" " +
                        "data-toggle=\"modal\" data-backdrop=\"static\"  class=\"accept\" data-jobid=\"" + jobViewDto.getId() + "\">" + value + "</a></li>");
            });

            otherBtn.add("<button type=\"button\" class=\"mui-btn mui-btn-outlined mui-btn-primary orderflow\">日志</button>");

            jobViewDto.setOtherBtn(otherBtn.stream().collect(Collectors.joining(" ")));
            jobViewDto.setStatusText(statusText);
            jobViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, jobViewDto.getType()));
            jobViewDto.setHandleStatusText(JobView.getHandleStatusTextForApp(handleList, jobViewDto.getHandleStatus()));

            long time = DateUtils.parseDateToSeconds(new Date());
            if (jobViewDto.getStatus() == JobStatusEnum.YXF.getValue()) {
                Long disTime = jobViewDto.getRepairTime() - jobViewDto.getSendTime();
                jobViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
            } else {
                jobViewDto.setRepairTimeHour("--");
            }

            CameraViewDto cameraViewDto;
            if ((jobViewDto.getType() == FaultTypeEnum.SXJLL.getValue() || jobViewDto.getType() == FaultTypeEnum.SXJ.getValue()) && jobViewDto.getPort() != CommonConstant.FAULT_POST) {
                cameraViewDto = this.cameraService.selectCameraViewByIpAndPortForApp(jobViewDto.getIp(), jobViewDto.getPort());
            } else {
                cameraViewDto = this.cameraService.selectCameraViewByIpAndPortForApp(jobViewDto.getIp(), null);
            }

            if (cameraViewDto != null) {
                jobViewDto.setLng(cameraViewDto.getLongitude());
                jobViewDto.setLat(cameraViewDto.getLatitude());
            } else {
                jobViewDto.setLng("0");
                jobViewDto.setLat("0");
            }

            jobViewDto.setUserType(sysUser.getType());
            jobViewDto.setGroupId(sysUser.getRoles().size() > 0 ? sysUser.getRoles().get(0).getRoleId() : 0L);

            Optional<SysUser> user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getSendUid())).findFirst();
            if (user.isPresent()) {
                jobViewDto.setSender(user.get().getNickName());
            } else {
                jobViewDto.setSender("未知");
            }

            user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getReceiverId())).findFirst();
            if (user.isPresent()) {
                jobViewDto.setReceiver(user.get().getNickName());
            } else {
                jobViewDto.setReceiver("未知");
            }
        }

        return getDataTable(jobViewDtos);
    }

    /**
     * 工单详情
     */
    @ApiOperation("工单详情")
    @GetMapping("/activeJobInfo")
    public AjaxResult activeJobInfo(@RequestParam Long id) {
        JobViewDto jobViewDto = this.jobInfoService.selectJobViewById(id);
        if (jobViewDto == null) {
            return AjaxResult.error("未找到工单信息记录");
        }

        List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
        List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
        jobViewDto.setStatusText(JobView.getStatusTextForApp(sysDictDataList, jobViewDto.getStatus()));
        jobViewDto.setTypeText(JobView.getTypeTextForApp(dictDataList, jobViewDto.getType()));
        jobViewDto.setTakeTimeText(DateUtils.datetimeToStr(jobViewDto.getTakeTime()));
        jobViewDto.setRepairTimeStr(jobViewDto.getRepairTime() == 0 ? "--" : DateUtils.datetimeToStr(jobViewDto.getRepairTime()));
        jobViewDto.setSendTimeStr(DateUtils.datetimeToStr(jobViewDto.getSendTime()));

        Long time = DateUtils.parseDateToSeconds(new Date());
        Long disTime = time - jobViewDto.getTakeTime();
        jobViewDto.setTaketimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));

        if (jobViewDto.getStatus() == JobStatusEnum.WXZ.getValue()) {
            disTime = time - jobViewDto.getSendTime();
            jobViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
        } else if (jobViewDto.getStatus() == JobStatusEnum.YXF.getValue()) {
            disTime = jobViewDto.getRepairTime() - jobViewDto.getSendTime();
            jobViewDto.setRepairTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
        }

        if (jobViewDto.getStatus() == JobStatusEnum.YGQ.getValue()) {
            jobViewDto.setHangupTimeStr(DateUtils.datetimeToStr(jobViewDto.getHangUpTime()));
            disTime = time - jobViewDto.getHangUpTime();
            jobViewDto.setHangUpTimeHour(DateUtils.getHoursStrOrMinutesStr(disTime));
        }

        jobViewDto.setZigzagTypeText(JobView.getTypeTextForApp(dictDataList, jobViewDto.getZigzagType()));
        List<SysUser> sysUsers = this.sysUserService.selectUserList(new SysUser());
        Optional<SysUser> user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getSendUid())).findFirst();
        if (user.isPresent()) {
            jobViewDto.setSender(user.get().getNickName());
        } else {
            jobViewDto.setSender("未知");
        }

        user = sysUsers.stream().filter(u -> u.getUserId().equals(jobViewDto.getReceiverId())).findFirst();
        if (user.isPresent()) {
            jobViewDto.setReceiver(user.get().getNickName());
        } else {
            jobViewDto.setReceiver("未知");
        }

        return AjaxResult.success(jobViewDto);
    }

    /**
     * 派单
     */
    @ApiOperation("派单")
    @PostMapping("/faultAssign")
    public Map<String, Object> faultAssign(@RequestParam Long id, @RequestParam Long receiverId, @RequestParam(value = "remark", required = false) String remark) {
        SysUser receiverUser = this.sysUserService.selectUserById(receiverId);
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();

        Map<String, Object> result = this.faultInfoService.assignForApp(id, sysUser.getUserId(), receiverId, remark, sysUser.getNickName());
        if (result == null || result.get("code").equals(0)) {
            return result;
        }

        Long cuId = Long.valueOf(result.get("cu_id").toString());
        String jobNo = (String) result.get("job_no");

        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", sysUser.getNickName());
        templateParam.put("job_no", jobNo);

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId().toString());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", jobNo);
        args.put("tpl_key", "TPL_MSG_PD");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                this.smsService.sendSMS(cuId, receiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);
            }
        }

        return AjaxResult.success(result);
    }

    @ApiOperation("派单-取运维队用户列表")
    @GetMapping("/faultAssign")
    public AjaxResult getFaultAssign(@RequestParam Long mtId) {
        SysUser sysUser = new SysUser();
        sysUser.setTeamId(mtId);
        List<SysUser> sysUsers = sysUserService.selectUserList(sysUser);
        return AjaxResult.success(sysUsers);
    }

    @ApiOperation("根据工单id取工单日志清单")
    @GetMapping("/workflow")
    public AjaxResult workflow(@RequestParam Long id) {
        HswJobLog jobLog = new HswJobLog();
        jobLog.setJobId(id);
        List<SysDictData> handleList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
        List<HswJobLog> jobLogs = this.jobLogService.selectHswJobLogList(jobLog)
                .stream().sorted(Comparator.comparingLong(HswJobLog::getHandleTime).reversed()).collect(Collectors.toList());
        jobLogs.forEach(log -> {
            log.setStatusText(JobView.getHandleStatusTextForApp(handleList, log.getHandleStatus()));
            log.setTime(DateUtils.datetimeToStr(log.getHandleTime()));
        });

        return AjaxResult.success(jobLogs);
    }

    @ApiOperation("根据工单id取工单日志最新一条")
    @GetMapping("/lastWorkflow")
    public AjaxResult lastWorkflow(@RequestParam Long id) {
        HswJobLog jobLog = new HswJobLog();
        jobLog.setJobId(id);
        List<SysDictData> handleList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
        List<HswJobLog> jobLogs = this.jobLogService.selectHswJobLogList(jobLog)
                .stream().sorted(Comparator.comparingLong(HswJobLog::getHandleTime).reversed()).collect(Collectors.toList());
        jobLog = jobLogs.size() > 0 ? jobLogs.get(0) : null;
        jobLog.setStatusText(JobView.getHandleStatusTextForApp(handleList, jobLog.getHandleStatus()));
        jobLog.setTime(DateUtils.datetimeToStr(jobLog.getHandleTime()));
        return AjaxResult.success(jobLog);
    }

    /**
     * 改派工单 同意/拒绝
     */
    @ApiOperation("改派工单 同意/拒绝")
    @GetMapping("/reAssign")
    public Map<String, Object> reAssign(@RequestParam Integer ok, @RequestParam Long id, @RequestParam Long receiverId, String reason) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = new HashMap<>();
        if (ok == 1) {//同意需要发送2条推送消息
            SysUser newReceiverUser = this.sysUserService.selectUserById(receiverId);
            res = this.jobInfoService.changeAssignForApp(id, sysUser.getUserId(), receiverId, reason, sysUser.getNickName());
            if (res.get("code").equals(0)) {
                return res;
            }

            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", newReceiverUser.getUserId());
            args.put("receiver_name", newReceiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_PD");
            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), newReceiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);

                    //发送同意申请给原接收者
                    SysUser oldReceiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("oldReceiverId").toString()));
                    args.put("receiver_id", oldReceiverUser.getUserId());
                    args.put("receiver_name", oldReceiverUser.getNickName());
                    args.put("tpl_key", "TPL_MSG_GP_OK");
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), newReceiverUser.getPhonenumber(), "SMS_187746654", templateParam, args);
                }
            }
        } else {
            res = this.jobInfoService.refuseChangeAssignForApp(id, reason, sysUser.getUserId(), sysUser.getNickName());
            if (res.get("code").equals(0)) {
                return res;
            }

            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", reason);

            Map<String, Object> args = new HashMap<>();
            args.put("reason", reason);
            args.put("job_no", res.get("jobNo"));
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_GP_REFUSE");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.REASSIGNMENT_NO, templateParam, args);
                }
            }
        }

        return res;
    }

    /**
     * 申请改派
     */
    @ApiOperation("申请改派")
    @PostMapping("/applyChangeAssign")
    public Map<String, Object> applyChangeAssign(@RequestParam Long id, String handleReason) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = this.jobInfoService.applyChangeAssignForApp(id, sysUser.getUserId(), sysUser.getNickName(), handleReason);
        if (res.get("code").equals(0)) {
            return res;
        }

        SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", sysUser.getNickName());
        templateParam.put("job_no", res.get("jobNo"));
        templateParam.put("reason", handleReason);

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", res.get("jobNo"));
        args.put("tpl_key", "TPL_MSG_SQGP");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                //先发派单消息给新接收者
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.APPLY_REASSIGNMENT, templateParam, args);
            }
        }

        return res;
    }

    /**
     * 申请改派
     */
    @ApiOperation("申请改派-取得改派工单")
    @GetMapping("/applyChangeAssign")
    public AjaxResult getApplyChangeAssign(@RequestParam Long id) {
        JobViewDto jobViewDto = this.jobInfoService.selectJobViewById(id);
        jobViewDto.setStatusText(JobView.getStatusText(jobViewDto.getStatus()));
        jobViewDto.setTypeText(JobView.getTypeText(jobViewDto.getType()));
        jobViewDto.setTaketimeStr(DateUtils.datetimeToStr(jobViewDto.getTakeTime()));
        return AjaxResult.success(jobViewDto);
    }

    /**
     * 申请挂起
     */
    @ApiOperation("申请挂起")
    @PostMapping("/applyHangUp")
    public Map<String, Object> applyHangUp(@RequestParam Long id, String handleReason) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = this.jobInfoService.applyHangUpForApp(id, sysUser.getUserId(), sysUser.getNickName(), handleReason);
        if (res.get("code").equals(0)) {
            return res;
        }

        SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", sysUser.getNickName());
        templateParam.put("job_no", res.get("jobNo"));
        templateParam.put("reason", handleReason);

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", res.get("jobNo"));
        args.put("tpl_key", "TPL_MSG_SQGQ");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                //先发派单消息给新接收者
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.APPLY_HANG_UP, templateParam, args);
            }
        }

        return res;
    }

    @ApiOperation("申请挂起-取得挂起工单")
    @GetMapping("/applyHangUp")
    public AjaxResult getApplyHangUp(@RequestParam Long id) {
        JobViewDto jobViewDto = this.jobInfoService.selectJobViewById(id);
        jobViewDto.setStatusText(JobView.getStatusText(jobViewDto.getStatus()));
        jobViewDto.setTypeText(JobView.getTypeText(jobViewDto.getType()));
        jobViewDto.setTaketimeStr(DateUtils.datetimeToStr(jobViewDto.getTakeTime()));
        return AjaxResult.success(jobViewDto);
    }

    /**
     * 挂起
     */
    @ApiOperation("挂起")
    @PostMapping("/hangUp")
    public Map<String, Object> hangUp(@RequestParam Integer ok, @RequestParam Long id, String reason) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = new HashMap<>();
        if (ok == 1) {
            res = this.jobInfoService.hangUpForApp(id, sysUser.getUserId(), sysUser.getNickName(), reason);
            if (res.get("code").equals(0)) {
                return res;
            }

            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", reason);

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_GQ_OK");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.HANG_UP_YES, templateParam, args);
                }
            }
        } else {
            res = this.jobInfoService.refuseHangUpForApp(id, sysUser.getUserId(), sysUser.getNickName(), reason);
            if (res.get("code").equals(0)) {
                return res;
            }

            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", reason);

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_GQ_REFUSE");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.HANG_UP_NO, templateParam, args);
                }
            }
        }

        return res;
    }

    /**
     * 撤回挂起
     */
    @ApiOperation("撤回挂起")
    @GetMapping("/resume")
    public Map<String, Object> resume(@RequestParam Long id, String reason, @RequestParam Long receiverId) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = this.jobInfoService.resumeForApp(id, sysUser.getUserId(), sysUser.getNickName(), reason, receiverId);
        if (res.get("code").equals(0)) {
            return res;
        }

        SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", sysUser.getNickName());
        templateParam.put("job_no", res.get("jobNo"));

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", res.get("jobNo"));
        args.put("tpl_key", "TPL_MSG_PD");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                //先发派单消息给新接收者
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);
            }
        }

        return res;
    }

    /**
     * 撤销工单
     */
    @ApiOperation("撤销工单")
    @GetMapping("/revoke")
    public Map<String, Object> revoke(@RequestParam Long id, String handleReason) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = this.jobInfoService.revokeForApp(id, sysUser.getUserId(), sysUser.getNickName(), handleReason);
        if (res.get("code").equals(0)) {
            return res;
        }

        SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("job_no", res.get("jobNo"));

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", res.get("jobNo"));
        args.put("tpl_key", "TPL_MSG_CX");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                //先发派单消息给新接收者
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.REVOKE, templateParam, args);
            }
        }

        return res;
    }

    /**
     * 结单
     */
    @ApiOperation("结单")
    @GetMapping("/finishJobInfo")
    public Map<String, Object> finishJobInfo(@RequestParam Long id, String repairRecord) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = this.jobInfoService.repairForApp(id, sysUser.getUserId(), sysUser.getNickName(), repairRecord);
        if (res.get("code").equals(0)) {
            return res;
        }

        SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("time", DateUtils.datetimeToStr(Long.valueOf(res.get("takeTime").toString())));
        templateParam.put("region_name", res.get("regionName"));
        templateParam.put("repair_record", repairRecord);

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", res.get("jobNo"));
        args.put("tpl_key", "TPL_MSG_WC");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                //先发派单消息给新接收者
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.STATEMENT, templateParam, args);
            }
        }

        return res;
    }

    //删除历史故障
    @ApiOperation("删除历史故障")
    @GetMapping("/deleteFault")
    public AjaxResult deleteFault(@RequestParam Long id) {
        this.faultInfoService.deleteHswFaultInfoById(id);
        return AjaxResult.success();
    }

    @ApiOperation("项目的设备报告")
    @GetMapping("/deviceReport")
    public AjaxResult deviceReport(@RequestParam Long pid) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids;
        if (pid != null && pid > 0) {
            pids = new Long[]{pid};
        } else {
            pids = this.projectService.getProjectIdsByUser(sysUser);
        }

        List<DeviceCountDto> deviceCountDtos = this.diagnosisDeviceService.selectDeviceCountList(pids);
        return AjaxResult.success(deviceCountDtos);
    }

    @ApiOperation("故障报告")
    @GetMapping("/faultReport")
    public AjaxResult faultReport(@RequestParam(required = false) String taketime, @RequestParam(required = false) Long pid) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] pids = this.projectService.getProjectIdsByUser(sysUser);
        if (pid != null && pid > 0) {
            pids = new Long[]{pid};
        }

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotBlank(taketime)) {
            dateRange = taketime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime();
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime();
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime();
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime();
        }

        startTime = startTime / 1000;
        endTime = endTime / 1000;

        List<FaultReportDto> faultReports = this.faultInfoService.selectFaultReportList(pids, startTime, endTime);

        return AjaxResult.success(faultReports);
    }

    /**
     * 根据所属诊断器ip和端口号获取摄像机详细信息
     *
     * @param ip
     * @param port
     * @return
     */
    @ApiOperation("根据所属诊断器ip和端口号获取摄像机详细信息")
    @GetMapping(value = "/getInfoByIpAndPort")
    public AjaxResult getInfoByIpAndPort(@RequestParam(value = "ip") String ip, @RequestParam(value = "port") String port) {
        return AjaxResult.success(this.cameraService.selectHswCameraByIpAndPort(ip, port));
    }

    /**
     * 根据所属诊断器ip查询摄像机列表
     *
     * @param ip
     * @return
     */
    @ApiOperation("根据所属诊断器ip查询摄像机列表")
    @GetMapping(value = "/selectCameraListByIp")
    public AjaxResult selectCameraListByIp(@RequestParam(value = "ip") String ip) {
        return AjaxResult.success(this.cameraService.selectCameraListByIp(ip));
    }
}