package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api("设备相关")
@RestController
@RequestMapping("/api/device")
public class ApiDeviceController {

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private IHswProjectService projectService;

    @Autowired
    private IHswDiagnosisDeviceService diagnosisDeviceService;

    @Autowired
    private IHswDivideWorkService divideWorkService;

    @Autowired
    private IHswCameraService cameraService;

    @ApiOperation("取得项目分工信息")
    @GetMapping(value = "/getFenGong")
    public AjaxResult getFenGong(@RequestParam("logical_addr") String logicalAddr) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] myProjects = this.projectService.getProjectIdsByUser(sysUser);
        HswDiagnosisDevice diagnosisDevice = new HswDiagnosisDevice();
        diagnosisDevice.setLogicalAddr(logicalAddr);
        diagnosisDevice = this.diagnosisDeviceService.selectDiagnosisDeviceForApi(diagnosisDevice);
        Map<String, Object> data = new HashMap<>();
        if (diagnosisDevice != null) {
            data.put("device", diagnosisDevice);
            if (ArrayUtils.contains(myProjects, diagnosisDevice.getPid())) {
                //读取该项目分工列表
                HswDivideWork divideWork = new HswDivideWork();
                divideWork.setPid(diagnosisDevice.getPid());
                List<HswDivideWork> divideWorks = this.divideWorkService.selectHswDivideWorkList(divideWork);
                data.put("code", 1);
                data.put("fengong", divideWorks);
                return AjaxResult.success(data);
            } else {
                //无权限访问
                return AjaxResult.error("无权限访问");
            }
        } else {
            return AjaxResult.error("找不到该项目分工信");
        }
    }

    @ApiOperation("取得诊断器信息")
    @GetMapping(value = "/getDiagnosisDevice")
    public AjaxResult getDiagnosisDevice(@RequestParam("logical_addr") String logicalAddr) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Long[] myProjects = this.projectService.getProjectIdsByUser(sysUser);
        HswDiagnosisDevice diagnosisDevice = new HswDiagnosisDevice();
        diagnosisDevice.setLogicalAddr(logicalAddr);
        diagnosisDevice = this.diagnosisDeviceService.selectDiagnosisDeviceForApi(diagnosisDevice);

        if (diagnosisDevice != null) {
            if (ArrayUtils.contains(myProjects, diagnosisDevice.getPid())) {
                return AjaxResult.success(diagnosisDevice);
            } else {
                //无权限访问
                return AjaxResult.error("无权限访问");
            }
        } else {
            return AjaxResult.error("找不到该诊断器信息");
        }
    }

    @ApiOperation("更新诊断器信息")
    @PostMapping(value = "/updateDevice")
    public AjaxResult updateDevice(@RequestBody HswDiagnosisDevice diagnosisDevice) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        HswDiagnosisDevice dbDiagnosisDevice = this.diagnosisDeviceService.selectHswDiagnosisDeviceById(diagnosisDevice.getId());
        if (dbDiagnosisDevice != null) {
            dbDiagnosisDevice.setSn(diagnosisDevice.getSn());
            dbDiagnosisDevice.setDivideWorkId(diagnosisDevice.getDivideWorkId());
            dbDiagnosisDevice.setAddress(diagnosisDevice.getAddress());
            dbDiagnosisDevice.setManufacturer(diagnosisDevice.getManufacturer());
            dbDiagnosisDevice.setModel(diagnosisDevice.getModel());
            dbDiagnosisDevice.setIp(diagnosisDevice.getIp());
            dbDiagnosisDevice.setInstallTime(diagnosisDevice.getInstallTime());
            dbDiagnosisDevice.setPid(diagnosisDevice.getPid());
            dbDiagnosisDevice.setLogicalAddr(diagnosisDevice.getLogicalAddr());
            dbDiagnosisDevice.setVer(diagnosisDevice.getVer());
            dbDiagnosisDevice.setUplinkPort(diagnosisDevice.getUplinkPort());
            dbDiagnosisDevice.setCameraCount(diagnosisDevice.getCameraCount());
            dbDiagnosisDevice.setWarranty(diagnosisDevice.getWarranty());
            dbDiagnosisDevice.setDistance(diagnosisDevice.getDistance());
            dbDiagnosisDevice.setNetwork(diagnosisDevice.getNetwork());
            dbDiagnosisDevice.setLongitude(diagnosisDevice.getLongitude());
            dbDiagnosisDevice.setLatitude(diagnosisDevice.getLatitude());

            int res = this.diagnosisDeviceService.updateHswDiagnosisDevice(dbDiagnosisDevice);
            if (res > 0) {
                //更新摄像机的经纬度
                this.cameraService.updateHswCameraByIp(diagnosisDevice.getIp(), diagnosisDevice.getLongitude(), diagnosisDevice.getLatitude());
                return AjaxResult.success("编辑成功");
            }
        }

        return AjaxResult.success("编辑失败");
    }
}
