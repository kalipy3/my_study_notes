package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.dto.CameraViewDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.FaultViewPageableDto;
import com.ruoyi.hsw.dto.index.EquFaultPageableDto;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.hsw.service.IIndexService;
import com.ruoyi.system.service.ISysDictDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 描述:
 * 首页大屏
 *
 * @author xiongxiangpeng
 * @create 2020-11-20 10:35
 */
@Api("首页大屏Controller")
@RestController
@RequestMapping("/hsw/index")
public class IndexController extends BaseController {

    @Autowired
    private IIndexService indexService;

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    @Autowired
    private IHswCameraService hswCameraService;

    /**
     * 近一周故障类型分布
     */
    @ApiOperation("近一周故障类型分布")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/faultTypeDistribution")
    public AjaxResult faultTypeDistribution(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.faultTypeDistribution(equFaultPageableDto));
    }

    /**
     * 近一周故障设备分布
     */
    @ApiOperation("近一周故障设备分布")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/faultEquDistribution")
    public AjaxResult faultEquDistribution(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.faultEquDistribution(equFaultPageableDto));
    }

    /**
     * 活动工单
     */
    @ApiOperation("活动工单")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/activeJobList")
    public AjaxResult activeJobList(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.activeJobList(equFaultPageableDto));
    }

    /**
     * 活动故障
     */
    @ApiOperation("活动故障")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/activeFaultList")
    public AjaxResult activeFaultList(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.activeFaultList(equFaultPageableDto));
    }

    /**
     * 频繁故障视点
     */
    @ApiOperation("频繁故障视点")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/frequentFaultSiteList")
    public AjaxResult frequentFaultSiteList(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.frequentFaultSiteList(equFaultPageableDto));
    }

    /**
     * 实施项目数
     */
    @ApiOperation("实施项目数")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/projectCount")
    public AjaxResult projectCount() {
        return AjaxResult.success(this.indexService.projectCount());
    }

    /**
     * 入驻建设单位
     */
    @ApiOperation("入驻建设单位")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/constructingUnitsCount")
    public AjaxResult constructingUnitsCount() {
        return AjaxResult.success(this.indexService.constructingUnitsCount());
    }

    /**
     * 近6个月工单统计
     */
    @ApiOperation("近6个月工单统计")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/monthJobData")
    public AjaxResult monthJobData() {
        return AjaxResult.success(this.indexService.monthJobData());
    }

    /**
     * 近一个月维修队工单统计
     */
    @ApiOperation("近一个月维修队工单统计")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/monthJobMtData")
    public AjaxResult monthJobMtData(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.monthJobMtData(equFaultPageableDto));
    }

    /**
     * 近一周在线率（当天在线率获取最后一条数据）
     */
    @ApiOperation("近一周在线率（当天在线率获取最后一条数据）")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/onlineRate")
    public AjaxResult onlineRate(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.onlineRate(equFaultPageableDto));
    }

    /**
     * 设备数量
     *
     * @param equFaultPageableDto
     * @return
     */
    @ApiOperation("设备数量")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/deviceCount")
    public AjaxResult deviceCount(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        return AjaxResult.success(this.indexService.deviceCount(equFaultPageableDto));
    }

    /**
     * 区域设备数量
     *
     * @param equFaultPageableDto
     * @return
     */
    @ApiOperation("区域设备数量")
//    @PreAuthorize("@ss.hasPermi('hsw:index:list')")
    @PostMapping("/cameraAreaCount")
    public AjaxResult cameraAreaCount(@RequestBody EquFaultPageableDto equFaultPageableDto) {

        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        } else {
            List<Long> defaultPids = new ArrayList<>();
            defaultPids.add(-1L);

            equFaultPageableDto.setPIds(defaultPids);
        }

        SysUser user = SecurityUtils.getLoginUser().getUser();

        // 默认地图显示区域编码，显示规则：管理员、运维单位显示江西省，建设单位显示该单位项目所在的市
        String mapCode = "36";
        switch (user.getType()) {
            case CommonConstant.USER_TYPE_CU:
                if (!CollectionUtils.isEmpty(pIds)) {
                    Long[] pids = new Long[pIds.size()];
                    pIds.toArray(pids);
                    List<HswProject> projectList = this.hswProjectService.selectHswProjectIds(pids);
                    mapCode = projectList.get(0).getCity().toString();
                }
                break;
            default:
                break;
        }

        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("mapCode", mapCode);

        if (EquFaultPageableDto.LEVEL_CITY.equals(equFaultPageableDto.getLevel())) {
            resultMap.put("data", this.indexService.cameraCountGroupByCity(equFaultPageableDto));
            return AjaxResult.success(resultMap);
        }

        if (EquFaultPageableDto.LEVEL_DISTRICT.equals(equFaultPageableDto.getLevel())) {
            resultMap.put("data", this.indexService.cameraCountGroupByDistrict(equFaultPageableDto));
            return AjaxResult.success(resultMap);
        }

        return AjaxResult.error("level参数错误");
    }

    /**
     * 故障趋势
     *
     * @param equFaultPageableDto
     * @return
     */
    @ApiOperation("故障趋势")
    @PostMapping("/faultTrend")
    public AjaxResult faultTrend(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }

        return AjaxResult.success(this.indexService.faultTrend(equFaultPageableDto));
    }

    /**
     * 绩效综合对比
     *
     * @param equFaultPageableDto
     * @return
     */
    @ApiOperation("绩效综合对比")
    @PostMapping("/performanceComparison")
    public AjaxResult performanceComparison(@RequestBody EquFaultPageableDto equFaultPageableDto) {
        List<Long> pIds = this.hswProjectService.findPidByUser();
        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        }

        return AjaxResult.success(this.indexService.performanceComparison(equFaultPageableDto));
    }

    /**
     * 获取摄像头点位
     *
     * @return
     */
    @ApiOperation("获取摄像头点位")
    @GetMapping("/getCameraMarker")
    public AjaxResult getCameraMarker() {

        // 获取当前登录用户可获取项目id
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            pidByUser.add(-1L);
        }
        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setPids(pids);
        List<CameraViewDto> cameraViewDtos = this.hswCameraService.selectCameraViewList(cameraViewDto);//所管辖的所有摄像机

        FaultViewPageableDto faultViewPageableDto = new FaultViewPageableDto();
        faultViewPageableDto.setPids(pids);
        faultViewPageableDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);

        // 获取故障级别字典
        List<SysDictData> faultLevelDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_LEVEL);

        List<FaultViewDto> faultViewDtos = this.hswFaultInfoService.selectFaultViewList2(faultViewPageableDto);
        faultViewDtos.forEach(fault -> {
            if (fault.getInfluenceCameraCount() > 0) {
                if (fault.getPort() == CommonConstant.FAULT_POST) {
                    //该ip下所有摄像机当前都处于故障状态
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                } else {
                    cameraViewDtos.stream().forEach(cv -> {
                        if (fault.getIp().equals(cv.getIp()) && fault.getPort().equals(cv.getPort())) {
                            cv.setIsFault(CommonConstant.IS_FAULT_YES);
                            cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                        }
                    });
                }
            }
        });

        String localCity = "高安市";

        // 项目区域字典
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_PROJECT_AREA);

        for (SysDictData d : sysDictDatas) {
            if (CommonParameter.AREA.equals(d.getDictLabel())) {
                localCity = d.getDictValue();
            }
        }

//        switch (sysUser.getType()) {
//            case 1://系统管理员
//                break;
//            default:
//                if (pids.length > 0) {
//                    HswProject project = this.hswProjectService.selectHswProjectById(pids[0]);
//                    if (project != null) {
//                        localCity = project.getDistrictLabel();
//                    }
//                }
//                break;
//        }

        Map<String, Object> result = new HashMap<>();
        result.put("localCity", localCity);
        result.put("data", cameraViewDtos);
        return AjaxResult.success(result);
    }

    private int getFaultLevel(List<SysDictData> sysDictDatas, Integer type) {
        int level = CommonConstant.FAULT_LEVEL_ZERO;

        if (!sysDictDatas.isEmpty()) {
            for (SysDictData sysDictData : sysDictDatas) {
                if (sysDictData.getDictLabel().equals(type.toString())) {
                    level = Integer.valueOf(sysDictData.getDictValue());
                }
            }
        }

        return level;
    }
}
