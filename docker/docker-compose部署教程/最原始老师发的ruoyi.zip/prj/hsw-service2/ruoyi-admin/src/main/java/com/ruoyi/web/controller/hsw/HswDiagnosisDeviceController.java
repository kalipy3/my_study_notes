package com.ruoyi.web.controller.hsw;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.model.LoginUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.web.service.TokenService;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.service.ISysDictTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * 诊断器Controller
 *
 * @author ruoyi
 * @date 2020-11-05
 */
@Api("诊断器管理")
@RestController
@RequestMapping("/hsw/diagnosisDevice")
public class HswDiagnosisDeviceController extends BaseController {
    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswOpticalTransceiverService hswOpticalTransceiverService;

    @Autowired
    private IHswOtherDeviceService hswOtherDeviceService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswDivideWorkService hswDivideWorkService;

    @Autowired
    private ISysDictTypeService dictTypeService;

    @Autowired
    private IHswProjectService projectService;

    /**
     * 查询诊断器列表
     */
    @ApiOperation("查询诊断器列表")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswDiagnosisDevice hswDiagnosisDevice) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswDiagnosisDevice.setPids(pids);

        startPage();
        List<HswDiagnosisDevice> list = hswDiagnosisDeviceService.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
        return getDataTable(list);
    }

    /**
     * 导出诊断器列表
     */
    @ApiOperation("导出诊断器列表")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:export')")
    @Log(title = "诊断器", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswDiagnosisDevice hswDiagnosisDevice) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswDiagnosisDevice.setPids(pids);

        List<HswDiagnosisDevice> list = hswDiagnosisDeviceService.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
        ExcelUtil<HswDiagnosisDevice> util = new ExcelUtil<HswDiagnosisDevice>(HswDiagnosisDevice.class);
        return util.exportExcel(list, "诊断器列表");
    }

    /**
     * 获取诊断器详细信息
     */
    @ApiOperation("获取诊断器详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswDiagnosisDeviceService.selectHswDiagnosisDeviceById(id));
    }

    /**
     * 新增诊断器
     */
    @ApiOperation("新增诊断器")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:add')")
    @Log(title = "诊断器", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody HswDiagnosisDevice hswDiagnosisDevice) {
        if (UserConstants.NOT_UNIQUE.equals(hswDiagnosisDeviceService.checkIpUnique(hswDiagnosisDevice))) {
            return AjaxResult.error("新增诊断器失败，ip'" + hswDiagnosisDevice.getIp() + "'已经存在");
        }

        if (UserConstants.NOT_UNIQUE.equals(hswDiagnosisDeviceService.checkLogicalAddrUnique(hswDiagnosisDevice))) {
            return AjaxResult.error("新增诊断器失败，逻辑地址'" + hswDiagnosisDevice.getLogicalAddr() + "'已经存在");
        }

        if (hswProjectService.selectHswProjectById(hswDiagnosisDevice.getPid()) == null) {
            return AjaxResult.error("新增诊断器失败，所属项目不存在");
        }

        if (hswDivideWorkService.selectHswDivideWorkById(hswDiagnosisDevice.getDivideWorkId()) == null) {
            return AjaxResult.error("新增诊断器失败，所属分工不存在");
        }

        List<HswDivideWork> hswDivideWorkList = hswDivideWorkService.selectHswDivideWorkByPid(hswDiagnosisDevice.getPid());

        long count = hswDivideWorkList.stream().filter(w -> hswDiagnosisDevice.getDivideWorkId().equals(w.getId())).count();

        if (count <= 0) {
            return AjaxResult.error("新增诊断器失败，所属分工不属于该项目");
        }

        hswDiagnosisDevice.setCreateBy(SecurityUtils.getUsername());
        hswDiagnosisDevice.setInstallTime(DateUtils.getDateMr(hswDiagnosisDevice.getInstallDate()));
        return toAjax(hswDiagnosisDeviceService.insertHswDiagnosisDevice(hswDiagnosisDevice));
    }

    /**
     * 修改诊断器
     */
    @ApiOperation("修改诊断器")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:edit')")
    @Log(title = "诊断器", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody HswDiagnosisDevice hswDiagnosisDevice) {
        if (UserConstants.NOT_UNIQUE.equals(hswDiagnosisDeviceService.checkIpUnique(hswDiagnosisDevice))) {
            return AjaxResult.error("修改诊断器失败，ip'" + hswDiagnosisDevice.getIp() + "'已经存在");
        }

        if (UserConstants.NOT_UNIQUE.equals(hswDiagnosisDeviceService.checkLogicalAddrUnique(hswDiagnosisDevice))) {
            return AjaxResult.error("修改诊断器失败，逻辑地址'" + hswDiagnosisDevice.getLogicalAddr() + "'已经存在");
        }

        if (hswProjectService.selectHswProjectById(hswDiagnosisDevice.getPid()) == null) {
            return AjaxResult.error("修改诊断器失败，所属项目不存在");
        }

        if (hswDivideWorkService.selectHswDivideWorkById(hswDiagnosisDevice.getDivideWorkId()) == null) {
            return AjaxResult.error("修改诊断器失败，所属分工不存在");
        }

        List<HswDivideWork> hswDivideWorkList = hswDivideWorkService.selectHswDivideWorkByPid(hswDiagnosisDevice.getPid());

        long count = hswDivideWorkList.stream().filter(w -> hswDiagnosisDevice.getDivideWorkId().equals(w.getId())).count();

        if (count <= 0) {
            return AjaxResult.error("修改诊断器失败，所属分工不属于该项目");
        }

        hswDiagnosisDevice.setUpdateBy(SecurityUtils.getUsername());
        hswDiagnosisDevice.setInstallTime(DateUtils.getDateMr(hswDiagnosisDevice.getInstallDate()));
        return toAjax(hswDiagnosisDeviceService.updateHswDiagnosisDevice(hswDiagnosisDevice));
    }

    /**
     * 删除诊断器
     */
    @ApiOperation("删除诊断器")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:remove')")
    @Log(title = "诊断器", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        for (Long id : ids) {
            HswDiagnosisDevice hswDiagnosisDevice = hswDiagnosisDeviceService.selectHswDiagnosisDeviceById(id);
            if (hswDiagnosisDevice != null) {
                // 删除所属诊断器下的摄像头
                this.hswCameraService.deleteHswCameraByIp(hswDiagnosisDevice.getIp());
                // 删除所属诊断器下的光纤收发器
                this.hswOpticalTransceiverService.deleteHswOpticalTransceiverByIp(hswDiagnosisDevice.getIp());
                // 删除所属诊断器下的其他设备
                this.hswOtherDeviceService.deleteHswOtherDeviceByIp(hswDiagnosisDevice.getIp());
            }
        }

        return toAjax(hswDiagnosisDeviceService.deleteHswDiagnosisDeviceByIds(ids));
    }

    /**
     * 下载导入模板
     *
     * @return
     */
    @ApiOperation("下载导入模板")
    @GetMapping("/importTemplate")
    public AjaxResult importTemplate() throws NoSuchFieldException, IllegalAccessException {

        // 上行端口Excel注解添加combo
        this.initExcel("uplinkPort", CommonParameter.HSW_UPLINK_PORT);

        // 网络运营商Excel注解添加combo
        this.initExcel("network", CommonParameter.HSW_NETWORK_OPERATOR);

        ExcelUtil<HswDiagnosisDevice> util = new ExcelUtil<HswDiagnosisDevice>(HswDiagnosisDevice.class);
        return util.importTemplateExcel("诊断器数据");
    }

    /**
     * 获取字典数据，给Excel注解的combo属性赋值
     *
     * @param fileName 字段名称
     * @param dictType 字典类型
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    private void initExcel(String fileName, String dictType) throws NoSuchFieldException, IllegalAccessException {
        Field field = HswDiagnosisDevice.class.getDeclaredField(fileName);
        Excel excelAnnotation = field.getAnnotation(Excel.class);
        InvocationHandler invocationHandler = Proxy.getInvocationHandler(excelAnnotation);
        Field memberValues = invocationHandler.getClass().getDeclaredField("memberValues");
        memberValues.setAccessible(true);
        Map map = (Map) memberValues.get(invocationHandler);

        List<SysDictData> dicList = dictTypeService.selectDictDataByType(dictType);
        Object[] objects = dicList.stream().map(l -> l.getDictLabel()).toArray();
        String[] combo = Arrays.copyOf(objects, objects.length, String[].class);
        map.put("combo", combo);
    }

    /**
     * 导入excel
     *
     * @param file          导入的excel文件
     * @param updateSupport 是否更新支持，如果已存在，则进行更新数据
     * @param pid           所属项目id
     * @return
     * @throws Exception
     */
    @ApiOperation("导入excel")
    @Log(title = "诊断器", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file, boolean updateSupport, Long pid) throws Exception {

        if (StringUtils.isNull(file)) {
            return AjaxResult.error("导入失败，导入文件不能为空");
        }

        if (StringUtils.isNull(pid)) {
            return AjaxResult.error("导入失败，所属项目不能为空");
        }

        if (hswProjectService.selectHswProjectById(pid) == null) {
            return AjaxResult.error("导入失败，所属项目不存在");
        }

        ExcelUtil<HswDiagnosisDevice> util = new ExcelUtil<HswDiagnosisDevice>(HswDiagnosisDevice.class);
        List<HswDiagnosisDevice> diagnosisDeviceList = util.importExcel(file.getInputStream());
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String operName = loginUser.getUsername();
        String message = hswDiagnosisDeviceService.importDiagnosisDevice(diagnosisDeviceList, updateSupport, operName, pid);
        return AjaxResult.success(message);
    }

    /**
     * 根据ip获取诊断器详细信息
     */
    @ApiOperation("根据ip获取诊断器详细信息")
//    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:queryByIp')")
    @GetMapping(value = "/getInfoByIp/{ip}")
    public AjaxResult getInfoByIp(@PathVariable("ip") String ip) {
        return AjaxResult.success(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(ip));
    }

    @ApiOperation("查询诊断器在线状态列表")
    @PreAuthorize("@ss.hasPermi('hsw:diagnosisDevice:online')")
    @GetMapping("/online")
    public TableDataInfo online(HswDiagnosisDevice hswDiagnosisDevice) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswDiagnosisDevice.setPids(pids);

        startPage();
        List<HswDiagnosisDevice> list = hswDiagnosisDeviceService.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
        return getDataTable(list);
    }
}
