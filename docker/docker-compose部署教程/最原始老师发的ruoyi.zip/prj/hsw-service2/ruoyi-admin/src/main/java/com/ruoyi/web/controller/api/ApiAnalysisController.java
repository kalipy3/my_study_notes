package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.service.IAnalysisService;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import com.ruoyi.hsw.service.IHswProjectMaintenanceUnitsService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysDictTypeService;
import com.ruoyi.system.service.ISysRoleService;
import com.ruoyi.system.service.ISysUserService;
import com.ruoyi.hsw.constant.CommonConstant;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@Api("绩效统计相关")
@RestController
@RequestMapping("/api/analysis")
public class ApiAnalysisController extends BaseController {

    @Autowired
    private IHswProjectService projectService;

    @Autowired
    private IHswProjectMaintenanceUnitsService projectMaintenanceUnitsService;

    @Autowired
    private ISysRoleService sysRoleService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    @Autowired
    private ISysDictTypeService sysDictTypeService;

    @Autowired
    private IHswDivideWorkService divideWorkService;

    @Autowired
    private IAnalysisService analysisService;

    /**
     * 运维单位
     *
     * @return
     */
    @ApiOperation("运维单位")
    @GetMapping(value = "/jixiao1")
    public AjaxResult jixiao1(@RequestParam(value = "pid", defaultValue = "0") Long pid,
                              @RequestParam(value = "muId", defaultValue = "0") Long muId,
                              @RequestParam(value = "timeoutLevel", defaultValue = "0") Integer timeoutLevel, String reportTime) {
        return MUByArtificialRepair1(pid, muId, timeoutLevel, reportTime);
    }

    /**
     * 运维单位 人工修复
     */
    private AjaxResult MUByArtificialRepair1(Long pid, Long muId, Integer timeoutLevel, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);


        List<ProjectMaintenanceUnitsViewDto> projectMaintenanceUnitsViewDtos = new ArrayList<>();
        if (pid > 0) {
            projectMaintenanceUnitsViewDtos = this.projectMaintenanceUnitsService.selectProjectMaintenanceUnitsViewList(pid);
        } else if (pids.size() > 0) {
            projectMaintenanceUnitsViewDtos = this.projectMaintenanceUnitsService.selectListByPids(pids);
        }

        List<Long> needQueryMtid = new ArrayList<>();//需要查询的运维单位id
        if (muId == 0) {
            projectMaintenanceUnitsViewDtos.forEach(mu -> {
                needQueryMtid.add(mu.getMuId());
            });
        } else {
            needQueryMtid.add(muId);
        }

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 运维单位
        MuAnalysisPageableDto muAnalysisPageableDto = new MuAnalysisPageableDto();
        muAnalysisPageableDto.setStartTime(startTime);
        muAnalysisPageableDto.setEndTime(endTime);
        if (needQueryMtid.size() > 0) {
            muAnalysisPageableDto.setMuIds(needQueryMtid);
        }
        if (pid > 0) {
            muAnalysisPageableDto.setPid(pid);
        } else {
            muAnalysisPageableDto.setPIds(pids);
        }
        if (timeoutLevel > 0) {
            muAnalysisPageableDto.setTimeoutLevel(timeoutLevel + "");
        }

        return AjaxResult.success(this.analysisService.muAnalysis1(muAnalysisPageableDto));
    }

    /**
     * 维修队
     */
    public AjaxResult MTByArtificialRepair1(Long pid, Long muId, Long mtId, Integer timeoutLevel, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 维修队
        MtAnalysisPageableDto mtAnalysisPageableDto = new MtAnalysisPageableDto();
        mtAnalysisPageableDto.setStartTime(startTime);
        mtAnalysisPageableDto.setEndTime(endTime);
        if (pid > 0) {
            mtAnalysisPageableDto.setPid(pid);
        } else {
            mtAnalysisPageableDto.setPIds(pids);
        }
        if (muId > 0) {
            mtAnalysisPageableDto.setMuId(muId);
        }
        if (mtId > 0) {
            mtAnalysisPageableDto.setMtId(mtId);
        }
        if (timeoutLevel > 0) {
            mtAnalysisPageableDto.setTimeoutLevel(timeoutLevel + "");
        }

        return AjaxResult.success(this.analysisService.mtAnalysis1(mtAnalysisPageableDto));
    }

    /**
     * 维修队长
     */
    public AjaxResult TDByArtificialRepair1(Long pid, Long muId, String mtId, Integer timeoutLevel, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);

        Long uid;
        Long mTeamId;
        String[] ids = new String[2];
        if (StringUtils.isNotEmpty(mtId)) {
            ids = mtId.split("~");
            uid = Long.valueOf(ids[0]);
            mTeamId = Long.valueOf(ids[1]);
        } else {
            uid = 0L;
            mTeamId = 0L;
        }

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 维修队长
        MtlAnalysisPageableDto mtlAnalysisPageableDto = new MtlAnalysisPageableDto();
        mtlAnalysisPageableDto.setStartTime(startTime);
        mtlAnalysisPageableDto.setEndTime(endTime);
        if (pid > 0) {
            mtlAnalysisPageableDto.setPid(pid);
        } else {
            mtlAnalysisPageableDto.setPIds(pids);
        }
        if (muId > 0) {
            mtlAnalysisPageableDto.setMuId(muId);
        }
        if (mTeamId > 0) {
            mtlAnalysisPageableDto.setMtId(mTeamId);
        }
        if (timeoutLevel > 0) {
            mtlAnalysisPageableDto.setTimeoutLevel(timeoutLevel + "");
        }
        if (uid > 0) {
            mtlAnalysisPageableDto.setUserId(uid);
        }

        return AjaxResult.success(this.analysisService.mtlAnalysis1(mtlAnalysisPageableDto));
    }

    /**
     * 维修员
     */
    public AjaxResult TLByArtificialRepair1(Long pid, Long muId, Long mtId, Long staffId, Long timeoutLevel, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);


        List<ProjectMaintenanceUnitsViewDto> projectMaintenanceUnitsViewDtos = new ArrayList<>();
        if (pid > 0) {
            projectMaintenanceUnitsViewDtos = this.projectMaintenanceUnitsService.selectProjectMaintenanceUnitsViewList(pid);
        } else if (pids.size() > 0) {
            projectMaintenanceUnitsViewDtos = this.projectMaintenanceUnitsService.selectListByPids(pids);
        }

        List<Long> needQueryMtid = new ArrayList<>();//需要查询的运维单位id
        if (muId == 0) {
            projectMaintenanceUnitsViewDtos.forEach(mu -> {
                needQueryMtid.add(mu.getMuId());
            });
        } else {
            needQueryMtid.add(muId);
        }

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 维修员
        MtManAnalysisPageableDto mtManAnalysisPageableDto = new MtManAnalysisPageableDto();
        mtManAnalysisPageableDto.setStartTime(startTime);
        mtManAnalysisPageableDto.setEndTime(endTime);
        if (needQueryMtid.size() > 0) {
            mtManAnalysisPageableDto.setMuIds(needQueryMtid);
        }
        if (pid > 0) {
            mtManAnalysisPageableDto.setPid(pid);
        } else {
            mtManAnalysisPageableDto.setPIds(pids);
        }
        if (mtId > 0) {
            mtManAnalysisPageableDto.setMtId(mtId);
        }
        if(staffId > 0){
            mtManAnalysisPageableDto.setUserId(staffId);;
        }
        if (timeoutLevel > 0) {
            mtManAnalysisPageableDto.setTimeoutLevel(timeoutLevel + "");
        }

        return AjaxResult.success(this.analysisService.mtManAnalysis1(mtManAnalysisPageableDto));
    }

    /**
     * 派单员
     */
    public AjaxResult Sender1(Long uid, Double repaireHour, String reportTime) {
        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 派单员
        DispatcherPageableDto dispatcherPageableDto = new DispatcherPageableDto();
        dispatcherPageableDto.setStartTime(startTime);
        dispatcherPageableDto.setEndTime(endTime);
        if (uid > 0) {
            dispatcherPageableDto.setUserId(uid);
        }
        if (repaireHour > 0) {
            dispatcherPageableDto.setSendHour(repaireHour);
        }

        return AjaxResult.success(this.analysisService.dispatcher(dispatcherPageableDto));
    }

    /**
     * 设备厂商
     */
    private AjaxResult manufacturer1(Integer analysisType, String deviceType, String manufacturer, Double repaireHour, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 设备厂商
        EquAnalysisPageableDto equAnalysisPageableDto = new EquAnalysisPageableDto();
        equAnalysisPageableDto.setDeviceType(deviceType);
        equAnalysisPageableDto.setAnalysisType(analysisType);
        equAnalysisPageableDto.setStartTime(startTime);
        equAnalysisPageableDto.setEndTime(endTime);
        if (manufacturer != null) {
            equAnalysisPageableDto.setManufacturer(manufacturer);
        }
        if (pids.size() > 0) {
            equAnalysisPageableDto.setPIds(pids);
        }
        if (repaireHour > 0) {
            equAnalysisPageableDto.setRepaireHour(repaireHour);
        }

        return AjaxResult.success(this.analysisService.equAnalysis(equAnalysisPageableDto));
    }

    /**
     * 网络运营商
     */
    private AjaxResult communications1(Integer analysisType, String operator, Double repaireHour, Long pid, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 网络供应商
        NetworkOperatorsPageableDto networkOperatorsPageableDto = new NetworkOperatorsPageableDto();
        networkOperatorsPageableDto.setAnalysisType(analysisType);
        networkOperatorsPageableDto.setStartTime(startTime);
        networkOperatorsPageableDto.setEndTime(endTime);
        if (operator != null) {
            networkOperatorsPageableDto.setCommunicationsOperations(operator);
        }
        if (pid > 0) {
            networkOperatorsPageableDto.setPid(pid);
        } else {
            networkOperatorsPageableDto.setPIds(pids);
        }
        if (repaireHour > 0) {
            networkOperatorsPageableDto.setRepaireHour(repaireHour);
        }

        return AjaxResult.success(this.analysisService.networkOperators(networkOperatorsPageableDto));
    }

    /**
     * 电力运营商
     */
    private AjaxResult PowerCompany1(Integer analysisType, Long pid, String operator, Double repaireHour, String reportTime) {
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        List<Long> pids = this.projectService.getPIdsByUser(sysUser);

        Long startTime;
        Long endTime;
        String[] dateRange = new String[2];
        if (StringUtils.isNotEmpty(reportTime)) {
            dateRange = reportTime.split("~");
            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) - 29);
            Date begin = cal.getTime();

            dateRange[0] = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            dateRange[1] = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            startTime = DateUtils.dateTime(dateRange[0] + " 00:00:00").getTime() / 1000;
            endTime = DateUtils.dateTime(dateRange[1] + " 23:59:59").getTime() / 1000;
        }

        // 电力供应商
        PowerOperatorsPageableDto powerOperatorsPageableDto = new PowerOperatorsPageableDto();
        powerOperatorsPageableDto.setAnalysisType(analysisType);
        powerOperatorsPageableDto.setStartTime(startTime);
        powerOperatorsPageableDto.setEndTime(endTime);
        if (operator != null) {
            powerOperatorsPageableDto.setElectricityOperating(operator);
        }
        if (pid > 0) {
            powerOperatorsPageableDto.setPid(pid);
        } else {
            powerOperatorsPageableDto.setPIds(pids);
        }
        if (repaireHour != null && repaireHour > 0) {
            powerOperatorsPageableDto.setRepaireHour(repaireHour);
        }

        return AjaxResult.success(this.analysisService.powerOperators(powerOperatorsPageableDto));
    }

    /**
     * 维修队
     *
     * @return
     */
    @ApiOperation("维修队")
    @GetMapping(value = "/jixiao2")
    public AjaxResult jixiao2(@RequestParam(value = "pid", defaultValue = "0") Long pid,
                              @RequestParam(value = "muId", defaultValue = "0") Long muId,
                              @RequestParam(value = "mtId", defaultValue = "0") Long mtId,
                              @RequestParam(value = "timeoutLevel", defaultValue = "0") Integer timeoutLevel, String reportTime) {
        return MTByArtificialRepair1(pid, muId, mtId, timeoutLevel, reportTime);
    }

    /**
     * 维修队长
     *
     * @return
     */
    @ApiOperation("维修队长")
    @GetMapping(value = "/jixiao3")
    public AjaxResult jixiao3(@RequestParam(value = "pid", defaultValue = "0") Long pid,
                              @RequestParam(value = "muId", defaultValue = "0") Long muId,
                              String mtId,
                              @RequestParam(value = "timeoutLevel", defaultValue = "0") Integer timeoutLevel, String reportTime) {
        return TDByArtificialRepair1(pid, muId, mtId, timeoutLevel, reportTime);
    }
    /**
     * 维修员
     *
     * @return
     */
    @ApiOperation("维修员")
    @GetMapping(value = "/jixiao4")
    public AjaxResult jixiao4(@RequestParam(value = "pid", defaultValue = "0") Long pid,
                              @RequestParam(value = "muId", defaultValue = "0") Long muId,
                              @RequestParam(value = "mtId", defaultValue = "0") Long mtId,
                              @RequestParam(value = "staffId", defaultValue = "0") Long staffId,
                              @RequestParam(value = "timeoutLevel", defaultValue = "0") Long timeoutLevel, String reportTime) {
        return TLByArtificialRepair1(pid, muId, mtId, staffId, timeoutLevel, reportTime);
    }
    /**
     * 派单员
     *
     * @return
     */
    @ApiOperation("派单员")
    @GetMapping(value = "/jixiao5")
    public AjaxResult jixiao5(@RequestParam(value = "uid", defaultValue = "0") Long uid,
                              @RequestParam(value = "repaireHour", defaultValue = "0") Double repaireHour, String reportTime) {
        return Sender1(uid, repaireHour, reportTime);
    }
    /**
     * 设备厂商
     *
     * @return
     */
    @ApiOperation("设备厂商")
    @GetMapping(value = "/jixiao6")
    public AjaxResult jixiao6(String deviceType, String manufacturer,
                              @RequestParam(value = "repaireHour", defaultValue = "0") Double repaireHour, String reportTime) {
        return manufacturer1(CommonConstant.ARTIFICIAL, deviceType, manufacturer, repaireHour, reportTime);
    }
    /**
     * 网络运营商
     *
     * @return
     */
    @ApiOperation("网络运营商")
    @GetMapping(value = "/jixiao7")
    public AjaxResult jixiao7(String operator,
                              @RequestParam(value = "repaireHour", defaultValue = "0") Double repaireHour,
                              @RequestParam(value = "pid", defaultValue = "0") Long pid, String reportTime) {
        return communications1(CommonConstant.ARTIFICIAL, operator, repaireHour, pid, reportTime);
    }
    /**
     * 电力公司
     *
     * @return
     */
    @ApiOperation("电力公司")
    @GetMapping(value = "/jixiao8")
    public AjaxResult jixiao8(@RequestParam(value = "pid", defaultValue = "0") Long pid, String operator,
                              @RequestParam(value = "repaireHour",  defaultValue = "0") Double repaireHour,
                               String reportTime) {
        return PowerCompany1(CommonConstant.ARTIFICIAL, pid, operator, repaireHour, reportTime);
    }

    @ApiOperation("根据项目和运维单位取得运维队分工列表")
    @GetMapping(value = "/getMt")
    public AjaxResult getMt(@RequestParam Long pid, @RequestParam Long muId) {
        HswDivideWork divideWork = new HswDivideWork();
        divideWork.setPid(pid);
        divideWork.setMuId(muId);

        List<HswDivideWork> divideWorks = this.divideWorkService.selectHswDivideWorkList(divideWork);
        return AjaxResult.success(divideWorks);
    }

    @ApiOperation("取得项目运维单位列表")
    @GetMapping(value = "/getMu")
    public AjaxResult getMu(@RequestParam Long pid) {
        ProjectMaintenanceUnitsViewDto projectMaintenanceUnitsViewDto = new ProjectMaintenanceUnitsViewDto();
        projectMaintenanceUnitsViewDto.setPid(pid);
        List<ProjectMaintenanceUnitsViewDto> projectMaintenanceUnitsViewDtos = this.projectMaintenanceUnitsService.selectProjectMaintenanceUnitsViewList(projectMaintenanceUnitsViewDto);
        return AjaxResult.success(projectMaintenanceUnitsViewDtos);
    }

    @ApiOperation("取得指定运维单位的维修队长列表")
    @GetMapping(value = "/getTl")
    public AjaxResult getTl(@RequestParam Long muid) {
        // 维修队长 = 6
        List<SysUser> sysUsers = this.sysUserService.selectByMuId(muid, CommonConstant.ROLE_MTL, null);
        return AjaxResult.success(sysUsers);
    }

    @ApiOperation("根据运维队id取用户列表")
    @GetMapping(value = "/getStaff")
    public AjaxResult getStaff(@RequestParam Long mtid) {
        List<Long> teamIds = new ArrayList<>();
        teamIds.add(mtid);
        List<SysUser> sysUsers = this.sysUserService.selectUserByTeamIds(teamIds, null);
        return AjaxResult.success(sysUsers);
    }

    @ApiOperation("取得摄像机类型列表")
    @GetMapping(value = "/getCameraType")
    public AjaxResult getCameraType() {
        SysDictData sysDictData = new SysDictData();
        sysDictData.setDictType(CommonParameter.HSW_CAMERA_TYPE);
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectDictDataList(sysDictData);
        return AjaxResult.success(sysDictDatas);
    }

    @ApiOperation("取得摄像机生产商列表")
    @GetMapping(value = "/getDeviceManufacturer")
    public AjaxResult getDeviceManufacturer() {
        SysDictData sysDictData = new SysDictData();
        sysDictData.setDictType(CommonParameter.HSW_CAMERA_MANUFACTURER);
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectDictDataList(sysDictData);
        return AjaxResult.success(sysDictDatas);
    }

    @ApiOperation("取得网络运营商列表")
    @GetMapping(value = "/getTelecomOperators")
    public AjaxResult getTelecomOperators() {
        SysDictData sysDictData = new SysDictData();
        sysDictData.setDictType(CommonParameter.HSW_NETWORK_OPERATOR);
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectDictDataList(sysDictData);
        return AjaxResult.success(sysDictDatas);
    }

    @ApiOperation("取得电力公司列表")
    @GetMapping(value = "/getPowerCompany")
    public  AjaxResult getPowerCompany() {
        SysDictData sysDictData = new SysDictData();
        sysDictData.setDictType(CommonParameter.HSW_POWER_OPERATION);
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectDictDataList(sysDictData);
        return AjaxResult.success(sysDictDatas);
    }

    @ApiOperation("取得建设单位的派单员列表")
    @GetMapping(value = "/getSender")
    public AjaxResult getSender() {
        // 角色-》派单员 11，用户类型-》2=建设单位用户
        List<SysUser> sysUsers = this.sysUserService.selectSysUserListByRoleId(CommonConstant.ROLE_DISPATCHER, CommonConstant.TYPE_CONSTRUCTION_UNIT);
        return AjaxResult.success(sysUsers);
    }
}
