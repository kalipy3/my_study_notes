package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.dto.CameraViewDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.FaultViewPageableDto;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.system.service.ISysDictDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 视点地图
 *
 * @author zyj
 * @date 2020/11/20 11:35
 */
@Api("视点地图")
@RestController
@RequestMapping("/hsw/viewMap")
public class HswViewMapController extends BaseController {

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    /**
     * 获取项目树
     *
     * @return
     */
    @ApiOperation("获取项目树")
    @GetMapping("/getProjectTree")
    public AjaxResult getProjectTree() {
        return AjaxResult.success(hswProjectService.getTreeByArea());
    }

    /**
     * 获取摄像头点位
     *
     * @return
     */
    @ApiOperation("获取摄像头点位")
    @GetMapping("/getCameraMarker")
    public AjaxResult getCameraMarker() {

        // 获取当前登录用户可获取项目id
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            pidByUser.add(-1L);
        }
        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setPids(pids);
        List<CameraViewDto> cameraViewDtos = this.hswCameraService.selectCameraViewList(cameraViewDto);//所管辖的所有摄像机

        FaultViewPageableDto faultViewPageableDto = new FaultViewPageableDto();
        faultViewPageableDto.setPids(pids);
        faultViewPageableDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);

        // 获取故障级别字典
        List<SysDictData> faultLevelDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_LEVEL);

        List<FaultViewDto> faultViewDtos = this.hswFaultInfoService.selectFaultViewList2(faultViewPageableDto);
        faultViewDtos.forEach(fault -> {
            if (fault.getInfluenceCameraCount() > 0) {
                if (fault.getPort() == CommonConstant.FAULT_POST) {
                    //该ip下所有摄像机当前都处于故障状态
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                } else {
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp()) && fault.getPort().equals(c.getPort())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                }
            }
        });

        String localCity = "高安市";

        // 项目区域字典
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_PROJECT_AREA);

        for (SysDictData d : sysDictDatas) {
            if (CommonParameter.AREA.equals(d.getDictLabel())) {
                localCity = d.getDictValue();
            }
        }

//        switch (sysUser.getType()) {
//            case 1://系统管理员
//                break;
//            default:
//                if (pids.length > 0) {
//                    HswProject project = this.hswProjectService.selectHswProjectById(pids[0]);
//                    if (project != null) {
//                        localCity = project.getDistrictLabel();
//                    }
//                }
//                break;
//        }

        Map<String, Object> result = new HashMap<>();
        result.put("localCity", localCity);
        result.put("data", cameraViewDtos);
        return AjaxResult.success(result);
    }

    /**
     * 获取摄像头列表
     *
     * @param pid
     * @param divideWorkId
     * @param keyword
     * @return
     */
    @ApiOperation("获取摄像头列表")
    @GetMapping("/cameraList")
    public TableDataInfo cameraList(@RequestParam(value = "pid") Long pid,
                                    @RequestParam(value = "divideWorkId") Long divideWorkId,
                                    @RequestParam(value = "keyword", required = false) String keyword) {
        startPage();
        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setPid(pid);
        cameraViewDto.setDivideWorkId(divideWorkId);
        cameraViewDto.setKeyword(keyword);

        List<CameraViewDto> list = this.hswCameraService.selectCameraViewList(cameraViewDto);
        return getDataTable(list);
    }

    /**
     * 修改摄像机经纬度
     *
     * @param hswCamera
     * @return
     */
    @ApiOperation("修改摄像机经纬度")
    @Log(title = "修改摄像机经纬度", businessType = BusinessType.UPDATE)
    @PutMapping("/editCameraCoordinate")
    public AjaxResult editCameraCoordinate(@RequestBody HswCamera hswCamera) {

        if (hswCamera.getId() == null) {
            return AjaxResult.error("id不能为空");
        }

        if (StringUtils.isEmpty(hswCamera.getLatitude())) {
            return AjaxResult.error("纬度不能为空");
        }

        if (StringUtils.isEmpty(hswCamera.getLongitude())) {
            return AjaxResult.error("经度不能为空");
        }

        HswCamera updateHswCamera = new HswCamera();
        updateHswCamera.setId(hswCamera.getId());
        updateHswCamera.setLatitude(hswCamera.getLatitude());
        updateHswCamera.setLongitude(hswCamera.getLongitude());
        updateHswCamera.setUpdateBy(SecurityUtils.getUsername());

        return toAjax(hswCameraService.updateHswCamera(updateHswCamera));
    }

    private int getFaultLevel(List<SysDictData> sysDictDatas, Integer type) {
        int level = CommonConstant.FAULT_LEVEL_ZERO;

        if (!sysDictDatas.isEmpty()) {
            for (SysDictData sysDictData : sysDictDatas) {
                if (sysDictData.getDictLabel().equals(type.toString())) {
                    level = Integer.valueOf(sysDictData.getDictValue());
                }
            }
        }
        return level;
    }


}
