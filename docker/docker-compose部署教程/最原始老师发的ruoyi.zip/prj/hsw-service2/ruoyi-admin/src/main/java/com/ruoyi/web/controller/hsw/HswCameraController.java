package com.ruoyi.web.controller.hsw;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.model.LoginUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.web.service.TokenService;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import com.ruoyi.system.service.ISysDictTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * 摄像机Controller
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Api("摄像机管理")
@RestController
@RequestMapping("/hsw/camera")
public class HswCameraController extends BaseController {
    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ISysDictTypeService dictTypeService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询摄像机列表
     */
    @ApiOperation("查询摄像机列表")
    @PreAuthorize("@ss.hasPermi('hsw:camera:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswCamera hswCamera) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswCamera.setPids(pids);

        startPage();
        List<HswCamera> list = hswCameraService.selectHswCameraList(hswCamera);
        return getDataTable(list);
    }

    /**
     * 导出摄像机列表
     */
    @ApiOperation("导出摄像机列表")
    @PreAuthorize("@ss.hasPermi('hsw:camera:export')")
    @Log(title = "摄像机", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswCamera hswCamera) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswCamera.setPids(pids);

        List<HswCamera> list = hswCameraService.selectHswCameraList(hswCamera);
        ExcelUtil<HswCamera> util = new ExcelUtil<HswCamera>(HswCamera.class);
        return util.exportExcel(list, "摄像机列表");
    }

    /**
     * 获取摄像机详细信息
     */
    @ApiOperation("获取摄像机详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:camera:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswCameraService.selectHswCameraById(id));
    }

    /**
     * 新增摄像机
     */
    @ApiOperation("新增摄像机")
    @PreAuthorize("@ss.hasPermi('hsw:camera:add')")
    @Log(title = "摄像机", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody HswCamera hswCamera) {
        if (UserConstants.NOT_UNIQUE.equals(hswCameraService.checkSelfIpUnique(hswCamera))) {
            return AjaxResult.error("新增摄像机失败，自身IP'" + hswCamera.getSelfIp() + "'已经存在");
        }

        if (UserConstants.NOT_UNIQUE.equals(hswCameraService.checkPortUniqueByIp(hswCamera))) {
            return AjaxResult.error("新增摄像机失败，端口'" + hswCamera.getPort() + "'已经存在");
        }

        HswDiagnosisDevice hswDiagnosisDevice = hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswCamera.getIp());

        if (StringUtils.isNull(hswDiagnosisDevice)) {
            return AjaxResult.error("新增摄像机失败，所属诊断器ip'" + hswCamera.getIp() + "'不存在");
        }

        // 诊断器上行端口为电口1，代表诊断器已占用端口1，摄像机不允许端口为1
        if (hswDiagnosisDevice.getUplinkPort().equals(3)) {
            if (hswCamera.getPort().equals(1)) {
                return AjaxResult.error("新增摄像机失败，摄像机端口'" + hswCamera.getPort() + "'已被诊断器占用");
            }
        }

        // 诊断器最多只能添加4个摄像头
        if (hswCameraService.selectCameraCountByIp(hswCamera.getIp()) > 3) {
            return AjaxResult.error("新增失败:所属诊断器ip'" + hswCamera.getIp() + "'下已添加4个摄像头");
        }

        hswCamera.setCreateBy(SecurityUtils.getUsername());
        hswCamera.setInstallTime(DateUtils.getDateMr(hswCamera.getInstallDate()));
        return toAjax(hswCameraService.insertHswCamera(hswCamera));
    }

    /**
     * 修改摄像机
     */
    @ApiOperation("修改摄像机")
    @PreAuthorize("@ss.hasPermi('hsw:camera:edit')")
    @Log(title = "摄像机", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody HswCamera hswCamera) {
        if (UserConstants.NOT_UNIQUE.equals(hswCameraService.checkSelfIpUnique(hswCamera))) {
            return AjaxResult.error("修改摄像机失败，自身IP'" + hswCamera.getSelfIp() + "'已经存在");
        }

        if (UserConstants.NOT_UNIQUE.equals(hswCameraService.checkPortUniqueByIp(hswCamera))) {
            return AjaxResult.error("修改摄像机失败，端口'" + hswCamera.getPort() + "'已经存在");
        }

        if (StringUtils.isNull(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswCamera.getIp()))) {
            return AjaxResult.error("修改摄像机失败，所属诊断器ip'" + hswCamera.getIp() + "'不存在");
        }

        HswDiagnosisDevice hswDiagnosisDevice = hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswCamera.getIp());

        // 诊断器上行端口为电口1，代表诊断器已占用端口1，摄像机不允许端口为1
        if (hswDiagnosisDevice.getUplinkPort().equals(3)) {
            if (hswCamera.getPort().equals(1)) {
                return AjaxResult.error("修改摄像机失败，摄像机端口'" + hswCamera.getPort() + "'已被诊断器占用");
            }
        }

        hswCamera.setUpdateBy(SecurityUtils.getUsername());
        hswCamera.setInstallTime(DateUtils.getDateMr(hswCamera.getInstallDate()));
        return toAjax(hswCameraService.updateHswCamera(hswCamera));
    }

    /**
     * 删除摄像机
     */
    @ApiOperation("删除摄像机")
    @PreAuthorize("@ss.hasPermi('hsw:camera:remove')")
    @Log(title = "摄像机", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswCameraService.deleteHswCameraByIds(ids));
    }

    /**
     * 下载导入模板
     *
     * @return
     */
    @ApiOperation("下载导入模板")
    @GetMapping("/importTemplate")
    public AjaxResult importTemplate() throws NoSuchFieldException, IllegalAccessException {

        // 类型Excel注解添加combo
        this.initExcel("deviceType", CommonParameter.HSW_CAMERA_TYPE);

        // 端口号Excel注解添加combo
        this.initExcel("port", CommonParameter.HSW_CAMERA_PORT);

        // 生产厂商Excel注解添加combo
        this.initExcel("manufacturer", CommonParameter.HSW_CAMERA_MANUFACTURER);

        ExcelUtil<HswCamera> util = new ExcelUtil<HswCamera>(HswCamera.class);
        return util.importTemplateExcel("摄像机数据");
    }

    /**
     * 获取字典数据，给Excel注解的combo属性赋值
     *
     * @param fileName 字段名称
     * @param dictType 字典类型
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    private void initExcel(String fileName, String dictType) throws NoSuchFieldException, IllegalAccessException {
        Field field = HswCamera.class.getDeclaredField(fileName);
        Excel excelAnnotation = field.getAnnotation(Excel.class);
        InvocationHandler invocationHandler = Proxy.getInvocationHandler(excelAnnotation);
        Field memberValues = invocationHandler.getClass().getDeclaredField("memberValues");
        memberValues.setAccessible(true);
        Map map = (Map) memberValues.get(invocationHandler);

        List<SysDictData> dicList = dictTypeService.selectDictDataByType(dictType);
        Object[] objects = dicList.stream().map(l -> l.getDictLabel()).toArray();
        String[] combo = Arrays.copyOf(objects, objects.length, String[].class);
        map.put("combo", combo);
    }

    /**
     * 导入excel
     *
     * @param file 导入的excel文件
     * @return
     * @throws Exception
     */
    @ApiOperation("导入excel")
    @Log(title = "摄像机", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('hsw:camera:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception {

        if (StringUtils.isNull(file)) {
            return AjaxResult.error("导入失败，导入文件不能为空");
        }

        ExcelUtil<HswCamera> util = new ExcelUtil<HswCamera>(HswCamera.class);
        List<HswCamera> hswCameraList = util.importExcel(file.getInputStream());
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String operName = loginUser.getUsername();

        int failureNum = 1;
        StringBuilder failureMsg = new StringBuilder();
        String resultMsg;
        for (HswCamera camera : hswCameraList) {
            failureNum++;
            resultMsg = hswCameraService.checkValid(camera, hswCameraList);
            if (StringUtils.isNotEmpty(resultMsg)) {
                failureMsg.append("<br/>第" + failureNum + "项" + resultMsg);
            }
        }

        if (StringUtils.isNotEmpty(failureMsg.toString())) {
            return AjaxResult.error(failureMsg.toString());
        }

        String message = hswCameraService.importCamera(hswCameraList, operName);
        return AjaxResult.success(message);
    }

    /**
     * 根据所属诊断器ip和端口号获取摄像机详细信息
     *
     * @param ip
     * @param port
     * @return
     */
    @ApiOperation("根据所属诊断器ip和端口号获取摄像机详细信息")
//    @PreAuthorize("@ss.hasPermi('hsw:camera:queryByIpAndPort')")
    @GetMapping(value = "/{ip}/{port}")
    public AjaxResult getInfoByIpAndPort(@PathVariable("ip") String ip, @PathVariable("port") String port) {
        return AjaxResult.success(hswCameraService.selectHswCameraByIpAndPort(ip, port));
    }
}
