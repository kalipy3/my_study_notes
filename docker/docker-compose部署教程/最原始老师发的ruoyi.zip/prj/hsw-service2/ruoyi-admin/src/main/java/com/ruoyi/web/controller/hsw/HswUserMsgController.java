package com.ruoyi.web.controller.hsw;

import java.util.Date;
import java.util.List;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.HswUserMsg;
import com.ruoyi.hsw.dto.MyMsgPageableDto;
import com.ruoyi.hsw.dto.UserMsgView;
import com.ruoyi.hsw.service.IHswUserMsgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 消息发送信息Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("用户消息管理")
@RestController
@RequestMapping("/hsw/userMsg")
public class HswUserMsgController extends BaseController {
    @Autowired
    private IHswUserMsgService hswUserMsgService;

    /**
     * 查询消息发送信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:msg:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswUserMsg hswUserMsg) {
        startPage();
        List<HswUserMsg> list = hswUserMsgService.selectHswUserMsgList(hswUserMsg);
        return getDataTable(list);
    }

    /**
     * 导出消息发送信息列表
     */
    @PreAuthorize("@ss.hasPermi('system:msg:export')")
    @Log(title = "消息发送信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswUserMsg hswUserMsg) {
        List<HswUserMsg> list = hswUserMsgService.selectHswUserMsgList(hswUserMsg);
        ExcelUtil<HswUserMsg> util = new ExcelUtil<HswUserMsg>(HswUserMsg.class);
        return util.exportExcel(list, "用户消息列表");
    }

    /**
     * 获取消息发送信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:msg:query')")
    @GetMapping(value = "/{mid}")
    public AjaxResult getInfo(@PathVariable("mid") Long mid) {
        return AjaxResult.success(hswUserMsgService.selectHswUserMsgById(mid));
    }

    /**
     * 新增消息发送信息
     */
    @PreAuthorize("@ss.hasPermi('system:msg:add')")
    @Log(title = "消息发送信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HswUserMsg hswUserMsg) {
        return toAjax(hswUserMsgService.insertHswUserMsg(hswUserMsg));
    }

    /**
     * 修改消息发送信息
     */
    @PreAuthorize("@ss.hasPermi('system:msg:edit')")
    @Log(title = "消息发送信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HswUserMsg hswUserMsg) {
        return toAjax(hswUserMsgService.updateHswUserMsg(hswUserMsg));
    }

    /**
     * 删除消息发送信息
     */
    @PreAuthorize("@ss.hasPermi('system:msg:remove')")
    @Log(title = "消息发送信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{mids}")
    public AjaxResult remove(@PathVariable Long[] mids) {
        return toAjax(hswUserMsgService.deleteHswUserMsgByIds(mids));
    }

    /**
     * 我的消息
     */
    @ApiOperation("我的消息")
    @GetMapping("/myMsg")
    public TableDataInfo myMsg(MyMsgPageableDto myMsgPageableDto) {
        startPage();
        // 获取当前登录人id
        Long userId = SecurityUtils.getLoginUser().getUser().getUserId();
        myMsgPageableDto.setUserId(userId);
        List<UserMsgView> list = this.hswUserMsgService.selectUserMsgView(myMsgPageableDto);
        return getDataTable(list);
    }

    /**
     * 全部标记已读
     */
    @ApiOperation("全部标记已读")
    @GetMapping("/allRead")
    public AjaxResult allRead() {
        // 获取当前登录人id
        Long userId = SecurityUtils.getLoginUser().getUser().getUserId();
        Long readTime = DateUtils.getDateMr(new Date());

        if (!this.hswUserMsgService.existCountByUserId(userId, CommonConstant.STATUS_UNREAD)) {
            return toAjax(1);
        }

        return toAjax(this.hswUserMsgService.allRead(CommonConstant.STATUS_READ, userId, readTime));
    }

    /**
     * 标记单个已读
     */
    @ApiOperation("标记单个已读")
    @GetMapping("/read/{mid}")
    public AjaxResult read(@PathVariable("mid") Long mid) {
        // 获取当前登录人id
        Long userId = SecurityUtils.getLoginUser().getUser().getUserId();
        Long readTime = DateUtils.getDateMr(new Date());
        return toAjax(this.hswUserMsgService.read(CommonConstant.STATUS_READ, userId, mid, readTime));
    }
}
