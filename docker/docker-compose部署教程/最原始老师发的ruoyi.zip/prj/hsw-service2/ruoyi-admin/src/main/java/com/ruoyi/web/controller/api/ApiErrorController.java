package com.ruoyi.web.controller.api;

public class ApiErrorController {
}
