package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.constant.CommonSms;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.HswFaultInfo;
import com.ruoyi.hsw.domain.HswJobInfo;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswJobInfoService;
import com.ruoyi.hsw.service.ISmsService;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.service.ISysConfigService;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 故障信息Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("故障信息Controller")
@RestController
@RequestMapping("/hsw/faultInfo")
public class HswFaultInfoController extends BaseController {
    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private IHswJobInfoService hswJobInfoService;

    @Autowired
    private IHswDivideWorkService hswDivideWorkService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISmsService smsService;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    /**
     * 查询活动故障信息列表
     */
    @ApiOperation("查询活动故障信息列表")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswFaultInfo hswFaultInfo) {
        HswFaultInfo faultInfo = this.hswFaultInfoService.dataPermission(hswFaultInfo);
        startPage();
        List<HswFaultInfo> list = hswFaultInfoService.selectHswFaultInfoList(faultInfo);
        return getDataTable(list);
    }

    /**
     * 查询历史故障信息列表
     */
    @ApiOperation("查询历史故障信息列表")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:historyList')")
    @GetMapping("/historyList")
    public TableDataInfo historyList(HswFaultInfo hswFaultInfo) {
        HswFaultInfo faultInfo = this.hswFaultInfoService.dataPermission(hswFaultInfo);
        startPage();
        List<HswFaultInfo> list = hswFaultInfoService.selectHistoryList(faultInfo);
        return getDataTable(list);
    }

    /**
     * 导出活动故障信息列表
     */
    @ApiOperation("导出活动故障信息列表")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:export')")
    @Log(title = "故障信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswFaultInfo hswFaultInfo) {
        HswFaultInfo faultInfo = this.hswFaultInfoService.dataPermission(hswFaultInfo);
        List<HswFaultInfo> list = hswFaultInfoService.selectHswFaultInfoList(faultInfo);
        if (!list.isEmpty()) {
            List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
            list.forEach(entity -> {
                // 故障类型
                if (!dictDataList.isEmpty()) {
                    dictDataList.forEach(dictData -> {
                        if (entity.getType().equals(dictData.getDictValue())) {
                            entity.setType(dictData.getDictLabel());
                        }
                    });
                }

                // 故障状态
                if (StringUtils.isNotNull(entity.getStatus())) {
                    if (!sysDictDataList.isEmpty()) {
                        sysDictDataList.forEach(dictData -> {
                            if (entity.getStatus().equals(dictData.getDictValue())) {
                                entity.setStatus(dictData.getDictLabel());
                            }
                        });
                    }
                }

                // 发生时间
                if (entity.getTakeTime() != null && entity.getTakeTime() > 0) {
                    entity.setTakeDate(DateUtils.parseSecondsToDate(entity.getTakeTime()));
                } else {
                    entity.setTakeDate(null);
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }
            });
        }
        ExcelUtil<HswFaultInfo> util = new ExcelUtil<HswFaultInfo>(HswFaultInfo.class);
        return util.exportExcel(list, "活动故障信息列表");
    }

    /**
     * 导出历史故障信息列表
     */
    @ApiOperation("导出历史故障信息列表")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:historyExport')")
    @Log(title = "故障信息", businessType = BusinessType.EXPORT)
    @GetMapping("/historyExport")
    public AjaxResult historyExport(HswFaultInfo hswFaultInfo) {
        HswFaultInfo faultInfo = this.hswFaultInfoService.dataPermission(hswFaultInfo);
        List<HswFaultInfo> list = hswFaultInfoService.selectHistoryList(faultInfo);
        if (!list.isEmpty()) {
            List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);
            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
            list.forEach(entity -> {
                // 故障类型
                if (!dictDataList.isEmpty()) {
                    dictDataList.forEach(dictData -> {
                        if (entity.getType().equals(dictData.getDictValue())) {
                            entity.setType(dictData.getDictLabel());
                        }
                    });
                }

                // 故障状态
                if (StringUtils.isNotNull(entity.getStatus())) {
                    if (!sysDictDataList.isEmpty()) {
                        sysDictDataList.forEach(dictData -> {
                            if (entity.getStatus().equals(dictData.getDictValue())) {
                                entity.setStatus(dictData.getDictLabel());
                            }
                        });
                    }
                }

                // 发生时间
                if (entity.getTakeTime() != null && entity.getTakeTime() > 0) {
                    entity.setTakeDate(DateUtils.parseSecondsToDate(entity.getTakeTime()));
                } else {
                    entity.setTakeDate(null);
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }
            });
        }
        ExcelUtil<HswFaultInfo> util = new ExcelUtil<HswFaultInfo>(HswFaultInfo.class);
        return util.exportExcel(list, "历史故障信息列表");
    }

    /**
     * 获取故障信息详细信息
     */
    @ApiOperation("获取故障信息详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswFaultInfoService.selectHswFaultInfoById(id));
    }

    /**
     * 新增故障信息
     */
    @ApiOperation("新增故障信息")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:add')")
    @PostMapping(value = "/add")
    public AjaxResult add(@RequestBody HswFaultInfo hswFaultInfo) {

        if (hswFaultInfo.getId() != null) {
            hswFaultInfo.setId(null);
        }

        hswFaultInfo.setCreateBy(SecurityUtils.getUsername());
        hswFaultInfo.setCreateTime(DateUtils.getNowDate());
        return toAjax(hswFaultInfoService.insertHswFaultInfo(hswFaultInfo));
    }

    /**
     * 删除故障信息
     */
    @ApiOperation("删除故障信息")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:remove')")
    @Log(title = "故障信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswFaultInfoService.deleteHswFaultInfoByIds(ids));
    }

    /**
     * 查询维修人员
     */
    @ApiOperation("删除故障信息")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:faultAssign')")
    @GetMapping("/mtMan")
    public AjaxResult mtMan(@RequestParam("id") Long id) {
        return AjaxResult.success(this.hswFaultInfoService.mtMan(id));
    }

    /**
     * 故障派单
     */
    @ApiOperation("故障派单")
    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:faultAssign')")
    @Log(title = "故障派单", businessType = BusinessType.INSERT)
    @PostMapping("/faultAssign")
    public AjaxResult faultAssign(@RequestBody HswJobInfo hswJobInfo) {
        SysUser receiverUser = this.sysUserService.selectUserById(hswJobInfo.getReceiverId());
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();

        if (hswJobInfo.getId() != null) {
            hswJobInfo.setId(null);
        }

        if (this.hswJobInfoService.existFaultId(hswJobInfo.getFaultId())) {
            AjaxResult.error("派单失败：重复派单");
        }

        Map<String, Object> result = hswFaultInfoService.insertHswJobInfo(hswJobInfo);
        if (!result.get("code").equals(1)) {
            return AjaxResult.error("派单失败");
        }

        Long cuId = (Long) result.get("cuId");
        String jobNo = (String) result.get("jobNo");

        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", sysUser.getNickName());
        templateParam.put("job_no", jobNo);

        Map<String, Object> args = new HashMap<>();
        args.put("title", "您有一个工单需要处理");
        args.put("send_name", sysUser.getNickName());
        args.put("receiver_id", receiverUser.getUserId().toString());
        args.put("receiver_name", receiverUser.getNickName());
        args.put("job_no", jobNo);
        args.put("tpl_key", "TPL_MSG_PD");

        SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
        if (StringUtils.isNotNull(sysConfig)) {
            if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                this.smsService.sendSMS(cuId, receiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);
            }
        }

        return AjaxResult.success("派单成功");
    }

    /**
     * 根据项目id获取维修人员信息
     *
     * @param pid
     * @return
     */
    @ApiOperation("根据项目id获取维修人员信息")
//    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:getMtUser')")
    @GetMapping("/getMtUser")
    public AjaxResult getMtUser(@RequestParam("pid") Long pid) {

        // 获取分工
        List<HswDivideWork> hswDivideWorkList = this.hswDivideWorkService.selectHswDivideWorkByPid(pid);

        if (CollectionUtils.isEmpty(hswDivideWorkList)) {
            return AjaxResult.success();
        }

        // 获取维修队id列表
        List<Long> teamIds = hswDivideWorkList.stream().map(d -> d.getAtId()).collect(Collectors.toList());

        // 获取用户信息
        List<SysUser> sysUsers = this.sysUserService.selectUserByTeamIds(teamIds, null);

        return AjaxResult.success(sysUsers);
    }

    /**
     * 根据项目id和角色获取维修人员信息
     */
    @ApiOperation("根据项目id和类型获取维修人员信息")
//    @PreAuthorize("@ss.hasPermi('hsw:faultInfo:getMtUser')")
    @GetMapping("/getMtUserByRole")
    public AjaxResult getMtUserByRole(@RequestParam("pid") Long pid, @RequestParam("personnel") Integer role) {

        // 获取分工
        List<HswDivideWork> hswDivideWorkList = this.hswDivideWorkService.selectHswDivideWorkByPid(pid);

        if (CollectionUtils.isEmpty(hswDivideWorkList)) {
            return AjaxResult.success();
        }

        // 获取维修队id列表
        List<Long> teamIds = hswDivideWorkList.stream().map(d -> d.getAtId()).collect(Collectors.toList());

        // 获取用户信息
        List<SysUser> sysUsers = this.sysUserService.selectUserByTeamIds(teamIds, role);

        return AjaxResult.success(sysUsers);
    }

}
