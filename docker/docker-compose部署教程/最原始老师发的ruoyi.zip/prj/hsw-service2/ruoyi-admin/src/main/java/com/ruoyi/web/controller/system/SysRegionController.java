package com.ruoyi.web.controller.system;

import java.util.ArrayList;
import java.util.List;

import com.ruoyi.system.domain.vo.RegionDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.SysRegion;
import com.ruoyi.system.service.ISysRegionService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 中国省市区数据库Controller
 *
 * @author ruoyi
 * @date 2020-12-04
 */
@Api("行政区划")
@RestController
@RequestMapping("/system/region")
public class SysRegionController extends BaseController {
    @Autowired
    private ISysRegionService sysRegionService;

    /**
     * 查询中国省市区数据库列表
     */
    @PreAuthorize("@ss.hasPermi('system:region:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysRegion sysRegion) {
        startPage();
        List<SysRegion> list = sysRegionService.selectSysRegionList(sysRegion);
        return getDataTable(list);
    }

    /**
     * 导出中国省市区数据库列表
     */
    @PreAuthorize("@ss.hasPermi('system:region:export')")
    @Log(title = "中国省市区数据库", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysRegion sysRegion) {
        List<SysRegion> list = sysRegionService.selectSysRegionList(sysRegion);
        ExcelUtil<SysRegion> util = new ExcelUtil<SysRegion>(SysRegion.class);
        return util.exportExcel(list, "region");
    }

    /**
     * 获取中国省市区数据库详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:region:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(sysRegionService.selectSysRegionById(id));
    }

    /**
     * 新增中国省市区数据库
     */
    @PreAuthorize("@ss.hasPermi('system:region:add')")
    @Log(title = "中国省市区数据库", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysRegion sysRegion) {
        return toAjax(sysRegionService.insertSysRegion(sysRegion));
    }

    /**
     * 修改中国省市区数据库
     */
    @PreAuthorize("@ss.hasPermi('system:region:edit')")
    @Log(title = "中国省市区数据库", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysRegion sysRegion) {
        return toAjax(sysRegionService.updateSysRegion(sysRegion));
    }

    /**
     * 删除中国省市区数据库
     */
    @PreAuthorize("@ss.hasPermi('system:region:remove')")
    @Log(title = "中国省市区数据库", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(sysRegionService.deleteSysRegionByIds(ids));
    }

    /**
     * 查询中国省市区数据库列表
     */
    @ApiOperation("取得所有区划父子级列表")
    @GetMapping("/cascadeList")
    public AjaxResult cascadeList(@RequestParam(defaultValue = "0") String parentCode) {
        List<RegionDto> regionDtos = sysRegionService.selectCascadeList(parentCode);
        return AjaxResult.success(regionDtos);
    }

}
