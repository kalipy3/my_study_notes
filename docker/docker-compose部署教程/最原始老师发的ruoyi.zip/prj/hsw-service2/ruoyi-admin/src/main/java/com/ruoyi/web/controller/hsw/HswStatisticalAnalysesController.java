package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.domain.HswFaultInfo;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.domain.vo.FaultStatusVo;
import com.ruoyi.hsw.domain.vo.JobStaffStatisticsVo;
import com.ruoyi.hsw.domain.vo.JobTeamStatisticsVo;
import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.DiagnosisDeviceViewDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.service.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Api("统计分析Controller")
@RestController
@RequestMapping("/hsw/statisticalAnalyses")
public class HswStatisticalAnalysesController extends BaseController {

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private IHswJobInfoService hswJobInfoService;

    @Autowired
    private IHswDivideWorkService hswDivideWorkService;

    /**
     * 获取项目树
     *
     * @return
     */
    @ApiOperation("获取项目树")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:projectTree')")
    @GetMapping("/getProjectTree")
    public AjaxResult getProjectTree() {
        return AjaxResult.success(hswProjectService.getTreeByCuId());
    }

    /**
     * 资产统计-各项目设备数量
     *
     * @param pids
     * @return
     */
    @ApiOperation("资产统计-各项目设备数量")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:assets')")
    @GetMapping("/assets")
    public AjaxResult assets(@RequestParam(value = "pids", required = false) Long[] pids) {
        // pids未传时，获取当前登录用户可查询的项目id
//        pids = setDefaultPid(pids);

        return AjaxResult.success(hswDiagnosisDeviceService.selectGroupByPidCount(pids));
    }

    /**
     * 资产统计-获取各设备总数
     *
     * @param pids
     * @return
     */
    @ApiOperation("资产统计-获取各设备总数")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:deviceAll')")
    @GetMapping("/assets/getDeviceAll")
    public AjaxResult getDeviceAll(@RequestParam(value = "pids", required = false) Long[] pids) {

        // pids未传时，获取当前登录用户可查询的项目id
//        pids = setDefaultPid(pids);

        return AjaxResult.success(hswDiagnosisDeviceService.selectByPidCountAll(pids));
    }

    /**
     * 资产统计-导出
     *
     * @param pids
     * @return
     */
    @ApiOperation("资产统计-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:assetsExport')")
    @Log(title = "资产统计-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/assets/export")
    public AjaxResult assetsExport(@RequestParam(value = "pids", required = false) Long[] pids) {

        // pids未传时，获取当前登录用户可查询的项目id
//        pids = setDefaultPid(pids);

        List<DeviceCountDto> list = hswDiagnosisDeviceService.selectGroupByPidCount(pids);
        ExcelUtil<DeviceCountDto> util = new ExcelUtil<DeviceCountDto>(DeviceCountDto.class);
        return util.exportExcel(list, "资产统计");
    }

    /**
     * 运行统计
     *
     * @param pids
     * @return
     */
    @ApiOperation("运行统计")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:run')")
    @GetMapping("/run")
    public AjaxResult run(@RequestParam(value = "pids", required = false) Long[] pids,
                          @RequestParam(value = "startDate", required = false) Long startDate,
                          @RequestParam(value = "endDate", required = false) Long endDate) {
        return AjaxResult.success(hswFaultInfoService.selectFaultCountByPidsAndDate(pids, startDate, endDate));
    }

    /**
     * 运行统计-导出
     *
     * @param pids
     * @return
     */
    @ApiOperation("运行统计-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:runExport')")
    @Log(title = "运行统计-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/run/export")
    public AjaxResult runExport(@RequestParam(value = "pids", required = false) Long[] pids,
                                @RequestParam(value = "startDate", required = false) Long startDate,
                                @RequestParam(value = "endDate", required = false) Long endDate) {
        List<FaultViewDto> list = hswFaultInfoService.selectFaultCountByPidsAndDate(pids, startDate, endDate);
        ExcelUtil<FaultViewDto> util = new ExcelUtil<FaultViewDto>(FaultViewDto.class);
        return util.exportExcel(list, "运行统计");
    }

    /**
     * 故障统计
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("故障统计")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:fault')")
    @GetMapping("/fault")
    public AjaxResult fault(@RequestParam(value = "pids", required = false) Long[] pids,
                            @RequestParam(value = "startDate", required = false) Long startDate,
                            @RequestParam(value = "endDate", required = false) Long endDate) {
        // pids未传时，获取当前登录用户可查询的项目id
        pids = setDefaultPid(pids);

        return AjaxResult.success(hswFaultInfoService.selectFaultTypeCountByPidsAndDate(pids, startDate, endDate));
    }

    /**
     * 故障统计-导出
     *
     * @param pids
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("故障统计-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:faultExport')")
    @Log(title = "故障统计-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/fault/export")
    public AjaxResult faultExport(@RequestParam(value = "pids", required = false) Long[] pids,
                                  @RequestParam(value = "startDate", required = false) Long startDate,
                                  @RequestParam(value = "endDate", required = false) Long endDate) {
        // pids未传时，获取当前登录用户可查询的项目id
        pids = setDefaultPid(pids);

        Map<String, Object> stringObjectMap = hswFaultInfoService.selectFaultTypeCountByPidsAndDate(pids, startDate, endDate);
        List<FaultStatisticsVo> list = (List<FaultStatisticsVo>) stringObjectMap.get("faultList");
        ExcelUtil<FaultStatisticsVo> util = new ExcelUtil<FaultStatisticsVo>(FaultStatisticsVo.class);
        return util.exportExcel(list, "故障统计");
    }

    /**
     * 设置当前用户可查询的项目id
     *
     * @param pids
     * @return
     */
    private Long[] setDefaultPid(@RequestParam(value = "pids", required = false) Long[] pids) {
        if (pids == null || pids.length <= 0) {
            List<Long> pidByUser = hswProjectService.findPidByUser();
            if (pidByUser.isEmpty()) {
                pidByUser.add(-1L);
            }

            pids = new Long[pidByUser.size()];
            pidByUser.toArray(pids);
        }
        return pids;
    }

    /**
     * 修复统计
     *
     * @param pid
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("修复统计")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:repair')")
    @GetMapping("/repair")
    public AjaxResult repair(@RequestParam(value = "pid", required = false) Long pid,
                             @RequestParam(value = "startDate", required = false) Long startDate,
                             @RequestParam(value = "endDate", required = false) Long endDate) {
        return AjaxResult.success(hswFaultInfoService.selectFaultStatusByPidAndDate(pid, startDate, endDate));
    }

    /**
     * 修复统计-导出
     *
     * @param pid
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("修复统计-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:repairExport')")
    @Log(title = "修复统计-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/repair/export")
    public AjaxResult repairExport(@RequestParam(value = "pid", required = false) Long pid,
                                   @RequestParam(value = "startDate", required = false) Long startDate,
                                   @RequestParam(value = "endDate", required = false) Long endDate) {
        List<FaultStatusVo> list = hswFaultInfoService.selectFaultStatusByPidAndDate(pid, startDate, endDate);
        ExcelUtil<FaultStatusVo> util = new ExcelUtil<FaultStatusVo>(FaultStatusVo.class);
        return util.exportExcel(list, "修复统计");
    }

    /**
     * 获取项目列表
     *
     * @return
     */
    @ApiOperation("获取项目列表")
    @GetMapping("/getProjectList")
    public AjaxResult getProjectList() {
        return AjaxResult.success(hswProjectService.selectProjectByUser());
    }

    /**
     * 获取分工树
     *
     * @return
     */
    @ApiOperation("获取分工树")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:divideWorkTree')")
    @GetMapping("/getDivideWorkTree")
    public AjaxResult getDivideWorkTree() {
        return AjaxResult.success(hswDivideWorkService.selectTreeByPid());
    }

    /**
     * 工单统计-维修队
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("工单统计-维修队")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:job')")
    @GetMapping("/jobTeam")
    public AjaxResult jobTeam(@RequestParam(value = "divideWorkIds", required = false) Long[] divideWorkIds,
                              @RequestParam(value = "startDate", required = false) Long startDate,
                              @RequestParam(value = "endDate", required = false) Long endDate) {
        // divideWorkIds未传时，获取当前登录用户可查询的分工id
        divideWorkIds = setDefaultWorkId(divideWorkIds);


        return AjaxResult.success(hswJobInfoService.selectJobTeamByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate));
    }

    /**
     * 工单统计-维修队-导出
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("工单统计-维修队-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:jobTeamExport')")
    @Log(title = "工单统计-维修队-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/jobTeam/export")
    public AjaxResult jobTeamExport(@RequestParam(value = "divideWorkIds", required = false) Long[] divideWorkIds,
                                    @RequestParam(value = "startDate", required = false) Long startDate,
                                    @RequestParam(value = "endDate", required = false) Long endDate) {
        // divideWorkIds未传时，获取当前登录用户可查询的分工id
        divideWorkIds = setDefaultWorkId(divideWorkIds);

        List<JobTeamStatisticsVo> list = hswJobInfoService.selectJobTeamByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate);
        ExcelUtil<JobTeamStatisticsVo> util = new ExcelUtil<JobTeamStatisticsVo>(JobTeamStatisticsVo.class);
        return util.exportExcel(list, "维修队工单统计");
    }


    /**
     * 工单统计-维修员工
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("工单统计-维修员工")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:job')")
    @GetMapping("/jobStaff")
    public AjaxResult jobStaff(@RequestParam(value = "divideWorkIds", required = false) Long[] divideWorkIds,
                               @RequestParam(value = "startDate", required = false) Long startDate,
                               @RequestParam(value = "endDate", required = false) Long endDate) {
        // divideWorkIds未传时，获取当前登录用户可查询的分工id
        divideWorkIds = setDefaultWorkId(divideWorkIds);
        return AjaxResult.success(hswJobInfoService.selectJobStaffByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate));
    }

    /**
     * 工单统计-维修员工-导出
     *
     * @param divideWorkIds
     * @param startDate
     * @param endDate
     * @return
     */
    @ApiOperation("工单统计-维修员工-导出")
    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:jobStaffExport')")
    @Log(title = "工单统计-维修员工-导出", businessType = BusinessType.EXPORT)
    @GetMapping("/jobStaff/export")
    public AjaxResult jobStaffExport(@RequestParam(value = "divideWorkIds", required = false) Long[] divideWorkIds,
                                     @RequestParam(value = "startDate", required = false) Long startDate,
                                     @RequestParam(value = "endDate", required = false) Long endDate) {
        // divideWorkIds未传时，获取当前登录用户可查询的分工id
        divideWorkIds = setDefaultWorkId(divideWorkIds);

        List<JobStaffStatisticsVo> list = hswJobInfoService.selectJobStaffByDivideWorkIdsAndDate(divideWorkIds, startDate, endDate);
        ExcelUtil<JobStaffStatisticsVo> util = new ExcelUtil<JobStaffStatisticsVo>(JobStaffStatisticsVo.class);
        return util.exportExcel(list, "维修员工工单统计");
    }

    /**
     * 设置当前用户可查询的分工
     *
     * @param divideWorkIds
     * @return
     */
    private Long[] setDefaultWorkId(@RequestParam(value = "divideWorkIds", required = false) Long[] divideWorkIds) {
        if (divideWorkIds == null || divideWorkIds.length <= 0) {
            List<Long> pidByUser = hswProjectService.findPidByUser();
            if (pidByUser.isEmpty()) {
                pidByUser.add(-1L);
            }

            Long[] pids = new Long[pidByUser.size()];
            pidByUser.toArray(pids);

            List<HswDivideWork> hswDivideWorkList = hswDivideWorkService.selectHswDivideWorkByPids(pids);

            List<Long> ids = hswDivideWorkList.stream().map(w -> w.getId()).collect(Collectors.toList());

            if (ids.isEmpty()) {
                ids.add(-1L);
            }
            divideWorkIds = new Long[ids.size()];
            ids.toArray(divideWorkIds);
        }
        return divideWorkIds;
    }

    /**
     * 根据项目id获取分工列表
     *
     * @param pid
     * @return
     */
    @ApiOperation("根据项目id获取分工列表")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:getDivideWorkList')")
    @GetMapping("/getDivideWorkList")
    public AjaxResult getDivideWorkList(@RequestParam Long pid) {
        return AjaxResult.success(hswDivideWorkService.selectHswDivideWorkByPid(pid));
    }

    /**
     * 项目一览表-视点分布
     *
     * @param diagnosisDeviceViewDto
     * @return
     */
    @ApiOperation("项目一览表-视点分布")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:project')")
    @GetMapping("/getDiagnosisView")
    public AjaxResult getDiagnosisView(DiagnosisDeviceViewDto diagnosisDeviceViewDto) {
        // 获取当前登录用户可查询的项目
        List<Long> pidByUser = hswProjectService.findPidByUser();
        if (pidByUser.isEmpty()) {
            pidByUser.add(-1L);
        }
        Long[] pids = new Long[pidByUser.size()];
        pidByUser.toArray(pids);
        diagnosisDeviceViewDto.setPids(pids);

        return AjaxResult.success(hswDiagnosisDeviceService.selectDiagnosisDeviceViewList(diagnosisDeviceViewDto));
    }

    /**
     * 项目一览表-最近故障
     *
     * @param hswFaultInfo
     * @return
     */
    @ApiOperation("项目一览表-最近故障")
//    @PreAuthorize("@ss.hasPermi('hsw:statisticalAnalyses:project')")
    @GetMapping("/getFaultByPid")
    public TableDataInfo getFaultByPid(HswFaultInfo hswFaultInfo) {
        startPage();
        List<HswFaultInfo> list = hswFaultInfoService.selectHswFaultInfoList(hswFaultInfo);
        return getDataTable(list);
    }
}
