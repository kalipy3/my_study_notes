package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.config.RuoYiConfig;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExportExcelUtils;
import com.ruoyi.hsw.commonEnum.CameraTypeEnum;
import com.ruoyi.hsw.commonEnum.ExportEnum;
import com.ruoyi.hsw.commonEnum.HandleStatusEnum;
import com.ruoyi.hsw.commonEnum.JobStatusEnum;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.domain.*;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.domain.vo.FaultStatusVo;
import com.ruoyi.hsw.domain.vo.JobStaffStatisticsVo;
import com.ruoyi.hsw.domain.vo.JobTeamStatisticsVo;
import com.ruoyi.hsw.dto.DeviceCountDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 一键导出
 */
@Api("一键导出")
@RestController
@RequestMapping("/hsw/clickExport")
public class ClickExportController extends BaseController {

    @Autowired
    private IHswJobInfoService hswJobInfoService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswOpticalTransceiverService hswOpticalTransceiverService;

    @Autowired
    private IHswOtherDeviceService hswOtherDeviceService;

    @ApiOperation("一键导出")
    @GetMapping("/export")
    public AjaxResult export(@RequestParam(value = "startDate", required = false) Long startDate,
                             @RequestParam(value = "endDate", required = false) Long endDate,
                             @RequestParam(value = "pid", required = false) Long pid,
                             @RequestParam(value = "arrayList") List<Integer> arrayList) {
        List<Integer> collect = arrayList.stream().sorted().collect(Collectors.toList());

        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String filename = sdf.format(new Date()) + "华视维.xlsx";
        try {
            String downloadPath = RuoYiConfig.getDownloadPath() + filename;
            File desc = new File(downloadPath);
            if (!desc.getParentFile().exists()) {
                desc.getParentFile().mkdirs();
            }

            OutputStream out = new FileOutputStream(downloadPath);

            List<Long> pids = new ArrayList<>();

            HswJobInfo jobInfo = new HswJobInfo();
            jobInfo.setPid(pid);
            jobInfo.setTakeStartTime(startDate);
            jobInfo.setTakeEndTime(endDate);

            HswFaultInfo hswFaultInfo = new HswFaultInfo();
            hswFaultInfo.setPid(pid);
            hswFaultInfo.setTakeStartTime(startDate);
            hswFaultInfo.setTakeEndTime(endDate);

            String[] headersDiagnosisDevice = this.getHeaderDiagnosisDevice();
            String[] headersFault = this.getHeaderFault();
            String[] headersHistoryFault = this.getHeaderFault();
            String[] headersJob = this.getHeaderJob();
            String[] headersHistoryJob = this.getHeaderJob();
            String[] headersCamera = this.getHeaderCamera();
            String[] headerOpticalTransceiver = this.getHeaderOpticalTransceiver();
            String[] headerOtherDevice = this.getHeaderOtherDevice();
            String[] headerAssets = this.getHeaderAssets();
            String[] headerFaultCount = this.getHeaderFaultCount();
            String[] headerFaultTypeCount = this.getHeaderFaultTypeCount();
            String[] headerFaultStatus = this.getHeaderFaultStatus();
            String[] headerJobTeam = this.getHeaderJobTeam();
            String[] headerJobStaff = this.getHeaderJobStaff();

            ExportExcelUtils eeu = new ExportExcelUtils();//工具类写法在下面
            HSSFWorkbook workbook = new HSSFWorkbook();

            int count = 0;

            if (collect.size() > 0) {
                for (Integer arr: collect) {
                    count = count + 1;
                    switch (arr) {
                        /**
                         * 诊断器
                         */
                        case 0:
                            // 诊断器
                            HswDiagnosisDevice hswDiagnosisDevice = new HswDiagnosisDevice();
                            hswDiagnosisDevice.setPid(pid);
                            List<HswDiagnosisDevice> hswDiagnosisDeviceList = hswDiagnosisDeviceService.selectHswDiagnosisDeviceList(hswDiagnosisDevice);
                            List<List<String>> diagnosisDeviceList = this.getDiagnosisDeviceList(hswDiagnosisDeviceList);
                            eeu.exportExcel(workbook, count-1, "诊断器", headersDiagnosisDevice, diagnosisDeviceList, out);
                            break;
                        /**
                         * 摄像头
                         */
                        case 1:
                            // 摄像机
                            HswCamera hswCamera = new HswCamera();
                            if (StringUtils.isNotNull(pid)) {
                                pids.add(pid);
                                hswCamera.setPids(pids);
                            }

                            List<HswCamera> hswCameraList = hswCameraService.selectHswCameraList(hswCamera);
                            List<List<String>> cameraList = this.getCameraList(hswCameraList);
                            eeu.exportExcel(workbook, count-1, "摄像头", headersCamera, cameraList, out);
                            break;
                        /**
                         * 光纤收发器
                         */
                        case 2:
                            // 光纤收发器
                            HswOpticalTransceiver hswOpticalTransceiver = new HswOpticalTransceiver();
                            if (StringUtils.isNotNull(pid)) {
                                pids.add(pid);
                                hswOpticalTransceiver.setPids(pids);
                            }

                            List<HswOpticalTransceiver> hswOpticalTransceiverList = hswOpticalTransceiverService.selectHswOpticalTransceiverList(hswOpticalTransceiver);
                            List<List<String>> opticalTransceiverList = this.getOpticalTransceiverList(hswOpticalTransceiverList);
                            eeu.exportExcel(workbook, count-1, "光纤收发器", headerOpticalTransceiver, opticalTransceiverList, out);
                            break;
                        /**
                         * 其他设备
                         */
                        case 3:
                            // 其他设备
                            HswOtherDevice hswOtherDevice = new HswOtherDevice();
                            if (StringUtils.isNotNull(pid)) {
                                pids.add(pid);
                                hswOtherDevice.setPids(pids);
                            }
                            List<HswOtherDevice> hswOtherDeviceList = hswOtherDeviceService.selectHswOtherDeviceList(hswOtherDevice);
                            List<List<String>> otherDeviceList = this.getOtherDeviceList(hswOtherDeviceList);
                            eeu.exportExcel(workbook, count-1, "其他设备", headerOtherDevice, otherDeviceList, out);
                            break;
                        /**
                         * 活动故障信息列表
                         */
                        case 4:
                            // 活动故障信息列表
                            List<HswFaultInfo> hswFaultInfoList = hswFaultInfoService.selectHswFaultInfoList(hswFaultInfo);
                            List<List<String>> faultList = this.getFaultList(hswFaultInfoList);
                            eeu.exportExcel(workbook, count-1, "活动故障信息列表", headersFault, faultList, out);
                            break;
                        /**
                         * 历史故障信息列表
                         */
                        case 5:
                            // 历史故障信息列表
                            List<HswFaultInfo> historyFaultInfoList = hswFaultInfoService.selectHistoryList(hswFaultInfo);
                            List<List<String>> historyFaultList = this.getFaultList(historyFaultInfoList);
                            eeu.exportExcel(workbook, count-1, "历史故障信息列表", headersHistoryFault, historyFaultList, out);
                            break;
                        /**
                         * 活动工单列表
                         */
                        case 6:
                            // 活动工单列表
                            List<HswJobInfo> hswJobInfoList = hswJobInfoService.selectHswJobInfoList(jobInfo);
                            List<List<String>> jobList = this.getJobInfoList(hswJobInfoList);
                            eeu.exportExcel(workbook, count-1, "活动工单列表", headersJob, jobList, out);
                            break;
                        /**
                         * 历史工单列表
                         */
                        case 7:
                            // 历史工单列表
                            List<HswJobInfo> historyJobInfoList = hswJobInfoService.selectHistoryList(jobInfo);
                            List<List<String>> historyJobList = this.getJobInfoList(historyJobInfoList);
                            eeu.exportExcel(workbook, count-1, "历史工单列表", headersHistoryJob, historyJobList, out);
                            break;
                        /**
                         * 资产统计
                         */
                        case 8:
                            // 资产统计
                            List<DeviceCountDto> deviceCountList = hswDiagnosisDeviceService.selectGroupCount(pid);
                            List<List<String>> assetsList = this.getAssetsList(deviceCountList);
                            eeu.exportExcel(workbook, count-1, "资产统计", headerAssets, assetsList, out);

                            break;
                        /**
                         * 运行统计
                         */
                        case 9:
                            // 运行统计
                            List<FaultViewDto> faultViewList = hswFaultInfoService.selectFaultCountByDate(pid, startDate, endDate);
                            List<List<String>> faultCountList = this.getFaultCountList(faultViewList);
                            eeu.exportExcel(workbook, count-1, "运行统计", headerFaultCount, faultCountList, out);
                            break;
                        /**
                         * 故障统计
                         */
                        case 10:
                            // 故障统计
                            Map<String, Object> stringObjectMap = hswFaultInfoService.selectFaultTypeCountByDate(pid, startDate, endDate);
                            List<FaultStatisticsVo> faultStatisticsVoList = (List<FaultStatisticsVo>) stringObjectMap.get("faultList");
                            List<List<String>> faultTypeCountList = this.getFaultTypeCountList(faultStatisticsVoList);
                            eeu.exportExcel(workbook, count-1, "故障统计", headerFaultTypeCount, faultTypeCountList, out);
                            break;
                        /**
                         * 修复统计
                         */
                        case 11:
                            // 修复统计
                            List<FaultStatusVo> faultStatusVoList = hswFaultInfoService.selectFaultStatusByDate(pid, startDate, endDate);
                            List<List<String>> faultStatusList = this.getFaultStatusList(faultStatusVoList);
                            eeu.exportExcel(workbook, count-1, "修复统计", headerFaultStatus, faultStatusList, out);
                            break;
                        /**
                         * 工单统计-维修队
                         */
                        case 12:
                            // 工单统计-维修队
                            List<JobTeamStatisticsVo> jobTeamStatisticsVoList = hswJobInfoService.selectJobTeamByDate(pid, startDate, endDate);
                            List<List<String>> jobTeamList = this.getJobTeamList(jobTeamStatisticsVoList);
                            eeu.exportExcel(workbook, count-1, "工单统计-维修队", headerJobTeam, jobTeamList, out);
                            break;
                        /**
                         * 工单统计-维修队
                         */
                        case 13:
                            // 工单统计-维修员工
                            List<JobStaffStatisticsVo> jobStaffStatisticsVoList = hswJobInfoService.selectJobStaffByDate(pid, startDate, endDate);
                            List<List<String>> jobStaffList = this.getJobStaffList(jobStaffStatisticsVoList);
                            eeu.exportExcel(workbook, count-1, "工单统计-维修员工", headerJobStaff, jobStaffList, out);
                            break;

                        default:
                            break;
                    }
                }

            }

            //原理就是将所有的数据一起写入，然后再关闭输入流。
            workbook.write(out);
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return AjaxResult.success(filename);
    }

    public List<List<String>> getDiagnosisDeviceList(List<HswDiagnosisDevice> hswDiagnosisDeviceList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswDiagnosisDeviceList.isEmpty()) {
            hswDiagnosisDeviceList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getProjectTitle());
                rowData.add(entity.getAddress());
                rowData.add(entity.getUplinkPort() + "");
                rowData.add(entity.getLogicalAddr());
                rowData.add(entity.getSn());
                rowData.add(entity.getModel());
                rowData.add(entity.getVer());
                rowData.add(entity.getWorkAddress());
                rowData.add(entity.getIp());
                String installDate = "";
                if (StringUtils.isNotNull(entity.getInstallDate())) {
                    installDate = sdf.format(entity.getInstallDate());
                }
                rowData.add(installDate);
                rowData.add(entity.getManufacturer());
                rowData.add(entity.getWarranty() + "");
                rowData.add(entity.getDistance() + "");
                rowData.add(entity.getNetwork());
                rowData.add(entity.getCameraCount() + "");
                rowData.add(entity.getLongitude());
                rowData.add(entity.getLatitude());
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderDiagnosisDevice() {
        String[] headersDiagnosisDevice = {
                "项目",
                "详细地址",
                "上行端口",
                "逻辑地址",
                "序列号",
                "型号",
                "版本",
                "分工区域",
                "ip",
                "安装时间",
                "生产厂商",
                "质保期",
                "距指挥中心距离(KM)",
                "网络运营商",
                "摄像头数量",
                "经度",
                "纬度"
        };

        return headersDiagnosisDevice;
    }

    public List<List<String>> getCameraList(List<HswCamera> hswCameraList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswCameraList.isEmpty()) {
            hswCameraList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getHswDiagnosisDevice().getProjectTitle());
                rowData.add(entity.getHswDiagnosisDevice().getWorkAddress());
                rowData.add(entity.getPosition());
                String deviceType = "";
                if (CameraTypeEnum.QIANGJI.getValue().equals(entity.getDeviceType())) {
                    deviceType = CameraTypeEnum.QIANGJI.getLabel();
                } else if (CameraTypeEnum.QIUJI.getValue().equals(entity.getDeviceType())) {
                    deviceType = CameraTypeEnum.QIUJI.getLabel();
                } else if (CameraTypeEnum.BANQIUJI.getValue().equals(entity.getDeviceType())) {
                    deviceType = CameraTypeEnum.BANQIUJI.getLabel();
                }
                rowData.add(deviceType);
                rowData.add(entity.getSn());
                rowData.add(entity.getModel());
                rowData.add(entity.getIp());
                rowData.add(entity.getSelfIp());
                rowData.add(entity.getLongitude());
                rowData.add(entity.getLatitude());
                rowData.add(entity.getPort() + "");
                String installDate = "";
                if (StringUtils.isNotNull(entity.getInstallDate())) {
                    installDate = sdf.format(entity.getInstallDate());
                }
                rowData.add(installDate);
                rowData.add(entity.getManufacturer());
                rowData.add(entity.getWarranty() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderCamera() {
        String[] headersCamera = {
                "项目",
                "分工区域",
                "方位",
                "类型",
                "序列号",
                "型号",
                "ip",
                "分工区域",
                "ip",
                "自身ip",
                "经度",
                "纬度",
                "端口号",
                "安装时间",
                "生产厂商",
                "质保期"
        };

        return headersCamera;
    }

    public List<List<String>> getOpticalTransceiverList(List<HswOpticalTransceiver> hswOpticalTransceiverList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswOpticalTransceiverList.isEmpty()) {
            hswOpticalTransceiverList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getProjectTitle());
                rowData.add(entity.getWorkAddress());
                rowData.add(entity.getModel());
                rowData.add(entity.getSn());
                rowData.add(entity.getIp());
                String installDate = "";
                if (StringUtils.isNotNull(entity.getInstallDate())) {
                    installDate = sdf.format(entity.getInstallDate());
                }
                rowData.add(installDate);
                rowData.add(entity.getManufacturer());
                rowData.add(entity.getWarranty() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderOpticalTransceiver() {
        String[] headersOpticalTransceiver = {
                "项目",
                "分工区域",
                "型号",
                "序列号",
                "诊断器ip",
                "安装时间",
                "生产厂商",
                "质保期(年)"
        };

        return headersOpticalTransceiver;
    }

    public List<List<String>> getOtherDeviceList(List<HswOtherDevice> hswOtherDevices) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswOtherDevices.isEmpty()) {
            hswOtherDevices.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getProjectTitle());
                rowData.add(entity.getWorkAddress());
                rowData.add(entity.getName());
                rowData.add(entity.getModel());
                rowData.add(entity.getSn());
                rowData.add(entity.getIp());
                rowData.add(entity.getDescr());
                String installDate = "";
                if (StringUtils.isNotNull(entity.getInstallDate())) {
                    installDate = sdf.format(entity.getInstallDate());
                }
                rowData.add(installDate);
                rowData.add(entity.getManufacturer());
                rowData.add(entity.getWarranty() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderOtherDevice() {
        String[] headersOtherDevice = {
                "项目",
                "分工区域",
                "设备名称",
                "型号",
                "序列号",
                "诊断器ip",
                "描述",
                "安装时间",
                "生产厂商",
                "质保期(年)"
        };

        return headersOtherDevice;
    }

    public List<List<String>> getFaultList(List<HswFaultInfo> hswFaultInfoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswFaultInfoList.isEmpty()) {
            hswFaultInfoList.forEach(entity -> {
                // 故障类型
                entity.setType(HandleStatusEnum.valueOf(Integer.valueOf(entity.getType())).getLabel());

                // 故障状态
                entity.setStatus(JobStatusEnum.valueOf(Integer.valueOf(entity.getStatus())).getLabel());

                // 发生时间
                if (entity.getTakeTime() != null && entity.getTakeTime() > 0) {
                    entity.setTakeDate(DateUtils.parseSecondsToDate(entity.getTakeTime()));
                } else {
                    entity.setTakeDate(null);
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }
                List<String> rowData = new ArrayList();
                rowData.add(entity.getRegionName());
                rowData.add(entity.getIp());
                rowData.add(entity.getSn());
                rowData.add(String.valueOf(entity.getPort()));
                rowData.add(entity.getType());
                String takeDate = "";
                if (StringUtils.isNotNull(entity.getTakeDate())) {
                    takeDate = sdf.format(entity.getTakeDate());
                }
                rowData.add(takeDate);
                rowData.add(entity.getProject().getTitle());
                rowData.add(entity.getDescr());
                rowData.add(entity.getStatus());
                String repairDate = "";
                if (StringUtils.isNotNull(entity.getRepairDate())) {
                    repairDate = sdf.format(entity.getRepairDate());
                }

                rowData.add(repairDate);
                rowData.add(entity.getMaintenanceUnits().getName());
                rowData.add(entity.getMaintenanceTeam().getName());
                rowData.add(entity.getArea());
                rowData.add(String.valueOf(entity.getZigzagCount()));
                rowData.add(String.valueOf(entity.getInfluenceCameraCount()));
                rowData.add(entity.getNetwork());
                data1.add(rowData);
            });
        }

        return data1;
    }

    public String[] getHeaderFault() {
        String[] headersFault = {
                "视点位置",
                "视点IP",
                "逻辑地址32位",
                "端口号，非摄像机故障为0",
                "故障类型",
                "发生时间",
                "项目名称",
                "故障描述",
                "故障状态",
                "修复时间",
                "运维单位名称",
                "维修队名称",
                "分工区域",
                "颠簸次数",
                "影响摄像机数量",
                "网络运营商"
        };

        return headersFault;
    }

    public List<List<String>> getJobInfoList(List<HswJobInfo> hswJobInfoList) {
        List<List<String>> data2 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!hswJobInfoList.isEmpty()) {
            hswJobInfoList.forEach(entity -> {
                // 派单时间
                if (entity.getSendTime() != null && entity.getSendTime() > 0) {
                    entity.setSendDate(DateUtils.parseSecondsToDate(entity.getSendTime()));
                } else {
                    entity.setSendDate(null);
                }

                // 接单时间
                if (entity.getReceiverTime() != null && entity.getReceiverTime() > 0) {
                    entity.setReceiverDate(DateUtils.parseSecondsToDate(entity.getReceiverTime()));
                } else {
                    entity.setReceiverDate(null);
                }

                if (entity.getSendUid() != null) {
                    // 派单人
//                    SysUser sendUser = this.sysUserService.selectUserById(entity.getSendUid());
//                    if (StringUtils.isNotNull(sendUser)) {
//                        entity.setSendName(sendUser.getNickName());
//                    }
                }

                if (entity.getReceiverId() != null) {
                    // 接单人
//                    SysUser receiverUser = this.sysUserService.selectUserById(entity.getReceiverId());
//                    if (StringUtils.isNotNull(receiverUser)) {
//                        entity.setReceiverName(receiverUser.getNickName());
//                    }
                }

                // 工单状态
                if (StringUtils.isNotNull(entity.getStatus())) {
                    entity.setStatusText(JobStatusEnum.valueOf(entity.getStatus()).getLabel());
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }

                // 挂起时间
                if (entity.getHangUpTime() != null && entity.getHangUpTime() > 0) {
                    entity.setHangUpDate(DateUtils.parseSecondsToDate(entity.getHangUpTime()));
                } else {
                    entity.setHangUpDate(null);
                }

                // 撤回挂起时间
                if (entity.getResumeTime() != null && entity.getResumeTime() > 0) {
                    entity.setResumeDate(DateUtils.parseSecondsToDate(entity.getResumeTime()));
                } else {
                    entity.setResumeDate(null);
                }

                // 操作状态
                entity.setHandleStatusText(HandleStatusEnum.valueOf(entity.getHandleStatus()).getLabel());

                List<String> rowData = new ArrayList();
                rowData.add(entity.getJobNo());
                rowData.add(entity.getFaultNo());
                String sendDate = "";
                if (StringUtils.isNotNull(entity.getSendDate())) {
                    sendDate  = sdf.format(entity.getSendDate());
                }
                rowData.add(sendDate);
                rowData.add(entity.getSendName());
                rowData.add(entity.getReceiverName());
                String receiverDate = "";
                if (StringUtils.isNotNull(entity.getReceiverDate())) {
                    receiverDate = sdf.format(entity.getReceiverDate());
                }
                rowData.add(receiverDate);
                rowData.add(entity.getStatusText());
                String repairDate = "";
                if (StringUtils.isNotNull(entity.getRepairDate())) {
                    repairDate = sdf.format(entity.getRepairDate());
                }
                rowData.add(repairDate);
                rowData.add(entity.getRepairRecord());
                String hangUpDate = "";
                if (StringUtils.isNotNull(entity.getHangUpDate())) {
                    hangUpDate = sdf.format(entity.getHangUpDate());
                }
                rowData.add(hangUpDate);
                rowData.add(entity.getHangUpReason());
                String resumeDate = "";
                if (StringUtils.isNotNull(entity.getResumeDate())) {
                    resumeDate = sdf.format(entity.getResumeDate());
                }
                rowData.add(resumeDate);
                rowData.add(entity.getHandleStatusText());
                rowData.add(entity.getProject().getTitle());
                rowData.add(entity.getMaintenanceUnits().getName());
                rowData.add(entity.getMaintenanceTeam().getName());
                data2.add(rowData);

            });
        }

        return data2;
    }

    public String[] getHeaderJob() {
        String[] headersJob = {
                "工单编号",
                "故障编号",
                "派单时间",
                "派单人",
                "接单人",
                "接单时间",
                "工单状态",
                "修复时间",
                "维修记录",
                "挂起时间",
                "挂起原因",
                "撤回挂起时间",
                "操作状态",
                "项目名称",
                "运维单位名称",
                "运维队名称"
        };

        return headersJob;
    }

    public List<List<String>> getAssetsList(List<DeviceCountDto> deviceCountDtoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        if (!deviceCountDtoList.isEmpty()) {
            deviceCountDtoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getProjectTitle());
                rowData.add(entity.getDiagnosisCount() + "");
                rowData.add(entity.getCameraCount() + "");
                rowData.add(entity.getOpticalTransceiverCount() + "");
                rowData.add(entity.getOtherDeviceCount() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderAssets() {
        String[] headersAssets = {
                "项目",
                "诊断器数量",
                "摄像机数量",
                "光纤收发器数量",
                "其他设备数量"
        };

        return headersAssets;
    }

    public List<List<String>> getFaultCountList(List<FaultViewDto> faultViewDtoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!faultViewDtoList.isEmpty()) {
            faultViewDtoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getProjectTitle());
                rowData.add(entity.getArea());
                rowData.add(entity.getCameraCountAll() + "");
                rowData.add(entity.getOnlineAvgCount() + "");
                rowData.add(entity.getOfflineAvgCount() + "");
                rowData.add(entity.getHungAvgCount() + "");
                rowData.add(entity.getOnlineAvgRate() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderFaultCount() {
        String[] headersFaultCount = {
                "项目",
                "分工区域",
                "摄像机数量",
                "平均在线数",
                "平均离线数",
                "平均挂起数",
                "平均在线率"
        };

        return headersFaultCount;
    }

    public List<List<String>> getFaultTypeCountList(List<FaultStatisticsVo> faultStatisticsVoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!faultStatisticsVoList.isEmpty()) {
            faultStatisticsVoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getDatestr());
                rowData.add(entity.getType1Count() + "");
                rowData.add(entity.getType2Count() + "");
                rowData.add(entity.getType3Count() + "");
                rowData.add(entity.getType5Count() + "");
                rowData.add(entity.getType6Count() + "");
                rowData.add(entity.getType7Count() + "");
                rowData.add(entity.getType9Count() + "");
                rowData.add(entity.getOnlineRate() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderFaultTypeCount() {
        String[] headersFaultTypeCount = {
                "日期",
                "市电断电",
                "光纤链路故障",
                "光纤收发器故障",
                "摄像机故障",
                "主光缆故障",
                "诊断器故障",
                "工作不稳定",
                "在线率"
        };

        return headersFaultTypeCount;
    }

    public List<List<String>> getFaultStatusList(List<FaultStatusVo> faultStatusVoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!faultStatusVoList.isEmpty()) {
            faultStatusVoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getArea());
                rowData.add(entity.getTotal() + "");
                rowData.add(entity.getAssignCount() + "");
                rowData.add(entity.getFinishCount() + "");
                rowData.add(entity.getHungCount() + "");
                rowData.add(entity.getFinishRate() + "");
                if (StringUtils.isNotNull(entity.getAvg())) {
                    rowData.add(entity.getAvg() + "");
                } else {
                    rowData.add("0.00");
                }

                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderFaultStatus() {
        String[] headersFaultStatus = {
                "区域",
                "故障总数",
                "工单数",
                "完成数",
                "挂起数",
                "完成率(%)",
                "平均时长"
        };

        return headersFaultStatus;
    }

    public List<List<String>> getJobTeamList(List<JobTeamStatisticsVo> jobTeamStatisticsVoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        //创建SimpleDateFormat对象实例并定义好转换格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!jobTeamStatisticsVoList.isEmpty()) {
            jobTeamStatisticsVoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                rowData.add(entity.getMaintenanceUnitsName());
                rowData.add(entity.getMaintenanceTeamName());
                rowData.add(entity.getTotal() + "");
                rowData.add(entity.getAssignCount() + "");
                rowData.add(entity.getFinishCount() + "");
                rowData.add(entity.getHungCount() + "");
                rowData.add(entity.getTimeoutCount() + "");
                rowData.add(entity.getFinishRate() + "");
                rowData.add(entity.getAvg() + "");
                data1.add(rowData);
            });
        }
        return data1;
    }

    public String[] getHeaderJobTeam() {
        String[] headersJobTeam = {
                "运维单位",
                "维修队名称",
                "故障总数",
                "工单数",
                "完成数",
                "挂起数",
                "超时数",
                "完成率(%)",
                "平均时长"
        };

        return headersJobTeam;
    }

    public List<List<String>> getJobStaffList(List<JobStaffStatisticsVo> jobStaffStatisticsVoList) {
        List<List<String>> data1 = new ArrayList<List<String>>();
        if (!jobStaffStatisticsVoList.isEmpty()) {
            jobStaffStatisticsVoList.forEach(entity -> {
                List<String> rowData = new ArrayList();
                if (StringUtils.isNotNull(entity)) {
                    rowData.add(entity.getMaintenanceUnitsName());
                    rowData.add(entity.getMaintenanceTeamName());
                    rowData.add(entity.getReceiverName());
                    rowData.add(entity.getAssignCount() + "");
                    rowData.add(entity.getFinishCount() + "");
                    rowData.add(entity.getHungCount() + "");
                    rowData.add(entity.getTimeoutCount() + "");
                    rowData.add(entity.getFinishRate() + "");
                    rowData.add(entity.getAvg() + "");
                    data1.add(rowData);
                }
            });
        }
        return data1;
    }

    public String[] getHeaderJobStaff() {
        String[] headersJobStaff = {
                "运维单位",
                "维修队名称",
                "维修员",
                "工单数",
                "完成数",
                "挂起数",
                "超时数",
                "转单数",
                "完成率(%)",
                "平均时长"
        };

        return headersJobStaff;
    }
}
