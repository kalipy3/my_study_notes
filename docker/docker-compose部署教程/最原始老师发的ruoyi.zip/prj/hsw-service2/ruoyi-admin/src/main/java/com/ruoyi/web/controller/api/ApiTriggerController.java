package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.hsw.commonEnum.FaultTypeEnum;
import com.ruoyi.hsw.commonEnum.JobStatusEnum;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.constant.CommonSms;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.domain.HswFaultInfo;
import com.ruoyi.hsw.domain.HswSysMsg;
import com.ruoyi.hsw.domain.HswUserMsg;
import com.ruoyi.hsw.dto.*;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.domain.SysUserRole;
import com.ruoyi.system.service.ISysConfigService;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysRoleService;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 触发故障(物联网平台调用)
 */
@Slf4j
@Api("触发故障(物联网平台调用)")
@RequestMapping("/api/trigger")
@RestController
public class ApiTriggerController {

    @Autowired
    private IHswFaultInfoService faultInfoService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private IHswSysMsgService sysMsgService;

    @Autowired
    private IHswUserMsgService userMsgService;

    @Autowired
    private ISysRoleService roleService;

    @Autowired
    private ISmsService smsService;

    @Autowired
    private IHswDiagnosisDeviceService diagnosisDeviceService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    /**
     * 触发故障 调用此api需要header验证
     *
     * @return
     */
    @ApiOperation("触发故障 调用此api需要header验证")
    @PostMapping(value = "/trigger")
    public AjaxResult triggerFault(
            @RequestParam(value = "ip") String ip,
            @RequestParam(value = "port", defaultValue = "0") Integer port,
            @RequestParam(value = "type", defaultValue = "0") String type,
            @RequestParam(value = "descr", defaultValue = "") String descr,
            @RequestParam(value = "zigzag_type", defaultValue = "0") Integer zigzagType,
            @RequestParam(value = "zigzag_count", defaultValue = "0") Integer zigzagCount,
            @RequestParam(value = "zigzag_status", defaultValue = "0") Integer zigzagStatus,
            @RequestParam(value = "op_state", defaultValue = "0") String opState,
            @RequestParam(value = "taketime", defaultValue = "") String taketime) {

        log.info("触发故障->ip={},port={},type={},descr={},zigzag_type={},zigzag_count={},zigzag_status={},op_state={},taketime={}", ip, port, type, descr, zigzagType, zigzagCount, zigzagStatus, opState, taketime);
        // 工作不稳定故障不记录
        if (FaultTypeEnum.GZBWD.getValue().toString().equals(type) || FaultTypeEnum.GZBWD_DQGZ.getValue().toString().equals(type)) {
            return new AjaxResult(0, "添加失败,工作不稳定不记录");
        }

        log.info("添加触发故障->ip={},port={},type={},descr={},zigzag_type={},zigzag_count={},zigzag_status={},op_state={},taketime={}", ip, port, type, descr, zigzagType, zigzagCount, zigzagStatus, opState, taketime);
        DiagnosisDeviceViewDto diagnosisDeviceViewDto = null;
        diagnosisDeviceViewDto = this.diagnosisDeviceService.selectDiagnosisDeviceViewByIpForApp(ip);
        AjaxResult resultMap = null;
        // 找不到对应的诊断器直接返回错误
        if (diagnosisDeviceViewDto == null) {
            log.warn("添加故障失败，找不到对应的诊断器, ip：{}", ip);
            resultMap = new AjaxResult(0, "添加失败:ip非法");
            resultMap.put("token", "");
            return resultMap;
        }

        // 防止重复故障
        HswFaultInfo faultInfo = new HswFaultInfo();
        faultInfo.setIp(ip);
        faultInfo.setPort(port);
        faultInfo.setType(type);
        if (this.faultInfoService.isFaultExistsForIot(faultInfo)) {
            return new AjaxResult(0, "添加失败,设备相关故障已存在");
        }

        // 新增故障
        Map<String, Object> res = this.faultInfoService.addfromDevice(ip, port, type, descr, zigzagCount, zigzagType, zigzagStatus, opState, taketime);

        if (res.get("code").equals(1)) {
            SysConfig tpl = this.sysConfigService.selectConfigByConfigKey("TPL_MSG_FAULT_TAKE");
            List<SysUser> sysUsers = (List<SysUser>) res.get("user");
            String fault_id = res.get("faultId").toString();
            String fault_no = res.get("faultNo").toString();
            String region_name = res.get("regionName").toString();
            String take_time = DateUtils.parseDateToStr("yyyy年MM月dd日 hh:mm:ss", DateUtils.parseSecondsToDate(res.get("takeTime").toString()));
            type = res.get("type").toString();
            String area = res.get("area").toString();
            ip = res.get("ip").toString();
            port = Integer.valueOf(res.get("port").toString());

            String typeText = CommonConstant.FAULT_TYPE_TEXT;

            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_TYPE);

            for (SysDictData sysDictData : sysDictDataList) {
                if (sysDictData.getDictValue().equals(type)) {
                    typeText = sysDictData.getDictLabel();
                }
            }

            List<String> uids = new ArrayList<>();
            for (int i = 0; i < sysUsers.size(); i++) {
                uids.add(sysUsers.get(i).getUserId().toString());
            }

            String title = "故障发生消息";
            String content = "您有一条故障需要处理，故障编号：" + fault_no + "，请点击查看详情";
            if (tpl != null) {
                title = tpl.getConfigName();
                content = tpl.getConfigValue();
                content = content.replace("${time}", take_time);
                content = content.replace("${region_name}", region_name);
                content = content.replace("${type}", typeText);
                content = content.replace("${ip}", ip);
                content = content.replace("${port}", port.toString());
            }

            HswSysMsg sysMsg = new HswSysMsg();
            sysMsg.setTitle(title);
            sysMsg.setContent(content);
            sysMsg.setCreateBy("系统");
            sysMsg.setJobNo("");

            String uidss = String.join(",", uids);
            sysMsg.setToUids(uidss);

            this.sysMsgService.insertHswSysMsg(sysMsg);

            //发系统消息
            for (SysUser sysUser : sysUsers) {
                HswUserMsg userMsg = new HswUserMsg();
                userMsg.setMid(sysMsg.getId());
                userMsg.setUid(sysUser.getUserId());
                userMsg.setStatus(CommonConstant.STATUS_UNREAD);
                userMsg.setUname(sysUser.getNickName());
                userMsg.setReadTime(0);
                this.userMsgService.insertHswUserMsg(userMsg);

                Map<String, Object> templateParam = new HashMap<>();
                templateParam.put("time", take_time);
                templateParam.put("region_name", region_name);
                templateParam.put("type", typeText);
                templateParam.put("ip", ip);
                templateParam.put("port", port);

                Map<String, Object> args = new HashMap<>();
                args.put("title", "您有一个工单需要处理");
                args.put("send_name", "系统");
                args.put("receiver_id", sysUser.getUserId());
                args.put("receiver_name", sysUser.getNickName());
                args.put("job_no", "");
                args.put("tpl_key", "TPL_MSG_FAULT_TAKE");
                this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), sysUser.getPhonenumber(), CommonSms.FAULT_NOTICE, templateParam, args);
            }
        } else {
            AjaxResult ajaxResult = AjaxResult.error();
            ajaxResult.putAll(res);
            return ajaxResult;
        }

        return AjaxResult.success(res);
    }

    /**
     * 触发自动恢复 调用此api需要header验证
     *
     * @return
     */
    @ApiOperation("触发自定恢复 调用此api需要header验证")
    @PostMapping(value = "/recovery")
    public AjaxResult recoveryFault(
            @RequestParam(value = "ip", defaultValue = "") String ip,
            @RequestParam(value = "port", defaultValue = "0") Integer port,
            @RequestParam(value = "type", defaultValue = "0") String type,
            @RequestParam(value = "zigzag_type", defaultValue = "0") Integer zigzagType) {
        log.info("恢复故障->ip={},port={},type={},zigzag_type={}", ip, port, type, zigzagType);

        FaultViewDto faultViewDto = this.faultInfoService.selectFaultViewForRecoveryForApi(ip, port, type, zigzagType);
        if (faultViewDto != null) {
            HswFaultInfo hswFaultInfo = this.faultInfoService.selectHswFaultInfoById(faultViewDto.getId());
            hswFaultInfo.setStatus(JobStatusEnum.ZDHF.getValue().toString());
            hswFaultInfo.setFlagStatus(CommonConstant.FLAG_STATUS_HISTORY.toString());
            hswFaultInfo.setRepairTime(DateUtils.parseDateToSeconds(new Date()));
            int result = this.faultInfoService.updateHswFaultInfo(hswFaultInfo);

            String r = "";
            if (result > 0) {
                // 取得用户
                // 用户类型(type)=运维单位(3) and 所属维修队(teamid)=faultInfo.getMtId()队
                // 维修队长用户
                List<SysUserRole> sysUserRoles = roleService.selectSysUserRoleList(CommonConstant.ROLE_MTL, null);
                SysUser sysUserParam = new SysUser();
                sysUserParam.setTeamId(faultViewDto.getMtId());
                sysUserParam.setType(CommonConstant.USER_TYPE_MU);
                List<SysUser> sysUsers = this.sysUserService.selectUserList(sysUserParam);
                sysUsers = sysUsers.stream().filter(u -> {
                    for (SysUserRole sysUserRole : sysUserRoles) {
                        if (sysUserRole.getUserId().equals(u.getUserId())) {
                            return true;
                        }
                    }
                    return false;
                }).collect(Collectors.toList());
                for (SysUser sysUser : sysUsers) {
                    Date takeTime = DateUtils.parseSecondsToDate(faultViewDto.getTakeTime());
                    Map<String, Object> templateParam = new HashMap<>();
                    templateParam.put("time", DateUtils.parseDateToStr("yyyy年MM月dd日 hh:mm:ss", takeTime));
                    templateParam.put("region_name", faultViewDto.getRegionName());

                    Map<String, Object> args = new HashMap<>();
                    args.put("title", "您有一个工单需要处理");
                    args.put("send_name", "系统");
                    args.put("receiver_id", sysUser.getUserId().toString());
                    args.put("receiver_name", sysUser.getUserName());
                    args.put("job_no", "");
                    args.put("tpl_key", "TPL_MSG_FAULT_RUSEME");
                    AjaxResult smsResult = this.smsService.sendSMS(faultViewDto.getCuId(), sysUser.getPhonenumber(), CommonSms.AUTOMATIC_RECOVERY, templateParam, args);
                }

                return AjaxResult.success("恢复故障成功", r);
            } else {
                return AjaxResult.error(0, "恢复故障失败");
            }
        } else {
            return AjaxResult.error(0, "找不到要恢复的故障");
        }
    }

    /**
     * 取得活动故障 调用此api需要header验证
     *
     * @return
     */
    @ApiOperation("取得活动故障 调用此api需要header验证")
    @PostMapping(value = "/getActiveFault")
    public AjaxResult getActiveFault(@RequestParam("ip") String ip) {
        // 根据ip取活动故障
        HswFaultInfo faultInfo = new HswFaultInfo();
        faultInfo.setIp(ip);
        List<HswFaultInfo> faultInfoList = this.faultInfoService.selectHswFaultInfoList(faultInfo);

        // 转成dto
        List<GetActiveFaultDto> getActiveFaultDtos = faultInfoList.stream().map(f -> {
            GetActiveFaultDto getActiveFaultDto = new GetActiveFaultDto();
            BeanUtils.copyProperties(f, getActiveFaultDto);
            return getActiveFaultDto;
        }).collect(Collectors.toList());

        return getActiveFaultDtos.size() > 0 ? new AjaxResult(1,"获取成功", getActiveFaultDtos) : new AjaxResult(1, "获取失败", null);
    }

    /**
     * 更新故障 调用此api需要header验证
     *
     * @return
     */
    @ApiOperation("更新故障 调用此api需要header验证")
    @PostMapping(value = "/updateFault")
    public AjaxResult updateFault(@RequestParam(value = "ip", defaultValue = "") String ip,
                                  @RequestParam(value = "port", defaultValue = "0") Integer port,
                                  @RequestParam(value = "old_type", defaultValue = "0") String oldType,
                                  @RequestParam(value = "new_type", defaultValue = "0") String newType,
                                  @RequestParam(value = "desc", defaultValue = "") String descr,
                                  @RequestParam(value = "zigzag_type", defaultValue = "0") Integer zigzagType,
                                  @RequestParam(value = "zigzag_count", defaultValue = "0") Integer zigzagCount) {

        UpdateFaultDto updateFaultDto = new UpdateFaultDto();
        updateFaultDto.setIp(ip);
        updateFaultDto.setPort(port);
        updateFaultDto.setOldType(oldType);
        updateFaultDto.setNewType(newType);
        updateFaultDto.setDescr(descr);
        updateFaultDto.setZigzagType(zigzagType);
        updateFaultDto.setZigzagCount(zigzagCount);
        if (this.faultInfoService.updateHswFaultInfoByApi(updateFaultDto)) {
            return AjaxResult.success("更新故障信息成功");
        } else {
            return AjaxResult.success("更新故障信息失败");
        }
    }

    /**
     * 通过逻辑地址获取诊断的配置：ip,camera_count,uplink_port
     * Post:  "/getGfg?logical_addr=".$logical_addr
     *
     * @return
     */
    @ApiOperation("通过逻辑地址获取诊断的配置")
    @PostMapping({"/getCfg", "/getGfg"})
    public AjaxResult getCfg(@RequestParam("logical_addr") String logicalAddr) {
        HswDiagnosisDevice diagnosisDevice = new HswDiagnosisDevice();
        diagnosisDevice.setLogicalAddr(logicalAddr);
        diagnosisDevice = this.diagnosisDeviceService.selectDiagnosisDeviceForApi(diagnosisDevice);
        DiagnosisDeviceCfgDto diagnosisDeviceCfgDto = null;
        if (diagnosisDevice != null) {
            diagnosisDeviceCfgDto = new DiagnosisDeviceCfgDto();
            diagnosisDeviceCfgDto.setIp(diagnosisDevice.getIp());
            diagnosisDeviceCfgDto.setCameraCount(diagnosisDevice.getCameraCount());
            diagnosisDeviceCfgDto.setUplinkPort(diagnosisDevice.getUplinkPort());
        }

        return diagnosisDeviceCfgDto == null ? new AjaxResult(1, "获取失败", null) : new AjaxResult(1, "获取成功", diagnosisDeviceCfgDto);
    }

    /**
     * 通过IP地址获取诊断器的配置：ip,camera_count,uplink_port
     *
     * @return
     */
    @ApiOperation("通过IP地址获取诊断器的配置")
    @PostMapping(value = "/getCfgByIp")
    public AjaxResult getCfgByIp(@RequestParam("ip") String ip) {
        HswDiagnosisDevice diagnosisDevice = new HswDiagnosisDevice();
        diagnosisDevice.setIp(ip);
        diagnosisDevice = this.diagnosisDeviceService.selectDiagnosisDeviceForApi(diagnosisDevice);
        DiagnosisDeviceCfgDto diagnosisDeviceCfgDto = null;
        if (diagnosisDevice != null) {
            diagnosisDeviceCfgDto = new DiagnosisDeviceCfgDto();
            diagnosisDeviceCfgDto.setIp(diagnosisDevice.getIp());
            diagnosisDeviceCfgDto.setCameraCount(diagnosisDevice.getCameraCount());
            diagnosisDeviceCfgDto.setUplinkPort(diagnosisDevice.getUplinkPort());
        }

        return diagnosisDeviceCfgDto == null ? new AjaxResult(0, "获取失败", 0) : new AjaxResult(1, "获取成功", diagnosisDeviceCfgDto);
    }

    /**
     * 判断指定IP的诊断器是否存在，如果存在，返回其1，不存在返0
     *
     * @return
     */
    @ApiOperation("判断指定IP的诊断器是否存在，如果存在，返回其1，不存在返0")
    @PostMapping(value = "/isExists")
    public AjaxResult isExists(@RequestParam("ip") String ip) {
        HswDiagnosisDevice diagnosisDevice = new HswDiagnosisDevice();
        diagnosisDevice.setIp(ip);
        diagnosisDevice = this.diagnosisDeviceService.selectDiagnosisDeviceForApi(diagnosisDevice);
        return diagnosisDevice == null ? new AjaxResult(0, "获取失败", 0) : new AjaxResult(1, "获取成功", 1);
    }

    /**
     * 指定IP，指定故障是正存在，存在，返回1，否则返回0
     *
     * @return
     */
    @ApiOperation("指定IP，指定故障是否存在，存在，返回1，否则返回0")
    @PostMapping(value = "/isFaultExists")
    public AjaxResult isFaultExists(@RequestParam("ip") String ip, @RequestParam("port") Integer port, @RequestParam("type") String type) {
        HswFaultInfo faultInfo = new HswFaultInfo();
        faultInfo.setIp(ip);
        faultInfo.setPort(port);
        faultInfo.setType(type);

        boolean result = this.faultInfoService.isFaultExistsForApi(faultInfo);
        return result ? new AjaxResult(1, "故障存在", 1) : new AjaxResult(1, "故障不存在", 0);
    }
}
