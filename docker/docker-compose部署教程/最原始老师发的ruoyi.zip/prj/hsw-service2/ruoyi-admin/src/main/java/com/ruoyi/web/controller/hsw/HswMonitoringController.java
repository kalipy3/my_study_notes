package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.hsw.dto.CameraViewDto;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 实时监控controller
 *
 * @author zyj
 * @date 2020/11/26 11:08
 */
@Api("实时监控controller")
@RestController
@RequestMapping("/hsw/monitoring")
public class HswMonitoringController extends BaseController {

    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswDivideWorkService hswDivideWorkService;


    /**
     * 获取项目树
     *
     * @return
     */
    @ApiOperation("获取项目树")
    @GetMapping("/getProjectTree")
    public AjaxResult getProjectTree() {
        return AjaxResult.success(hswDivideWorkService.getTreeByPid());
    }


    /**
     * 获取摄像头列表
     *
     * @param pid
     * @param divideWorkId
     * @param keyword
     * @return
     */
    @ApiOperation("获取摄像头列表")
    @GetMapping("/cameraList")
    public TableDataInfo cameraList(@RequestParam(value = "pid") Long pid,
                                    @RequestParam(value = "divideWorkId") Long divideWorkId,
                                    @RequestParam(value = "keyword", required = false) String keyword) {
        startPage();
        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setPid(pid);
        cameraViewDto.setDivideWorkId(divideWorkId);
        cameraViewDto.setKeyword(keyword);

        List<CameraViewDto> list = this.hswCameraService.selectCameraViewList(cameraViewDto);
        return getDataTable(list);
    }

}
