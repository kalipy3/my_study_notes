package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.hsw.domain.HswCamera;
import com.ruoyi.hsw.service.IHswCameraService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api("地图相关")
@RestController
@RequestMapping("/api/map")
public class ApiMapController {
    @Autowired
    private IHswCameraService cameraService;

    @ApiOperation("修改地图坐标")
    @PutMapping(value = "/mapModifyCoord")
    public AjaxResult mapModifyCoord(@RequestParam String id, @RequestParam String longitude, @RequestParam String latitude) {
        int result = this.cameraService.updateHswCameraBySelfIp(id, longitude, latitude);
        return result > 0 ? AjaxResult.success("修改成功") : AjaxResult.error("修改失败");
    }
}
