package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.domain.entity.SysDictData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * TODO:
 *
 * @author youyong
 * @date 2020/11/11 0011
 */
public class JobView {
    public static String getStatusTextForApp(List<SysDictData> sysDictDataList, Integer status) {

        String statusText = "";

        for (SysDictData sysDictData:sysDictDataList) {
            if (sysDictData.getDictValue().equals(status.toString())) {
                statusText = sysDictData.getDictLabel();
            }
        }

        return statusText;
    }

    public static String getStatusText(Integer status) {
        String statusText = "";
        switch (status) {
            case 0:
                statusText = "<span class=\"label label-sm label-default-outline\">未派单</span>";
                break;
            case 1:
                statusText = "<span class=\"label label-sm label-info-outline\">待接单</span>";
                break;
            case 2:
                statusText = "<span class=\"label label-sm label-warning-outline\">维修中</span>";
                break;
            case 3:
                statusText = "<span class=\"label label-sm label-success-outline\">已修复</span>";
                break;
            case 4:
                statusText = "<span class=\"label label-sm label-danger-outline\">已挂起</span>";
                break;
            case 5:
                statusText = "<span class=\"label label-sm label-success-outline\">自动恢复</span>";
                break;
            case 6:
                statusText = "<span class=\"label label-sm label-default-outline\">已撤单</span>";
                break;
            default:
                break;
        }
        return statusText;
    }

    public static String getStatusText2ForApp(List<SysDictData> sysDictDataList, Integer status) {
        String statusText = "";
        for (SysDictData sysDictData:sysDictDataList) {
            if (sysDictData.getDictValue().equals(status.toString())) {
                statusText = sysDictData.getDictLabel();
            }
        }

        return statusText;
    }

    /**
     * 用户工单状态
     */
    public static String getStatusText2(Integer status) {
        String statusText = "";
        switch (status) {
            case 0:
                statusText = "<span class=\"label label-sm label-default-outline\">未派单</span>";
                break;
            case 1:
                statusText = "<span class=\"label label-sm label-info-outline\">待接单</span>";
                break;
            case 2:
                statusText = "<span class=\"label label-sm label-warning-outline\">维修中</span>";
                break;
            case 3:
                statusText = "<span class=\"label label-sm label-success-outline\">已完成</span>";
                break;
            case 4:
                statusText = "<span class=\"label label-sm label-danger-outline\">已挂起</span>";
                break;
            case 5:
                statusText = "<span class=\"label label-sm label-success-outline\">自动恢复</span>";
                break;
            case 6:
                statusText = "<span class=\"label label-sm label-default-outline\">已撤单</span>";
                break;
            default:
                break;
        }
        return statusText;
    }

    public static String getTypeTextForApp(List<SysDictData> sysDictDataList, Integer type) {
        String typeText = "";
        for (SysDictData sysDictData:sysDictDataList) {
            if (sysDictData.getDictValue().equals(type.toString())) {
                typeText = sysDictData.getDictLabel();
            }
        }

        return typeText;
    }

    public static String getTypeTextForApp2(List<SysDictData> sysDictDataList, Integer type) {
        String typeText = "";
        for (SysDictData sysDictData:sysDictDataList) {
            if (sysDictData.getDictValue().equals(type.toString())) {
                typeText = sysDictData.getDictLabel();
            }
        }

        return typeText;
    }

    public static String getTypeText(Integer type) {
        String typeText = "";
        switch (type) {
            case 1:
                typeText = "<span class=\"label label-sm label-primary\">市电断电</span>";
                break;
            case 2:
                typeText = "<span class=\"label label-sm label-primary\">光纤链路故障</span>";
                break;
            case 3:
                typeText = "<span class=\"label label-sm label-danger\">光纤收发器故障</span>";
                break;
            case 4:
                typeText = "<span class=\"label label-sm label-primary\">摄像机链路故障</span>";
                break;
            case 5:
                typeText = "<span class=\"label label-sm label-danger\">摄像机故障</span>";
                break;
            case 6:
                typeText = "<span class=\"label label-sm label-primary\">主光缆故障</span>";
                break;
            case 7:
                typeText = "<span class=\"label label-sm label-danger\">诊断器故障</span>";
                break;
            case 8:
                typeText = "<span class=\"label label-sm label-warning\">诊断信号输出不正常</span>";
                break;
            case 9:
                typeText = "<span class=\"label label-sm label-warning\">工作不稳定</span>";
                break;
            case 10:
                typeText = "<span class=\"label label-sm label-warning\">工作不稳定-当前故障</span>";
                break;
            case 11:
                typeText = "<span class=\"label label-sm label-primary\">ONU链路故障</span>";
                break;
            case 12:
                typeText = "<span class=\"label label-sm label-primary\">诊断器电源适配器故障</span>";
                break;
            default:
                break;
        }
        return typeText;
    }

    public static String getTypeText2(Integer type) {
        String typeText = "";
        switch (type) {
            case 1:
                typeText = "<span class=\"label label-sm label-primary\">市电断电</span>";
                break;
            case 2:
                typeText = "<span class=\"label label-sm label-primary\">光纤链路故障</span>";
                break;
            case 3:
                typeText = "<span class=\"label label-sm label-danger\">光纤收发器故障</span>";
                break;
            case 4:
                typeText = "<span class=\"label label-sm label-primary\">摄像机链路故障</span>";
                break;
            case 5:
                typeText = "<span class=\"label label-sm label-danger\">摄像机故障</span>";
                break;
            case 6:
                typeText = "<span class=\"label label-sm label-primary\">主光缆故障</span>";
                break;
            case 7:
                typeText = "<span class=\"label label-sm label-danger\">诊断器故障</span>";
                break;
            case 8:
                typeText = "<span class=\"label label-sm label-warning\">诊断信号输出不正常</span>";
                break;
            case 9:
                typeText = "<span class=\"label label-sm label-warning\">工作不稳定-当前正常</span>";
                break;
            case 10:
                typeText = "<span class=\"label label-sm label-warning\">工作不稳定-当前故障</span>";
                break;
            case 11:
                typeText = "<span class=\"label label-sm label-primary\">ONU链路故障</span>";
                break;
            case 12:
                typeText = "<span class=\"label label-sm label-primary\">诊断器电源适配器故障</span>";
                break;
        }
        return typeText;
    }

    public static String getHandleStatusTextForApp(List<SysDictData> sysDictDataList, Integer status) {
        String handleStatusText = "";
        for (SysDictData sysDictData:sysDictDataList) {
            if (sysDictData.getDictValue().equals(status.toString())) {
                handleStatusText = sysDictData.getDictLabel();
            }
        }

        return handleStatusText;
    }

    public static String getHandleStatusText(Integer status) {
        String handleStatusText = "";
        switch (status) {
            case 0:
                handleStatusText = "<span class=\"label label-sm label-info-outline\">已派单</span>";
                break;
            case 1:
                handleStatusText = "<span class=\"label label-sm label-info-outline\">已接单</span>";
                break;
            case 2:
                handleStatusText = "<span class=\"label label-sm label-danger-outline\">已拒绝</span>";
                break;
            case 3:
                handleStatusText = "<span class=\"label label-sm label-primary-outline\">申请改派</span>";
                break;
            case 4:
                handleStatusText = "<span class=\"label label-sm label-info-outline\">已改派</span>";
                break;
            case 5:
                handleStatusText = "<span class=\"label label-sm label-primary-outline\">申请挂起</span>";
                break;
            case 6:
                handleStatusText = "<span class=\"label label-sm label-default-outline\">已挂起</span>";
                break;
            case 7:
                handleStatusText = "<span class=\"label label-sm label-warning-outline\">已撤回挂起</span>";
                break;
            case 8:
                handleStatusText = "<span class=\"label label-sm label-danger-outline\">已撤销</span>";
                break;
            case 9:
                handleStatusText = "<span class=\"label label-sm label-success-outline\">已结单</span>";
                break;
            case 10:
                handleStatusText = "<span class=\"label label-sm label-danger-outline\">驳回挂起</span>";
                break;
            case 11:
                handleStatusText = "<span class=\"label label-sm label-danger-outline\">驳回改派</span>";
                break;
            case 12:
                handleStatusText = "<span class=\"label label-sm label-success-outline\">自动恢复</span>";
                break;
            case 13:
                handleStatusText = "<span class=\"label label-sm label-info-outline\">已撤单</span>";
                break;
            default:
                break;
        }
        return handleStatusText;
    }

    /**
     * 获取工单操作按钮
     */
    public static Map<String, String> optBtns(Integer jobStatus, Long toUid, Integer handleStatus, Long groupId, Integer userType, Long currentUid) {
        //groupId=7 维修员  groupId=6 维修队长
        //handle_status 操作状态：0=派单；1=接单；2=拒绝；3=申请改派；4=改派；5=申请挂起；6=挂起；7=撤回挂起；8=撤销；9=结单；10=拒绝挂起；11=拒绝改派
        //$job_status 工单状态（0=未派单；1=待接单；2=在修； 3=已修复；4=挂起）
        Map<String, String> btns = new HashMap<>();
        switch (jobStatus) {

            case 2://在修
//                if (userType == 3) {//运维单位用户才有权限操作工单流转 申请挂起/结单/挂起/撤单 按钮
                    if (groupId == 7) {//维修员

                        switch (handleStatus) {
                            case 0:
                                btns.put("applyHangUp", "申请挂起");
                                btns.put("applyChangeAssign", "申请改派");
                                btns.put("finishJobInfo", "结单");
                                break;
                            case 10://拒绝挂起
                                btns.put("applyChangeAssign", "申请改派");
                                btns.put("finishJobInfo", "结单");
                                break;
                            case 11://拒绝改派
                                btns.put("applyHangUp", "申请挂起");
                                btns.put("finishJobInfo", "结单");

                            case 7:
                                btns.put("applyHangUp", "申请挂起");
                                btns.put("applyChangeAssign", "申请改派");
                                btns.put("finishJobInfo", "结单");
                                break;
                            case 4:
                                btns.put("applyHangUp", "申请挂起");
                                btns.put("finishJobInfo", "结单");
                                break;
                            default:
                                break;
                        }
                        btns.put("revoke", "撤单");
                    } else if (groupId == 6) {
                        if (toUid.equals(currentUid)) {
                            switch (handleStatus) {
                                case 0:
                                    btns.put("applyHangUp", "申请挂起");
                                    btns.put("applyChangeAssign", "申请改派");
                                    btns.put("finishJobInfo", "结单");
                                    break;
                                case 3:
                                    btns.put("reassign", "改派");
                                    break;
                                case 4:
                                    btns.put("applyHangUp", "申请挂起");
                                    btns.put("finishJobInfo", "结单");
                                    break;
                                case 5:
                                    btns.put("hangUp", "挂起");
                                    break;
                                case 7:
                                    btns.put("applyHangUp", "申请挂起");
                                    btns.put("applyChangeAssign", "申请改派");
                                    btns.put("finishJobInfo", "结单");
                                    break;
                                case 10://拒绝挂起
                                    btns.put("applyChangeAssign", "申请改派");
                                    btns.put("finishJobInfo", "结单");
                                    break;
                                case 11://拒绝改派
                                    btns.put("applyHangUp", "申请挂起");
                                    btns.put("finishJobInfo", "结单");
                                default:
                                    break;
                            }
                        } else {
                            switch (handleStatus) {
                                case 3:
                                    btns.put("reassign", "改派");
                                    break;
                                case 5:
                                    btns.put("hangUp", "挂起");
                                    break;
                            }
                        }

                        btns.put("revoke", "撤单");
                    }
//                }
                break;
            case 4://挂起
//                if (userType == 3) {//运维单位用户才有权限操作工单流转 撤回挂起/撤单 按钮
                    if (groupId == 6 && handleStatus == 6) {//维修队长
                        btns.put("resume", "撤回挂起");
                        btns.put("revoke", "撤单");
                    }
//                }
                break;
            default:
                break;
        }
        return btns;
    }
}
