package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswDivideWork;
import com.ruoyi.hsw.service.IHswDivideWorkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 分工职责Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("分工职责Controller")
@RestController
@RequestMapping("/hsw/divideWork")
public class HswDivideWorkController extends BaseController {
    @Autowired
    private IHswDivideWorkService hswDivideWorkService;

    /**
     * 查询分工职责列表
     */
    @ApiOperation("查询分工职责列表")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswDivideWork hswDivideWork) {
        startPage();
        List<HswDivideWork> list = hswDivideWorkService.selectHswDivideWorkList(hswDivideWork);
        return getDataTable(list);
    }

    /**
     * 导出分工职责列表
     */
    @ApiOperation("导出分工职责列表")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @Log(title = "分工职责", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswDivideWork hswDivideWork) {
        List<HswDivideWork> list = hswDivideWorkService.selectHswDivideWorkList(hswDivideWork);
        ExcelUtil<HswDivideWork> util = new ExcelUtil<HswDivideWork>(HswDivideWork.class);
        return util.exportExcel(list, "分工职责列表");
    }

    /**
     * 获取分工职责详细信息
     */
    @ApiOperation("获取分工职责详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswDivideWorkService.selectHswDivideWorkById(id));
    }

    /**
     * 新增分工职责
     */
    @ApiOperation("新增分工职责")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @Log(title = "分工职责", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HswDivideWork hswDivideWork) {

        if (hswDivideWork.getId() != null) {
            hswDivideWork.setId(null);
        }

        if (this.hswDivideWorkService.existArea(hswDivideWork.getArea(), hswDivideWork.getPid())) {
            return AjaxResult.error("重复添加分工数据");
        }

        return toAjax(hswDivideWorkService.insertHswDivideWork(hswDivideWork));
    }

    /**
     * 修改分工职责
     */
    @ApiOperation("修改分工职责")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @Log(title = "分工职责", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HswDivideWork hswDivideWork) {

        if (this.hswDivideWorkService.existAreaWithNeId(hswDivideWork.getArea(), hswDivideWork.getPid(), hswDivideWork.getId())) {
            return AjaxResult.error("重复添加分工数据");
        }

        return toAjax(hswDivideWorkService.updateHswDivideWork(hswDivideWork));
    }

    /**
     * 删除分工职责
     */
    @ApiOperation("删除分工职责")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @Log(title = "分工职责", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(hswDivideWorkService.deleteHswDivideWorkById(id));
    }
}
