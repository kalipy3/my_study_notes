package com.ruoyi.web.controller.api;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.domain.HswDiagnosisDevice;
import com.ruoyi.hsw.domain.vo.FaultStatisticsVo;
import com.ruoyi.hsw.dto.DiagnosisDeviceViewDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.dto.JobViewDto;
import com.ruoyi.hsw.dto.index.DeviceAreaDto;
import com.ruoyi.hsw.dto.index.DeviceDateCountDto;
import com.ruoyi.hsw.dto.index.EquFaultPageableDto;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Api("首页相关")
@RestController
@RequestMapping("/api/index")
public class ApiIndexController {
    @Autowired
    private IHswDiagnosisDeviceService diagnosisDeviceService;

    @Autowired
    private IIndexService indexService;

    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private IHswJobInfoService hswJobInfoService;

    /**
     * 首页
     *
     * @return
     */
    @ApiOperation("首页")
    @PostMapping
    public AjaxResult index(@RequestParam(value = "pid", required = false) Long pid,
                            @RequestParam(value = "taketime", required = false) String taketime) {

        Long startDate = 0L;
        Long endDate = 0L;

        // 发生时间未传时取最近7天
        if (StringUtils.isNotEmpty(taketime)) {
            String[] dateArray = taketime.split("~");
            // 开始时间
            startDate = DateUtils.getDateMr(DateUtils.parseDate(dateArray[0] + " 00:00:00"));
            // 结束时间
            endDate = DateUtils.getDateMr(DateUtils.parseDate(dateArray[1] + " 23:59:59"));
        } else {
            // 近7天
            Date begin = DateUtils.getSevenDays();
            String beginString = DateUtils.parseDateToStr("yyyy-MM-dd", begin);
            String endString = DateUtils.parseDateToStr("yyyy-MM-dd", new Date());

            // 开始时间
            startDate = DateUtils.getDateMr(DateUtils.parseDate(beginString + " 00:00:00"));
            // 结束时间
            endDate = DateUtils.getDateMr(DateUtils.parseDate(endString + " 23:59:59"));
        }

        EquFaultPageableDto equFaultPageableDto = new EquFaultPageableDto();

        // 项目id未传时，获取当前用户可查询的项目
        List<Long> pIds = new ArrayList<>();
        if (pid != null) {
            pIds.add(pid);
        } else {
            // 获取当前登录用户可查询的项目
            pIds = this.hswProjectService.findPidByUser();
        }

        if (!pIds.isEmpty()) {
            equFaultPageableDto.setPIds(pIds);
        } else {
            pIds.add(-1L);
            equFaultPageableDto.setPIds(pIds);
        }

        Long[] pids = new Long[pIds.size()];
        pIds.toArray(pids);

        // 获取设备数量
        DeviceAreaDto deviceAreaDto = this.indexService.deviceCountForApi(equFaultPageableDto);


        // 近7天的故障类型数量和在线比
        Map<String, Object> faultMap = this.hswFaultInfoService.selectFaultTypeCountByPidsAndDate(pids, startDate, endDate);

        // 24小时数
        String[] hour24 = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"};

        // 当前小时数
        String mm = DateUtils.dateTimeNow("HH");

        // 24小时在线率
        List<DeviceDateCountDto> deviceDateCounts = this.hswFaultInfoService.selectFaultGroupHour(pids, startDate, endDate);

        List<DeviceDateCountDto> showData24 = new ArrayList<>();
        for (String h : hour24) {
            if (h.equals(mm)) {
                break;
            }

            Optional<DeviceDateCountDto> any = deviceDateCounts.stream().filter(d -> h.equals(d.getDateStr())).findAny();
            if (any.isPresent()) {
                DeviceDateCountDto deviceDateCountDto = any.get();
                DecimalFormat df = new DecimalFormat("#.0");
                deviceDateCountDto.setRate(deviceAreaDto.getCameraCount().equals(0)
                        ? 0D
                        : (deviceDateCountDto.getCount() > deviceAreaDto.getCameraCount())
                        ? 0D
                        : Double.valueOf(df.format((deviceAreaDto.getCameraCount() - deviceDateCountDto.getCount()) * 100D / deviceAreaDto.getCameraCount())));
                showData24.add(any.get());
            } else {
                DeviceDateCountDto deviceDateCount = new DeviceDateCountDto();
                deviceDateCount.setDateStr(h);
                deviceDateCount.setCount(0);
                deviceDateCount.setRate(0D);
                showData24.add(deviceDateCount);
            }
        }


        FaultViewDto faultViewDto = new FaultViewDto();
        faultViewDto.setPids(pids);

        JobViewDto jobViewDto = new JobViewDto();
        jobViewDto.setPids(pids);

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        sysUser = this.sysUserService.selectUserById(sysUser.getUserId());
        //1=系统管理员；2=维修管理员；3=维修人员
        switch (sysUser.getType()) {
            case CommonConstant.USER_TYPE_SYSTEM:// 系统管理员用户
                break;
            case CommonConstant.USER_TYPE_CU:// 建设单位用户
                faultViewDto.setCuId(sysUser.getConstructingUnitsId());// 建设单位

                jobViewDto.setCuId(sysUser.getConstructingUnitsId());// 建设单位
                break;
            case CommonConstant.USER_TYPE_MU:// 运维单位用户
                faultViewDto.setMuId(sysUser.getMaintenanceUnitsId());// 运维单位
                faultViewDto.setMtId(sysUser.getTeamId());// 维修队

                jobViewDto.setMuId(sysUser.getMaintenanceUnitsId());// 运维单位
                jobViewDto.setMtId(sysUser.getTeamId());// 维修队

                // 只有维修员用户才需要过滤自己的工单
                if (sysUser.getRoles().stream().anyMatch(r -> r.getRoleId().equals(CommonConstant.ROLE_MAINTENANCE_MAN))) {
                    jobViewDto.setReceiverId(sysUser.getUserId()); // 接单人id
                }

                break;
            default:
                break;
        }

        // 故障数量
        Integer faultCount = this.hswFaultInfoService.selectFaultViewCount(faultViewDto);

        // 工单数量
        Integer jobCount = this.hswJobInfoService.selectJobViewCount(jobViewDto);

        Map<String, Object> data = new HashMap<>();
        data.put("deviceTotal", deviceAreaDto);
        data.put("faultTypeCount", faultMap.get("fault"));
        data.put("weekcount", faultMap.get("faultList"));
        data.put("showData24", showData24);
        data.put("faultCount", faultCount);
        data.put("jobCount", jobCount);

        return AjaxResult.success(data);
    }

    /**
     * 根据ip查询诊断器
     *
     * @param ip
     * @return
     */
    @ApiOperation("根据ip查询诊断器")
    @PostMapping("/getDiagnosisByIp")
    public AjaxResult getDiagnosisByIp(@RequestParam("ip") String ip) {
        HswDiagnosisDevice diagnosisDevice = this.diagnosisDeviceService.selectHswDiagnosisDeviceByIp(ip);
        return AjaxResult.success(diagnosisDevice);
    }
}
