package com.ruoyi.web.controller.hsw;

import java.util.List;

import com.ruoyi.common.core.domain.model.LoginUser;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.web.service.TokenService;
import com.ruoyi.hsw.domain.HswOpticalTransceiver;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.hsw.domain.HswOtherDevice;
import com.ruoyi.hsw.service.IHswOtherDeviceService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * 其他设备Controller
 *
 * @author ruoyi
 * @date 2020-11-06
 */
@Api("其他设备")
@RestController
@RequestMapping("/hsw/otherDevice")
public class HswOtherDeviceController extends BaseController {
    @Autowired
    private IHswOtherDeviceService hswOtherDeviceService;

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询其他设备列表
     */
    @ApiOperation("查询其他设备列表")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswOtherDevice hswOtherDevice) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswOtherDevice.setPids(pids);

        startPage();
        List<HswOtherDevice> list = hswOtherDeviceService.selectHswOtherDeviceList(hswOtherDevice);
        return getDataTable(list);
    }

    /**
     * 导出其他设备列表
     */
    @ApiOperation("导出其他设备列表")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:export')")
    @Log(title = "其他设备", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswOtherDevice hswOtherDevice) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswOtherDevice.setPids(pids);

        List<HswOtherDevice> list = hswOtherDeviceService.selectHswOtherDeviceList(hswOtherDevice);
        ExcelUtil<HswOtherDevice> util = new ExcelUtil<HswOtherDevice>(HswOtherDevice.class);
        return util.exportExcel(list, "其他设备列表");
    }

    /**
     * 获取其他设备详细信息
     */
    @ApiOperation("获取其他设备详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswOtherDeviceService.selectHswOtherDeviceById(id));
    }

    /**
     * 新增其他设备
     */
    @ApiOperation("新增其他设备")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:add')")
    @Log(title = "其他设备", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody HswOtherDevice hswOtherDevice) {
        if (StringUtils.isNull(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswOtherDevice.getIp()))) {
            return AjaxResult.error("新增其他设备失败，所属诊断器ip'" + hswOtherDevice.getIp() + "'不存在");
        }

        hswOtherDevice.setCreateBy(SecurityUtils.getUsername());
        hswOtherDevice.setInstallTime(DateUtils.getDateMr(hswOtherDevice.getInstallDate()));
        return toAjax(hswOtherDeviceService.insertHswOtherDevice(hswOtherDevice));
    }

    /**
     * 修改其他设备
     */
    @ApiOperation("修改其他设备")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:edit')")
    @Log(title = "其他设备", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody HswOtherDevice hswOtherDevice) {
        if (StringUtils.isNull(hswDiagnosisDeviceService.selectHswDiagnosisDeviceByIp(hswOtherDevice.getIp()))) {
            return AjaxResult.error("修改其他设备失败，所属诊断器ip'" + hswOtherDevice.getIp() + "'不存在");
        }

        hswOtherDevice.setUpdateBy(SecurityUtils.getUsername());
        hswOtherDevice.setInstallTime(DateUtils.getDateMr(hswOtherDevice.getInstallDate()));
        return toAjax(hswOtherDeviceService.updateHswOtherDevice(hswOtherDevice));
    }

    /**
     * 删除其他设备
     */
    @ApiOperation("删除其他设备")
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:remove')")
    @Log(title = "其他设备", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswOtherDeviceService.deleteHswOtherDeviceByIds(ids));
    }

    /**
     * 下载导入模板
     *
     * @return
     */
    @ApiOperation("下载导入模板")
    @GetMapping("/importTemplate")
    public AjaxResult importTemplate() {
        ExcelUtil<HswOtherDevice> util = new ExcelUtil<HswOtherDevice>(HswOtherDevice.class);
        return util.importTemplateExcel("其他设备数据");
    }

    /**
     * 导入excel
     *
     * @param file 导入的excel文件
     * @return
     * @throws Exception
     */
    @ApiOperation("导入excel")
    @Log(title = "其他设备", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('hsw:otherDevice:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception {

        if (StringUtils.isNull(file)) {
            return AjaxResult.error("导入失败，导入文件不能为空");
        }

        ExcelUtil<HswOtherDevice> util = new ExcelUtil<HswOtherDevice>(HswOtherDevice.class);
        List<HswOtherDevice> hswOtherDeviceList = util.importExcel(file.getInputStream());
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String operName = loginUser.getUsername();

        int failureNum = 1;
        StringBuilder failureMsg = new StringBuilder();
        String resultMsg;
        for (HswOtherDevice otherDevice : hswOtherDeviceList) {
            failureNum++;
            resultMsg = hswOtherDeviceService.checkValid(otherDevice, hswOtherDeviceList);
            if (StringUtils.isNotEmpty(resultMsg)) {
                failureMsg.append("<br/>第" + failureNum + "项" + resultMsg);
            }
        }

        if (StringUtils.isNotEmpty(failureMsg.toString())) {
            return AjaxResult.error(failureMsg.toString());
        }

        String message = hswOtherDeviceService.importOtherDevice(hswOtherDeviceList, operName);
        return AjaxResult.success(message);
    }
}
