package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswMaintenanceTeam;
import com.ruoyi.hsw.service.IHswMaintenanceTeamService;
import com.ruoyi.hsw.service.IHswProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 维修队Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("维修队")
@RestController
@RequestMapping("/hsw/maintenanceTeam")
public class HswMaintenanceTeamController extends BaseController {
    @Autowired
    private IHswMaintenanceTeamService hswMaintenanceTeamService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询维修队列表
     */
    @ApiOperation("查询维修队列表")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswMaintenanceTeam hswMaintenanceTeam) {
        startPage();
        List<HswMaintenanceTeam> list = hswMaintenanceTeamService.selectHswMaintenanceTeamList(hswMaintenanceTeam);
        return getDataTable(list);
    }

    /**
     * 导出维修队列表
     */
    @ApiOperation("导出维修队列表")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:export')")
    @Log(title = "维修队", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswMaintenanceTeam hswMaintenanceTeam) {
        List<HswMaintenanceTeam> list = hswMaintenanceTeamService.selectHswMaintenanceTeamList(hswMaintenanceTeam);
        ExcelUtil<HswMaintenanceTeam> util = new ExcelUtil<HswMaintenanceTeam>(HswMaintenanceTeam.class);
        return util.exportExcel(list, "维修队列表");
    }

    /**
     * 获取维修队详细信息
     */
    @ApiOperation("获取维修队详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswMaintenanceTeamService.selectHswMaintenanceTeamById(id));
    }

    /**
     * 新增维修队
     */
    @ApiOperation("新增维修队")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:add')")
    @Log(title = "维修队", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HswMaintenanceTeam hswMaintenanceTeam) {

        if (this.hswMaintenanceTeamService.existName(hswMaintenanceTeam.getName())) {
            return AjaxResult.error("名称已经存在");
        }

        return toAjax(hswMaintenanceTeamService.insertHswMaintenanceTeam(hswMaintenanceTeam));
    }

    /**
     * 修改维修队
     */
    @ApiOperation("修改维修队")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:edit')")
    @Log(title = "维修队", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HswMaintenanceTeam hswMaintenanceTeam) {
        return toAjax(hswMaintenanceTeamService.updateHswMaintenanceTeam(hswMaintenanceTeam));
    }

    /**
     * 删除维修队
     */
    @ApiOperation("删除维修队")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceTeam:remove')")
    @Log(title = "维修队", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswMaintenanceTeamService.deleteHswMaintenanceTeamByIds(ids));
    }
}
