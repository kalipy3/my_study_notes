package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswConstructingUnits;
import com.ruoyi.hsw.service.IHswConstructingUnitsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 建设单位Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("建设单位管理")
@RestController
@RequestMapping("/hsw/constructingUnits")
public class HswConstructingUnitsController extends BaseController {
    @Autowired
    private IHswConstructingUnitsService hswConstructingUnitsService;

    /**
     * 查询建设单位列表
     */
    @ApiOperation("查询建设单位列表")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswConstructingUnits hswConstructingUnits) {
        startPage();
        List<HswConstructingUnits> list = hswConstructingUnitsService.selectHswConstructingUnitsList(hswConstructingUnits);
        return getDataTable(list);
    }

    /**
     * 导出建设单位列表
     */
    @ApiOperation("导出建设单位列表")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:export')")
    @Log(title = "建设单位", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswConstructingUnits hswConstructingUnits) {
        List<HswConstructingUnits> list = hswConstructingUnitsService.selectHswConstructingUnitsList(hswConstructingUnits);
        ExcelUtil<HswConstructingUnits> util = new ExcelUtil<HswConstructingUnits>(HswConstructingUnits.class);
        return util.exportExcel(list, "建设单位列表");
    }

    /**
     * 获取建设单位详细信息
     */
    @ApiOperation("获取建设单位详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswConstructingUnitsService.selectHswConstructingUnitsById(id));
    }

    /**
     * 新增建设单位
     */
    @ApiOperation("新增建设单位")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:add')")
    @Log(title = "建设单位", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody HswConstructingUnits hswConstructingUnits) {
        hswConstructingUnits.setCreateBy(SecurityUtils.getUsername());
        return toAjax(hswConstructingUnitsService.insertHswConstructingUnits(hswConstructingUnits));
    }

    /**
     * 修改建设单位
     */
    @ApiOperation("修改建设单位")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:edit')")
    @Log(title = "建设单位", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody HswConstructingUnits hswConstructingUnits) {
        hswConstructingUnits.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(hswConstructingUnitsService.updateHswConstructingUnits(hswConstructingUnits));
    }

    /**
     * 删除建设单位
     */
    @ApiOperation("删除建设单位")
    @PreAuthorize("@ss.hasPermi('hsw:constructingUnits:remove')")
    @Log(title = "建设单位", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswConstructingUnitsService.deleteHswConstructingUnitsByIds(ids));
    }
}
