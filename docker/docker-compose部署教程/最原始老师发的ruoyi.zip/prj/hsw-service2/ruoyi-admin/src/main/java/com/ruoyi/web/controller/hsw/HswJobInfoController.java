package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.constant.CommonSms;
import com.ruoyi.hsw.domain.HswJobInfo;
import com.ruoyi.hsw.service.IHswJobInfoService;
import com.ruoyi.hsw.service.ISmsService;
import com.ruoyi.system.domain.SysConfig;
import com.ruoyi.system.service.ISysConfigService;
import com.ruoyi.system.service.ISysDictDataService;
import com.ruoyi.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 工单Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("工单Controller")
@RestController
@RequestMapping("/hsw/jobInfo")
public class HswJobInfoController extends BaseController {
    @Autowired
    private IHswJobInfoService hswJobInfoService;

    @Autowired
    private ISysUserService sysUserService;

    @Autowired
    private ISmsService smsService;

    @Autowired
    private ISysConfigService sysConfigService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    /**
     * 查询活动工单列表
     */
    @ApiOperation("查询活动工单列表")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswJobInfo hswJobInfo) {
        // 获取用户数据权限
        HswJobInfo jobInfo = this.dataPermission(hswJobInfo);
        startPage();
        List<HswJobInfo> list = hswJobInfoService.selectHswJobInfoList(jobInfo);
        return getDataTable(list);
    }

    /**
     * 查询历史工单列表
     */
    @ApiOperation("查询历史工单列表")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:historyList')")
    @GetMapping("/historyList")
    public TableDataInfo historyList(HswJobInfo hswJobInfo) {
        // 获取用户数据权限
        HswJobInfo jobInfo = this.dataPermission(hswJobInfo);
        startPage();
        List<HswJobInfo> list = hswJobInfoService.selectHistoryList(jobInfo);
        return getDataTable(list);
    }

    /**
     * 导出活动工单列表
     */
    @ApiOperation("导出活动工单列表")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:export')")
    @Log(title = "工单", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswJobInfo hswJobInfo) {
        // 获取用户数据权限
        HswJobInfo jobInfo = this.dataPermission(hswJobInfo);
        List<HswJobInfo> list = hswJobInfoService.selectHswJobInfoList(jobInfo);
        if (!list.isEmpty()) {
            List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
            list.forEach(entity -> {
                // 派单时间
                if (entity.getSendTime() != null && entity.getSendTime() > 0) {
                    entity.setSendDate(DateUtils.parseSecondsToDate(entity.getSendTime()));
                } else {
                    entity.setSendDate(null);
                }

                // 接单时间
                if (entity.getReceiverTime() != null && entity.getReceiverTime() > 0) {
                    entity.setReceiverDate(DateUtils.parseSecondsToDate(entity.getReceiverTime()));
                } else {
                    entity.setReceiverDate(null);
                }

                if (entity.getSendUid() != null) {
                    // 派单人
                    SysUser sendUser = this.sysUserService.selectUserById(entity.getSendUid());
                    if (StringUtils.isNotNull(sendUser)) {
                        entity.setSendName(sendUser.getNickName());
                    }
                }

                if (entity.getReceiverId() != null) {
                    // 接单人
                    SysUser receiverUser = this.sysUserService.selectUserById(entity.getReceiverId());
                    if (StringUtils.isNotNull(receiverUser)) {
                        entity.setReceiverName(receiverUser.getNickName());
                    }
                }

                // 工单状态
                if (StringUtils.isNotNull(entity.getStatus())) {
                    if (!sysDictDataList.isEmpty()) {
                        sysDictDataList.forEach(dictData -> {
                            if (entity.getStatus().toString().equals(dictData.getDictValue())) {
                                entity.setStatusText(dictData.getDictLabel());
                            }
                        });
                    }
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }

                // 挂起时间
                if (entity.getHangUpTime() != null && entity.getHangUpTime() > 0) {
                    entity.setHangUpDate(DateUtils.parseSecondsToDate(entity.getHangUpTime()));
                } else {
                    entity.setHangUpDate(null);
                }

                // 撤回挂起时间
                if (entity.getResumeTime() != null && entity.getResumeTime() > 0) {
                    entity.setResumeDate(DateUtils.parseSecondsToDate(entity.getResumeTime()));
                } else {
                    entity.setResumeDate(null);
                }

                // 操作状态
                if (!dictDataList.isEmpty()) {
                    dictDataList.forEach(dictData -> {
                        if (entity.getHandleStatus().toString().equals(dictData.getDictValue())) {
                            entity.setHandleStatusText(dictData.getDictLabel());
                        }
                    });
                }

            });
        }
        ExcelUtil<HswJobInfo> util = new ExcelUtil<HswJobInfo>(HswJobInfo.class);
        return util.exportExcel(list, "活动工单列表");
    }

    /**
     * 导出历史工单列表
     */
    @ApiOperation("导出历史工单列表")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:historyExport')")
    @Log(title = "工单", businessType = BusinessType.EXPORT)
    @GetMapping("/historyExport")
    public AjaxResult historyExport(HswJobInfo hswJobInfo) {
        // 获取用户数据权限
        HswJobInfo jobInfo = this.dataPermission(hswJobInfo);
        List<HswJobInfo> list = hswJobInfoService.selectHistoryList(jobInfo);
        if (!list.isEmpty()) {
            List<SysDictData> dictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_HANDLE_STATUS);
            List<SysDictData> sysDictDataList = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_JOB_STATUS);
            list.forEach(entity -> {
                // 派单时间
                if (entity.getSendTime() != null && entity.getSendTime() > 0) {
                    entity.setSendDate(DateUtils.parseSecondsToDate(entity.getSendTime()));
                } else {
                    entity.setSendDate(null);
                }

                // 接单时间
                if (entity.getReceiverTime() != null && entity.getReceiverTime() > 0) {
                    entity.setReceiverDate(DateUtils.parseSecondsToDate(entity.getReceiverTime()));
                } else {
                    entity.setReceiverDate(null);
                }

                if (entity.getSendUid() != null) {
                    // 派单人
                    SysUser sendUser = this.sysUserService.selectUserById(entity.getSendUid());
                    if (StringUtils.isNotNull(sendUser)) {
                        entity.setSendName(sendUser.getNickName());
                    }
                }

                if (entity.getReceiverId() != null) {
                    // 接单人
                    SysUser receiverUser = this.sysUserService.selectUserById(entity.getReceiverId());
                    if (StringUtils.isNotNull(receiverUser)) {
                        entity.setReceiverName(receiverUser.getNickName());
                    }
                }

                // 工单状态
                if (StringUtils.isNotNull(entity.getStatus())) {
                    if (!sysDictDataList.isEmpty()) {
                        sysDictDataList.forEach(dictData -> {
                            if (entity.getStatus().toString().equals(dictData.getDictValue())) {
                                entity.setStatusText(dictData.getDictLabel());
                            }
                        });
                    }
                }

                // 修复时间
                if (entity.getRepairTime() != null && entity.getRepairTime() > 0) {
                    entity.setRepairDate(DateUtils.parseSecondsToDate(entity.getRepairTime()));
                } else {
                    entity.setRepairDate(null);
                }

                // 挂起时间
                if (entity.getHangUpTime() != null && entity.getHangUpTime() > 0) {
                    entity.setHangUpDate(DateUtils.parseSecondsToDate(entity.getHangUpTime()));
                } else {
                    entity.setHangUpDate(null);
                }

                // 撤回挂起时间
                if (entity.getResumeTime() != null && entity.getResumeTime() > 0) {
                    entity.setResumeDate(DateUtils.parseSecondsToDate(entity.getResumeTime()));
                } else {
                    entity.setResumeDate(null);
                }

                // 操作状态
                if (!dictDataList.isEmpty()) {
                    dictDataList.forEach(dictData -> {
                        if (entity.getHandleStatus().toString().equals(dictData.getDictValue())) {
                            entity.setHandleStatusText(dictData.getDictLabel());
                        }
                    });
                }

            });
        }
        ExcelUtil<HswJobInfo> util = new ExcelUtil<HswJobInfo>(HswJobInfo.class);
        return util.exportExcel(list, "活动工单列表");
    }

    /**
     * 获取工单详细信息
     */
    @ApiOperation("获取工单详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswJobInfoService.selectHswJobInfoById(id));
    }

    /**
     * 删除工单
     */
    @ApiOperation("删除工单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:remove')")
    @Log(title = "工单", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswJobInfoService.deleteHswJobInfoByIds(ids));
    }

    /**
     * 接单
     */
    @ApiOperation("接单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:accept')")
    @GetMapping(value = "/accept/{id}")
    public AjaxResult accept(@PathVariable("id") Long id) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        if (hswJobInfo == null) {
            return AjaxResult.error("接单失败：未找到该工单");
        }

        if (!hswJobInfo.getReceiverId().equals(user.getUserId())) {
            return AjaxResult.error("接单失败：非法参数，该工单未派单于您");
        }

        return toAjax(this.hswJobInfoService.accept(hswJobInfo));
    }

    /**
     * 拒绝派单
     */
    @ApiOperation("拒绝派单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:refuse')")
    @GetMapping(value = "/refuse")
    public AjaxResult refuse(@RequestParam("id") Long id, @RequestParam("rejection") String rejection) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        if (hswJobInfo == null) {
            return AjaxResult.error("拒绝失败：该工单不存在");
        }

        if (!hswJobInfo.getReceiverId().equals(user.getUserId())) {
            return AjaxResult.error("拒绝失败：非法参数，该工单未派单于您");
        }

        hswJobInfo.setRejection(rejection);
        return toAjax(this.hswJobInfoService.refuse(hswJobInfo));
    }

    /**
     * 申请改派工单
     */
    @ApiOperation("申请改派工单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:applyChangeAssign')")
    @GetMapping(value = "/applyChangeAssign")
    public AjaxResult applyChangeAssign(@RequestParam("id") Long id, @RequestParam("rejection") String rejection) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        if (hswJobInfo == null) {
            return AjaxResult.error("申请失败：未找到该工单");
        }

        if (!hswJobInfo.getReceiverId().equals(user.getUserId())) {
            return AjaxResult.error("申请失败：非法参数，该工单未派单于您");
        }

        hswJobInfo.setRejection(rejection);
        Map<String, Object> res = this.hswJobInfoService.applyChangeAssign(hswJobInfo);
        if (res.get("code").equals(1)) {
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", user.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", hswJobInfo.getRejection());

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", user.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_SQGP");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.APPLY_REASSIGNMENT, templateParam, args);
                }
            }

            return AjaxResult.success("申请改派成功");
        }

        return AjaxResult.error("申请改派失败");
    }

    /**
     * 改派工单 同意/拒绝
     */
    @ApiOperation("改派工单 同意/拒绝")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:reAssign')")
    @GetMapping(value = "/reAssign")
    public AjaxResult reAssign(@RequestParam("id") Long id,
                               @RequestParam("receiverId") Long receiverId,
                               @RequestParam("reason") String reason,
                               @RequestParam("status") Integer status) {

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);
        Map<String, Object> res = new HashMap<>();
        if (hswJobInfo == null) {
            return AjaxResult.error("改派失败：未找到该工单");
        }

        hswJobInfo.setRejection(reason);

        if (status.equals(1)) {
            SysUser newReceiverUser = this.sysUserService.selectUserById(receiverId);
            res = this.hswJobInfoService.reAssign(hswJobInfo, receiverId);
            if (res.get("code").equals(1)) {
                Map<String, Object> templateParam = new HashMap<>();
                templateParam.put("name", sysUser.getNickName());
                templateParam.put("job_no", res.get("jobNo"));

                Map<String, Object> args = new HashMap<>();
                args.put("title", "您有一个工单需要处理");
                args.put("send_name", sysUser.getNickName());
                args.put("receiver_id", newReceiverUser.getUserId());
                args.put("receiver_name", newReceiverUser.getNickName());
                args.put("job_no", res.get("jobNo"));
                args.put("tpl_key", "TPL_MSG_PD");

                SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
                if (StringUtils.isNotNull(sysConfig)) {
                    if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                        //先发派单消息给新接收者
                        this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), newReceiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);

                        //发送同意申请给原接收者
                        SysUser oldReceiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("oldReceiverId").toString()));
                        args.put("receiver_id", oldReceiverUser.getUserId());
                        args.put("receiver_name", oldReceiverUser.getNickName());
                        args.put("tpl_key", "TPL_MSG_GP_OK");
                        this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), newReceiverUser.getPhonenumber(), CommonSms.REASSIGNMENT_YES, templateParam, args);
                    }
                }

                return AjaxResult.success("成功");
            }
        } else {
            res = this.hswJobInfoService.refuseAssign(hswJobInfo);
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", reason);

            Map<String, Object> args = new HashMap<>();
            args.put("reason", reason);
            args.put("job_no", res.get("jobNo"));
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_GP_REFUSE");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.REASSIGNMENT_NO, templateParam, args);
                }
            }

            return AjaxResult.success("成功");
        }

        return AjaxResult.error("失败");
    }


    /**
     * 结单
     */
    @ApiOperation("结单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:finish')")
    @GetMapping(value = "/finish")
    public AjaxResult finish(@RequestParam("id") Long id, @RequestParam("repairRecord") String repairRecord) {
        SysUser user = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        if (hswJobInfo == null) {
            return AjaxResult.error("维修反馈失败：未找到该工单");
        }

        if (!hswJobInfo.getReceiverId().equals(user.getUserId())) {
            return AjaxResult.error("维修反馈失败：非法参数，该工单未派单于您");
        }

        hswJobInfo.setRepairRecord(repairRecord);
        Map<String, Object> res = this.hswJobInfoService.repair(hswJobInfo);
        if (res.get("code").equals(1)) {
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("time", DateUtils.datetimeToStr(Long.valueOf(res.get("takeTime").toString())));
            templateParam.put("region_name", res.get("regionName"));
            templateParam.put("repair_record", repairRecord);

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", user.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_WC");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.STATEMENT, templateParam, args);
                }
            }

            return AjaxResult.success("结单成功");
        }
        return AjaxResult.error("结单失败");
    }

    /**
     * 申请挂起
     */
    @ApiOperation("申请挂起")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:applyHangUp')")
    @GetMapping(value = "/applyHangUp")
    public AjaxResult applyHangUp(@RequestParam("id") Long id, @RequestParam("handleReason") String handleReason) {
        SysUser user = SecurityUtils.getLoginUser().getUser();
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        if (hswJobInfo == null) {
            return AjaxResult.error("申请挂起失败：未找到该工单");
        }

        if (!hswJobInfo.getReceiverId().equals(user.getUserId())) {
            return AjaxResult.error("申请挂起失败：非法参数，该工单未派单于您");
        }

        hswJobInfo.setHangUpReason(handleReason);

        Map<String, Object> res = this.hswJobInfoService.applyHangUp(hswJobInfo);
        if (res.get("code").equals(1)) {
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("sendUid").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", user.getNickName());
            templateParam.put("job_no", res.get("jobNo"));
            templateParam.put("reason", handleReason);

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", user.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_SQGQ");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.APPLY_HANG_UP, templateParam, args);
                }
            }

            return AjaxResult.success("申请成功");
        }
        return AjaxResult.error("申请失败");
    }

    /**
     * 挂起工单 同意/拒绝
     */
    @ApiOperation("挂起工单 同意/拒绝")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:hangUp')")
    @GetMapping(value = "/hangUp")
    public AjaxResult hangUp(@RequestParam("id") Long id,
                             @RequestParam("reason") String reason,
                             @RequestParam("status") Integer status) {
        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        Map<String, Object> res = new HashMap<>();

        if (hswJobInfo == null) {
            return AjaxResult.error("挂起失败：未找到该工单");
        }

        hswJobInfo.setHangUpReason(reason);

        if (status.equals(1)) {
            res = this.hswJobInfoService.hangUp(hswJobInfo);
            if (res.get("code").equals(1)) {
                SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
                Map<String, Object> templateParam = new HashMap<>();
                templateParam.put("name", sysUser.getNickName());
                templateParam.put("job_no", res.get("jobNo"));
                templateParam.put("reason", reason);

                Map<String, Object> args = new HashMap<>();
                args.put("title", "您有一个工单需要处理");
                args.put("send_name", sysUser.getNickName());
                args.put("receiver_id", receiverUser.getUserId());
                args.put("receiver_name", receiverUser.getNickName());
                args.put("job_no", res.get("jobNo"));
                args.put("tpl_key", "TPL_MSG_GQ_OK");

                SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
                if (StringUtils.isNotNull(sysConfig)) {
                    if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                        //先发派单消息给新接收者
                        this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.HANG_UP_YES, templateParam, args);
                    }
                }

                return AjaxResult.success("成功");
            }
        } else {
            res = this.hswJobInfoService.refuseHangUp(hswJobInfo);
            if (res.get("code").equals(1)) {
                SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
                Map<String, Object> templateParam = new HashMap<>();
                templateParam.put("name", sysUser.getNickName());
                templateParam.put("job_no", res.get("jobNo"));
                templateParam.put("reason", reason);

                Map<String, Object> args = new HashMap<>();
                args.put("title", "您有一个工单需要处理");
                args.put("send_name", sysUser.getNickName());
                args.put("receiver_id", receiverUser.getUserId());
                args.put("receiver_name", receiverUser.getNickName());
                args.put("job_no", res.get("jobNo"));
                args.put("tpl_key", "TPL_MSG_GQ_REFUSE");

                SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
                if (StringUtils.isNotNull(sysConfig)) {
                    if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                        //先发派单消息给新接收者
                        this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.HANG_UP_NO, templateParam, args);
                    }
                }

                return AjaxResult.success("成功");
            }
        }

        return AjaxResult.error("失败");
    }

    /**
     * 恢复被挂起的工单
     */
    @ApiOperation("恢复被挂起的工单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:resume')")
    @GetMapping(value = "/resume")
    public AjaxResult resume(@RequestParam("id") Long id,
                             @RequestParam("reason") String reason,
                             @RequestParam("receiverId") Long receiverId) {

        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);

        SysUser sysUser = SecurityUtils.getLoginUser().getUser();
        if (hswJobInfo == null) {
            return AjaxResult.error("撤回挂起失败：未找到该工单");
        }

        hswJobInfo.setRejection(reason);
        hswJobInfo.setReceiverId(receiverId);

        Map<String, Object> res = this.hswJobInfoService.resume(hswJobInfo);
        if (res.get("code").equals(1)) {
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("name", sysUser.getNickName());
            templateParam.put("job_no", res.get("jobNo"));

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_PD");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.DISTRIBUTE_LEAFLETS, templateParam, args);
                }
            }

            return AjaxResult.success("撤回成功");
        }

        return AjaxResult.error("撤回失败");
    }

    /**
     * 撤销工单
     */
    @ApiOperation("撤销工单")
    @PreAuthorize("@ss.hasPermi('hsw:jobInfo:revoke')")
    @GetMapping(value = "/revoke")
    public AjaxResult revoke(@RequestParam("id") Long id,
                             @RequestParam("handleReason") String handleReason) {

        HswJobInfo hswJobInfo = this.hswJobInfoService.selectHswJobInfoById(id);
        SysUser sysUser = SecurityUtils.getLoginUser().getUser();

        if (hswJobInfo == null) {
            return AjaxResult.error("撤销工单失败：未找到该工单");
        }

        hswJobInfo.setRejection(handleReason);
        Map<String, Object> res = this.hswJobInfoService.revoke(hswJobInfo);
        if (res.get("code").equals(1)) {
            SysUser receiverUser = this.sysUserService.selectUserById(Long.parseLong(res.get("receiverId").toString()));
            Map<String, Object> templateParam = new HashMap<>();
            templateParam.put("job_no", res.get("jobNo"));

            Map<String, Object> args = new HashMap<>();
            args.put("title", "您有一个工单需要处理");
            args.put("send_name", sysUser.getNickName());
            args.put("receiver_id", receiverUser.getUserId());
            args.put("receiver_name", receiverUser.getNickName());
            args.put("job_no", res.get("jobNo"));
            args.put("tpl_key", "TPL_MSG_CX");

            SysConfig sysConfig = this.sysConfigService.selectConfigByConfigKey(CommonParameter.SMS_OPEN);
            if (StringUtils.isNotNull(sysConfig)) {
                if (sysConfig.getConfigValue().equals(CommonConstant.SMS_OPEN_YES)) {
                    //先发派单消息给新接收者
                    this.smsService.sendSMS(Long.valueOf(res.get("cuId").toString()), receiverUser.getPhonenumber(), CommonSms.REVOKE, templateParam, args);
                }
            }

            return AjaxResult.success("撤销成功");
        }

        return AjaxResult.error("撤销失败");
    }

    /**
     * 获取用户数据权限
     */
    public HswJobInfo dataPermission(HswJobInfo hswJobInfo) {

        SysUser user = SecurityUtils.getLoginUser().getUser();
        //1=系统管理员用户；2=建设单位用户；3=运维单位用户
        switch (user.getType()) {
            case CommonConstant.USER_TYPE_CU:
                // 建设单位id
                hswJobInfo.setCuId(user.getConstructingUnitsId());
                break;
            case CommonConstant.USER_TYPE_MU:
                // 运维单位id
                hswJobInfo.setMuId(user.getMaintenanceUnitsId());
                if (user.getTeamId() != null && user.getTeamId() != 0) {
                    // 运维队id
                    hswJobInfo.setMtId(user.getTeamId());
                }
                // 维修员id
                if (!user.getRoles().isEmpty()) {
                    user.getRoles().forEach(sysRole -> {
                        if (sysRole.getRoleId() == CommonConstant.ROLE_MAINTENANCE_MAN) {
                            hswJobInfo.setReceiverId(user.getUserId());
                        }
                    });
                }
                break;
            default:
                break;
        }

        return hswJobInfo;
    }
}
