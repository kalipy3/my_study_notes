package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswMaintenanceUnits;
import com.ruoyi.hsw.domain.HswProject;
import com.ruoyi.hsw.domain.HswProjectMaintenanceUnits;
import com.ruoyi.hsw.service.*;
import com.ruoyi.system.domain.vo.RegionDto;
import com.ruoyi.system.service.ISysRegionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 项目Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("项目Controller")
@RestController
@RequestMapping("/hsw/projectArchive")
public class HswProjectArchiveController extends BaseController {
    @Autowired
    private IHswProjectService hswProjectService;

    @Autowired
    private IHswProjectMaintenanceUnitsService hswProjectMaintenanceUnitsService;

    @Autowired
    private IHswMaintenanceUnitsService hswMaintenanceUnitsService;

    @Autowired
    private ISysRegionService sysRegionService;

    @Autowired
    private IHswConstructingUnitsService hswConstructingUnitsService;

    @Autowired
    private IHswMaintenanceTeamService hswMaintenanceTeamService;

    @Autowired
    private IHswConstructingTeamService hswConstructingTeamService;

    /**
     * 查询项目列表
     */
    @ApiOperation("查询项目列表")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswProject hswProject) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswProject.setPids(pids);
        startPage();
        List<HswProject> list = hswProjectService.selectHswProjectList(hswProject);
        list.forEach(project -> {
            List<HswMaintenanceUnits> hswMaintenanceUnitsList = new ArrayList<>();
            List<HswProjectMaintenanceUnits> hswProjectMaintenanceUnitsList = this.hswProjectMaintenanceUnitsService.selectHswProjectMaintenanceUnitsById(project.getId());
            if (!hswProjectMaintenanceUnitsList.isEmpty()) {
                hswProjectMaintenanceUnitsList.forEach(hswProjectMaintenanceUnits -> {
                    HswMaintenanceUnits hswMaintenanceUnits = this.hswMaintenanceUnitsService.selectHswMaintenanceUnitsById(hswProjectMaintenanceUnits.getMuId());
                    hswMaintenanceUnitsList.add(hswMaintenanceUnits);
                });
                project.setMaintenanceUnits(hswMaintenanceUnitsList);
            }
        });
        return getDataTable(list);
    }

    /**
     * 导出项目列表
     */
    @ApiOperation("导出项目列表")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:export')")
    @Log(title = "项目", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswProject hswProject) {
        // 获取用户的数据权限
        HswProject entity = this.hswProjectService.dataPermission(hswProject);
        List<HswProject> list = hswProjectService.selectHswProjectList(entity);
        ExcelUtil<HswProject> util = new ExcelUtil<HswProject>(HswProject.class);
        return util.exportExcel(list, "项目档案数据");
    }

    /**
     * 获取项目详细信息
     */
    @ApiOperation("获取项目详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswProjectService.selectHswProjectById(id));
    }

    /**
     * 新增项目
     */
    @ApiOperation("新增项目")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:add')")
    @Log(title = "项目", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HswProject hswProject) {

        if (hswProject.getId() != null) {
            hswProject.setId(null);
        }

        if (!this.hswConstructingUnitsService.existCount()) {
            return AjaxResult.error("请先添加建设单位");
        }

        if (!this.hswConstructingTeamService.existCount()) {
            return AjaxResult.error("请先添加施工单位");
        }

        if (!this.hswMaintenanceUnitsService.existCount()) {
            return AjaxResult.error("请先添加运维单位");
        }

        if (!this.hswMaintenanceTeamService.existCount()) {
            return AjaxResult.error("请先添加维修队");
        }

        hswProject.setCreateBy(SecurityUtils.getUsername());
        return toAjax(hswProjectService.insertHswProject(hswProject));
    }

    /**
     * 修改项目
     */
    @ApiOperation("修改项目")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:edit')")
    @Log(title = "项目", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HswProject hswProject) {
        hswProject.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(hswProjectService.updateHswProject(hswProject));
    }

    /**
     * 删除项目
     */
    @ApiOperation("删除项目")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:remove')")
    @Log(title = "项目", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(hswProjectService.deleteHswProjectById(id));
    }

    /**
     * 竣工
     */
    @ApiOperation("竣工")
    @PreAuthorize("@ss.hasPermi('hsw:projectArchive:finish')")
    @Log(title = "竣工", businessType = BusinessType.UPDATE)
    @GetMapping("/finish")
    public AjaxResult finish(@RequestParam("id") Long id) {
        return toAjax(hswProjectService.finish(id));
    }

    /**
     * 取得项目所在区划父子级列表
     */
    @ApiOperation("取得项目所在区划父子级列表")
    @GetMapping("/cascadeRegionListByProject")
    public AjaxResult cascadeRegionListByProject(@RequestParam(defaultValue = "0") String parentCode) {
        List<RegionDto> regionDtos = this.sysRegionService.selectCascadeList(parentCode);
        List<HswProject> hswProjects = this.hswProjectService.selectHswProjectList(new HswProject());

        List<String> projectProvinceIds = hswProjects.stream().filter(p -> p.getProvince() != null).map(p -> p.getProvince().toString()).distinct().collect(Collectors.toList());
        if (projectProvinceIds.size() > 0) {
            Iterator<RegionDto> iterator = regionDtos.iterator();
            while (iterator.hasNext()) {
                RegionDto regionDto = iterator.next();
                if (!projectProvinceIds.contains(regionDto.getValue())) {
                    iterator.remove();
                }
            }
        }

        return AjaxResult.success(regionDtos);
    }
}
