package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswSysMsg;
import com.ruoyi.hsw.service.IHswSysMsgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 系统消息Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("系统消息管理")
@RestController
@RequestMapping("/hsw/sysMsg")
public class HswSysMsgController extends BaseController {
    @Autowired
    private IHswSysMsgService hswSysMsgService;

    /**
     * 查询系统消息列表
     */
    @ApiOperation("查询系统消息列表")
    @PreAuthorize("@ss.hasPermi('hsw:sysMsg:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswSysMsg hswSysMsg) {
        startPage();
        List<HswSysMsg> list = hswSysMsgService.selectHswSysMsgList(hswSysMsg);
        return getDataTable(list);
    }

    /**
     * 导出系统消息列表
     */
    @ApiOperation("导出系统消息列表")
    @PreAuthorize("@ss.hasPermi('hsw:sysMsg:export')")
    @Log(title = "系统消息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswSysMsg hswSysMsg) {
        List<HswSysMsg> list = hswSysMsgService.selectHswSysMsgList(hswSysMsg);
        ExcelUtil<HswSysMsg> util = new ExcelUtil<HswSysMsg>(HswSysMsg.class);
        return util.exportExcel(list, "系统消息列表");
    }

    /**
     * 获取系统消息详细信息
     */
    @ApiOperation("获取系统消息详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:sysMsg:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswSysMsgService.selectHswSysMsgById(id));
    }

    /**
     * 删除系统消息
     */
    @ApiOperation("删除系统消息")
    @PreAuthorize("@ss.hasPermi('hsw:sysMsg:remove')")
    @Log(title = "系统消息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(hswSysMsgService.deleteHswSysMsgById(id));
    }
}
