package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswJobLog;
import com.ruoyi.hsw.service.IHswJobLogService;
import com.ruoyi.hsw.service.IHswProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 工单日志Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@RestController
@RequestMapping("/hsw/jobLog")
public class HswJobLogController extends BaseController {
    @Autowired
    private IHswJobLogService hswJobLogService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询工单日志列表
     */
    @PreAuthorize("@ss.hasPermi('hsw:jobLog:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswJobLog hswJobLog) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswJobLog.setPids(pids);
        startPage();
        List<HswJobLog> list = hswJobLogService.selectHswJobLogList(hswJobLog);
        return getDataTable(list);
    }

    /**
     * 导出工单日志列表
     */
    @PreAuthorize("@ss.hasPermi('hsw:jobLog:export')")
    @Log(title = "工单日志", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswJobLog hswJobLog) {
        // 获取当前登录用户可查询的项目列表
        List<Long> pids = this.hswProjectService.findPidByUser();
        if (pids.isEmpty()) {
            pids.add(-1L);
        }
        hswJobLog.setPids(pids);
        List<HswJobLog> list = hswJobLogService.selectHswJobLogList(hswJobLog);
        ExcelUtil<HswJobLog> util = new ExcelUtil<HswJobLog>(HswJobLog.class);
        return util.exportExcel(list, "log");
    }

    /**
     * 获取工单日志详细信息
     */
    @PreAuthorize("@ss.hasPermi('hsw:jobLog:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswJobLogService.selectHswJobLogById(id));
    }

    /**
     * 删除工单日志
     */
    @PreAuthorize("@ss.hasPermi('hsw:jobLog:remove')")
    @Log(title = "工单日志", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(hswJobLogService.deleteHswJobLogByIds(ids));
    }
}
