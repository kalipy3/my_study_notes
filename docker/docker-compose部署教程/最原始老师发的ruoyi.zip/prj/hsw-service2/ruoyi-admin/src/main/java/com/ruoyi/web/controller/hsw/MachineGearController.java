package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysDictData;
import com.ruoyi.hsw.constant.CommonConstant;
import com.ruoyi.hsw.constant.CommonParameter;
import com.ruoyi.hsw.dto.CameraViewDto;
import com.ruoyi.hsw.dto.FaultViewDto;
import com.ruoyi.hsw.service.IHswCameraService;
import com.ruoyi.hsw.service.IHswDiagnosisDeviceService;
import com.ruoyi.hsw.service.IHswFaultInfoService;
import com.ruoyi.hsw.service.IHswJobInfoService;
import com.ruoyi.system.service.ISysDictDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 一机一档
 */
@Api("一机一档")
@RestController
@RequestMapping("/hsw/machineGear")
public class MachineGearController extends BaseController {

    @Autowired
    private IHswDiagnosisDeviceService hswDiagnosisDeviceService;

    @Autowired
    private IHswCameraService hswCameraService;

    @Autowired
    private IHswFaultInfoService hswFaultInfoService;

    @Autowired
    private ISysDictDataService sysDictDataService;

    @Autowired
    private IHswJobInfoService hswJobInfoService;

    /**
     * 获取项目诊断器树
     */
    @ApiOperation("获取项目诊断器树")
    @GetMapping("/getProDevTree")
    public AjaxResult getProDevTree() {
        return AjaxResult.success(this.hswDiagnosisDeviceService.getTreeByPid());
    }

    /**
     * 根据诊断器id获取诊断器详细信息
     */
    @ApiOperation("获取诊断器详细信息")
    @GetMapping(value = "/{diagnosisDeviceId}")
    public AjaxResult getByDiagnosisDeviceId(@PathVariable("diagnosisDeviceId") Long id) {
        return AjaxResult.success(hswDiagnosisDeviceService.selectHswDiagnosisDeviceById(id));
    }

    /**
     * 根据ip故障统计饼状图
     */
    @ApiOperation("根据ip故障统计饼状图")
    @GetMapping("/fault")
    public AjaxResult fault(@RequestParam(value = "ip") String ip) {

        return AjaxResult.success(this.hswFaultInfoService.selectFaultTypeCountByIp(ip));
    }

    /**
     * 根据ip获取摄像头点位
     *
     * @return
     */
    @ApiOperation("根据ip获取摄像头点位")
    @GetMapping("/getCameraMarker")
    public AjaxResult getCameraMarker(@RequestParam("ip") String ip) {


        CameraViewDto cameraViewDto = new CameraViewDto();
        cameraViewDto.setIp(ip);
        List<CameraViewDto> cameraViewDtos = this.hswCameraService.selectCameraViewList(cameraViewDto);//所管辖的所有摄像机

        FaultViewDto faultViewDto = new FaultViewDto();
        faultViewDto.setIp(ip);
        faultViewDto.setFlagStatus(CommonConstant.FLAG_STATUS_ACTIVITY);

        // 获取故障级别字典
        List<SysDictData> faultLevelDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_FAULT_LEVEL);

        List<FaultViewDto> faultViewDtos = this.hswFaultInfoService.selectFaultViewList(faultViewDto);
        faultViewDtos.forEach(fault -> {
            if (fault.getInfluenceCameraCount() > 0) {
                if (fault.getPort() == CommonConstant.FAULT_POST) {
                    //该ip下所有摄像机当前都处于故障状态
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                } else {
                    cameraViewDtos.stream().filter(c -> fault.getIp().equals(c.getIp()) && fault.getPort().equals(c.getPort())).forEach(cv -> {
                        cv.setIsFault(CommonConstant.IS_FAULT_YES);
                        cv.setFaultLevel(getFaultLevel(faultLevelDictDatas, fault.getType()));
                    });
                }
            }
        });

        String localCity = "高安市";

        // 项目区域字典
        List<SysDictData> sysDictDatas = this.sysDictDataService.selectByDictType(CommonParameter.HSW_PROJECT_AREA);

        for (SysDictData d : sysDictDatas) {
            if (CommonParameter.AREA.equals(d.getDictLabel())) {
                localCity = d.getDictValue();
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("localCity", localCity);
        result.put("data", cameraViewDtos);
        return AjaxResult.success(result);
    }

    private int getFaultLevel(List<SysDictData> sysDictDatas, Integer type) {
        int level = CommonConstant.FAULT_LEVEL_ZERO;

        if (!sysDictDatas.isEmpty()) {
            for (SysDictData sysDictData : sysDictDatas) {
                if (sysDictData.getDictLabel().equals(type.toString())) {
                    level = Integer.valueOf(sysDictData.getDictValue());
                }
            }
        }
        return level;
    }

    /**
     * 根据ip查询摄像机列表
     */
    @ApiOperation("根据ip查询摄像机列表")
    @GetMapping("/hswCameraList")
    public AjaxResult hswCameraList(@RequestParam("ip") String ip) {

        return AjaxResult.success(hswCameraService.selectCameraListByIp(ip));
    }

    /**
     * 根据ip查询故障列表
     */
    @ApiOperation("根据ip查询故障列表")
    @GetMapping("/hswFaultInfoList")
    public AjaxResult hswFaultInfoList(@RequestParam("ip") String ip) {

        return AjaxResult.success(hswFaultInfoService.selectHswFaultInfoListByIp(ip));
    }

    /**
     * 根据ip查询工单列表
     */
    @ApiOperation("根据ip查询工单列表")
    @GetMapping("/hswJobInfoList")
    public AjaxResult hswJobInfoList(@RequestParam("ip") String ip) {

        return AjaxResult.success(hswJobInfoService.selectHswJobInfoListByIp(ip));
    }
}