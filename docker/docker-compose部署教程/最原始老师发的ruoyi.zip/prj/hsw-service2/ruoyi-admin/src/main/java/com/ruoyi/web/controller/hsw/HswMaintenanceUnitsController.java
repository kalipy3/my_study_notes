package com.ruoyi.web.controller.hsw;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.hsw.domain.HswMaintenanceUnits;
import com.ruoyi.hsw.service.IHswMaintenanceTeamService;
import com.ruoyi.hsw.service.IHswMaintenanceUnitsService;
import com.ruoyi.hsw.service.IHswProjectService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 运维单位Controller
 *
 * @author ruoyi
 * @date 2020-11-04
 */
@Api("运维单位Controller")
@RestController
@RequestMapping("/hsw/maintenanceUnits")
public class HswMaintenanceUnitsController extends BaseController {
    @Autowired
    private IHswMaintenanceUnitsService hswMaintenanceUnitsService;

    @Autowired
    private IHswMaintenanceTeamService hswMaintenanceTeamService;

    @Autowired
    private IHswProjectService hswProjectService;

    /**
     * 查询运维单位列表
     */
    @ApiOperation("查询运维单位列表")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:list')")
    @GetMapping("/list")
    public TableDataInfo list(HswMaintenanceUnits hswMaintenanceUnits) {
        startPage();
        List<HswMaintenanceUnits> list = hswMaintenanceUnitsService.selectHswMaintenanceUnitsList(hswMaintenanceUnits);
        return getDataTable(list);
    }

    /**
     * 根据运维单位id数组查询运维单位列表
     */
    @ApiOperation("根据运维单位id数组查询运维单位列表")
    @PreAuthorize("@ss.hasPermi('hsw:divideWork:list')")
    @GetMapping("/treeList/{ids}")
    public AjaxResult treeList(@PathVariable("ids") Long[] ids) {
        List<HswMaintenanceUnits> list = hswMaintenanceUnitsService.treeList(ids);
        return AjaxResult.success(list);
    }

    /**
     * 导出运维单位列表
     */
    @ApiOperation("导出运维单位列表")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:export')")
    @Log(title = "运维单位", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(HswMaintenanceUnits hswMaintenanceUnits) {
        List<HswMaintenanceUnits> list = hswMaintenanceUnitsService.selectHswMaintenanceUnitsList(hswMaintenanceUnits);
        ExcelUtil<HswMaintenanceUnits> util = new ExcelUtil<HswMaintenanceUnits>(HswMaintenanceUnits.class);
        return util.exportExcel(list, "运维单位");
    }

    /**
     * 获取运维单位详细信息
     */
    @ApiOperation("获取运维单位详细信息")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(hswMaintenanceUnitsService.selectHswMaintenanceUnitsById(id));
    }

    /**
     * 新增运维单位
     */
    @ApiOperation("新增运维单位")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:add')")
    @Log(title = "运维单位", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody HswMaintenanceUnits hswMaintenanceUnits) {
        if (hswMaintenanceUnits.getId() != null) {
            hswMaintenanceUnits.setId(null);
        }

        return toAjax(hswMaintenanceUnitsService.insertHswMaintenanceUnits(hswMaintenanceUnits));
    }

    /**
     * 修改运维单位
     */
    @ApiOperation("修改运维单位")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:edit')")
    @Log(title = "运维单位", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody HswMaintenanceUnits hswMaintenanceUnits) {
        return toAjax(hswMaintenanceUnitsService.updateHswMaintenanceUnits(hswMaintenanceUnits));
    }

    /**
     * 删除运维单位
     */
    @ApiOperation("删除运维单位")
    @PreAuthorize("@ss.hasPermi('hsw:maintenanceUnits:remove')")
    @Log(title = "运维单位", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        boolean result = this.hswMaintenanceTeamService.selectHswMaintenanceTeamCountByMuId(id);
        if (result) {
            return AjaxResult.error("运维单位存在维修队，不能删除");
        }

        return toAjax(hswMaintenanceUnitsService.deleteHswMaintenanceUnitsById(id));
    }
}
