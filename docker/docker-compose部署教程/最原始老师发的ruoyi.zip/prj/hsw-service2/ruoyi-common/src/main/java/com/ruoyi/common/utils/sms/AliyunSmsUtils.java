package com.ruoyi.common.utils.sms;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.ruoyi.common.core.domain.AjaxResult;
import lombok.extern.slf4j.Slf4j;

import java.rmi.ServerException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 阿里短信工具类
 *
 * @author youyong
 * @date 2020/11/18 0018
 */
@Slf4j
public final class AliyunSmsUtils {
    /**
     * 屏蔽构造函数，避免被实例化
     */
    private AliyunSmsUtils() {
    }

    /**
     * 短信发送返回信息
     */
    private static final String MESSAGE_OK = "OK";

    /**
     * 阿里云短信服务提供的标识用户
     */
    private final static String ACCESS_KEY_ID = "LTAI4Fian5Xmtx5bL2P8pe9R";

    /**
     * 阿里云短信服务提供的密钥，用来验证用户的密钥
     */
    private final static String ACCESS_SECRET = "pXKvzGvDme2t2XvzpWosYNuFZ1ERDq";

    /**
     * 短信内容签名
     */
    private final static String SIGN_NAME = "华视维";

    /**
     * 短信发送方法
     *
     * @param accessKeyId     阿里云短信服务提供的标识用户
     * @param accessKeySecret 阿里云短信服务提供的密钥，用来验证用户的密钥
     * @param signName        短信内容签名
     * @param mobile          手机号
     * @param templateCode    短信模板
     * @param templateParam   模板参数
     * @return
     */
    public static AjaxResult sendSms(String accessKeyId, String accessKeySecret, String signName, String mobile, String templateCode, Map<String, Object> templateParam) {
        if (!isMobile(mobile)) {
            return AjaxResult.error("短信发送失败，手机号码不正确");
        }

        // 阿里云短信服务提供的模板代码，此代码是由自己创建的模板得到的
        if ("".equals(templateCode)) {
            return AjaxResult.error("短信服务提供的模板代码不能为空");
        }

        DefaultProfile profile = DefaultProfile.getProfile("default", accessKeyId, accessKeySecret);
        IAcsClient client = new DefaultAcsClient(profile);


        CommonRequest request = new CommonRequest();
        request.setSysMethod(MethodType.POST);
        request.setSysDomain("dysmsapi.aliyuncs.com");
        request.setSysVersion("2017-05-25");
        request.setSysAction("SendSms");
        // 要发送到的手机号
        request.putQueryParameter("PhoneNumbers", mobile);
        // 短信签名名称。请在控制台签名管理页面签名名称一列查看。 说明 必须是已添加、并通过审核的短信签名。
        request.putQueryParameter("SignName", signName);
        // 短信模板ID。请在控制台模板管理页面模板CODE一列查看。 说明 必须是已添加、并通过审核的短信签名；且发送国际/港澳台消息时，请使用国际/港澳台短信模版。
        request.putQueryParameter("TemplateCode", templateCode);
        // 短信模板变量对应的实际值，JSON格式。 说明 如果JSON中需要带换行符，请参照标准的JSON协议处理。
        request.putQueryParameter("TemplateParam", JSONObject.toJSONString(templateParam));

        String data = null;
        try {
            CommonResponse response = client.getCommonResponse(request);
            System.out.println("=========================" + response);
            data = response.getData();
        } catch (ClientException e) {
            log.error("短信发送失败：" + e.getMessage(), e);
            return AjaxResult.error("短信发送失败：" + e.getMessage());
        }

        if (data == null) {
            return AjaxResult.error("短信发送失败");
        }

        return AjaxResult.success("短信发送成功",data);
    }

    public static AjaxResult sendSms(String mobile, String templateCode, Map<String, Object> templateParam) {
        return sendSms(ACCESS_KEY_ID, ACCESS_SECRET, SIGN_NAME, mobile, templateCode, templateParam);
    }

    public static boolean isSuccessSendAliyunSms(String mobile, String templateCode, Map<String, Object> templateParam) {
        return isSuccessSendAliyunSms(ACCESS_KEY_ID, ACCESS_SECRET, SIGN_NAME, mobile, templateCode, templateParam);
    }

    public static boolean isSuccessSendAliyunSms(String accessKeyId, String accessKeySecret, String signName, String mobile, String templateCode, Map<String, Object> templateParam) {
        boolean bl = false;
        AjaxResult ajaxResult = sendSms(accessKeyId, accessKeySecret, signName, mobile, templateCode, templateParam);
        if (ajaxResult.get("data") == null) {
            log.error("短信发送失败，返回信息为空");
            return false;
        }

        try {
            // 解析JSON字符串
            JSONObject jsonObject = JSONObject.parseObject((String) ajaxResult.get("data"));
            String message = jsonObject.getString("Message");
            String requestId = jsonObject.getString("RequestId");
            String bizId = "";
            // 当发送失败时不会有回执id，防止json解析报错，如返回结果{"Message":"触发分钟级流控Permits:1","RequestId":"FE686A34-6021-44A4-B034-A5F7792D7B39","Code":"isv.BUSINESS_LIMIT_CONTROL"}
            if (MESSAGE_OK.equals(message)) {
                bizId = jsonObject.getString("BizId");
            }
            String backCode = jsonObject.getString("Code");
            boolean condition = false;
            // 如果需要添加回传的短信消息到数据库，则把isSuccessSendAliyunSms方法独立出来
            if (condition) {
                log.error("添加短信回传数据" + bizId + requestId + "失败！");
            }
            if (MESSAGE_OK.equals(backCode)) {
                bl = true;
            } else {
                log.error("短信发送失败!");
            }
        } catch (Exception e) {
            log.error("解析JSON字符串失败!" + e.getMessage(), e);
        }

        return bl;
    }

    /**
     * 验证是否是正确的手机
     *
     * @param mobile 手机号码
     * @return
     */
    private static boolean isMobile(String mobile) {
        boolean bl = false;
        String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$";
        if (mobile.length() != 11) {
            bl = false;
        } else {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(mobile);
            boolean isMatch = m.matches();
            bl = isMatch;
        }
        return bl;
    }

    public static void main(String[] args) {
        Map<String, Object> templateParam = new HashMap<>();
        templateParam.put("name", "游生");
        templateParam.put("job_no", "GD202001");
        // 采用默认key,密钥发送
        AliyunSmsUtils.sendSms("18970868791", "SMS_187746645", templateParam);
        // 发送并验证是否发否成功
        AliyunSmsUtils.isSuccessSendAliyunSms("18970868791", "SMS_187746645", templateParam);
    }
}
