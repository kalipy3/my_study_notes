package com.ruoyi.common.constant;

/**
 * 常量
 *
 * @author youyong
 * @date 2020/11/14 0014
 */
public interface HswConst {


}
